import type { GameState } from './model';
import type { GameCommand, SimulationPort, SimulationSnapshot } from './contracts';
import type { GameEngine } from '../core/GameEngine';
import { queueBuilding } from './systems/buildingSystem';
import { issueAttack, issueAttackBase, issueMove, holdSelected } from './systems/combatSystem';
import { queueUnit } from './systems/trainingSystem';
import { normalizeEconomyState } from './systems/economySystem';

/**
 * Owns the authoritative single-player state.
 * Commands are translated here; presentation layers never mutate game state.
 */
export class SimulationRuntime implements SimulationPort {
  private state: GameState;
  private listeners = new Set<(snapshot: SimulationSnapshot) => void>();

  constructor(private readonly engine: GameEngine, initialState: GameState) {
    this.state = normalizeEconomyState(initialState);
  }

  getSnapshot(): SimulationSnapshot {
    return this.state;
  }

  subscribe(listener: (snapshot: SimulationSnapshot) => void): () => void {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  }

  dispatch(command: GameCommand): void {
    if (this.state.outcome !== 'playing' && command.type !== 'units/select') return;
    const selected = 'unitIds' in command ? new Set(command.unitIds) : new Set<number>();
    let next = this.state;

    switch (command.type) {
      case 'units/select':
        next = {
          ...next,
          units: next.units.map(unit => {
            if (unit.faction !== 'player' || unit.hp <= 0) return unit;
            const shouldSelect = selected.has(unit.id);
            return { ...unit, selected: command.additive ? (shouldSelect ? !unit.selected : unit.selected) : shouldSelect };
          }),
        };
        break;
      case 'units/move': {
        const chosen = next.units.map(unit => ({ ...unit, selected: unit.faction === 'player' && selected.has(unit.id) }));
        next = issueMove({ ...next, units: chosen }, command.x, command.z);
        break;
      }
      case 'units/attack': {
        const chosen = next.units.map(unit => ({ ...unit, selected: unit.faction === 'player' && selected.has(unit.id) }));
        next = issueAttack({ ...next, units: chosen }, command.targetUnitId);
        break;
      }
      case 'units/attack-base': {
        const chosen = next.units.map(unit => ({ ...unit, selected: unit.faction === 'player' && selected.has(unit.id) }));
        next = issueAttackBase({ ...next, units: chosen });
        break;
      }
      case 'units/set-rally-point': {
        const x=Math.max(-38,Math.min(38,command.x));
        const z=Math.max(-28,Math.min(28,command.z));
        next={...next,rallyPoint:{x,z},message:'RALLY POINT DESIGNATED'};
        break;
      }
      case 'units/clear-rally-point':
        next={...next,rallyPoint:null,message:'RALLY POINT CLEARED'};
        break;
      case 'units/hold': {
        const chosen = next.units.map(unit => ({ ...unit, selected: unit.faction === 'player' && selected.has(unit.id) }));
        next = holdSelected({ ...next, units: chosen });
        break;
      }
      case 'buildings/queue':
        next = queueBuilding(next, command.buildingKind);
        break;
      case 'units/train':
        next = queueUnit(next, command.unitKind);
        break;
    }

    if (next !== this.state) this.publish(next);
  }

  step(deltaSeconds: number): void {
    const next = this.engine.step(this.state, deltaSeconds);
    if (next !== this.state) this.publish(next);
  }

  /** Legacy and current saves are normalized at the simulation boundary. */
  restore(snapshot: GameState): void {
    this.publish(normalizeEconomyState(snapshot));
  }

  private publish(next: GameState): void {
    this.state = next;
    for (const listener of this.listeners) listener(this.state);
  }
}
