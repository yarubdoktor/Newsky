# IRON FRONT 0.6: status against the development brief

This document distinguishes working implementation from future production work. The delivered game is a complete one-sector solo skirmish loop with paid opposing economies, not a finished AAA strategy title. Version 0.6 adds the mine economy: a rich mine per faction with a dedicated haul road, mine workers and haul trucks shuttling finite mixed resources to each HQ, plus a rally-point bug fix. Version 0.5.2 removed the 3D renderer entirely (2D-only tactical map, contextual building cards, training strip, select-all, rally points, unit separation). Version 0.5 added the supply truck, destructible wall segments, direct structure targeting, drag-rectangle selection, formations, fuel logistics, a collapsible command HUD, a much larger battlefield, and an opponent that builds up but holds fire until the first engagement.

## Implemented and integrated

| Area | Delivered behavior |
|---|---|
| Entry and UI | Existing React entry remains connected; Arabic/English briefing, biome and difficulty choices, instructions, tabs, pause, speed, restart and results |
| World | Enlarged 2D tactical map (roughly double the earlier span) with the enemy base far away, tappable buildings with contextual cards, climate colors, rocky mid-field cover, two bases, three contested central depots and two faction mines with dashed haul roads and depletion labels (3D renderer removed in 0.5.2) |
| Climate | Forest/desert/snow variants, snow/rain particles, timed lighting cycle; snow and desert alter ground speed |
| Building kinds | HQ, barracks, armored factory, vehicle works, airfield, ammo depot, fuel refinery/depot, power, research, watchtower, missile defense, barrier section, command relay, hospital |
| Building rules | Paid costs and timers, bounded slots/limits, health and removal on destruction, paid level upgrades, production prerequisites |
| Unit kinds | Infantry, sniper, combat engineer, anti-armor, recon vehicle, main tank, heavy tank, armored vehicle, artillery, attack helicopter, recon drone, supply truck, mine worker and haul truck |
| Unit rules | Health, armor, speed, vision, range, damage, individual cooldown, ammo use, training cost/time, prerequisite and queue/army caps |
| Commands | Single selection, drag-rectangle multi-select, Shift-add, roster multi-select, select-all, line/wedge/flank formations for group movement, local defense, targeted unit attack, direct attacks on specific enemy structures, attack HQ, hold and retreat |
| Navigation | Fixed-grid A* around buildings and two rock outcrops; aerial units use direct paths |
| Combat | Simultaneous damage/cooldown, range-based deterministic damage reduction, armor and anti-armor penetration, forest infantry cover modifier, destructible structures |
| Detection | Units outside sensor coverage are hidden from the field and tactical map; research and recon units improve vision |
| Economy | Steel, fuel, power, ammunition; finite industrial reserves, building-based production, finite capturable steel depots, symmetrical salvage rewards, vehicle fuel consumption with half-speed dry-pool crawling, supply-truck ammunition/fuel transfer, and since 0.6 a rich finite mine per faction worked by mine workers (50S/25F/20P/20A per trip) and haul trucks (300S/150F/100P/100A per trip) shuttling along a dedicated haul road to the HQ |
| Opponent | Independent distant base, resources, paid building/training/research, finite reserve, ammunition use, expand/defend/attack/rebuild states, trains up to two mine workers for its own economy; never initiates hostilities before the first cross-faction engagement, then launches waves by readiness and difficulty |
| Difficulty | Changes AI decision frequency and assault cadence, not hidden resource grants, free units or stat multipliers |
| Research | Five timed paid technologies: weapons, armor, mobility, industry, reconnaissance |
| Support | Hospital recovery, engineer teammate recovery, paid HQ repair, level-scaled defensive fire |
| Persistence | JSON file save/load including both sides, orders, buildings, training, research, settings, capture zones and mine pools/harvest jobs |
| Ending | Destroy enemy HQ to win; friendly HQ destruction causes defeat; terminal simulation freezes and restart is available |
| Presentation | Distinct procedural silhouettes by role, health bars, tracers/hit flashes, synthesized shot/explosion tones, HUD/minimap/event log, collapsible full-screen-map command HUD |
| Delivery | Offline single HTML, complete TypeScript source, lockfile, automated tests, documentation and third-party notices |

## Implemented in simplified form

- **Graphics:** low-poly procedural geometry, not photorealistic authored AAA models, skeletal animations or cinematics.
- **Maps:** three climate/terrain variants of the same tactical sector layout, not a vast open world or three independent campaign maps.
- **Cover and accuracy:** deterministic damage modifiers, not line-of-sight raycasts, ballistic simulation or a full positional cover system.
- **Fog of war:** sensor-based hidden enemy units and structures, not a persistent explored-terrain/fog texture.
- **AI:** an inspectable local rule/state machine, not learning AI or a full tactical planner. It uses paid production and can save for infrastructure, defend visible threats and rebuild lost production.
- **Air units:** attack helicopters and armed recon drones fly over obstacles; there is no landing, refueling, passenger transport or realistic air/ground targeting matrix.
- **Health:** headquarters use a separate 0–100 health track. Other structures use their own HP; levels improve durability, economy, production speed or defensive fire by role.
- **Fortification:** ten individually destructible wall-segment buildings fill a perimeter ring around the friendly base (with a gate gap); corner towers remain decoration only.
- **Audio:** synthesized combat cues, not recorded vehicle engines, spatial battle ambience, voice acting or music.
- **Difficulty:** three meaningful planning presets, not extensive competitive balance testing.
- **Performance:** adaptive shadow disabling and tactical-mode fallback; no hardware-GPU performance guarantee or tested native-device matrix.

## Not yet implemented

- Narrative campaign, persistent mission progression, scripted mission chains or campaign selection.
- Multiplayer, network synchronization, alliances or multiple independent opponents.
- Realistic cities, industrial districts, deformable terrain, building rubble, volumetric smoke, fire propagation or full weather simulation.
- A military-currency/credits resource and a separate industrial-materials currency; this release uses four resource counters plus finite industrial stock.
- Special forces, light/advanced tank subtypes, rocket artillery, transport helicopters or fighter jets. (Supply trucks are implemented since 0.5; the mine worker and haul truck are implemented since 0.6.)
- Passenger loading/unloading, transport helicopters or maintenance attrition. (Supply lines, unit fuel consumption, supply trucks and drag-box selection are implemented since 0.5.)
- Customizable key binding, full accessibility settings or a complete settings menu.
- Tech-tree dependencies between multiple tiers, beyond prerequisite structures and five one-level timed technologies.
- Worker-based economy with fully dynamic navmesh, unit-unit collision avoidance beyond the current separation pass, or multithreaded ECS/Web Workers. (The mine/worker/haul-truck resource economy is implemented since 0.6; see the harvest system.)
- Cloud/automatic saves, compatibility with old v3 localStorage saves or a backend.
- Windows EXE, Android APK, iOS app, controller support, commercial certification or production anti-cheat.

## Suggested next development sequence

- Replace the static perimeter with individual destructible, navigable fortification segments and add direct building-target commands. (Done in 0.5.)
- Add separation steering and richer navigation/terrain/line-of-sight tests before increasing army or map size. (Separation pass done in 0.5.2; terrain/line-of-sight remain.)
- Expand the opponent's scouting, production composition and strategic objectives, then benchmark complete matches.
- Build a campaign and two genuinely different layouts using the verified simulation core.
- Add authored licensed vehicle/infantry assets, animations, spatial audio and effects with a clear mobile GPU budget.
- Introduce multiplayer only after defining deterministic authority, save/version migration and synchronization rules.
