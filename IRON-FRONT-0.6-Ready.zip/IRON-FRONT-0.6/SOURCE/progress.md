Original prompt: IRON-FRONTهذا اسم لعبتي الي عم اطورها https://github.com/yarubdoktor/Yarub.git وهاد رابط مستودعي الي فيه اللعبه هل يمكنك جلب اللعبة وتكملة بناءها وبس تنتهي ارسلها لي ملف،زيب جاهز

## Scope
Continue the existing React/Three.js IRON-FRONT folder at upstream ea42b1a. Leave separate Godot ZIP history unchanged. Deliver a portable offline browser build plus complete editable source, not a Windows EXE or APK.

## Baseline
Inspected repository, source modules and original browser rendering. Dependencies installed. Original main flows documented in FLOWS.md.

## Implementation milestone
Version 0.4 is a complete single-player skirmish first release, not a claim of finished AAA commercial production. Preserve original procedural 3D art and military palette. Add actual base combat, recruitment, working support buildings, Arabic/English controls, validated file saves, accessible 2D fallback and offline single-file build.

## Expanded user brief
The user supplied an extensive AAA RTS plan and explicitly allowed a complete playable first version followed by incremental expansion. Priority shifted from free-spawn waves to a fair opponent using the same paid construction, production, research and ammunition systems.

## Implemented
Eleven unit types, fourteen structure kinds including HQ, finite stock and capture depots, A*, vision, group orders, simultaneous combat/cooldowns, armor/cover/range, destructible production, AI state machine, timed research, building levels, repair/healing, weather/lighting, synthesized audio, localized HUD and versioned validated save files. Source remains connected through original main.tsx.

## Verification so far
27 automated simulation tests pass. TypeScript and portable build pass. npm audit reports zero vulnerabilities for the installed lockfile. Real browser controls exercised for paid construction and recruitment, group movement, hold, HQ attack, pause/resume, speed, language, timed research, save download/import/rejection, help, restart cancellation and both result states. Desktop and 375px screenshots reviewed.

## Performance note
The test environment uses software WebGL and produces low 3D FPS. The game disables shadows first, then automatically switches to the playable tactical map after sustained low FPS. Hardware-accelerated 3D and physical mobile devices are not certified by this test.

## Remaining work
See FEATURE-STATUS.md for precise limitations and a future sequence. The portable artifact was verified offline, ZIP integrity passed and the extracted source passed clean installation, all 27 tests and build. Delivery is the explicitly requested downloadable archive, not a public website. No remote git push is authorized or performed.

## Version 0.5 milestone

Phase 1 of the completion plan plus the requested mobile-commander UX, in sequence:

- Twelfth unit kind: the supply truck (cargo of 150 ammunition and 100 fuel) transferring 2 ammo/s and 1.5 fuel/s near friendly frontline units and the HQ.
- Vehicle fuel consumption during movement with half-speed crawling on a dry pool; navigation throttle and combat burn wired to the faction pools.
- Ten individually destructible perimeter wall segments on a ring with a gate gap; corner towers are decoration only.
- Direct attack orders against specific enemy structures (walls included), clearing when the target falls; HQ ids route to the existing HQ order.
- Drag-rectangle multi-select on the 3D field and the 2D map, with Shift additive selection.
- Line, wedge and flank formations for group movement destinations.
- Collapsible command HUD: fold the bottom panel away for a full-screen map and back, with a quick pause/speed bar while folded; default folded on phones.
- Enlarged battlefield: navigation grid roughly doubled, enemy base moved far away (HQ at 58,-4), three contested central depots, added mid-field rock cover, extended terrain/road/mountains/trees, and a free camera (right-drag orbit, middle-drag pan, wheel zoom on desktop; one-finger rotate and two-finger pan/zoom on touch).
- Contact rule: the first cross-faction engagement flips a persisted contact flag; the AI builds, researches and expands but never attacks before it, then launches assault waves by army readiness and difficulty. The old forced tick-15 probe attack was removed.
- Save format stays version 4 with the new contact field optional, so 0.4 saves still load.
- 38 automated tests (11 new), TypeScript and the single-file build pass; phone-viewport browser QA on the deployed preview covered briefing, folded-HUD 2D map, 60 FPS 3D scene, free zoom and panel open/close.

## Version 0.5.2 milestone

The 3D renderer was removed entirely at the user's request; the game is 2D-only:

- Deleted `FortressScene.tsx` and the `three`/`@react-three` dependency tree, halving the bundle to about 1.07 MB.
- Tappable buildings on the 2D map with a contextual building card: click a structure to see its training, upgrade and repair actions instead of hunting through panel lists.
- Always-visible training strip with progress bars and remaining time, select-all in the collapsed quick bar, and a rally-point system: reinforcements march from the producer to the flag with formation spread; a unit-separation pass stops units from stacking.
- Fixed the rally bug where `asPlayer` mirrored the player's rally point, which had marched enemy reinforcements into the player's base and tripped the contact flag.

## Version 0.6 milestone

The mine economy, as requested:

- Each faction owns a rich mine (player at (6,-11), enemy at (40,11)) with a finite mixed pool of 8000 steel, 4000 fuel, 2500 power and 3000 ammo.
- Thirteenth and fourteenth unit kinds: the mine worker (50S/0F/5P/0A, 5 s, trained from the HQ) and the haul truck (160S/40F/15P/0A, 8 s, from the vehicle factory).
- Dedicated dashed haul road drawn from each HQ to its mine on the tactical map, with a pickaxe mine icon and a live percentage label of the remaining deposit.
- Harvest cycle (`harvestSystem.ts`): walk the road to the mine, mine for 3.5 s (worker) or 2.5 s (hauler), carry a mixed bundle (worker 50S/25F/20P/20A, hauler 300S/150F/100P/100A) back to the HQ, deposit into the faction pool, then return; the mine depletes and both icons track it.
- The AI hires up to two workers for its own mine, so the enemy economy also runs on real haul income.
- Save format stays version 4: `harvest` on units and the `mines` array are optional/validated additions, so older saves still load.
- 41 automated tests (new harvest-cycle test plus the fourteen-unit prerequisites test), TypeScript and the single-file build pass; phone-viewport cloud-browser QA confirmed the mine icons, both haul roads, worker training from the HQ card and live resource growth from deposits.
