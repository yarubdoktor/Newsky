import type { GameState, Unit } from './types';
import { UNIT_SPECS } from './unitSystem';
export type Point={x:number;z:number};
const SIZE=2,MIN_X=-30,MIN_Z=-26,WIDTH=56,HEIGHT=27;
const key=(x:number,z:number)=>z*WIDTH+x;
const world=(index:number):Point=>({x:MIN_X+(index%WIDTH)*SIZE,z:MIN_Z+Math.floor(index/WIDTH)*SIZE});
const cell=(p:Point)=>({x:Math.max(0,Math.min(WIDTH-1,Math.round((p.x-MIN_X)/SIZE))),
  z:Math.max(0,Math.min(HEIGHT-1,Math.round((p.z-MIN_Z)/SIZE)))});
/** Rocky outcrops double as cover on the long no-man's-land between the two bases. */
export const rocks=[{x:4,z:-2,r:1.9},{x:7,z:7,r:1.5},{x:30,z:-9,r:2.2},{x:34,z:8,r:1.8},
  {x:41,z:-6,r:2},{x:26,z:2,r:1.6},{x:47,z:9,r:1.7},{x:50,z:-12,r:2.1}];
export function blocked(state:GameState,p:Point):boolean {
  if(rocks.some(r=>Math.hypot(p.x-r.x,p.z-r.z)<r.r+.4))return true;
  return [...state.buildings,...state.opponent.buildings].some(b=>
    Math.abs(p.x-b.x)<(b.kind==='hq'?2:1.3)&&Math.abs(p.z-b.z)<(b.kind==='hq'?1.9:1.3));
}
/** Bounded A* with four-neighbor routing, avoiding structures and rocky outcrops. */
export function findPath(state:GameState,unit:Unit,target:Point):Point[] {
  if(UNIT_SPECS[unit.kind].air)return [target];
  const start=cell(unit),end=cell(target),startKey=key(start.x,start.z),endKey=key(end.x,end.z);
  const open=new Set([startKey]),came=new Map<number,number>(),g=new Map([[startKey,0]]);
  const heuristic=(index:number)=>Math.abs(index%WIDTH-end.x)+Math.abs(Math.floor(index/WIDTH)-end.z);
  let closest=startKey;
  while(open.size){
    let current=-1,best=Infinity;
    for(const i of open){const score=(g.get(i)??Infinity)+heuristic(i);if(score<best){best=score;current=i;}}
    if(heuristic(current)<heuristic(closest))closest=current;
    if(current===endKey){closest=current;break;}
    open.delete(current);
    const x=current%WIDTH,z=Math.floor(current/WIDTH);
    for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+dx,nz=z+dz;if(nx<0||nx>=WIDTH||nz<0||nz>=HEIGHT)continue;
      const next=key(nx,nz);if(next!==startKey&&blocked(state,world(next)))continue;
      const score=(g.get(current)??Infinity)+1;
      if(score<(g.get(next)??Infinity)){came.set(next,current);g.set(next,score);open.add(next);}
    }
  }
  const path:Point[]=[];let cursor=closest;
  while(cursor!==startKey){path.unshift(world(cursor));const previous=came.get(cursor);if(previous===undefined)break;cursor=previous;}
  if(closest===endKey&&!blocked(state,target))path.push(target);
  return path;
}
export function advanceMovement(state:GameState,unit:Unit,target:Point,dt:number):Unit {
  let path=unit.path;
  if(path.length===0||Math.hypot(path[path.length-1].x-target.x,path[path.length-1].z-target.z)>2)
    path=findPath(state,unit,target);
  while(path.length&&Math.hypot(path[0].x-unit.x,path[0].z-unit.z)<.12)path=path.slice(1);
  if(!path.length)return {...unit,path,order:unit.order==='move'?'idle':unit.order};
  const p=path[0],dx=p.x-unit.x,dz=p.z-unit.z,d=Math.hypot(dx,dz);
  const technologies=unit.faction==='player'?state.technologies:state.opponent.technologies;
  const terrain=state.biome==='snow'?.82:state.biome==='desert'?.92:1;
  const fuelPool=unit.faction==='player'?state.resources.fuel:state.opponent.resources.fuel;
  // Ground vehicles crawl at half speed when the faction fuel pool is dry.
  const throttle=UNIT_SPECS[unit.kind].air||unit.armor<2?1:fuelPool>0?1:.5;
  const distance=Math.min(d,unit.speed*(1+technologies.mobility*.2)*(UNIT_SPECS[unit.kind].air?1:terrain)*throttle*dt);
  return {...unit,path,x:unit.x+(d?dx/d*distance:0),z:unit.z+(d?dz/d*distance:0)};
}
