import { useRef, useState } from 'react';
import type { GameState } from './types';
import { BUILDING_LABELS } from './catalog';
import { useId } from 'react';
import { visibleTo } from './visibility';
import { rocks } from './navigation';

type Props={state:GameState;onSelect:(id:number,enemy:boolean,multi:boolean)=>void;
  onMoveOrder:(x:number,z:number)=>void;onAttackHQ:()=>void;onAttackBuilding:(id:string)=>void;
  onRectSelect:(x1:number,z1:number,x2:number,z2:number,additive:boolean)=>void;moveMode:boolean;rallyMode?:boolean;
  onSetRally:(x:number,z:number)=>void;
  onSelectBuilding:(id:string)=>void;selectedBuildingId?:string|null};
/** Fictional local battlefield coordinates, not a geographical map. */
export function TacticalMap({state,onSelect,onMoveOrder,onAttackHQ,onAttackBuilding,onRectSelect,moveMode,rallyMode,onSetRally,onSelectBuilding,selectedBuildingId}:Props) {
  const pattern=useId();
  const svgRef=useRef<SVGSVGElement|null>(null);
  const drag=useRef<{x1:number;z1:number;x2:number;z2:number}|null>(null);
  const [rect,setRect]=useState<{x1:number;z1:number;x2:number;z2:number}|null>(null);
  const toWorld=(clientX:number,clientY:number)=>{
    const svg=svgRef.current;if(!svg)return{x:0,z:0};
    const p=svg.createSVGPoint();p.x=clientX;p.y=clientY;
    const matrix=svg.getScreenCTM();if(!matrix)return{x:0,z:0};
    return p.matrixTransform(matrix.inverse());
  };
  return <svg ref={svgRef} className="tactical-map" viewBox="-28 -26 106 52" aria-label="Tactical battlefield"
    style={{cursor:moveMode||rallyMode?'crosshair':'default'}}
    onPointerDown={e=>{
      if(moveMode||e.button!==0)return;
      if((e.target as Element).closest('[data-clickable]'))return;
      const p=toWorld(e.clientX,e.clientY);
      drag.current={x1:p.x,z1:p.z,x2:p.x,z2:p.z};
    }}
    onPointerMove={e=>{
      if(!drag.current)return;
      const p=toWorld(e.clientX,e.clientY);
      drag.current={...drag.current,x2:p.x,z2:p.z};setRect({...drag.current});
    }}
    onPointerUp={e=>{
      const box=drag.current;drag.current=null;setRect(null);
      if(!box)return;
      if(Math.abs(box.x2-box.x1)<.4&&Math.abs(box.z2-box.z1)<.4)return;
      onRectSelect(box.x1,box.z1,box.x2,box.z2,e.shiftKey);
    }}
    onClick={e=>{
      if(moveMode){const local=toWorld(e.clientX,e.clientY);onMoveOrder(local.x,local.z);}
      else if(rallyMode){const local=toWorld(e.clientX,e.clientY);onSetRally(local.x,local.z);}
    }}>
    <defs><pattern id={pattern} width="2" height="2" patternUnits="userSpaceOnUse">
      <path d="M 2 0 H 0 V 2" fill="none" stroke="#6f8774" strokeWidth=".035"/>
    </pattern></defs>
    <rect x="-28" y="-26" width="106" height="52" fill={state.biome==='snow'?'#6f8881':state.biome==='desert'?'#796d50':'#25372f'}/>
    <rect x="-28" y="-26" width="106" height="52" fill={`url(#${pattern})`}/>
    <path d="M-24-3H-1V1 M-1 7V12H-24V-3 M70 3H47V-12H70V3 M47-6V-9" stroke="#acb7a9" strokeWidth=".45" fill="none"/>
    <path d="M-3 4H58V-4" stroke="#96a185" strokeWidth=".8" opacity=".15" fill="none"/>
    {/* Friendly buildings are tappable: they open their own contextual training/upgrade card. */}
    {state.buildings.map(b=>{
      const chosen=selectedBuildingId===b.id,constructing=b.status==='constructing';
      return <g key={b.id} data-clickable role="button" tabIndex={0} aria-label={BUILDING_LABELS[b.kind]}
        style={{cursor:'pointer',opacity:constructing?.75:1}}
        onClick={e=>{e.stopPropagation();onSelectBuilding(b.id);}}
        onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelectBuilding(b.id);}}}>
        <title>{BUILDING_LABELS[b.kind]}</title>
        {chosen&&<rect x={b.x-1.7} y={b.z-1.4} width="3.4" height="2.8" fill="none" stroke="#e8cb7f" strokeWidth=".22" rx=".3" className="bld-select-ring"/>}
        <rect x={b.x-1.3} y={b.z-1} width="2.6" height="2" fill={b.kind==='hq'?'#d5c18e':b.kind==='wall'?'#8a9a90':'#7d9b86'}
          stroke={constructing?'#e8cb7f':'#d1dbc8'} strokeWidth=".1" strokeDasharray={constructing?'.25 .15':undefined} rx=".15"/>
        <text x={b.x} y={b.z+.3} textAnchor="middle" fill="#101c17" fontSize={b.kind==='wall'?".55":".8"} fontWeight="bold">{b.kind==='hq'?'HQ':b.kind==='wall'?'W':b.kind.slice(0,3).toUpperCase()}</text>
        {b.hp<b.maxHp&&<path d={`M${b.x-1.2} ${b.z+1.25}h${2.4*b.hp/b.maxHp}`} stroke="#a9d8ab" strokeWidth=".14"/>}
        {constructing&&<text x={b.x} y={b.z-1.35} textAnchor="middle" fontSize=".55" fill="#e8cb7f">{Math.round(100-100*b.remaining/b.buildSeconds)}%</text>}
      </g>;})}
    {state.opponent.buildings.filter(b=>b.kind!=='hq'&&visibleTo(state,'player',b)).map(b=><g key={b.id} data-clickable
      style={{cursor:'pointer'}} role="button" tabIndex={0} aria-label={`Attack ${BUILDING_LABELS[b.kind]}`}
      onClick={e=>{e.stopPropagation();onAttackBuilding(b.id);}}
      onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onAttackBuilding(b.id);}}}>
      <rect x={b.x-1.3} y={b.z-1} width="2.6" height="2" fill="#b16e5d" stroke="#e7a094" strokeWidth=".1"/>
      <text x={b.x} y={b.z+.3} textAnchor="middle" fontSize={b.kind==='wall'?".5":".75"} fill="#fff2df">{b.kind==='wall'?'W':b.kind.slice(0,3).toUpperCase()}</text>
    </g>)}
    {rocks.map((r,i)=><circle key={i} cx={r.x} cy={r.z} r={r.r} fill="#687c6b" stroke="#9bada0" strokeWidth=".1"/>)}
    {/* Rich mines with a dedicated haul road running to each headquarters. */}
    {state.mines.map(m=>{
      const total=m.steel+m.fuel+m.power+m.ammo;
      const road=m.faction==='player'?'M-1 4Q2 -4 6 -11':'M46 -4Q43 4 40 11';
      return <g key={m.faction} pointerEvents="none">
        <path d={road} stroke="#c9b97e" strokeWidth=".22" strokeDasharray=".9 .55" opacity=".5" fill="none"/>
        <circle cx={m.x} cy={m.z} r="1.7" fill="#4a4038" stroke="#e8cb7f" strokeWidth=".16"/>
        <path d={`M${m.x-.55} ${m.z+.45}l1-1.4M${m.x+.55} ${m.z+.45}l-1-1.4`} stroke="#e8cb7f" strokeWidth=".14"/>
        <text x={m.x} y={m.z+2.8} textAnchor="middle" fontSize=".7" fill="#c9b97e">{Math.round(100*total/17500)}%</text>
      </g>;})}
    {state.zones.map(z=><g key={z.id}><circle cx={z.x} cy={z.z} r="2.5" fill="none" stroke={z.owner==='player'?'#a8dfb6':z.owner==='enemy'?'#ef9b85':'#dcc78e'} strokeWidth=".16"/>
      <text x={z.x} y={z.z+.3} textAnchor="middle" fontSize="1" fill="#eee4c5">{Math.round(Math.abs(z.progress)*10)}%</text></g>)}
    <g data-clickable role="button" tabIndex={0} aria-label="Attack hostile headquarters" onClick={e=>{e.stopPropagation();onAttackHQ();}}
      onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onAttackHQ();}}}>
      <rect x="55.5" y="-6" width="5" height="4" fill="#9b5046" stroke="#e7a094" strokeWidth=".15"/>
      <text x="58" y="-3.6" textAnchor="middle" fill="#fff2df" fontSize="1">HQ</text>
    </g>
    {/* Rally flag: fresh reinforcements march here instead of stacking at the barracks. */}
    <g className={`rally-flag${rallyMode?' armed':''}`} pointerEvents="none">
      <circle cx={state.rally.x} cy={state.rally.z} r=".45" fill="#e8cb7f"/>
      <circle cx={state.rally.x} cy={state.rally.z} r="1.1" fill="none" stroke="#e8cb7f" strokeWidth=".1" strokeDasharray=".2 .2"/>
      <path d={`M${state.rally.x} ${state.rally.z}V${state.rally.z-2.4}`} stroke="#e8cb7f" strokeWidth=".14"/>
      <path d={`M${state.rally.x} ${state.rally.z-2.4}h1.7v.9h-1.7z`} fill="#e8cb7f"/>
    </g>
    {state.units.filter(u=>u.faction==='player'||visibleTo(state,'player',u)).map(u=><g key={u.id} data-clickable role="button" tabIndex={0} aria-label={`${u.faction} ${u.kind} ${u.id}`}
      style={{cursor:'pointer'}}
      onClick={e=>{e.stopPropagation();onSelect(u.id,u.faction==='enemy',e.shiftKey);}}
      onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(u.id,u.faction==='enemy',e.shiftKey);}}}>
      <circle cx={u.x} cy={u.z} r="1.1" fill="transparent"/>
      {u.selected&&<circle cx={u.x} cy={u.z} r=".9" fill="none" stroke="#82e2d2" strokeWidth=".16"/>}
      {u.kind==='tank'?<rect x={u.x-.55} y={u.z-.7} width="1.1" height="1.4" rx=".16" fill={u.faction==='enemy'?'#ed8e7b':'#c6d5a7'}/>
        :<circle cx={u.x} cy={u.z} r=".4" fill={u.faction==='enemy'?'#ed8e7b':'#c6d5a7'}/>}
      <path d={`M${u.x-.6} ${u.z-1.1}h${1.2*u.hp/u.maxHp}`} stroke={u.faction==='enemy'?'#ed8e7b':'#a4dfb2'} strokeWidth=".14"/>
      {u.kind==='supply'&&u.cargo&&<path d={`M${u.x-.6} ${u.z-1.5}h${1.2*(u.cargo.ammo+u.cargo.fuel)/250}`} stroke="#e8cb7f" strokeWidth=".12"/>}
    </g>)}
    {state.shots.map(s=><line key={s.id} x1={s.x} y1={s.z} x2={s.toX} y2={s.toZ} stroke={s.faction==='player'?'#f1d58b':'#ed8e7b'} strokeWidth=".12"/>)}
    {rect&&<rect x={Math.min(rect.x1,rect.x2)} y={Math.min(rect.z1,rect.z2)}
      width={Math.abs(rect.x2-rect.x1)} height={Math.abs(rect.z2-rect.z1)}
      fill="rgba(133,226,209,.12)" stroke="#85e2d1" strokeWidth=".15" pointerEvents="none"/>}
    <text x="-26" y="-22" fontSize="1" fill="#a4baab">N ↑</text>
  </svg>;
}
