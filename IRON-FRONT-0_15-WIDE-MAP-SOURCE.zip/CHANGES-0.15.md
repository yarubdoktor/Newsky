# 0.15 – Wide map

- Battlefield enlarged from 104×52 to 154×80 world units (≈ 2.2× the area). Enemy half pushed 40 units east; depth grew from ±26 to ±40.
- New `src/game/mapConfig.ts` holds the map size, mirror axis and river position.
- River now runs the full depth with **five** bridges (z = −26, −12, 0, 12, 26); mountain walls guard the outer fords.
- 4 impassable lakes, 15 extra rock outcrops, 2 extra capture zones (flank bridges).
- Prettier terrain: ground colour patches, tree groves, instanced grass tufts, banked river, snow-capped mountains, dirt roads to every bridge, mountain skyline on all four edges, dark skirt past the edge.
- Radar minimap, camera bounds, A* grid, AI mirror, enemy HQ (98,−4), save-file coordinate limits all updated.
- Tests updated to the new coordinates (not run here: no node_modules / network).
