# IRON FRONT 0.4: verification report

This release continues the original repository's `IRON-FRONT` React application. Tests verify an integrated single-sector skirmish release, not completion of every feature in the AAA brief.

## Automated checks

- `npm test`: 27 tests passed, zero failures.
- `npm run build`: TypeScript project check and Vite production build passed.
- `npm install --package-lock-only`: lockfile synchronized with version 0.4.0; audit reported zero known vulnerabilities at the time of this run.
- Production output: one self-contained `dist/index.html`, approximately 1.93 MB before ZIP compression. Fonts and application assets are embedded.
- Two nonfatal Rollup warnings concern dependency comment annotations in Zod. They do not indicate TypeScript errors or a failed build.

## Simulation coverage

- Fresh independent missions and equal initial resources/unit statistics for both factions.
- Immediate construction payment, construction timing, real income and structure limits.
- Production prerequisites, all eleven unit types, sequential queues, queue/army limits and destroyed-production interruption.
- Bounded group movement, coordinate conventions, A* obstacle avoidance, direct aerial routes and hold orders.
- Simultaneous damage plus cooldown, symmetric ammunition consumption, empty-ammo behavior and automatic defense.
- HQ attack, victory/defeat and terminal-state freeze; destruction/removal of ordinary buildings.
- Hospital and engineer healing, timed paid research, finite industrial stock, paid repair and building upgrades.
- Paid AI training/building, autonomous construction and tactical-state changes without free reinforcement spawns.
- Sensor coverage and reconnaissance upgrades; finite-resource strategic capture.
- Full save round-trip, malformed/oversized/nonfinite/invalid-enum/duplicate-ID rejection.
- Deterministic, nonmutating simulation updates.

## Browser checks

Chromium was driven against the development app and the production HTML. Desktop and narrow-screen screenshots were visually inspected; no game JavaScript exceptions were observed during the final checks.

- Arabic briefing, English switch, mission start and actual connected game entry.
- Command/build/army/support panels, paid power/factory construction and infantry training.
- Multi-unit selection, ground movement, hold, enemy-HQ attack, pause/resume and simulation speeds.
- Research-center construction and completed paid weapons research through the actual UI.
- Actual save-file download, valid reimport, invalid-file rejection and unchanged game after rejection.
- Help, restart confirmation/cancellation and restart after a result.
- Victory and defeat dialogs tested with controlled valid save fixtures followed by real combat. This is not a claim of manually completing a natural campaign.
- Sound toggle state checked and synthesized sound code exercised. Physical speaker quality was not audited.
- Layout inspected at 1440 × 960 and 375 × 812; the narrow layout had no horizontal document overflow.
- The supplied game Playwright client completed two screenshot/state iterations without an errors output file after fixing the favicon request.
- A fresh browser context with networking disabled opened the production HTML through `file://`, started the Arabic mission and returned live game state. It made no HTTP/HTTPS requests and produced no JavaScript exceptions.

## Opponent smoke simulations

Five-minute maximum idle-player simulations ended in player defeat in all three difficulty presets, at approximately 194 seconds on easy, 170 on normal and 168 on hard. The opponent constructed 7–8 buildings and trained units using paid systems. These are smoke checks showing that the opponent acts and can end a match, not evidence of broad balance testing.

## Performance and limitations

The test environment uses software WebGL, not a hardware gaming GPU. The 3D view ran at roughly 9–12 FPS in that environment; adaptive shadow disabling and an automatic switch to the fully playable SVG tactical view handle sustained poor performance. No claim is made of hardware-GPU frame rates, physical-phone compatibility or AAA visual quality.

Navigation does not yet include unit separation, full ballistic line-of-sight or a dynamic navigation mesh. Maps share one layout, and campaign/multiplayer are not implemented. See `FEATURE-STATUS.md` for all scope boundaries.

## Release packaging

The release script collects the portable HTML, source and built distribution, lockfile, tests, guides and dependency notices without `node_modules` or repository history.

- Python ZIP integrity validation passed.
- The archive was extracted into a separate verification directory.
- Its extracted `PLAY-IRON-FRONT.html` opened offline through `file://`, accepted select-all, advanced its simulation and built paid enemy infrastructure without JavaScript exceptions.
- `npm ci`, all 27 tests, TypeScript and the production build also passed inside the extracted `SOURCE` directory.
- Dependency license notices include the embedded Barlow Condensed and Noto Sans Arabic font licenses.
- A dependency emits a nonfatal `three-mesh-bvh@0.7.8` deprecation warning during installation. The observed browser checks succeeded; future dependency modernization should include compatibility and graphics regression testing.
