import { Component, useEffect, useRef, useState, type ReactNode } from 'react';
import { FortressScene } from './game/FortressScene';
import { TacticalMap } from './game/TacticalMap';
import { BUILDINGS, BUILDING_LABELS } from './game/catalog';
import { queueBuilding, upgradeBuilding } from './game/buildingSystem';
import { holdSelected, issueAttack, issueMove } from './game/combatSystem';
import { newGame } from './game/initialState';
import { recruit, repairBase, stepGame, upgrade, UNIT_SPECS } from './game/simulation';
import { RESEARCH } from './game/productionSystem';
import { canAfford } from './game/economy';
import { decodeSave, encodeSave } from './game/saveSystem';
import { buildingArabic, buildingDescription, words, type Language } from './game/i18n';
import { visibleTo } from './game/visibility';
import { battleAudio } from './game/audioSystem';
import type { BuildingKind, GameState, ResearchKind, UnitKind } from './game/types';

declare global {
  interface Window { render_game_to_text:()=>string; advanceTime:(ms:number)=>void; }
}
class SceneGuard extends Component<{children:ReactNode;fallback:ReactNode},{failed:boolean}> {
  state={failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  render(){return this.state.failed?this.props.fallback:this.props.children;}
}
const time=(seconds:number)=>`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(Math.floor(seconds%60)).padStart(2,'0')}`;
export default function App() {
  const [game,setGame]=useState<GameState>(()=>newGame());
  const [language,setLanguage]=useState<Language>('ar');
  const [tab,setTab]=useState<'command'|'build'|'army'|'support'>('command');
  const [running,setRunning]=useState(true);
  const [moveMode,setMoveMode]=useState(false);
  const [view,setView]=useState<'3d'|'2d'>(()=>window.innerWidth<700?'2d':'3d');
  const [modal,setModal]=useState<'briefing'|'help'|'restart'|null>('briefing');
  const [biome,setBiome]=useState<GameState['biome']>('forest');
  const [difficulty,setDifficulty]=useState<GameState['difficulty']>('normal');
  const [sound,setSound]=useState(false);
  const [speed,setSpeed]=useState(1);
  const [notice,setNotice]=useState('');
  const file=useRef<HTMLInputElement>(null);
  const frameRemainder=useRef(0);
  const previousAudio=useRef({kills:0,losses:0,tick:0});
  const t=words[language],ar=language==='ar';
  const effectiveRunning=running&&!modal&&game.phase==='playing';
  const selected=game.units.filter(u=>u.faction==='player'&&u.selected);
  const friendlies=game.units.filter(u=>u.faction==='player');
  const enemies=game.units.filter(u=>u.faction==='enemy'&&visibleTo(game,'player',u));
  const buildingName=(kind:BuildingKind)=>ar?buildingArabic[kind]:BUILDING_LABELS[kind];
  const unitName=(kind:UnitKind)=>ar?UNIT_SPECS[kind].ar:UNIT_SPECS[kind].name;
  useEffect(()=>{document.documentElement.lang=language;},[language]);
  useEffect(()=>{
    if(view!=='2d')return;
    let frame=0,frames=0,last=performance.now();
    const count=(now:number)=>{
      frames++;
      if(now-last>=1000){
        const element=document.getElementById('performance');
        if(element)element.textContent=`${Math.round(frames*1000/(now-last))} FPS / 2D`;
        frames=0;last=now;
      }
      frame=requestAnimationFrame(count);
    };
    frame=requestAnimationFrame(count);return ()=>cancelAnimationFrame(frame);
  },[view]);
  useEffect(()=>{
    if(!effectiveRunning)return;
    const interval=window.setInterval(()=>setGame(g=>{
      let next=g;for(let i=0;i<speed;i++)next=stepGame(next,.1);return next;
    }),100);
    return ()=>window.clearInterval(interval);
  },[effectiveRunning,speed]);
  useEffect(()=>{
    window.render_game_to_text=()=>JSON.stringify({
      coordinates:'World x east, z south. Friendly HQ (-12,4); enemy HQ (20,-4).',
      paused:!effectiveRunning,view,language,...game,
    });
    window.advanceTime=(ms:number)=>{
      if(!effectiveRunning||!Number.isFinite(ms)||ms<0)return;
      frameRemainder.current+=Math.min(ms,120000);
      const steps=Math.floor((frameRemainder.current+1e-6)/100);frameRemainder.current-=steps*100;
      setGame(g=>{let next=g;for(let i=0;i<steps;i++)next=stepGame(next,.1);return next;});
    };
  },[game,effectiveRunning,view,language]);
  useEffect(()=>{
    const previous=previousAudio.current;
    if(effectiveRunning&&sound){
      if(game.kills>previous.kills||game.losses>previous.losses)battleAudio.play('explosion');
      else if(game.shots.length&&game.tick!==previous.tick)battleAudio.play('shot');
    }
    previousAudio.current={kills:game.kills,losses:game.losses,tick:game.tick};
  },[game.tick,game.kills,game.losses,game.shots.length,sound,effectiveRunning]);
  const selectAll=()=>setGame(g=>({...g,units:g.units.map(u=>({...u,selected:u.faction==='player'}))}));
  useEffect(()=>{
    const handle=(event:KeyboardEvent)=>{
      if(event.target instanceof HTMLInputElement||event.target instanceof HTMLSelectElement||modal)return;
      if(event.code==='Space'&&event.target instanceof HTMLButtonElement)return;
      if(event.code==='Space'){event.preventDefault();setRunning(v=>!v);}
      if(event.key.toLowerCase()==='a'){event.preventDefault();selectAll();}
      if(event.key.toLowerCase()==='m'&&selected.length)setMoveMode(v=>!v);
      if(event.key==='Escape')setMoveMode(false);
    };
    window.addEventListener('keydown',handle);return ()=>window.removeEventListener('keydown',handle);
  },[modal,selected.length]);
  const selectUnit=(id:number,isEnemy:boolean,multi:boolean)=>{
    if(isEnemy){setGame(g=>issueAttack(g,id));setMoveMode(false);return;}
    setGame(g=>({...g,units:g.units.map(u=>u.id===id?{...u,selected:multi?!u.selected:true}:multi?u:{...u,selected:false})}));
  };
  const moveUnits=(x:number,z:number)=>{
    if(!moveMode)return;
    setGame(g=>issueMove(g,x,z));setMoveMode(false);
  };
  const attackHQ=()=>{setGame(g=>issueAttack(g,-1));setMoveMode(false);};
  const begin=()=>{
    setGame(newGame(biome,difficulty));setRunning(true);setModal(null);setMoveMode(false);
    setTab('command');setNotice('');frameRemainder.current=0;
  };
  const save=()=>{
    try{
      const blob=new Blob([encodeSave(game)],{type:'application/json'}),url=URL.createObjectURL(blob);
      const anchor=document.createElement('a');anchor.href=url;anchor.download=`IRON-FRONT-${Math.floor(game.tick)}.json`;
      document.body.append(anchor);anchor.click();anchor.remove();window.setTimeout(()=>URL.revokeObjectURL(url),1000);
      setNotice(t.saveOk);
    }catch{setNotice(t.saveError);}
  };
  const importSave=async(selectedFile:File|undefined)=>{
    if(!selectedFile)return;
    try{
      if(selectedFile.size>500000)throw new Error('size');
      const loaded=decodeSave(await selectedFile.text());
      setGame(loaded);setBiome(loaded.biome);setDifficulty(loaded.difficulty);
      setRunning(false);setMoveMode(false);setModal(null);setNotice(t.loadOk);frameRemainder.current=0;
    }catch{setNotice(t.loadError);}
    finally{if(file.current)file.current.value='';}
  };
  const map=<TacticalMap state={game} onSelect={selectUnit} onMoveOrder={moveUnits} onAttackHQ={attackHQ} moveMode={moveMode}/>;
  const ended=game.phase!=='playing';
  const count=(kind:BuildingKind)=>game.buildings.filter(b=>b.kind===kind).length;
  const fieldControls=<div className="field-controls">
    <button onClick={()=>setView(v=>v==='3d'?'2d':'3d')}>{view==='3d'?t.map2d:t.map3d}</button>
    <button onClick={()=>setModal('help')}>{t.help}</button>
    <span className="performance" id="performance">{view==='2d'?'2D / SVG':'3D / WEBGL'}</span>
  </div>;
  return <main className="app-shell" dir={ar?'rtl':'ltr'}>
    <header className="topbar">
      <div className="brand" dir="ltr"><div className="brand-mark">IF</div><div><strong>IRON FRONT</strong><span>TOTAL DOMINATION</span></div></div>
      <div className="resources">{(['steel','fuel','power','ammo'] as const).map(key=>
        <div key={key}><small>{t[key]}</small><b>{Math.floor(game.resources[key]).toLocaleString('en-US')}</b></div>)}</div>
      <div className="top-actions"><button onClick={()=>setLanguage(ar?'en':'ar')} aria-label="Change language">{ar?'EN':'العربية'}</button>
        <button className="save-btn" onClick={save}>{t.save}</button>
        <button className="audio-btn" aria-pressed={sound} onClick={async()=>{try{setSound(await battleAudio.toggle());}catch{setNotice(ar?'الصوت غير متاح':'Audio unavailable');}}}>{sound?'SFX ON':'SFX OFF'}</button></div>
    </header>
    <section className="battle-area" aria-label={t.mission} dir="ltr">
      <div className="map-label"><span className="live-dot"/>{t.mission}<small>{t.sector}</small></div>
      <div className="map-stage">{view==='2d'?map:<SceneGuard fallback={map}>
        <FortressScene state={game} paused={!effectiveRunning} onSelect={selectUnit} onMoveOrder={moveUnits} onAttackHQ={attackHQ}
          onDegraded={()=>{setView('2d');setNotice(ar?'تم تفعيل الخريطة الخفيفة لتحسين الأداء. الميدان ثلاثي الأبعاد يحتاج تسريع الرسوميات.':'Performance mode enabled. Hardware acceleration is recommended for 3D.');}}/>
      </SceneGuard>}</div>
      <div className="map-vignette"/>
      <div className="status-stack">
        <div><small className="full-label">{t.hq}</small><small className="compact-label">{ar?'قاعدتك':'YOUR HQ'}</small><b>{Math.ceil(game.baseHp)}%<span className="health"><i style={{width:game.baseHp+'%'}}/></span></b></div>
        <div className="enemy"><small className="full-label">{t.enemyHQ}</small><small className="compact-label">{ar?'العدو':'HOSTILE'}</small><b>{Math.ceil(game.enemyHp)}%<span className="health"><i style={{width:game.enemyHp+'%'}}/></span></b></div>
      </div>
      {fieldControls}
      {!effectiveRunning&&!modal&&!ended&&<button className="pause-overlay" onClick={()=>setRunning(true)}>{t.resume}</button>}
      <div className="map-coords">{t.friendly} {friendlies.length} / {t.hostile} {enemies.length} / {t.wave} {game.wave}
        <span>{t.next} {Math.ceil(Math.max(0,game.nextWave-game.tick))}{t.seconds}</span></div>
      <div className={`unit-hint ${moveMode?'armed':''}`}>{moveMode?t.moveHint:selected.length?`${selected.length} ${t.selected}`:t.hint}</div>
    </section>
    <section className="command-panel" id="commands">
      <div className="panel-head"><div><small>{t.playing}</small><h1>{ar?'قيادة العمليات':'FORTRESS OPERATIONS'}</h1></div>
        <div className="online"><span className={effectiveRunning?'live-dot':''}/>{effectiveRunning?t.active:t.paused}<b dir="ltr">T+ {time(game.tick)}</b></div>
      </div>
      <nav className="tabs" aria-label={ar?'لوحات القيادة':'Command panels'}>{(['command','build','army','support'] as const).map(key=>
        <button key={key} aria-pressed={tab===key} className={tab===key?'active':''} onClick={()=>setTab(key)}>{t[key]}</button>)}</nav>
      <div className="panel-body">
        {tab==='command'&&<div className="command-content">
          <div className="command-summary"><b>{t.objective}</b><p>{effectiveRunning?(ar?'المناطق المركزية تنتج الحديد عند السيطرة عليها. موارد الصناعة محدودة؛ احمِ المنشآت وراقب الذخيرة.':'Capture central depots for steel. Industrial reserves are finite. Protect your production and watch ammunition.') : t.pausedText}</p>
            <small>{t.kills} {game.kills} / {t.losses} {game.losses} / {ar?'احتياطي الصناعة':'INDUSTRIAL RESERVE'} {game.reserve.toLocaleString('en-US')}</small>
          </div>
          <div className="action-row">
            <button disabled={!friendlies.length||ended} onClick={selectAll}>{t.selectAll}</button>
            <button className={moveMode?'primary-action':''} aria-pressed={moveMode} disabled={!selected.length||ended} onClick={()=>setMoveMode(v=>!v)}>{moveMode?t.cancel:t.move}</button>
            <button disabled={!selected.length||ended} onClick={()=>{setGame(g=>holdSelected(g));setMoveMode(false);}}>{t.hold}</button>
            <button className="attack-action" disabled={!selected.length||ended} onClick={attackHQ}>{t.attackHQ}</button>
            <button disabled={!selected.length||ended} onClick={()=>{setGame(g=>issueMove(g,-5,4));setMoveMode(false);}}>{ar?'تراجع':'RETREAT'}</button>
            <button disabled={ended} onClick={()=>{setRunning(v=>!v);setMoveMode(false);}}>{running?t.pause:t.resume}</button>
            <button onClick={()=>setSpeed(v=>v===1?2:v===2?4:1)} aria-label="Simulation speed">{speed}×</button>
          </div>
          <div className="mini-map">{map}<small>{ar?'خريطة تكتيكية تفاعلية':'INTERACTIVE TACTICAL MAP'}</small></div>
        </div>}
        {tab==='build'&&<div className="construction-grid">{BUILDINGS.map(spec=>{
          const active=game.buildings.find(b=>b.kind===spec.kind&&b.status==='active');
          const inProgress=game.buildings.find(b=>b.kind===spec.kind&&b.status==='constructing');
          const limit=spec.kind==='watchtower'||spec.kind==='wall'?4:1;
          const limitReached=count(spec.kind)>=limit,affordable=canAfford(game.resources,spec.cost);
          return <article className="construction-card" key={spec.kind}>
            <div className="building-symbol">{spec.short}</div><div className="building-copy"><b>{buildingName(spec.kind)}</b>
              <small>{ar?buildingDescription[spec.kind]??'تدريب المشاة والقناصة والمهندسين':spec.description}</small>
              <span className="cost" dir="ltr">{spec.cost.steel} S / {spec.cost.fuel} F / {spec.cost.power} P / {spec.seconds}s</span>
              {inProgress&&<><progress max={inProgress.buildSeconds} value={inProgress.buildSeconds-inProgress.remaining}/><small>{Math.ceil(inProgress.remaining)}{t.seconds}</small></>}
              {active&&<small className="built-label">{t.operational} / LV {active.level} / {Math.ceil(active.hp)} HP</small>}
            </div><div className="card-buttons">
              <button disabled={limitReached||!affordable||ended} onClick={()=>setGame(g=>queueBuilding(g,spec.kind))}>{limitReached?t.limit:!affordable?t.unaffordable:t.buy}</button>
              {active&&active.level<3&&<button disabled={ended} onClick={()=>setGame(g=>upgradeBuilding(g,active.id))}>{ar?'تطوير':'UPGRADE'} {active.level+1}</button>}
            </div>
          </article>;
        })}</div>}
        {tab==='army'&&<div className="army-content">
          <div className="training-grid">{(Object.keys(UNIT_SPECS) as UnitKind[]).map(kind=>{
            const spec=UNIT_SPECS[kind],ready=game.buildings.some(b=>b.kind===spec.building&&b.status==='active');
            const affordable=canAfford(game.resources,spec)&&game.resources.ammo>=spec.ammo;
            return <article className="unit-card" key={kind}><b>{unitName(kind)}</b><small>{ar?'صحة':'HP'} {spec.hp} / {ar?'ضرر':'DMG'} {spec.damage} / {ar?'مدى':'RNG'} {spec.range}</small>
              <span className="cost" dir="ltr">{spec.steel} S / {spec.fuel} F / {spec.power} P / {spec.ammo} A / {spec.seconds}s</span>
              <button disabled={!ready||!affordable||game.training.length>=5||friendlies.length+game.training.length>=24||ended} onClick={()=>setGame(g=>recruit(g,kind))}>{ready?t.train:buildingName(spec.building)}</button></article>;
          })}</div>
          <div className="training-queue"><b>{t.queue} ({game.training.length}/5)</b>{game.training.length?game.training.map((item,i)=>
            <div key={item.id}><span>{unitName(item.kind)} #{item.id}</span><progress max={item.total} value={item.total-item.remaining}/><small>{i===0?Math.ceil(item.remaining)+t.seconds:ar?'انتظار':'QUEUED'}</small></div>):<small>{t.emptyQueue}</small>}</div>
          <div className="roster"><b>{t.friendly} ({friendlies.length}/24)</b>{!friendlies.length&&<p>{t.noUnits}</p>}
            {friendlies.map(u=><button key={u.id} aria-pressed={u.selected} className={u.selected?'selected-unit':''} onClick={()=>selectUnit(u.id,false,true)}>
              {unitName(u.kind)} #{u.id}<span>{Math.ceil(u.hp)}/{u.maxHp} HP / {u.order.toUpperCase()}</span></button>)}
          </div>
        </div>}
        {tab==='support'&&<div className="support-content">
          <div className="research-grid">{(Object.keys(RESEARCH) as ResearchKind[]).map(kind=>{
            const spec=RESEARCH[kind],done=game.technologies[kind]>0,job=game.research?.kind===kind?game.research:null;
            const ready=game.buildings.some(b=>b.kind==='research'&&b.status==='active');
            return <article className="unit-card" key={kind}><b>{ar?spec.ar:spec.en}</b>
              <span className="cost" dir="ltr">{spec.steel} S / {spec.fuel} F / {spec.power} P / {spec.seconds}s</span>
              {job&&<progress max={job.total} value={job.total-job.remaining}/>}
              <button disabled={done||!!game.research||!ready||!canAfford(game.resources,spec)||ended} onClick={()=>setGame(g=>upgrade(g,kind))}>
                {done?t.operational:job?Math.ceil(job.remaining)+t.seconds:!ready?buildingName('research'):ar?'ابدأ البحث':'RESEARCH'}</button>
            </article>;
          })}</div>
          <div className="support-actions"><button disabled={game.baseHp>=100||game.resources.steel<120||ended} onClick={()=>setGame(g=>repairBase(g))}>{t.repair}<small>{t.repairCost}</small></button>
            <button disabled={ended} onClick={()=>setGame(g=>upgradeBuilding(g,'HQ-001'))}>{ar?'تطوير المقر':'UPGRADE HQ'}</button>
            <button onClick={save}>{t.save}</button><button onClick={()=>file.current?.click()}>{t.load}</button>
            <button onClick={()=>setModal('restart')}>{t.newMission}</button>
            <button aria-pressed={sound} onClick={async()=>{try{setSound(await battleAudio.toggle());}catch{setNotice(ar?'الصوت غير متاح':'Audio unavailable');}}}>{sound?'SFX ON':'SFX OFF'}</button></div>
          <div className="event-log" aria-label={ar?'سجل العمليات':'Military event log'}>{game.events.slice(-8).reverse().map((event,i)=><div key={`${event.time}-${i}`}><time dir="ltr">{time(event.time)}</time><span>{event.text}</span></div>)}</div>
        </div>}
      </div>
      <footer className="footer-line"><span className="log-dot"/><span>{notice||game.message}</span>
        {notice&&<button aria-label="Dismiss notification" onClick={()=>setNotice('')}>×</button>}
        <span className="footer-units">{selected.length} {t.selected} / {friendlies.length} {t.friendly}</span>
      </footer>
    </section>
    <input ref={file} type="file" accept=".json,application/json" aria-label={t.load} hidden onChange={e=>void importSave(e.target.files?.[0])}/>
    {(modal||ended)&&<div className="modal-backdrop"><section className="mission-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
      <div className="dialog-eyebrow" dir="ltr">IRON FRONT / TOTAL DOMINATION / 0.4</div>
      <h2 id="dialog-title">{ended?(game.phase==='victory'?t.victory:t.defeat):modal==='restart'?t.restartTitle:t.briefing}</h2>
      <p>{ended?(game.phase==='victory'?t.victoryText:t.defeatText):modal==='restart'?t.restartText:t.objective}</p>
      {ended?<div className="result-stats"><div><b>{game.kills*100+Math.ceil(game.baseHp)*10-game.losses*25}</b><small>{t.score}</small></div>
        <div><b>{time(game.tick)}</b><small>{ar?'مدة المعركة':'BATTLE TIME'}</small></div><div><b>{game.kills} / {game.losses}</b><small>{t.kills} / {t.losses}</small></div></div>
      :modal!=='restart'&&<><p>{t.instructions}</p><p className="controls-copy">{t.controls}</p>
        <div className="settings-grid"><label>{ar?'ميدان المعركة':'BATTLEFIELD'}<select value={biome} onChange={e=>setBiome(e.target.value as GameState['biome'])} disabled={modal==='help'}>
          <option value="forest">{ar?'وادي الغابات':'FOREST VALLEY'}</option><option value="desert">{ar?'الحدود الصحراوية':'DESERT FRONTIER'}</option><option value="snow">{ar?'الجبهة المتجمدة':'FROZEN FRONT'}</option></select></label>
          <label>{ar?'صعوبة التخطيط المعادي':'AI DIFFICULTY'}<select value={difficulty} onChange={e=>setDifficulty(e.target.value as GameState['difficulty'])} disabled={modal==='help'}>
            <option value="easy">{ar?'سهل':'EASY'}</option><option value="normal">{ar?'عادي':'NORMAL'}</option><option value="hard">{ar?'صعب':'HARD'}</option></select></label></div>
        <small>{ar?'الخصم يدفع تكاليف البناء والإنتاج نفسها، دون موارد مجانية.':'The opponent pays the same costs, with no free resources or reinforcements.'}</small></>}
      <div className="dialog-actions">{modal==='help'&&!ended?<button className="primary-action" onClick={()=>setModal(null)}>{t.resume}</button>:
        <button id="start-btn" className="primary-action" onClick={begin}>{ended||modal==='restart'?t.newMission:t.start}</button>}
        {!ended&&modal==='restart'&&<button onClick={()=>setModal(null)}>{t.cancel}</button>}
        {modal==='briefing'&&<button onClick={()=>file.current?.click()}>{t.load}</button>}
        {ended&&<button onClick={save}>{t.save}</button>}
        <button onClick={()=>setLanguage(ar?'en':'ar')}>{ar?'English':'العربية'}</button>
      </div>
    </section></div>}
  </main>;
}
