import type { GameState } from './types';
import { makeUnit } from './unitSystem';
export const newGame = (biome:GameState['biome']='forest',difficulty:GameState['difficulty']='normal'):GameState => ({
  resources:{steel:1100,fuel:650,power:260,ammo:360},
  buildings:[
    {id:'HQ-001',kind:'hq',level:1,hp:100,maxHp:100,x:-12,z:4,status:'active',remaining:0,buildSeconds:0},
    {id:'BLD-000',kind:'barracks',level:1,hp:100,maxHp:100,x:-8.2,z:5.2,status:'active',remaining:0,buildSeconds:0},
  ],
  units:[
    makeUnit(1,'tank','player',-3.2,2.5),makeUnit(2,'infantry','player',-2.2,4.2),makeUnit(3,'infantry','player',-3.7,5.3),
    makeUnit(101,'tank','enemy',11.2,-2.5),makeUnit(102,'infantry','enemy',10.2,-4.2),makeUnit(103,'infantry','enemy',11.7,-5.3),
  ],
  enemyHp:100,baseHp:100,tick:0,message:'FORTRESS ONLINE / القاعدة جاهزة',nextBuildingId:1,nextUnitId:104,
  phase:'playing',training:[],wave:0,nextWave:70,kills:0,losses:0,tech:0,shots:[],seed:731,
  technologies:{weapons:0,armor:0,mobility:0,industry:0,recon:0},research:null,reserve:12000,difficulty,biome,
  opponent:{
    resources:{steel:1100,fuel:650,power:260,ammo:360},
    buildings:[
      {id:'EN-HQ',kind:'hq',level:1,hp:100,maxHp:100,x:20,z:-4,status:'active',remaining:0,buildSeconds:0},
      {id:'EN-BAR',kind:'barracks',level:1,hp:100,maxHp:100,x:16.2,z:-5.2,status:'active',remaining:0,buildSeconds:0},
    ],
    training:[],technologies:{weapons:0,armor:0,mobility:0,industry:0,recon:0},research:null,
    reserve:12000,lastDecision:0,stance:'expand',
  },
  events:[{time:0,text:'OPERATION START / بدء العملية'}],
  zones:[{id:1,x:1,z:-8,owner:'neutral',progress:0,reserve:1500},
    {id:2,x:2,z:7,owner:'neutral',progress:0,reserve:1500}],
});
export const initialGameState=newGame();
