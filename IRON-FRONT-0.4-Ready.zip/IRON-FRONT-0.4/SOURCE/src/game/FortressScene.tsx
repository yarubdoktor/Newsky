import { useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Instance, Instances, Line, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import type { Building, BuildingKind, GameState, Unit } from './types';
import { visibleTo } from './visibility';
import { UNIT_SPECS } from './unitSystem';
import { rocks } from './navigation';

function Box({position=[0,0,0],size=[1,1,1],color='#758880'}:{
  position?:[number,number,number];size?:[number,number,number];color?:string}) {
  return <mesh position={position} castShadow receiveShadow><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.72} metalness={.28}/></mesh>;
}
function PerformanceMeter({onDegraded}:{onDegraded:()=>void}){
  const renderer=useThree(s=>s.gl),counter=useRef({frames:0,time:performance.now(),slow:0});
  useFrame(()=>{
    counter.current.frames++;const now=performance.now();
    if(now-counter.current.time>1000){
      const fps=Math.round(counter.current.frames*1000/(now-counter.current.time));
      if(fps<25&&renderer.shadowMap.enabled){renderer.shadowMap.enabled=false;renderer.shadowMap.needsUpdate=true;}
      const slow=fps<20?counter.current.slow+1:0;
      if(slow>=4)onDegraded();
      const element=document.getElementById('performance');
      if(element)element.textContent=`${fps} FPS / ${renderer.info.render.calls} DRAW`;
      counter.current={frames:0,time:now,slow};
    }
  });
  return null;
}
function Terrain({state,onMoveOrder}:{state:GameState;onMoveOrder:(x:number,z:number)=>void}) {
  const trees=useMemo(()=>Array.from({length:65},(_,i)=>({x:Math.sin(i*17.31)*35+4,z:Math.cos(i*9.17)*23,
    s:.7+(i%4)*.18})).filter(p=>!(p.x<0&&p.x>-25&&p.z>-4&&p.z<13)&&
      !(p.x>8&&p.x<33&&p.z<4&&p.z>-13)&&Math.abs(p.z)>8),[]);
  const color=state.biome==='snow'?'#c0ccc8':state.biome==='desert'?'#a18b65':'#4b6150';
  return <group>
    <mesh rotation={[-Math.PI/2,0,0]} receiveShadow onClick={e=>{e.stopPropagation();onMoveOrder(e.point.x,e.point.z);}}>
      <planeGeometry args={[100,70]}/><meshStandardMaterial color={color} roughness={1}/></mesh>
    <gridHelper args={[88,44,state.biome==='snow'?'#a0b3ad':'#7d8a6e','#63775f']} position={[4,.018,0]} material-transparent material-opacity={.22}/>
    <mesh position={[4,.025,3]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[56,3.2]}/><meshStandardMaterial color={state.biome==='snow'?'#9baaa6':'#897f69'} roughness={1}/></mesh>
    {state.biome!=='desert'&&<><Instances limit={80} castShadow><cylinderGeometry args={[.13,.2,1.6,5]}/><meshStandardMaterial color="#4b4c3c"/>
      {trees.map((t,i)=><Instance key={i} position={[t.x,.8*t.s,t.z]} scale={t.s}/>)}</Instances>
      <Instances limit={80} castShadow><coneGeometry args={[1,2.8,6]}/><meshStandardMaterial color={state.biome==='snow'?'#819b90':'#294b3c'}/>
        {trees.map((t,i)=><Instance key={i} position={[t.x,2.4*t.s,t.z]} scale={t.s}/>)}</Instances></>}
    {rocks.map((r,i)=><mesh key={i} position={[r.x,.65,r.z]} scale={[r.r,1.2,r.r]} castShadow><dodecahedronGeometry args={[1,0]}/><meshStandardMaterial color="#707a73" roughness={1}/></mesh>)}
    {Array.from({length:12},(_,i)=><mesh key={i} position={[-38+i*7,2,-27-(i%2)*3]} scale={[5+(i%3),4+(i%4),4]}><coneGeometry args={[1,2,5]}/><meshStandardMaterial color={state.biome==='snow'?'#a0b4b1':'#5b6b60'} roughness={1}/></mesh>)}
  </group>;
}
function FortressWalls({enemy=false}:{enemy?:boolean}) {
  const transform=(x:number,z:number):[number,number,number]=>[enemy?8-x:x,0,enemy?-z:z];
  return <group>
    {[{x:-12.5,z:-3.4,s:[23,.8,.45]},{x:-12.5,z:11.6,s:[23,.8,.45]},
      {x:-24,z:4.1,s:[.45,.8,15]},{x:-1,z:-.9,s:[.45,.8,5]},{x:-1,z:9.1,s:[.45,.8,5]}].map((w,i)=>
      <group key={i} position={transform(w.x,w.z)}><Box position={[0,.4,0]} size={w.s as [number,number,number]} color={enemy?'#705c53':'#7d8c84'}/></group>)}
    {[-24,-1].flatMap((x)=>[-3.4,11.6].map(z=><group key={`${x}:${z}`} position={transform(x,z)}>
      <Box position={[0,.85,0]} size={[1.3,1.7,1.3]} color="#718179"/><Box position={[0,1.9,0]} size={[1.6,.4,1.6]} color={enemy?'#956659':'#b5a273'}/>
    </group>))}
  </group>;
}
function Structure({building,enemy=false,onAttackHQ}:{building:Building;enemy?:boolean;onAttackHQ:()=>void}) {
  const {kind,x,z,status,remaining,buildSeconds}=building;
  const colors:Record<BuildingKind,string>={hq:'#a9b8b5',barracks:'#819878',power:'#b4a76d',refinery:'#9ba49c',
    factory:'#869a9d',research:'#819fa6',watchtower:'#9eac9e',hospital:'#c2cbc0',ammo:'#a99a72',
    vehicleFactory:'#819490',airfield:'#7b918d',missile:'#9d9e89',wall:'#87968b',command:'#9caca8'};
  const c=enemy?'#a76b5d':colors[kind],progress=status==='active'?1:1-remaining/buildSeconds;
  const tower=kind==='watchtower'||kind==='missile',height=tower?2.7:kind==='hq'?1.6:1;
  return <group position={[x,0,z]} onClick={e=>{if(enemy){e.stopPropagation();onAttackHQ();}}}>
    <Box position={[0,.08,0]} size={kind==='hq'?[4.8,.16,4.2]:[3.2,.16,2.8]} color="#34473f"/>
    <group scale={[1,Math.max(.08,progress),1]}>
      <Box position={[0,height/2,0]} size={tower?[.8,height,.8]:kind==='wall'?[2.8,1.3,.65]:kind==='hq'?[3.8,height,3.2]:[2.7,height,2.3]} color={c}/>
      {!['wall','refinery','airfield'].includes(kind)&&<Box position={[0,height+.18,0]} size={tower?[1.5,.35,1.5]:[2,.35,1.6]} color={enemy?'#66493f':'#41564f'}/>}
      {(kind==='hq'||kind==='command'||kind==='research')&&<group position={[.55,height+.3,0]}>
        <Box position={[0,.65,0]} size={[.08,1.3,.08]} color="#263b35"/>
        <mesh position={[0,1.25,0]} rotation={[.3,0,.5]}><sphereGeometry args={[.5,12,6,0,Math.PI]}/><meshStandardMaterial color="#c6d0bc" side={THREE.DoubleSide}/></mesh>
      </group>}
      {kind==='power'&&<><Box position={[-.6,1.7,0]} size={[.45,1.4,.45]} color="#d4c398"/><Box position={[.6,1.5,0]} size={[.45,1,.45]} color="#d4c398"/></>}
      {kind==='refinery'&&[-.8,0,.8].map(offset=><mesh key={offset} position={[offset,1.2,0]} castShadow><cylinderGeometry args={[.4,.4,2,12]}/><meshStandardMaterial color="#c1c3a8" roughness={.45} metalness={.5}/></mesh>)}
      {(kind==='factory'||kind==='vehicleFactory')&&<Box position={[0,.5,1.18]} size={[1.8,.8,.08]} color="#172b25"/>}
      {kind==='barracks'&&[-.8,0,.8].map(offset=><Box key={offset} position={[offset,.6,1.17]} size={[.3,.35,.04]} color="#d3d0a6"/>)}
      {kind==='hospital'&&<><Box position={[0,1.4,0]} size={[.4,.08,1.3]} color="#d64f40"/><Box position={[0,1.4,0]} size={[1.3,.08,.4]} color="#d64f40"/></>}
      {kind==='airfield'&&<><Box position={[0,1.03,0]} size={[2.8,.04,2.5]} color="#4b5a54"/><Box position={[0,1.08,0]} size={[1.6,.03,.15]} color="#dad9b5"/><Box position={[-.8,1.08,0]} size={[.15,.03,1.4]} color="#dad9b5"/><Box position={[.8,1.08,0]} size={[.15,.03,1.4]} color="#dad9b5"/></>}
      {kind==='missile'&&<group position={[0,3.1,0]} rotation={[0,0,-.5]}><Box size={[1.3,.45,.8]} color="#d4ca98"/><Box position={[-.5,.3,0]} size={[.12,.4,.9]} color="#364c40"/></group>}
      {kind==='ammo'&&[-.7,.1,.8].map(offset=><Box key={offset} position={[offset,1.35,0]} size={[.5,.5,.7]} color="#d0b979"/>)}
    </group>
    <mesh position={[0,.19,1.6]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[2.5*building.hp/building.maxHp,.12]}/><meshBasicMaterial color={enemy?'#ee9683':'#a9d8ab'}/></mesh>
    {building.level>1&&<mesh position={[1.2,1.5,0]}><sphereGeometry args={[.14,6,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>}
  </group>;
}
function UnitMesh({unit,onSelect}:{unit:Unit;onSelect:(id:number,enemy:boolean,multi:boolean)=>void}) {
  const enemy=unit.faction==='enemy',spec=UNIT_SPECS[unit.kind],vehicle=spec.armor>=2,
    air=!!spec.air,color=enemy?'#b86f5d':'#a4b58c',rotation=Math.atan2(unit.targetX-unit.x,unit.targetZ-unit.z);
  return <group position={[unit.x,air?2.7:.1,unit.z]} onClick={e=>{e.stopPropagation();onSelect(unit.id,enemy,!!(e.nativeEvent as PointerEvent).shiftKey);}}>
    <group rotation={[0,rotation,0]}>
      <Box position={[0,.35,0]} size={air?[.6,.4,1.7]:vehicle?[1.2,.5,1.8]:[.35,.65,.3]} color={color}/>
      {vehicle&&!air&&<><Box position={[-.64,.18,0]} size={[.25,.3,1.9]} color="#293c33"/><Box position={[.64,.18,0]} size={[.25,.3,1.9]} color="#293c33"/>
        <Box position={[0,.72,-.1]} size={unit.kind==='artillery'?[.6,.5,1.2]:[.65,.35,.7]} color={enemy?'#865144':'#6c845f'}/>
        <Box position={[0,.77,.8]} size={[.12,.12,unit.kind==='artillery'?2.3:1.5]} color="#304139"/></>}
      {!vehicle&&!air&&<><mesh position={[0,.89,0]}><sphereGeometry args={[.2,8,6]}/><meshStandardMaterial color={enemy?'#b7a089':'#d1c49e'}/></mesh>
        <Box position={[.22,.5,.2]} size={[.1,.1,unit.kind==='sniper'?.9:.5]} color="#26372d"/>
        {unit.kind==='antitank'&&<Box position={[.22,.73,0]} size={[.18,.18,.9]} color="#495a37"/>}</>}
      {air&&<><Box position={[0,.7,0]} size={unit.kind==='helicopter'?[3.5,.06,.18]:[2.4,.08,.2]} color="#c3ccb2"/><Box position={[0,.4,-1.1]} size={[1,.12,.25]} color="#a4b58c"/></>}
    </group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,.03,0]}><ringGeometry args={[vehicle?.9:.5,vehicle?1:.6,20]}/><meshBasicMaterial color={unit.selected?'#85e2d1':enemy?'#ef9b85':'#c4d6a8'} transparent opacity={unit.selected?1:.45}/></mesh>
    <group position={[0,1.5,0]}><mesh><planeGeometry args={[.95,.09]}/><meshBasicMaterial color="#152b22"/></mesh>
      <mesh position={[-.475*(1-unit.hp/unit.maxHp),0,.002]}><planeGeometry args={[.95*unit.hp/unit.maxHp,.065]}/><meshBasicMaterial color={enemy?'#ed9b8e':'#a3e1ac'}/></mesh></group>
  </group>;
}
function Weather({state,paused}:{state:GameState;paused:boolean}){
  const points=useRef<THREE.Points>(null);
  const positions=useMemo(()=>{
    const array=new Float32Array(140*3);
    for(let i=0;i<140;i++){array[i*3]=Math.sin(i*13.7)*34+4;array[i*3+1]=(i%19)*.8;array[i*3+2]=Math.cos(i*9.3)*24;}
    return array;
  },[]);
  useFrame((_,dt)=>{
    if(!points.current||paused)return;
    const attr=points.current.geometry.attributes.position;
    for(let i=0;i<attr.count;i++){attr.setY(i,(attr.getY(i)-dt*(state.biome==='snow'?1.5:8)+16)%16);}
    attr.needsUpdate=true;
  });
  if(state.biome==='desert')return null;
  return <points ref={points}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry>
    <pointsMaterial color={state.biome==='snow'?'#edf5ed':'#b6d1c9'} size={state.biome==='snow'?.08:.045} transparent opacity={.5}/></points>;
}
function AutoCamera(){
  const {camera,size}=useThree();
  useMemo(()=>{
    const distance=Math.max(1,1.4/(size.width/size.height));
    camera.position.set(4,29*distance,35*distance);camera.lookAt(4,0,2);
  },[camera,size.width,size.height]);
  return null;
}
export function FortressScene({state,paused,onSelect,onMoveOrder,onAttackHQ,onDegraded}:{
  state:GameState;paused:boolean;onSelect:(id:number,enemy:boolean,multi:boolean)=>void;
  onMoveOrder:(x:number,z:number)=>void;onAttackHQ:()=>void;onDegraded:()=>void}) {
  const daylight=.65+.35*Math.cos(state.tick/300*Math.PI*2);
  return <Canvas shadows camera={{position:[4,29,35],fov:48,near:.1,far:220}} dpr={1}
    gl={{antialias:false,powerPreference:'high-performance'}}
    onCreated={({gl})=>{
      const context=gl.getContext(),info=context.getExtension('WEBGL_debug_renderer_info');
      const name=info?String(context.getParameter(info.UNMASKED_RENDERER_WEBGL)):'';
      if(/swiftshader|llvmpipe|software/i.test(name))gl.shadowMap.enabled=false;
    }}
    fallback={<div>WebGL unavailable. Switch to the 2D tactical map.</div>}>
    <color attach="background" args={[state.biome==='snow'?'#738c90':'#263f3d']}/>
    <fog attach="fog" args={[state.biome==='snow'?'#a5bcb8':'#3c554a',60,145]}/>
    <ambientLight intensity={.9+daylight*.35}/><hemisphereLight args={['#cfdfdd','#50604b',1.4]}/>
    <directionalLight position={[-18,28,10]} intensity={daylight*2.2} castShadow shadow-mapSize={[1024,1024]}
      shadow-camera-left={-36} shadow-camera-right={36} shadow-camera-top={30} shadow-camera-bottom={-30} shadow-bias={-.001}/>
    <Terrain state={state} onMoveOrder={onMoveOrder}/><FortressWalls/><FortressWalls enemy/>
    {state.buildings.map(b=><Structure key={b.id} building={b} onAttackHQ={onAttackHQ}/>)}
    {state.opponent.buildings.filter(b=>b.kind==='hq'||visibleTo(state,'player',b)).map(b=>
      <Structure key={b.id} building={b} enemy onAttackHQ={onAttackHQ}/>)}
    {state.units.filter(u=>u.faction==='player'||visibleTo(state,'player',u)).map(u=><UnitMesh key={u.id} unit={u} onSelect={onSelect}/>)}
    {state.zones.map(z=><group key={z.id} position={[z.x,.07,z.z]}>
      <mesh rotation={[-Math.PI/2,0,0]}><ringGeometry args={[2.5,2.65,40]}/><meshBasicMaterial color={z.owner==='player'?'#a9d8ab':z.owner==='enemy'?'#ee9683':'#e4cd8f'}/></mesh>
      <Box position={[0,.25,0]} size={[1,.5,1]} color="#b9a875"/><Box position={[0,1.2,0]} size={[.06,2,.06]} color="#d5dcc4"/>
      <Box position={[.4,1.8,0]} size={[.8,.5,.03]} color={z.owner==='player'?'#80af8a':z.owner==='enemy'?'#c97662':'#c9b97e'}/>
    </group>)}
    {state.shots.map(shot=><group key={shot.id}>
      <Line points={[[shot.x,.85,shot.z],[shot.toX,.7,shot.toZ]]} color={shot.faction==='player'?'#ffe5a0':'#ffac80'} lineWidth={1.5}/>
      <mesh position={[shot.toX,.7,shot.toZ]}><sphereGeometry args={[.25,6,6]}/><meshBasicMaterial color="#ffd293"/></mesh>
    </group>)}
    <Weather state={state} paused={paused}/><AutoCamera/><PerformanceMeter onDegraded={onDegraded}/>
    <OrbitControls makeDefault target={[4,0,2]} maxPolarAngle={Math.PI/2.15} minDistance={15} maxDistance={110} enableDamping dampingFactor={.1}/>
  </Canvas>;
}
