import type { BuildingKind, GameState, ResearchKind, UnitKind } from './types';
import { advanceProduction, recruit, repairBase, upgrade } from './productionSystem';
import { queueBuilding } from './buildingSystem';
import { UNIT_SPECS } from './unitSystem';
import { visibleTo } from './visibility';

const mirror=<T extends {x:number;z:number}>(p:T):T=>({...p,x:8-p.x,z:-p.z||0});
/** Adapter to the exact same construction, economy, training and research code as the player. */
function asPlayer(state:GameState):GameState {
  const ai=state.opponent;
  return {...state,resources:ai.resources,buildings:ai.buildings.map(mirror),training:ai.training,
    units:state.units.map(u=>({...mirror(u),faction:u.faction==='enemy'?'player':'enemy',
      targetX:8-u.targetX,targetZ:-u.targetZ,path:u.path.map(mirror)})),
    baseHp:state.enemyHp,enemyHp:state.baseHp,technologies:ai.technologies,research:ai.research,
    tech:ai.technologies.weapons,reserve:ai.reserve};
}
function fromPlayer(state:GameState,proxy:GameState):GameState {
  return {...state,nextBuildingId:proxy.nextBuildingId,nextUnitId:proxy.nextUnitId,enemyHp:proxy.baseHp,
    units:[...state.units.filter(u=>u.faction==='player'),
      ...proxy.units.filter(u=>u.faction==='player').map(u=>({...mirror(u),faction:'enemy' as const,
        targetX:8-u.targetX,targetZ:-u.targetZ||0,path:u.path.map(mirror)}))],
    opponent:{...state.opponent,resources:proxy.resources,buildings:proxy.buildings.map(mirror),
      training:proxy.training,technologies:proxy.technologies,research:proxy.research,reserve:proxy.reserve}};
}
export function advanceAI(state:GameState,dt:number):GameState {
  let proxy=advanceProduction(asPlayer(state),dt);
  let next=fromPlayer(state,proxy);
  const period=state.difficulty==='easy'?8:state.difficulty==='hard'?2:4;
  if(state.tick-next.opponent.lastDecision<period)return next;
  next={...next,opponent:{...next.opponent,lastDecision:state.tick}};
  proxy=asPlayer(next);
  const owned=(kind:BuildingKind)=>proxy.buildings.some(b=>b.kind===kind);
  const priority:BuildingKind[]=['barracks','power','refinery','ammo','factory','vehicleFactory','watchtower','research','hospital','missile','airfield','command'];
  const blueprint=priority.find(k=>!owned(k));
  if(blueprint)proxy=queueBuilding(proxy,blueprint);
  const own=proxy.units.filter(u=>u.faction==='player');
  const threats=state.units.filter(u=>u.faction==='player'&&Math.hypot(u.x-20,u.z+4)<14&&visibleTo(state,'enemy',u));
  // Scout, defend, rebuild and attack are explicit economic/state-machine choices.
  const stance=threats.length?'defend':!owned('barracks')?'rebuild':own.length>=4&&state.tick>=state.nextWave?'attack':'expand';
  const production:UnitKind[]=threats.some(u=>u.armor>=7)?['antitank','tank','infantry']:
    state.tick>150?['helicopter','heavy','artillery','tank','infantry']:
    own.length%3===0?['tank','scout','infantry']:['infantry','antitank','sniper'];
  const savingForInfrastructure=blueprint&&!proxy.buildings.some(b=>b.kind===blueprint)&&
    own.length+proxy.training.length>=5&&!threats.length;
  if(proxy.training.length<2&&own.length<14&&!savingForInfrastructure){
    for(const kind of production){
      if(!proxy.buildings.some(b=>b.kind===UNIT_SPECS[kind].building&&b.status==='active'))continue;
      const result=recruit(proxy,kind);
      if(result.training.length>proxy.training.length){proxy=result;break;}
    }
  }
  if(proxy.baseHp<65)proxy=repairBase(proxy);
  if(!proxy.research&&owned('research')){
    const research=(['weapons','armor','industry','mobility','recon'] as ResearchKind[]).find(k=>!proxy.technologies[k]);
    if(research)proxy=upgrade(proxy,research);
  }
  next=fromPlayer(next,proxy);
  next={...next,opponent:{...next.opponent,stance}};
  if(state.tick>=15&&state.tick<15+period){
    next={...next,units:next.units.map(u=>u.faction==='enemy'&&u.id>=101&&u.id<=103
      ? {...u,order:'attack',targetId:-2,path:[]}:u)};
  }
  if(stance==='attack'){
    next={...next,wave:state.wave+1,nextWave:state.tick+(state.difficulty==='easy'?95:state.difficulty==='hard'?50:70),
      message:'ENEMY ASSAULT '+(state.wave+1)+' / هجوم جيش العدو',
      units:next.units.map(u=>u.faction==='enemy'?{...u,order:'attack',targetId:-2,path:[]}:u)};
  }else if(stance==='defend'){
    next={...next,units:next.units.map(u=>u.faction==='enemy'?{...u,order:'attack',targetId:threats[0].id,path:[]}:u)};
  }else{
    // A paid-for scout probes the central resource point; it is not spawned for free.
    next={...next,units:next.units.map(u=>u.faction==='enemy'&&u.kind==='scout'&&u.order==='idle'
      ? {...u,order:'move',targetX:2,targetZ:7,path:[]}:u)};
  }
  return next;
}
