import type { GameState } from './types';
import { BUILDING_LABELS } from './catalog';
import { useId } from 'react';
import { visibleTo } from './visibility';
import { rocks } from './navigation';

type Props={state:GameState;onSelect:(id:number,enemy:boolean,multi:boolean)=>void;
  onMoveOrder:(x:number,z:number)=>void;onAttackHQ:()=>void;moveMode:boolean};
/** Fictional local battlefield coordinates, not a geographical map. */
export function TacticalMap({state,onSelect,onMoveOrder,onAttackHQ,moveMode}:Props) {
  const pattern=useId();
  return <svg className="tactical-map" viewBox="-26 -17 60 34" aria-label="Tactical battlefield" onClick={e=>{
    const svg=e.currentTarget,p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;
    const matrix=svg.getScreenCTM();if(!matrix)return;
    const local=p.matrixTransform(matrix.inverse());onMoveOrder(local.x,local.y);
  }} style={{cursor:moveMode?'crosshair':'default'}}>
    <defs><pattern id={pattern} width="2" height="2" patternUnits="userSpaceOnUse">
      <path d="M 2 0 H 0 V 2" fill="none" stroke="#6f8774" strokeWidth=".035"/>
    </pattern></defs>
    <rect x="-26" y="-17" width="60" height="34" fill={state.biome==='snow'?'#6f8881':state.biome==='desert'?'#796d50':'#25372f'}/>
    <rect x="-26" y="-17" width="60" height="34" fill={`url(#${pattern})`}/>
    <path d="M-24-3H-1V1 M-1 7V12H-24V-3 M32 3H9V-1 M9-7V-12H32V3" stroke="#acb7a9" strokeWidth=".45" fill="none"/>
    <path d="M-3 4H20V-4" stroke="#96a185" strokeWidth=".8" opacity=".15" fill="none"/>
    {state.buildings.map(b=><g key={b.id} opacity={b.status==='constructing'?.55:1}>
      <title>{BUILDING_LABELS[b.kind]}</title>
      <rect x={b.x-1.3} y={b.z-1} width="2.6" height="2" fill={b.kind==='hq'?'#d5c18e':'#7d9b86'} stroke="#d1dbc8" strokeWidth=".1"/>
      <text x={b.x} y={b.z+.3} textAnchor="middle" fill="#101c17" fontSize=".8" fontWeight="bold">{b.kind==='hq'?'HQ':b.kind.slice(0,3).toUpperCase()}</text>
    </g>)}
    {state.opponent.buildings.filter(b=>b.kind!=='hq'&&visibleTo(state,'player',b)).map(b=><g key={b.id}>
      <rect x={b.x-1.3} y={b.z-1} width="2.6" height="2" fill="#b16e5d" stroke="#e7a094" strokeWidth=".1"/>
      <text x={b.x} y={b.z+.3} textAnchor="middle" fontSize=".75" fill="#fff2df">{b.kind.slice(0,3).toUpperCase()}</text>
    </g>)}
    {rocks.map((r,i)=><circle key={i} cx={r.x} cy={r.z} r={r.r} fill="#687c6b" stroke="#9bada0" strokeWidth=".1"/>)}
    {state.zones.map(z=><g key={z.id}><circle cx={z.x} cy={z.z} r="2.5" fill="none" stroke={z.owner==='player'?'#a8dfb6':z.owner==='enemy'?'#ef9b85':'#dcc78e'} strokeWidth=".16"/>
      <text x={z.x} y={z.z+.3} textAnchor="middle" fontSize="1" fill="#eee4c5">{Math.round(Math.abs(z.progress)*10)}%</text></g>)}
    <g role="button" tabIndex={0} aria-label="Attack hostile headquarters" onClick={e=>{e.stopPropagation();onAttackHQ();}}
      onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onAttackHQ();}}}>
      <rect x="17.5" y="-6" width="5" height="4" fill="#9b5046" stroke="#e7a094" strokeWidth=".15"/>
      <text x="20" y="-3.6" textAnchor="middle" fill="#fff2df" fontSize="1">HQ</text>
    </g>
    {state.units.filter(u=>u.faction==='player'||visibleTo(state,'player',u)).map(u=><g key={u.id} role="button" tabIndex={0} aria-label={`${u.faction} ${u.kind} ${u.id}`}
      onClick={e=>{e.stopPropagation();onSelect(u.id,u.faction==='enemy',e.shiftKey);}}
      onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(u.id,u.faction==='enemy',e.shiftKey);}}}>
      <circle cx={u.x} cy={u.z} r="1.1" fill="transparent"/>
      {u.selected&&<circle cx={u.x} cy={u.z} r=".9" fill="none" stroke="#82e2d2" strokeWidth=".16"/>}
      {u.kind==='tank'?<rect x={u.x-.55} y={u.z-.7} width="1.1" height="1.4" rx=".16" fill={u.faction==='enemy'?'#ed8e7b':'#c6d5a7'}/>
        :<circle cx={u.x} cy={u.z} r=".4" fill={u.faction==='enemy'?'#ed8e7b':'#c6d5a7'}/>}
      <path d={`M${u.x-.6} ${u.z-1.1}h${1.2*u.hp/u.maxHp}`} stroke={u.faction==='enemy'?'#ed8e7b':'#a4dfb2'} strokeWidth=".14"/>
    </g>)}
    {state.shots.map(s=><line key={s.id} x1={s.x} y1={s.z} x2={s.toX} y2={s.toZ} stroke={s.faction==='player'?'#f1d58b':'#ed8e7b'} strokeWidth=".12"/>)}
    <text x="-24" y="-13" fontSize="1" fill="#a4baab">N ↑</text>
  </svg>;
}
