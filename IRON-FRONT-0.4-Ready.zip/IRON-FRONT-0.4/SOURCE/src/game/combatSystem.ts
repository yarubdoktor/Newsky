import type { GameState } from './types';
import { advanceMovement } from './navigation';
import { visibleTo } from './visibility';

export const PLAYER_HQ = { x:-12, z:4 };
export const ENEMY_HQ = { x:20, z:-4 };
const distance=(a:{x:number;z:number},b:{x:number;z:number})=>Math.hypot(a.x-b.x,a.z-b.z);
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));

export function issueMove(state:GameState,x:number,z:number):GameState {
  if(state.phase!=='playing'||!Number.isFinite(x)||!Number.isFinite(z))return state;
  const selected=state.units.filter(u=>u.faction==='player'&&u.selected&&u.hp>0);
  const units=state.units.map(u=>{
    const index=selected.findIndex(s=>s.id===u.id);
    if(index<0)return u;
    return {...u,order:'move' as const,targetX:clamp(x+(index%3-1)*1.1,-23,24),
      targetZ:clamp(z+Math.floor(index/3)*1.1,-13,13),targetId:null,path:[]};
  });
  return {...state,units,message:selected.length?'MOVE ORDER / أمر تحرك':'SELECT UNITS FIRST / حدد وحدات أولاً'};
}

export function issueAttack(state:GameState,targetId:number):GameState {
  if(state.phase!=='playing')return state;
  const target=targetId===-1?ENEMY_HQ:state.units.find(u=>u.id===targetId&&u.faction==='enemy'&&u.hp>0);
  if(!target)return state;
  const count=state.units.filter(u=>u.faction==='player'&&u.selected&&u.hp>0).length;
  const units=state.units.map(u=>u.faction==='player'&&u.selected&&u.hp>0
    ? {...u,order:'attack' as const,targetId,targetX:target.x,targetZ:target.z,path:[]}:u);
  return {...state,units,message:count?'ATTACK CONFIRMED / تأكيد الهجوم':'SELECT UNITS FIRST / حدد وحدات أولاً'};
}

export function holdSelected(state:GameState):GameState {
  return {...state,units:state.units.map(u=>u.faction==='player'&&u.selected
    ? {...u,order:'idle' as const,targetId:null,targetX:u.x,targetZ:u.z,path:[]}:u),
    message:'HOLD & DEFEND / ثبات ودفاع'};
}

/** Fixed-step, simultaneous combat. Damage and weapon cooldown are independent. */
export function advanceCombat(state:GameState,dt=1):GameState {
  if(state.phase!=='playing')return state;
  let units=state.units.filter(u=>u.hp>0).map(u=>({...u,cooldown:Math.max(0,u.cooldown-dt)}));
  const shots=state.shots.map(s=>({...s,life:s.life-dt})).filter(s=>s.life>0);
  let ammo=state.resources.ammo,enemyHp=state.enemyHp,baseHp=state.baseHp;
  const damage=new Map<number,number>(),buildingDamage=new Map<string,number>();
  // Defenders only auto-acquire inside range; enemies actively advance after a preparation window.
  units=units.map(unit=>{
    const opponents=units.filter(v=>v.faction!==unit.faction&&visibleTo(state,unit.faction,v));
    const nearest=opponents.sort((a,b)=>distance(unit,a)-distance(unit,b))[0];
    if(unit.faction==='enemy'&&state.tick>=15&&nearest&&distance(unit,nearest)<unit.vision) {
      return {...unit,order:'attack' as const,targetId:nearest.id};
    }
    if(unit.order==='attack'&&unit.targetId!==null&&unit.targetId>=0&&!opponents.some(v=>v.id===unit.targetId))
      return unit.faction==='enemy'?{...unit,targetId:-2,path:[]}:{...unit,order:'idle' as const,targetId:null,path:[]};
    return unit;
  });
  units=units.map(unit=>{
    if(unit.order==='move')return advanceMovement(state,unit,{x:unit.targetX,z:unit.targetZ},dt);
    if(unit.order!=='attack')return unit;
    const target=unit.targetId===-1?ENEMY_HQ:unit.targetId===-2?PLAYER_HQ:units.find(v=>v.id===unit.targetId);
    if(!target)return unit;
    return distance(unit,target)>unit.range*.86?advanceMovement(state,{...unit,targetX:target.x,targetZ:target.z},target,dt):unit;
  });
  for(const unit of units) {
    if(unit.cooldown>1e-7)continue;
    const nearby=units.filter(v=>v.faction!==unit.faction&&distance(unit,v)<=unit.range&&visibleTo(state,unit.faction,v))
      .sort((a,b)=>distance(unit,a)-distance(unit,b))[0];
    const structures=(unit.faction==='player'?state.opponent.buildings:state.buildings)
      .filter(b=>b.kind!=='hq'&&distance(unit,b)<=unit.range);
    const ordered=unit.targetId===-1?ENEMY_HQ:unit.targetId===-2?PLAYER_HQ:units.find(v=>v.id===unit.targetId&&v.faction!==unit.faction);
    const target=nearby ?? (unit.order==='attack'?structures[0]??(ordered&&distance(unit,ordered)<=unit.range?ordered:null):null);
    if(!target)continue;
    const ammoCost=unit.armor>=7||unit.kind==='artillery'?3:1;
    const resources=unit.faction==='player'?{ammo}:state.opponent.resources;
    if(resources.ammo<ammoCost)continue;
    if(unit.faction==='player')ammo-=ammoCost;
    else state={...state,opponent:{...state.opponent,resources:{...state.opponent.resources,ammo:resources.ammo-ammoCost}}};
    const technologies=unit.faction==='player'?state.technologies:state.opponent.technologies;
    const opponentTech=unit.faction==='player'?state.opponent.technologies:state.technologies;
    const armor='armor' in target?target.armor+opponentTech.armor*5:0;
    const penetration=unit.kind==='antitank'?armor*.8:0;
    const cover=state.biome==='forest'&&'kind' in target&&['infantry','sniper','engineer','antitank'].includes(target.kind)?.85:1;
    const accuracy=1-.18*Math.min(1,distance(unit,target)/unit.range);
    const hit=Math.max(2,unit.damage*(1+technologies.weapons*.3)-armor+penetration)*cover*accuracy;
    if('id' in target&&typeof target.id==='number')damage.set(target.id,(damage.get(target.id)??0)+hit);
    else if('id' in target&&typeof target.id==='string')buildingDamage.set(target.id,(buildingDamage.get(target.id)??0)+hit*.3);
    else if(unit.faction==='player')enemyHp=Math.max(0,enemyHp-hit*.12);
    else baseHp=Math.max(0,baseHp-hit*.12);
    unit.cooldown=unit.kind==='artillery'?3:unit.armor>=7?2.2:1.2;
    shots.push({id:state.tick*1000+unit.id,x:unit.x,z:unit.z,toX:target.x,toZ:target.z,faction:unit.faction,life:.22});
  }
  // Towers and the command HQ provide functional, bounded point defense.
  if(Math.floor(state.tick+dt+1e-7)>Math.floor(state.tick+1e-7)){
    for(const [faction,buildings] of [['player',state.buildings],['enemy',state.opponent.buildings]] as const){
      for(const b of buildings.filter(b=>b.status==='active'&&['watchtower','hq','missile'].includes(b.kind))){
        const target=units.find(u=>u.faction!==faction&&distance(u,b)<(b.kind==='hq'?8:b.kind==='missile'?12:9));
        if(target)damage.set(target.id,(damage.get(target.id)??0)+(b.kind==='hq'?8:b.kind==='missile'?24:15)*b.level);
      }
    }
  }
  units=units.map(u=>{
    const hospital=(u.faction==='player'?state.buildings:state.opponent.buildings)
      .some(b=>b.kind==='hospital'&&b.status==='active'&&distance(b,u)<13);
    return {...u,hp:Math.max(0,Math.min(u.maxHp,u.hp-(damage.get(u.id)??0)+(hospital&&!damage.has(u.id)?3*dt:0)))};
  });
  const kills=units.filter(u=>u.hp<=0&&u.faction==='enemy').length;
  const losses=units.filter(u=>u.hp<=0&&u.faction==='player').length;
  const updateBuildings=(buildings:GameState['buildings'],hq:number)=>buildings.map(b=>({...b,
    hp:b.kind==='hq'?hq:Math.max(0,b.hp-(buildingDamage.get(b.id)??0))})).filter(b=>b.hp>0||b.kind==='hq');
  return {...state,units:units.filter(u=>u.hp>0),shots,enemyHp,baseHp,kills:state.kills+kills,losses:state.losses+losses,
    buildings:updateBuildings(state.buildings,baseHp),
    opponent:{...state.opponent,buildings:updateBuildings(state.opponent.buildings,enemyHp),
      resources:{...state.opponent.resources,steel:Math.min(99999,state.opponent.resources.steel+losses*30)}},
    resources:{...state.resources,ammo,steel:Math.min(99999,state.resources.steel+kills*30)},
    message:kills?'HOSTILE DESTROYED +30 STEEL / تدمير عدو':losses?'FRIENDLY UNIT LOST / خسارة وحدة':state.message};
}
