import type { BuildingKind, Unit, UnitKind } from './types';

export type UnitSpec={name:string;ar:string;steel:number;fuel:number;power:number;ammo:number;seconds:number;
  hp:number;damage:number;range:number;vision:number;armor:number;speed:number;building:BuildingKind;air?:boolean};
export const UNIT_SPECS:Record<UnitKind,UnitSpec>={
  infantry:{name:'RIFLE SQUAD',ar:'مشاة',steel:90,fuel:10,power:5,ammo:8,seconds:6,hp:80,damage:12,range:3.8,vision:9,armor:0,speed:1.9,building:'barracks'},
  sniper:{name:'SNIPER',ar:'قناص',steel:140,fuel:10,power:10,ammo:12,seconds:9,hp:55,damage:30,range:8,vision:12,armor:0,speed:1.4,building:'barracks'},
  engineer:{name:'COMBAT ENGINEER',ar:'مهندس ميداني',steel:130,fuel:15,power:10,ammo:8,seconds:8,hp:70,damage:8,range:3,vision:9,armor:1,speed:1.8,building:'barracks'},
  antitank:{name:'ANTI-ARMOR',ar:'مضاد دروع',steel:160,fuel:20,power:10,ammo:20,seconds:10,hp:75,damage:34,range:5.8,vision:10,armor:1,speed:1.5,building:'barracks'},
  scout:{name:'RECON VEHICLE',ar:'عربة استطلاع',steel:130,fuel:40,power:10,ammo:10,seconds:8,hp:80,damage:10,range:4.2,vision:16,armor:2,speed:3,building:'vehicleFactory'},
  tank:{name:'MAIN BATTLE TANK',ar:'دبابة قتالية',steel:230,fuel:80,power:20,ammo:20,seconds:12,hp:140,damage:26,range:5.5,vision:10,armor:7,speed:1.5,building:'factory'},
  heavy:{name:'HEAVY TANK',ar:'دبابة ثقيلة',steel:380,fuel:130,power:35,ammo:35,seconds:20,hp:240,damage:42,range:6,vision:10,armor:12,speed:1.05,building:'factory'},
  apc:{name:'ARMORED VEHICLE',ar:'مركبة مدرعة',steel:190,fuel:55,power:15,ammo:18,seconds:11,hp:140,damage:17,range:4.8,vision:11,armor:5,speed:2.2,building:'vehicleFactory'},
  artillery:{name:'SELF-PROPELLED GUN',ar:'مدفعية ذاتية',steel:320,fuel:90,power:30,ammo:40,seconds:17,hp:95,damage:48,range:11,vision:12,armor:3,speed:1.15,building:'vehicleFactory'},
  helicopter:{name:'ATTACK HELICOPTER',ar:'مروحية هجومية',steel:330,fuel:140,power:35,ammo:35,seconds:19,hp:130,damage:28,range:6.5,vision:13,armor:4,speed:2.8,building:'airfield',air:true},
  drone:{name:'RECON DRONE',ar:'طائرة استطلاع',steel:150,fuel:55,power:30,ammo:5,seconds:10,hp:45,damage:7,range:4,vision:20,armor:0,speed:3.5,building:'airfield',air:true},
};
export function makeUnit(id:number,kind:UnitKind,faction:'player'|'enemy',x:number,z:number):Unit {
  const s=UNIT_SPECS[kind];
  return {id,kind,faction,x,z,hp:s.hp,maxHp:s.hp,selected:false,order:'idle',targetX:x,targetZ:z,targetId:null,
    range:s.range,damage:s.damage,speed:s.speed,armor:s.armor,vision:s.vision,cooldown:0,path:[]};
}
