import { z } from 'zod';
import type { GameState } from './types';

const number=z.number().finite();
const hp=number.min(0).max(10000);
const id=number.int().min(1).max(100000000);
const kind=z.enum(['hq','barracks','power','refinery','factory','research','watchtower','hospital','ammo','vehicleFactory','airfield','missile','wall','command']);
const unitKind=z.enum(['tank','infantry','sniper','engineer','antitank','scout','heavy','apc','artillery','helicopter','drone']);
const researchKind=z.enum(['weapons','armor','mobility','industry','recon']);
const point=number.min(-100).max(100);
const timer=number.min(0).max(10000000);
const technologies=z.object({weapons:number.int().min(0).max(1),armor:number.int().min(0).max(1),
  mobility:number.int().min(0).max(1),industry:number.int().min(0).max(1),recon:number.int().min(0).max(1)});
const research=z.object({kind:researchKind,remaining:timer,total:timer.positive()}).refine(r=>r.remaining<=r.total).nullable();
const resources=z.object({steel:number.min(0).max(99999),fuel:number.min(0).max(99999),
  power:number.min(0).max(99999),ammo:number.min(0).max(99999)});
const building=z.object({
  id:z.string().min(1).max(32),kind,level:number.int().min(1).max(3),hp,maxHp:hp.positive(),
  x:point,z:point,status:z.enum(['active','constructing']),remaining:timer,buildSeconds:timer,
}).refine(b=>b.hp<=b.maxHp&&b.remaining<=b.buildSeconds&&
  (b.status==='active'?b.remaining===0:b.buildSeconds>0));
const training=z.array(z.object({id,kind:unitKind,remaining:timer,total:timer.positive()})
  .refine(t=>t.remaining<=t.total)).max(5);
const unit=z.object({
  id,kind:unitKind,faction:z.enum(['player','enemy']),x:point,z:point,hp,maxHp:hp.positive(),
  selected:z.boolean(),order:z.enum(['idle','move','attack']),targetX:point,targetZ:point,
  targetId:number.int().min(-2).max(100000000).nullable(),range:number.min(.1).max(30),
  damage:number.min(0).max(1000),speed:number.min(0).max(10),cooldown:number.min(0).max(10),
  armor:number.min(0).max(100),vision:number.min(0).max(100),
  path:z.array(z.object({x:point,z:point})).max(500),
}).refine(u=>u.hp<=u.maxHp);
const stateSchema=z.object({
  resources,buildings:z.array(building).max(24),
  units:z.array(unit).max(64),
  enemyHp:number.min(0).max(100),baseHp:number.min(0).max(100),
  tick:timer,message:z.string().max(240),nextBuildingId:id,nextUnitId:id,
  phase:z.enum(['playing','victory','defeat']),
  training,
  wave:number.int().min(0).max(1000000),nextWave:timer,kills:number.int().min(0).max(1000000),
  losses:number.int().min(0).max(1000000),tech:number.int().min(0).max(1),
  shots:z.array(z.object({id:number,x:point,z:point,toX:point,toZ:point,
    faction:z.enum(['player','enemy']),life:number.min(0).max(1)})).max(128),
  seed:number.int().min(0).max(100000000),
  technologies,research,reserve:number.int().min(0).max(12000),
  difficulty:z.enum(['easy','normal','hard']),biome:z.enum(['forest','desert','snow']),
  opponent:z.object({resources,buildings:z.array(building).max(24),training,technologies,research,
    reserve:number.int().min(0).max(12000),lastDecision:timer,stance:z.enum(['expand','defend','attack','rebuild'])}),
  events:z.array(z.object({time:timer,text:z.string().max(240)})).max(30),
  zones:z.array(z.object({id,x:point,z:point,owner:z.enum(['player','enemy','neutral']),
    progress:number.min(-10).max(10),reserve:number.int().min(0).max(1500)})).max(8),
}).superRefine((s,ctx)=>{
  const ids=[...s.units.map(u=>u.id),...s.training.map(t=>t.id),...s.opponent.training.map(t=>t.id)];
  const invalid=ids.length!==new Set(ids).size||ids.some(i=>i>=s.nextUnitId)||
    new Set(s.buildings.map(b=>b.id)).size!==s.buildings.length||
    s.buildings.filter(b=>b.kind==='hq').length!==1||
    s.opponent.buildings.filter(b=>b.kind==='hq').length!==1||
    s.units.filter(u=>u.faction==='enemy').length+s.opponent.training.length>24||
    s.units.filter(u=>u.faction==='player').length+s.training.length>24||
    (s.phase==='playing'&&(s.baseHp===0||s.enemyHp===0))||
    (s.phase==='victory'&&(s.enemyHp!==0||s.baseHp===0))||
    (s.phase==='defeat'&&s.baseHp!==0);
  if(invalid)ctx.addIssue({code:'custom',message:'Inconsistent mission state'});
});
export function encodeSave(state:GameState):string {
  return JSON.stringify({format:'IRON-FRONT',version:4,state:{...state,shots:[]}},null,2);
}
export function decodeSave(text:string):GameState {
  if(text.length>500000)throw new Error('Save too large');
  const envelope=z.object({format:z.literal('IRON-FRONT'),version:z.literal(4),state:stateSchema})
    .parse(JSON.parse(text));
  return {...envelope.state,shots:[]};
}
