import type { GameState, ResearchKind, UnitKind } from './types';
import { advanceConstruction } from './buildingSystem';
import { canAfford, payCost } from './economy';
import { makeUnit, UNIT_SPECS } from './unitSystem';
export { UNIT_SPECS };

export const RESEARCH:Record<ResearchKind,{en:string;ar:string;steel:number;fuel:number;power:number;seconds:number}>={
  weapons:{en:'WEAPONS +30%',ar:'قوة الأسلحة +30%',steel:250,fuel:60,power:80,seconds:25},
  armor:{en:'ARMOR +5',ar:'دروع إضافية +5',steel:220,fuel:50,power:60,seconds:22},
  mobility:{en:'MOBILITY +20%',ar:'سرعة الحركة +20%',steel:180,fuel:90,power:45,seconds:20},
  industry:{en:'PRODUCTION +25%',ar:'إنتاج الموارد +25%',steel:240,fuel:60,power:70,seconds:28},
  recon:{en:'VISION +35%',ar:'مدى الاستطلاع +35%',steel:160,fuel:40,power:90,seconds:18},
};
export function recruit(state:GameState,kind:UnitKind):GameState {
  if(state.phase!=='playing')return state;
  const spec=UNIT_SPECS[kind];
  if(!state.buildings.some(b=>b.kind===spec.building&&b.status==='active'))
    return {...state,message:'PRODUCTION BUILDING REQUIRED / مبنى الإنتاج غير جاهز'};
  if(state.training.length>=5)return {...state,message:'TRAINING QUEUE FULL / طابور التدريب ممتلئ'};
  if(state.units.filter(u=>u.faction==='player').length+state.training.length>=24)
    return {...state,message:'ARMY LIMIT 24 / الحد الأقصى 24 وحدة'};
  if(!canAfford(state.resources,spec)||state.resources.ammo<spec.ammo)
    return {...state,message:'INSUFFICIENT RESOURCES / الموارد غير كافية'};
  return {...state,resources:{...payCost(state.resources,spec),ammo:state.resources.ammo-spec.ammo},
    training:[...state.training,{id:state.nextUnitId,kind,remaining:spec.seconds,total:spec.seconds}],
    nextUnitId:state.nextUnitId+1,message:'TRAINING QUEUED / أضيفت وحدة للتدريب'};
}
export function upgrade(state:GameState,kind:ResearchKind='weapons'):GameState {
  if(state.phase!=='playing'||state.technologies[kind]||state.research)return state;
  if(!state.buildings.some(b=>b.kind==='research'&&b.status==='active'))
    return {...state,message:'RESEARCH CENTER REQUIRED / ابن مركز أبحاث أولاً'};
  const cost=RESEARCH[kind];
  if(!canAfford(state.resources,cost))return {...state,message:'INSUFFICIENT RESOURCES / الموارد غير كافية'};
  return {...state,research:{kind,remaining:cost.seconds,total:cost.seconds},resources:payCost(state.resources,cost),
    message:'RESEARCH STARTED / بدأ البحث'};
}
export function repairBase(state:GameState):GameState {
  if(state.phase!=='playing')return state;
  if(state.baseHp>=100)return {...state,message:'HQ AT FULL HEALTH / المقر سليم'};
  if(state.resources.steel<120)return {...state,message:'REPAIR REQUIRES 120 STEEL / الإصلاح يحتاج 120 حديد'};
  return {...state,baseHp:Math.min(100,state.baseHp+30),resources:{...state.resources,steel:state.resources.steel-120},
    message:'HQ REPAIRED +30 / إصلاح المقر +30'};
}
export function advanceProduction(state:GameState,dt:number):GameState {
  let next=advanceConstruction(state,dt);
  const training=next.training.map((t,i)=>{
    const producer=next.buildings.find(b=>b.kind===UNIT_SPECS[t.kind].building&&b.status==='active');
    return i===0&&producer?{...t,remaining:Math.max(0,t.remaining-dt*(1+(producer.level-1)*.2))}:t;
  });
  const completed=training[0]?.remaining<=1e-7?training.shift():null;
  if(completed)next={...next,units:[...next.units,makeUnit(completed.id,completed.kind,'player',-5,2+(completed.id%4))],
    message:'REINFORCEMENT READY / وحدة جديدة جاهزة'};
  next={...next,training};
  if(next.research&&next.buildings.some(b=>b.kind==='research'&&b.status==='active')){
    const level=next.buildings.find(b=>b.kind==='research'&&b.status==='active')!.level;
    const research={...next.research,remaining:Math.max(0,next.research.remaining-dt*(1+(level-1)*.2))};
    if(research.remaining<1e-7)next={...next,research:null,technologies:{...next.technologies,[research.kind]:1},
      tech:research.kind==='weapons'?1:next.tech,message:'RESEARCH COMPLETE / اكتمل البحث'};
    else next={...next,research};
  }
  return next;
}
