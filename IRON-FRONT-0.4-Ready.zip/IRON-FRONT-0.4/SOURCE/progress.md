Original prompt: IRON-FRONTهذا اسم لعبتي الي عم اطورها https://github.com/yarubdoktor/Yarub.git وهاد رابط مستودعي الي فيه اللعبه هل يمكنك جلب اللعبة وتكملة بناءها وبس تنتهي ارسلها لي ملف،زيب جاهز

## Scope
Continue the existing React/Three.js IRON-FRONT folder at upstream ea42b1a. Leave separate Godot ZIP history unchanged. Deliver a portable offline browser build plus complete editable source, not a Windows EXE or APK.

## Baseline
Inspected repository, source modules and original browser rendering. Dependencies installed. Original main flows documented in FLOWS.md.

## Implementation milestone
Version 0.4 is a complete single-player skirmish first release, not a claim of finished AAA commercial production. Preserve original procedural 3D art and military palette. Add actual base combat, recruitment, working support buildings, Arabic/English controls, validated file saves, accessible 2D fallback and offline single-file build.

## Expanded user brief
The user supplied an extensive AAA RTS plan and explicitly allowed a complete playable first version followed by incremental expansion. Priority shifted from free-spawn waves to a fair opponent using the same paid construction, production, research and ammunition systems.

## Implemented
Eleven unit types, fourteen structure kinds including HQ, finite stock and capture depots, A*, vision, group orders, simultaneous combat/cooldowns, armor/cover/range, destructible production, AI state machine, timed research, building levels, repair/healing, weather/lighting, synthesized audio, localized HUD and versioned validated save files. Source remains connected through original main.tsx.

## Verification so far
27 automated simulation tests pass. TypeScript and portable build pass. npm audit reports zero vulnerabilities for the installed lockfile. Real browser controls exercised for paid construction and recruitment, group movement, hold, HQ attack, pause/resume, speed, language, timed research, save download/import/rejection, help, restart cancellation and both result states. Desktop and 375px screenshots reviewed.

## Performance note
The test environment uses software WebGL and produces low 3D FPS. The game disables shadows first, then automatically switches to the playable tactical map after sustained low FPS. Hardware-accelerated 3D and physical mobile devices are not certified by this test.

## Remaining work
See FEATURE-STATUS.md for precise limitations and a future sequence. The portable artifact was verified offline, ZIP integrity passed and the extracted source passed clean installation, all 27 tests and build. Delivery is the explicitly requested downloadable archive, not a public website. No remote git push is authorized or performed.
