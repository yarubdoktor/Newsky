import test from 'node:test';
import assert from 'node:assert/strict';
import { newGame } from '../src/game/initialState';
import { advanceSeconds,stepGame } from '../src/game/simulation';
import { advanceProduction,recruit,repairBase,upgrade } from '../src/game/productionSystem';
import { advanceCombat,holdSelected,issueAttack,issueMove } from '../src/game/combatSystem';
import { queueBuilding,upgradeBuilding } from '../src/game/buildingSystem';
import { decodeSave,encodeSave } from '../src/game/saveSystem';
import { makeUnit,UNIT_SPECS } from '../src/game/unitSystem';
import { advanceAI } from '../src/game/aiSystem';
import { blocked,findPath } from '../src/game/navigation';
import { visibleTo } from '../src/game/visibility';
import type { BuildingKind,GameState } from '../src/game/types';

function withBuilding(state:GameState,kind:BuildingKind):GameState {
  const next=queueBuilding(state,kind);
  return {...next,buildings:next.buildings.map(b=>({...b,status:'active',remaining:0}))};
}
function isolated():GameState {
  const state=newGame();
  return {...state,units:state.units.filter(u=>u.faction==='player'),nextWave:9999,
    opponent:{...state.opponent,lastDecision:9999}};
}
test('fresh missions are independent and initial sides have identical resources and unit stats',()=>{
  const a=newGame(),b=newGame();a.resources.steel=0;assert.equal(b.resources.steel,1100);
  assert.deepEqual(b.resources,b.opponent.resources);
  assert.deepEqual(b.units.slice(0,3).map(u=>[u.kind,u.hp,u.damage]),b.units.slice(3).map(u=>[u.kind,u.hp,u.damage]));
});
test('construction deducts costs immediately, completes on time and produces real income',()=>{
  let state=queueBuilding(newGame(),'power');assert.equal(state.resources.steel,920);
  assert.equal(state.buildings.at(-1)?.status,'constructing');
  for(let i=0;i<120;i++){state=advanceProduction(state,.1);state={...state,tick:Math.round((state.tick+.1)*10)/10};}
  assert.equal(state.buildings.at(-1)?.status,'active');
  assert(state.resources.power>260);
});
test('unaffordable construction and structure limits cannot overspend',()=>{
  const state=newGame();state.resources.steel=0;
  const next=queueBuilding(state,'factory');assert.equal(next.buildings.length,2);assert.equal(next.resources.steel,0);
  let towers=newGame();towers.resources.steel=9999;
  for(let i=0;i<5;i++)towers=queueBuilding(towers,'watchtower');
  assert.equal(towers.buildings.filter(b=>b.kind==='watchtower').length,4);
});
test('recruitment has production prerequisites, exact payment and sequential training',()=>{
  let state=isolated();assert.equal(recruit(state,'tank').training.length,0);
  state=recruit(recruit(state,'infantry'),'infantry');
  assert.equal(state.training.length,2);assert.equal(state.resources.steel,920);
  state=advanceSeconds(state,6.1);assert.equal(state.units.length,4);assert.equal(state.training.length,1);
  assert(state.training[0].remaining>5.8);
});
test('training and research stop when their building is destroyed',()=>{
  let state=recruit(isolated(),'infantry');
  state={...state,buildings:state.buildings.filter(b=>b.kind!=='barracks')};
  const next=advanceSeconds(state,10);assert.equal(next.training[0].remaining,6);
});
test('recruitment caps queues and armies',()=>{
  let state=isolated();state.resources={steel:9999,fuel:9999,power:9999,ammo:9999};
  for(let i=0;i<9;i++)state=recruit(state,'infantry');assert.equal(state.training.length,5);
});
test('all eleven unit types are connected to real production prerequisites',()=>{
  let state=isolated();state.resources={steel:99999,fuel:99999,power:99999,ammo:99999};
  for(const kind of ['factory','vehicleFactory','airfield'] as const)state=withBuilding(state,kind);
  for(const kind of Object.keys(UNIT_SPECS) as (keyof typeof UNIT_SPECS)[]){
    const next=recruit({...state,training:[]},kind);assert.equal(next.training[0].kind,kind);
  }
});
test('movement is bounded, uses distinct formation destinations and correct x/z axes',()=>{
  let state=isolated();state.units=state.units.map(u=>({...u,selected:true}));
  state=issueMove(state,999,-999);
  assert(state.units.every(u=>u.targetX<=24&&u.targetZ>=-13));
  const before=state.units[0];state=advanceCombat(state,.1);
  assert.notEqual(state.units[0].x,before.x);
  assert.equal(issueMove(state,NaN,0),state);
});
test('A* avoids blocked structure/rock cells and aerial units take direct routes',()=>{
  const state=newGame();const unit=makeUnit(500,'infantry','player',1,-2);
  const path=findPath(state,unit,{x:10,z:-2});assert(path.length>2);
  assert(path.every(p=>!blocked(state,p)));
  assert.deepEqual(findPath(state,makeUnit(501,'drone','player',1,-2),{x:10,z:-2}),[{x:10,z:-2}]);
});
test('hold cancels movement and retains selection',()=>{
  let state=isolated();state.units[0].selected=true;state=holdSelected(issueMove(state,3,4));
  assert.equal(state.units[0].order,'idle');assert.equal(state.units[0].selected,true);
});
test('simultaneous fire applies both damage AND cooldown; ammunition is consumed symmetrically',()=>{
  let state=newGame();state.units=[makeUnit(1,'tank','player',0,0),makeUnit(101,'tank','enemy',2,0)];
  state=advanceCombat(state,.1);
  assert(state.units.every(u=>u.hp<u.maxHp&&u.cooldown>0));
  assert.equal(state.resources.ammo,357);assert.equal(state.opponent.resources.ammo,357);
  const health=state.units.map(u=>u.hp);state=advanceCombat(state,.1);
  assert.deepEqual(state.units.map(u=>u.hp),health);
});
test('weapons cannot fire without ammunition',()=>{
  let state=newGame();state.units=[makeUnit(1,'tank','player',0,0),makeUnit(101,'tank','enemy',2,0)];
  state.resources.ammo=0;state.opponent.resources.ammo=0;
  state=advanceCombat(state,.1);assert(state.units.every(u=>u.hp===u.maxHp));
});
test('idle units automatically defend against nearby visible enemies',()=>{
  let state=newGame();state.units=[makeUnit(1,'infantry','player',0,0),makeUnit(101,'infantry','enemy',2,0)];
  state=advanceCombat(state,.1);assert(state.units[1].hp<80);
});
test('attack HQ damages the base, victory freezes the entire simulation',()=>{
  let state=isolated();state.units=[{...makeUnit(1,'heavy','player',21,1),selected:true}];
  state.opponent.buildings=state.opponent.buildings.filter(b=>b.kind==='hq');state.enemyHp=.1;
  state=stepGame(issueAttack(state,-1));assert.equal(state.phase,'victory');assert.equal(state.enemyHp,0);
  assert.equal(stepGame(state),state);
});
test('defeat occurs when enemy units destroy the friendly HQ',()=>{
  let state=isolated();state.units=[{...makeUnit(101,'heavy','enemy',-10,4),order:'attack',targetId:-2}];
  state.buildings=state.buildings.filter(b=>b.kind==='hq');state.baseHp=.1;
  state=stepGame(state);assert.equal(state.phase,'defeat');
});
test('ordinary enemy buildings can be destroyed and removed',()=>{
  let state=isolated();const target=state.opponent.buildings.find(b=>b.kind==='barracks')!;
  target.hp=.1;state.units=[{...makeUnit(1,'heavy','player',target.x-2,target.z),selected:true}];
  state=advanceCombat(issueAttack(state,-1),.1);
  assert(!state.opponent.buildings.some(b=>b.kind==='barracks'));
});
test('hospital restores nearby damaged units; engineer restores teammates',()=>{
  let state=withBuilding(isolated(),'hospital');state.units[0]={...state.units[0],x:-9,z:4,hp:30};
  const healed=advanceCombat(state,1);assert(healed.units[0].hp>30);
  state=isolated();state.units=[makeUnit(1,'engineer','player',0,0),{...makeUnit(2,'tank','player',1,0),hp:30}];
  assert(stepGame(state).units[1].hp>30);
});
test('research costs resources, takes time and applies a persistent technology',()=>{
  let state=withBuilding(isolated(),'research');state.resources={steel:9999,fuel:9999,power:9999,ammo:9999};
  state=upgrade(state,'weapons');assert.equal(state.technologies.weapons,0);assert.equal(state.resources.steel,9749);
  state=advanceSeconds(state,25.1);assert.equal(state.technologies.weapons,1);assert.equal(state.research,null);
});
test('industrial reserves are finite and cannot become negative',()=>{
  let state=isolated();state.reserve=3;
  state=advanceSeconds(state,5);assert.equal(state.reserve,0);assert.equal(state.resources.steel,1103);
});
test('enemy shares paid construction and training; there are no free reinforcement spawns',()=>{
  let state=newGame();state.tick=4;
  const before=state.opponent.resources.steel;state=advanceAI(state,.1);
  assert(state.opponent.resources.steel<before);
  assert(state.opponent.buildings.some(b=>b.status==='constructing'));
  state=newGame();state.tick=100;state.opponent.resources={steel:0,fuel:0,power:0,ammo:0};state.opponent.reserve=0;
  const count=state.units.length;state=advanceAI(state,.1);assert.equal(state.units.length,count);
  assert.equal(state.opponent.training.length,0);
});
test('AI builds, produces and changes strategy during an autonomous simulation',()=>{
  const state=advanceSeconds(newGame(),65);
  assert(state.opponent.buildings.length>2);
  assert(state.nextUnitId>104);
  assert(state.opponent.resources.steel<2000);
});
test('fog-of-war visibility is expanded by reconnaissance research',()=>{
  const state=isolated();state.units=[makeUnit(1,'infantry','player',0,0)];
  assert.equal(visibleTo(state,'player',{x:11,z:0}),false);
  state.technologies.recon=1;assert.equal(visibleTo(state,'player',{x:11,z:0}),true);
});
test('strategic depots capture after sustained presence and pay finite steel income',()=>{
  let state=isolated();state.units=[makeUnit(1,'infantry','player',1,-8)];
  state=advanceSeconds(state,12);assert.equal(state.zones[0].owner,'player');
  assert(state.zones[0].reserve<1500);
});
test('repair and building upgrades are paid and have tangible effects',()=>{
  let state=isolated();state.baseHp=50;
  state=repairBase(state);assert.equal(state.baseHp,80);assert.equal(state.resources.steel,980);
  state=upgradeBuilding(state,'BLD-000');assert.equal(state.buildings[1].level,2);
  assert.equal(state.buildings[1].status,'constructing');
});
test('save round trip includes opponent, orders, research and map settings',()=>{
  const state=advanceSeconds(newGame('snow','hard'),20);
  const loaded=decodeSave(encodeSave(state));
  assert.deepEqual(loaded,{...state,shots:[]});
});
test('save rejects corrupted, oversized, invalid enum, duplicate IDs and nonfinite input',()=>{
  const state=newGame(),data=JSON.parse(encodeSave(state));
  for(const text of ['not json','x'.repeat(500001),JSON.stringify({...data,version:9})])assert.throws(()=>decodeSave(text));
  data.state.units[0].kind='spaceship';assert.throws(()=>decodeSave(JSON.stringify(data)));
  data.state.units[0].kind='tank';data.state.units[1].id=1;assert.throws(()=>decodeSave(JSON.stringify(data)));
  data.state.units[1].id=2;data.state.resources.steel=null;assert.throws(()=>decodeSave(JSON.stringify(data)));
});
test('simulation is deterministic and does not mutate the input state',()=>{
  const first=newGame(),baseline=JSON.stringify(first),a=advanceSeconds(first,10),b=advanceSeconds(newGame(),10);
  assert.deepEqual(a,b);assert.equal(JSON.stringify(first),baseline);
});
