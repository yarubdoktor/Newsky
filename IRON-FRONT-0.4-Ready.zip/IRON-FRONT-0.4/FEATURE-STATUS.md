# IRON FRONT 0.4: status against the development brief

This document distinguishes working implementation from future production work. The delivered game is a complete one-sector solo skirmish loop with paid opposing economies, not a finished AAA strategy title.

## Implemented and integrated

| Area | Delivered behavior |
|---|---|
| Entry and UI | Existing React entry remains connected; Arabic/English briefing, biome and difficulty choices, instructions, tabs, pause, speed, restart and results |
| World | Procedural 3D battlefield, orbit/pan/zoom, climate colors, trees, mountain silhouettes, road, two bases, rocks, two central depots |
| Climate | Forest/desert/snow variants, snow/rain particles, timed lighting cycle; snow and desert alter ground speed |
| Building kinds | HQ, barracks, armored factory, vehicle works, airfield, ammo depot, fuel refinery/depot, power, research, watchtower, missile defense, barrier section, command relay, hospital |
| Building rules | Paid costs and timers, bounded slots/limits, health and removal on destruction, paid level upgrades, production prerequisites |
| Unit kinds | Infantry, sniper, combat engineer, anti-armor, recon vehicle, main tank, heavy tank, armored vehicle, artillery, attack helicopter, recon drone |
| Unit rules | Health, armor, speed, vision, range, damage, individual cooldown, ammo use, training cost/time, prerequisite and queue/army caps |
| Commands | Single selection, Shift-add, roster multi-select, select-all, group movement formations, local defense, targeted unit attack, attack HQ, hold and retreat |
| Navigation | Fixed-grid A* around buildings and two rock outcrops; aerial units use direct paths |
| Combat | Simultaneous damage/cooldown, range-based deterministic damage reduction, armor and anti-armor penetration, forest infantry cover modifier, destructible structures |
| Detection | Units outside sensor coverage are hidden from the field and tactical map; research and recon units improve vision |
| Economy | Steel, fuel, power, ammunition; finite industrial reserves, building-based production, finite capturable steel depots, symmetrical salvage rewards |
| Opponent | Independent base, resources, paid building/training/research, finite reserve, ammunition use, expand/defend/attack/rebuild states |
| Difficulty | Changes AI decision frequency and assault cadence, not hidden resource grants, free units or stat multipliers |
| Research | Five timed paid technologies: weapons, armor, mobility, industry, reconnaissance |
| Support | Hospital recovery, engineer teammate recovery, paid HQ repair, level-scaled defensive fire |
| Persistence | JSON file save/load including both sides, orders, buildings, training, research, settings and capture zones |
| Ending | Destroy enemy HQ to win; friendly HQ destruction causes defeat; terminal simulation freezes and restart is available |
| Presentation | Distinct procedural silhouettes by role, health bars, tracers/hit flashes, synthesized shot/explosion tones, HUD/minimap/event log |
| Delivery | Offline single HTML, complete TypeScript source, lockfile, automated tests, documentation and third-party notices |

## Implemented in simplified form

- **Graphics:** low-poly procedural geometry, not photorealistic authored AAA models, skeletal animations or cinematics.
- **Maps:** three climate/terrain variants of the same tactical sector layout, not a vast open world or three independent campaign maps.
- **Cover and accuracy:** deterministic damage modifiers, not line-of-sight raycasts, ballistic simulation or a full positional cover system.
- **Fog of war:** sensor-based hidden enemy units and structures, not a persistent explored-terrain/fog texture.
- **AI:** an inspectable local rule/state machine, not learning AI or a full tactical planner. It uses paid production and can save for infrastructure, defend visible threats and rebuild lost production.
- **Air units:** attack helicopters and armed recon drones fly over obstacles; there is no landing, refueling, passenger transport or realistic air/ground targeting matrix.
- **Health:** headquarters use a separate 0–100 health track. Other structures use their own HP; levels improve durability, economy, production speed or defensive fire by role.
- **Fortification:** constructed barrier buildings are obstacles with destructible HP. The surrounding perimeter fence is environmental decoration, not individually destructible wall segments.
- **Audio:** synthesized combat cues, not recorded vehicle engines, spatial battle ambience, voice acting or music.
- **Difficulty:** three meaningful planning presets, not extensive competitive balance testing.
- **Performance:** adaptive shadow disabling and tactical-mode fallback; no hardware-GPU performance guarantee or tested native-device matrix.

## Not yet implemented

- Narrative campaign, persistent mission progression, scripted mission chains or campaign selection.
- Multiplayer, network synchronization, alliances or multiple independent opponents.
- Realistic cities, industrial districts, deformable terrain, building rubble, volumetric smoke, fire propagation or full weather simulation.
- A military-currency/credits resource and a separate industrial-materials currency; this release uses four resource counters plus finite industrial stock.
- Special forces, light/advanced tank subtypes, rocket artillery, supply trucks, transport helicopters or fighter jets.
- Passenger loading/unloading, supply lines, unit fuel consumption or maintenance attrition.
- Drag-box selection, customizable key binding, full accessibility settings or a complete settings menu.
- Tech-tree dependencies between multiple tiers, beyond prerequisite structures and five one-level timed technologies.
- Worker-based economy, fully dynamic navmesh, unit-unit collision avoidance or multithreaded ECS/Web Workers.
- Cloud/automatic saves, compatibility with old v3 localStorage saves or a backend.
- Windows EXE, Android APK, iOS app, controller support, commercial certification or production anti-cheat.

## Suggested next development sequence

- Replace the static perimeter with individual destructible, navigable fortification segments and add direct building-target commands.
- Add separation steering and richer navigation/terrain/line-of-sight tests before increasing army or map size.
- Expand the opponent's scouting, production composition and strategic objectives, then benchmark complete matches.
- Build a campaign and two genuinely different layouts using the verified simulation core.
- Add authored licensed vehicle/infantry assets, animations, spatial audio and effects with a clear mobile GPU budget.
- Introduce multiplayer only after defining deterministic authority, save/version migration and synchronization rules.
