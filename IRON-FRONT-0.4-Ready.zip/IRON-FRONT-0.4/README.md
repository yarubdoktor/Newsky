# IRON FRONT: TOTAL DOMINATION

Version 0.4 is a playable single-player RTS skirmish, continuing the existing React/TypeScript project rather than replacing it with an unrelated game. It is an integrated first release, not a claim that the full AAA production brief is finished.

## Play the portable release

Extract the ZIP and open `PLAY-IRON-FRONT.html` in a current desktop browser. The HTML contains the runtime, procedural graphics, styles and fonts, so it can run offline without npm or a server.

Enable browser hardware acceleration for the 3D battlefield. A fully playable tactical 2D mode is available and is selected automatically on small screens or sustained low 3D performance. The package is a browser game plus editable source, not a native Windows executable or Android application.

## Develop

From the source directory, use Node.js 20.19+:

```sh
npm ci
npm test
npm run dev
npm run build
```

The build produces one portable `dist/index.html`. `npm ci` needs internet on first setup; the compiled game does not.

## Included gameplay

- Three terrain/climate variants of the tactical sector: forest, desert and snow.
- Orbit, pan, zoom, day/night lighting, precipitation, tracers and generated sound effects.
- Four resource currencies, finite industrial reserves and two capturable steel depots.
- Fourteen structure kinds including the HQ, with construction timers, health, destruction and paid upgrades.
- Eleven unit kinds: infantry, sniper, engineer, anti-armor, scout, main battle tank, heavy tank, armored vehicle, artillery, attack helicopter and recon drone.
- Paid, prerequisite-driven sequential recruitment, capped queues and army sizes.
- Group move, attack, hold and retreat orders, A* navigation, vision limits, armor and deterministic range/cover modifiers.
- An opponent with its own resources, buildings, training, research and decision-state machine, using the same economic code and costs as the player.
- Timed weapons, armor, mobility, industry and reconnaissance research.
- Victory/defeat, restart, pause, simulation speed and Arabic/English UI.
- Validated versioned JSON save export/import, including the opponent's full state.

## Controls

Select a friendly unit, Shift-click to add units, or toggle members in the roster. Select Move then click the ground or minimap, click a visible hostile to attack, or issue Attack HQ to advance through enemy defenses. Hold stops movement but retains local automatic defense.

`A` selects all, `M` toggles destination mode, `Space` pauses/resumes and `Esc` cancels destination mode. Drag to orbit and use the wheel or pinch to zoom the 3D camera. Sound starts only after clicking SFX, in the header or Support panel.

## Saves and privacy

Save exports a JSON file; loading restores it paused for review. There is no account, analytics, cloud save, automatic save, external AI service or required game-network connection.

Version 3 browser-storage saves from the original project are left untouched but are not imported by the new version 4 file format. Save before closing the page. The validator rejects oversized, corrupted, invalid-enum and inconsistent-ID saves.

## Engine layout

| File | Responsibility |
|---|---|
| `simulation.ts` | Fixed-step orchestration, capture zones, game-over and events |
| `aiSystem.ts` | Mirrored same-rules economic adapter and opponent state machine |
| `navigation.ts` | Bounded A* and ground/air movement |
| `visibility.ts` | Unit and structure sensor queries |
| `combatSystem.ts` | Orders, simultaneous damage, cooldowns, ammunition and defenses |
| `economy.ts` | Production, affordability and payment |
| `buildingSystem.ts` | Slots, limits, construction and upgrades |
| `productionSystem.ts` | Training, timed research, repair |
| `unitSystem.ts` | Unit definitions and instantiation |
| `saveSystem.ts` | Versioned export and schema-validated import |
| `audioSystem.ts` | User-initiated synthesized effects |
| `FortressScene.tsx` | Procedural Three.js presentation |
| `TacticalMap.tsx` | Playable lightweight map and minimap |
| `App.tsx`, `i18n.ts` | Entry integration, UI and localization |

No Godot archive in the parent repository is modified. Nothing is pushed to the remote repository by this delivery.

## Status and limitations

See `FEATURE-STATUS.md` for the exact scope against the requested roadmap, `TEST-REPORT.md` for verification and `README-AR.md` for the Arabic player guide. Third-party notices accompany the release; no new license is assigned to the owner's original project.
