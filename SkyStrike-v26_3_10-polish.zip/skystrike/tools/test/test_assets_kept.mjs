// حارس الأصول: لا يجوز فقدان أي نموذج GLB/bin أو خريطة أصلية (طلب المالك). يقارن sha256 بالسجل.
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const root = new URL('../..', import.meta.url).pathname;
const man = JSON.parse(fs.readFileSync(new URL('./assets_manifest.json', import.meta.url)));
let bad = 0;
for(const [f, m] of Object.entries(man)){
  const p = path.join(root, f); const ex = fs.existsSync(p);
  const same = ex && crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex') === m.sha256;
  if(!same){ bad++; console.log('  ✗ '+f+(ex ? ' (تغيّر)' : ' (مفقود)')); }
}
console.log((bad ? '  ✗ ' : '  ✓ ')+Object.keys(man).length+' أصلاً أصلياً محفوظاً بلا تغيير');
if(bad) process.exit(1);
