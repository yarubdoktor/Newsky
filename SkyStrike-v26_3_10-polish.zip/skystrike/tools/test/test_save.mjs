/* بند M4 (قاعدة R9): ترحيل الحفظ القديم (موجات/أنماط/حملة) إلى بنية المهمات بلا فقد ما له قيمة. دالة صرفة. */
import {migrate, MV, f35Refund} from '../../src/save_migrate.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const legacy = () => ({v:2, coins:1234, xp:560, gems:7, sel:'mig29', pl:{f35:3, mig29:2}, gun:2, msl:3, multi:1, bomb:0,
  name:'Ali', scores:[{n:'Ali', s:900, l:3}], sk:{f35:'gold'}, sko:{f35:['gold']}, lg:{last:'2026-01-01', st:2},
  wk:{k:'x', l:[{k:'kj', n:3, p:1, c:0, r:100, g:0}]}, mis:{d:'2026-01-01', l:[]},
  st:{n:12, c:900}, cp:7, mode:'defend',
  map:'desert', q:'high', lang:'ar', sens:1.2});

console.log('ترحيل حفظ قديم:');
let s = migrate(legacy());
ok(s.coins === 1234+600 && s.xp === 560 && s.gems === 7, 'العملات (+تعويض ترقية F-35 المستوى 3 = 600) وXP والجواهر محفوظة');
ok(s.sel === 'mig29' && s.name === 'Ali', 'الطائرة المختارة والاسم محفوظان');
ok(s.pl.mig29 === 2 && !('f35' in s.pl) && s.gun === 2 && s.msl === 3 && s.multi === 1, 'الطائرات والأسلحة محفوظة');
ok(s.sk.mig29 === 'gold' && !('f35' in s.sk) && s.retired.f35.sk === 'gold' && s.retired.f35.sko.f35[0] === 'gold', 'ألوان F-35 تنتقل إلى MiG-29 وتُؤرشف');
ok(s.lg.st === 2 && s.st.n === 12, 'تسجيل الدخول والإحصاءات محفوظة');
ok(s.map === 'desert' && s.q === 'high' && s.lang === 'ar' && s.sens === 1.2, 'الإعدادات والخريطة محفوظة');
ok(s.scores.length === 1 && s.scores[0].s === 900, 'أعلى النتائج القديمة تبقى مخزّنة');
ok(s.cpOld === 7 && s.cp === 0, 'تقدّم الحملة القديم: يُحفظ بـ cpOld ويبدأ cp من 0');
ok(!('mode' in s) && !('mis' in s) && !('wk' in s), 'حقول النمط والمهام اليومية والأسبوعية تُزال');
ok(JSON.stringify(s.ms) === '{}' && s.mv === MV, 'ms فارغ ونسخة البنية');

console.log('سلامة الترحيل:');
const again = JSON.stringify(migrate(JSON.parse(JSON.stringify(s))));
ok(again === JSON.stringify(s), 'الترحيل مكرّر لا يغيّر شيئاً (idempotent)');
s = migrate({coins:5, mv:2, cp:2, ms:{m0:{stars:3, best:2000, bt:120, n:4, done:true}}});
ok(s.cp === 2 && s.ms.m0.stars === 3 && s.ms.m0.done && !('cpOld' in s), 'حفظ حديث لا يُمسّ');
s = migrate({coins:5, mv:2, ms:{m0:{stars:99, best:-1, bt:'x', n:'y', done:1}, bad:7, nul:null}});
ok(s.ms.m0.stars === 3 && s.ms.m0.best === 0 && s.ms.m0.bt === 0 && s.ms.m0.n === 0 && s.ms.m0.done === true &&
  !('bad' in s.ms) && !('nul' in s.ms), 'إدخالات ms التالفة تُنظّف');
s = migrate({coins:1, ms:'garbage'});
ok(typeof s.ms === 'object' && Object.keys(s.ms).length === 0 && s.cp === 0, 'ms نصي تالف ← كائن فارغ');
s = migrate({coins:1, cp:-3, mv:2});
ok(s.cp === 0, 'cp سالب ← 0');
ok(migrate(null) === null && migrate(undefined) === undefined, 'null/undefined لا ترمي خطأ');
s = migrate({coins:'x'});
ok(s.mv === MV, 'حفظ بقيمة غريبة يمرّ بلا خطأ');

console.log('ترحيل M8 (F-35 ← MiG-29، قاعدة R9):');
ok(f35Refund(1) === 0 && f35Refund(2) === 200 && f35Refund(3) === 600 && f35Refund(10) === 9000, 'تعويض الترقيات: 0/200/600/9000 للمستويات 1/2/3/10');
s = migrate({v:2, mv:1, coins:100, sel:'f35', pl:{f35:1}, gun:1});
ok(s.sel === 'mig29' && s.pl.mig29 === 1 && !('f35' in s.pl) && s.coins === 100, 'مستخدم F-35 مستوى 1: ينتقل لـ MiG-29 بلا تعويض (سعر F-35 كان 0)');
s = migrate({v:2, mv:1, coins:50, sel:'f35', pl:{f35:5, su57:2}, sk:{f35:'crimson', su57:'gold'}, sko:{'f35:crimson':1, 'su57:gold':1}});
ok(s.coins === 50+f35Refund(5) && s.coins === 50+200+400+600+800, 'F-35 مستوى 5 يعوَّض ترقياته (2000) فوق العملات');
ok(s.sel === 'mig29' && s.pl.su57 === 2 && s.pl.mig29 === 1, 'Su-57 المملوكة تبقى، وMiG-29 تُمنح مجاناً');
ok(s.sko['mig29:crimson'] === 1 && !('f35:crimson' in s.sko) && s.sko['su57:gold'] === 1 && s.sk.mig29 === 'crimson' && s.sk.su57 === 'gold', 'لون F-35 ينتقل لـ MiG-29 وألوان Su-57 لا تُمسّ');
ok(s.retired.f35.lv === 5 && s.retired.f35.refund === 2000 && s.retired.f35.sko['f35:crimson'] === 1, 'بيانات F-35 القديمة مؤرشفة بـ retired.f35');
s = migrate({v:2, mv:1, coins:10, sel:'su57', pl:{f35:4, su57:3, mig29:2}});
ok(s.sel === 'su57' && s.pl.mig29 === 2 && s.pl.su57 === 3, 'من يطير بـ Su-57 يبقى عليها ومستوى MiG-29 المملوكة لا يُخفَّض');
s = migrate({coins:10, sel:'f35', pl:{f35:2}, cp:4});
ok(s.mv === MV && s.sel === 'mig29' && s.coins === 10+200 && s.cpOld === 4, 'حفظ قديم جداً (بلا mv) يمرّ بالخطوتين معاً');
s = migrate({v:2, mv:1, coins:7, sel:'nope', pl:{}});
ok(s.sel === 'mig29' && s.pl.mig29 === 1 && !('retired' in s) && s.coins === 7, 'حفظ بلا F-35 وبطائرة غير معروفة: يصحَّح بلا تعويض');
s = migrate({v:2, mv:1, coins:100, sel:'f35', pl:{f35:3}});
const s2 = JSON.stringify(migrate(JSON.parse(JSON.stringify(s))));
ok(s2 === JSON.stringify(s) && s.coins === 700, 'تكرار الترحيل لا يعوّض مرتين');

console.log('مفتاح التخزين (قاعدة R9):');
import {readFileSync} from 'node:fs';
const src = readFileSync(new URL('../../src/save.js', import.meta.url), 'utf8');
ok(src.includes("'skystrike_v2'") && src.includes("'skystrike_v1'"), 'المفتاحان skystrike_v2 و v1 كما هما');
ok(/migrate\(s\)/.test(src) && src.indexOf('migrate(s)') < src.indexOf('Object.assign') + 60, 'load() يرحّل قبل الدمج');

if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
