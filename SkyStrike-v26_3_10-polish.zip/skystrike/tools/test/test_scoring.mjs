/* بند M4: التقييم (نجوم/نقاط) · المكافأة · تقدّم المهمات والفتح · الإحاطة · تقرير التقييم. كلها دوال صرفة. */
import {evaluate,rewardFor,SCORE,CLEAN_HP} from '../../src/mission/scoring.js';
import {record,chain,isUnlocked,nextIndex,summary,normalizeMs} from '../../src/mission/progress.js';
import {briefOf,threatsOf} from '../../src/mission/briefing.js';
import {makeReport} from '../../src/mission/debrief.js';
import {createRuntime} from '../../src/mission/mission_runtime.js';
import {MISSIONS} from '../../src/mission/mission_defs.js';
import {UI_TEXT} from '../../src/mission/ui_text.js';
import {MISSION_TEXT} from '../../src/mission/mission_text.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };

const defOpt = {id:'a', par:100, reward:{c:100, g:5, xp:200}, objectives:[{id:'o'}, {id:'s', optional:true}]};
const defNoOpt = {id:'b', par:100, reward:{c:100, g:0, xp:50}, objectives:[{id:'o'}]};
const objs = (o, s) => [{id:'o', status:o, optional:false}, {id:'s', status:s, optional:true}];
const run = (o = {}) => ({win:true, t:80, hpFrac:.9, allyLost:0, ff:0, score:400,
  objectives:objs('done', 'done'), ...o});
const crit = r => r.criteria.map(c => c.ok ? 1 : 0).join('');

console.log('التقييم:');
let r = evaluate(defOpt, run());
ok(r.stars === 3 && crit(r) === '111', 'نجاح كامل ونظيف = 3 نجوم');
r = evaluate(defOpt, run({objectives:objs('done', 'failed')}));
ok(r.stars === 2 && r.criteria[1].k === 'opt' && !r.criteria[1].ok, 'ثانوي فاشل = لا نجمة ثانية');
r = evaluate(defNoOpt, run({t:120, objectives:[{id:'o', status:'done'}]}));
ok(r.criteria[1].k === 'par' && !r.criteria[1].ok && r.stars === 2, 'بلا ثانوي: تجاوز الزمن المرجعي يخسر النجمة');
r = evaluate(defNoOpt, run({t:100, objectives:[{id:'o', status:'done'}]}));
ok(r.criteria[1].ok, 'الزمن = المرجعي بالضبط يكفي');
r = evaluate(defOpt, run({allyLost:1}));
ok(!r.criteria[2].ok && r.stars === 2, 'خسارة وحدة صديقة تلغي نجمة النظافة');
r = evaluate(defOpt, run({ff:1}));
ok(!r.criteria[2].ok, 'النيران الصديقة تلغي نجمة النظافة');
r = evaluate(defOpt, run({hpFrac:CLEAN_HP-.01}));
ok(!r.criteria[2].ok, 'صحة أقل من الحد تلغي نجمة النظافة');
r = evaluate(defOpt, run({hpFrac:CLEAN_HP}));
ok(r.criteria[2].ok, 'صحة تساوي الحد تكفي');
r = evaluate(defOpt, run({win:false}));
ok(r.stars === 0 && !r.win && !r.score.win && !r.score.time && !r.score.hp, 'الفشل: صفر نجوم وبلا مكافآت');
r = evaluate(defOpt, run({quit:true}));
ok(r.quit && !r.win && r.stars === 0, 'الانسحاب لا يُحسب نجاحاً');

console.log('النقاط:');
r = evaluate(defOpt, run());
ok(r.score.combat === 400 && r.score.win === SCORE.win && r.score.time === 20*SCORE.perSecond, 'قتال + نجاح + زمن');
ok(r.score.hp === Math.round(.9*SCORE.hp) && r.score.ally === 0, 'مكافأة الصحة وبلا خسائر');
ok(r.score.total === r.score.combat+r.score.win+r.score.time+r.score.hp+r.score.ally, 'المجموع = مجموع البنود');
r = evaluate(defOpt, run({t:150}));
ok(r.score.time === 0, 'تجاوز الزمن لا يعطي سالباً');
r = evaluate(defOpt, run({allyLost:2}));
ok(r.score.ally === -2*SCORE.allyLost && r.score.total > 0, 'عقوبة الخسائر الصديقة');
r = evaluate(defOpt, run({allyLost:99, score:10, win:false}));
ok(r.score.total === 0 && r.score.ally <= 0, 'المجموع لا ينزل تحت الصفر');
r = evaluate(defOpt, run({score:-50}));
ok(r.score.combat === 0, 'نقاط القتال لا تكون سالبة');

console.log('المكافأة:');
const w3 = evaluate(defOpt, run());
let rw = rewardFor(defOpt, undefined, w3);
ok(rw.first && rw.c === 100+3*20 && rw.g === 5 && rw.xp === 200 && rw.newStars === 3, 'أول نجاح: كاملة + نجوم جديدة');
rw = rewardFor(defOpt, {done:true, stars:3}, w3);
ok(!rw.first && rw.c === 25 && rw.g === 0 && rw.xp === 50 && rw.newStars === 0, 'الإعادة: ربع المكافأة بلا جواهر');
rw = rewardFor(defOpt, {done:true, stars:1}, w3);
ok(rw.newStars === 2 && rw.c === 25+2*20, 'إعادة بنجوم جديدة تزيد المكافأة');
rw = rewardFor(defOpt, undefined, evaluate(defOpt, run({win:false})));
ok(rw.c === 0 && rw.g === 0 && rw.xp === 0, 'الفشل بلا مكافأة مهمة');

console.log('التقدّم والفتح:');
const D = [{id:'a'}, {id:'b'}, {id:'c'}];
const win = (s = 3) => ({win:true, quit:false, stars:s, t:90.4, score:{total:1500}});
const ms = {};
ok(isUnlocked(ms, D, 0) && !isUnlocked(ms, D, 1) && nextIndex(ms, D) === 0, 'تبدأ الأولى فقط مفتوحة');
let e = record(ms, 'a', {win:false, quit:false, stars:0, t:30, score:{total:200}});
ok(e.n === 1 && !e.done && e.best === 200 && !isUnlocked(ms, D, 1), 'الفشل يزيد المحاولات فقط');
e = record(ms, 'a', win(2));
ok(e.done && e.stars === 2 && e.bt === 90 && e.best === 1500 && isUnlocked(ms, D, 1), 'النجاح يفتح التالية');
e = record(ms, 'a', win(1));
ok(e.stars === 2 && e.n === 3, 'النجوم لا تنقص بإعادة أضعف');
e = record(ms, 'a', {...win(3), t:60, score:{total:900}});
ok(e.stars === 3 && e.bt === 60 && e.best === 1500, 'أفضل نجوم وأقصر زمن وأعلى نقاط');
e = record(ms, 'b', {win:false, quit:true, stars:0, t:5, score:{total:999}});
ok(e.best === 0 && e.n === 1, 'الانسحاب لا يسجّل نقاطاً');
ok(chain(ms, D) === 1 && nextIndex(ms, D) === 1 && !isUnlocked(ms, D, 2), 'السلسلة والمقترحة');
record(ms, 'b', win(1)); record(ms, 'c', win(3));
ok(chain(ms, D) === 3 && nextIndex(ms, D) === 2, 'بعد إنجاز الكل المقترحة هي الأخيرة');
const sm = summary(ms, D);
ok(sm.done === 3 && sm.total === 3 && sm.stars === 3+1+3 && sm.maxStars === 9, 'الملخص: منجز ونجوم');
ok(JSON.stringify(normalizeMs({a:{stars:9, best:-5, bt:'x', n:2.4, done:1}, z:5, y:null})) ===
  JSON.stringify({a:{stars:3, best:0, bt:0, n:2, done:true}}), 'تنظيف السجل التالف');
ok(JSON.stringify(normalizeMs([1])) === '{}' && JSON.stringify(normalizeMs(null)) === '{}', 'مدخل غير كائن ← فارغ');

console.log('الإحاطة:');
for(const m of MISSIONS){
  const b = briefOf(m);
  ok(MISSION_TEXT[b.order] && MISSION_TEXT[b.desc], m.id+': نص الأمر والوصف موجودان');
  ok(b.threats.length > 0 && b.threats.every(x => UI_TEXT['th_'+x.kind]), m.id+': كل تهديد له تسمية');
  ok(b.objectives.every(o => MISSION_TEXT[o.text]), m.id+': نصوص الأهداف موجودة');
  ok(b.reward.c > 0 && b.par > 0 && b.starKeys.length === 3, m.id+': مكافأة وزمن مرجعي ونجوم');
}
const E = kind => ({side:'enemy', kind});
const tc = threatsOf({entities:[E('tank'), E('tank'), {side:'ally', kind:'tank'}, E('sam')],
  triggers:[{do:[{spawn:[E('jet'), E('jet'), E('jet')]}]}]});
ok(tc.length === 3 && tc[0].kind === 'jet' && tc[0].n === 3 && tc[1].kind === 'tank' && tc[1].n === 2,
  'التهديدات: العدو فقط + مستدعى المحفّزات + ترتيب بالعدد');

console.log('تقرير التقييم:');
const def = MISSIONS[0], rt = createRuntime(def);
const extra = {kj:3, kg:5, allyLost:1, hpFrac:.5, lvUp:'x', loot:'1', next:1};
const rep = makeReport(def, rt, evaluate(def, {...run(), objectives:[]}), rw, extra, 0);
ok(rep.idx === 0 && rep.id === def.id && rep.rows.length === def.objectives.length, 'حقول التقرير');
ok(rep.kj === 3 && rep.next === 1 && rep.loot === '1' && rep.lvUp === 'x', 'حقول الإضافات');
const STS = ['done', 'failed', 'open'];
ok(rep.rows.every(x => STS.includes(x.status) && MISSION_TEXT[x.text]), 'حالات الأهداف مبسّطة ونصوصها موجودة');
ok(makeReport(def, rt, w3, rw, {}, 0).next === -1, 'next الافتراضي -1');
const KEYS = ['db_win', 'db_fail', 'db_quit', 'st_win', 'st_opt', 'st_par', 'st_clean', 'opsT', 'briefT', 'debT', 'recT'];
for(const k of KEYS)
  ok(UI_TEXT[k] && UI_TEXT[k].length === 2, 'نص ثنائي اللغة: '+k);

if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
