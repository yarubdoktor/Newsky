/* اختبار M1: الجهات والاستهداف المتبادل — (1) اختيار الهدف (2) قواعد الإصابة والنيران الصديقة (3) سلوك الذكاء بالمحاكاة.
   التشغيل: node --import ./tools/test/register.mjs tools/test/test_targeting.mjs  (جزء من npm test) */
import * as S from './stubs.mjs';
import * as C from './stub_combat.mjs';
import {pickTarget, fallbackTarget, TARGET} from '../../src/mission/target_pick.js';
import {hitMul, FRIENDLY_FIRE} from '../../src/mission/factions.js';
const {W,P,V,Mesh,counts} = S;
const combat = await import('../../src/combat.js');
const ai = await import('../../src/ai.js');

let pass = 0, fail = 0;
const ok = (c,name,extra='') => { if(c){ pass++; console.log('  ✓',name); } else { fail++; console.log('  ✗',name,extra); } };
function reset(){
  W.G = {dead:false,diff:1,hit:false,combo:0,ct:0,mult:1,kj:0,kg:0,score:1000,coins:0,xp:0,t:0};
  W.units.length = 0; W.projs.length = 0; W.flares.length = 0; W.shake = 0; counts.explode = 0; C.shots.length = 0;
  P.g.position.set(0,0,0); P.hp = 100; P.speed = 150; P.cur = 150; P.side = 'player';
}
const rot = {set(){}};
const unit = (side,x,y,z,o = {}) => ({kind:'jet',side,g:{position:V(x,y,z),rotation:rot,userData:{}},r:9,air:true,hp:30,max:30,pts:100,
  fl:0,cd:99,mcd:99,yaw:0,pitch:0,sd:1,tn:2,sp:100,ag:.5,...o});
const gun = (side,x,z,kind = 'turret') => ({kind,side,g:{position:V(x,0,z),userData:{aim:{lookAt(){}}}},hp:50,max:50,r:9,muz:6,
  air:false,ground:true,cd:0,mcd:0,pts:100});
const proj = (o) => { const m = new Mesh(); m.position.copy(o.pos);
  return {mesh:m,dir:o.dir||V(0,0,-1),speed:o.speed,dmg:o.dmg||10,owner:o.owner,side:o.side,mis:!!o.mis,bomb:false,target:null,turn:2.4,vy:0,life:5}; };

console.log('1) جدول الإصابة hitMul');
ok(hitMul('player','enemy') === 1 && hitMul('ally','enemy') === 1,'اللاعب والحليف يضرّان العدو بالكامل');
ok(hitMul('enemy','player') === 1 && hitMul('enemy','ally') === 1,'العدو يضر اللاعب والحليف');
ok(hitMul('player','ally') === FRIENDLY_FIRE.dmgMul,'نيران صديقة: اللاعب على الحليف بضرر مخفّض');
ok(hitMul('ally','player') === 0 && hitMul('ally','ally') === 0 && hitMul('enemy','enemy') === 0,'لا ضرر بين الأصدقاء ولا بين الأعداء أنفسهم');
ok(hitMul('ally','nobody') === 0,'جهة مجهولة = لا ضرر');

console.log('2) اختيار الهدف');
{ reset(); const e = unit('enemy',0,0,0), a = unit('ally',300,0,0), far = unit('ally',1500,0,0); W.units.push(e,a,far);
  P.g.position.set(0,0,-900);
  ok(pickTarget(e,W.units,P,{range:2000}) === a,'العدو يفضّل حليفاً قريباً (300م) على اللاعب (900م)');
  ok(pickTarget(a,W.units,P,{range:2000}) === e,'الحليف يختار العدو ولا يختار اللاعب/الحليف');
  P.g.position.set(0,0,-200);
  ok(pickTarget(e,W.units,P,{range:2000}) === P,'اللاعب أقرب (200م) = هدف العدو');
  ok(pickTarget(e,W.units,P,{range:100}) === null,'خارج المدى = لا هدف');
  ok(pickTarget(e,W.units,P,{range:2000,playerDead:true}) === a,'اللاعب ميت = يُتجاهل');
  ok(fallbackTarget(e,P,false) === P && fallbackTarget(e,P,true) === null,'البديل للعدو: اللاعب الحي فقط');
  ok(fallbackTarget(a,P,false) === null,'الحليف ليس له اللاعب بديلاً');
  // ثبات الهدف: الحالي 300م، مرشح جديد 250م ليس أقرب بوضوح (< 0.7×) فلا نبدّل
  reset(); const e2 = unit('enemy',0,0,0), a1 = unit('ally',300,0,0), a2 = unit('ally',-250,0,0); W.units.push(e2,a1,a2);
  P.g.position.set(0,0,-5000); e2.tgt = a1;
  ok(pickTarget(e2,W.units,P,{range:2000}) === a1,'الهدف الحالي يثبت أمام مرشح أقرب قليلاً');
  a2.g.position.set(-150,0,0);
  ok(pickTarget(e2,W.units,P,{range:2000}) === a2,'يتحوّل لهدف أقرب بوضوح (150م مقابل 300م)');
  W.units.splice(W.units.indexOf(a2),1); e2.tgt = a2;
  ok(pickTarget(e2,W.units,P,{range:2000}) === a1,'هدف حالي ميت/مُزال = يُعاد الاختيار');
}

console.log('3) الإصابة والنيران الصديقة (combat)');
{ reset(); const en = unit('enemy',0,0,-500), al = unit('ally',0,0,-500);
  W.units.push(en); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'a',side:'ally',dmg:6})); combat.projectilesUpdate(.05);
  ok(en.hp === 24,'رصاصة حليف تصيب العدو');
  reset(); P.g.position.set(0,0,-500); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'a',side:'ally',dmg:6})); combat.projectilesUpdate(.05);
  ok(P.hp === 100,'رصاصة حليف لا تؤذي اللاعب');
  reset(); W.units.push(al); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'e',side:'enemy',dmg:6})); combat.projectilesUpdate(.05);
  ok(al.hp === 24,'رصاصة عدو تصيب الحليف');
  reset(); en.hp = 30; W.units.push(en); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'e',side:'enemy',dmg:6})); combat.projectilesUpdate(.05);
  ok(en.hp === 30 && W.projs.length === 1,'رصاصة عدو تمرّ عبر عدو آخر');
  reset(); al.hp = 30; W.units.push(al); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'p',dmg:10})); combat.projectilesUpdate(.05);
  ok(Math.abs(al.hp-27) < 1e-9,'نيران صديقة: رصاصة اللاعب تضر الحليف 30% فقط','hp='+al.hp);
  ok(W.units.length === 1,'الحليف ما زال حياً');
  reset(); al.hp = 2; W.units.push(al); W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'p',dmg:10})); combat.projectilesUpdate(.05);
  ok(W.units.length === 0 && W.G.ff === 1 && W.G.score === 1000-FRIENDLY_FIRE.killPenalty && W.G.kj === 0,
    'قتل حليف: عقوبة نقاط، بلا مكافأة قتل','score='+W.G.score);
  reset(); W.units.push(en); en.hp = 5; W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'a',side:'ally',dmg:10})); combat.projectilesUpdate(.05);
  ok(W.units.length === 0 && W.G.score === 1000 && W.G.kj === 0,'حليف يقتل عدواً: لا نقاط للاعب');
  reset(); W.units.push(en); en.hp = 5; W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'p',dmg:10})); combat.projectilesUpdate(.05);
  ok(W.units.length === 0 && W.G.kj === 1 && W.G.score > 1000,'اللاعب يقتل عدواً: مكافأة كالسابق');
  reset(); W.units.push(en); W.units.push(unit('ally',0,0,-480)); en.g.position.set(0,0,-495);
  W.projs.push(proj({pos:V(0,0,-480),speed:1,owner:'p',dmg:10,mis:true,life:0})); combat.projectilesUpdate(.05);
  ok(true,'صاروخ ينتهي عمره قرب وحدات بلا أخطاء');
  reset(); const m = unit('ally',0,0,-500); W.units.push(m);        // صاروخ عدو موجّه لحليف يلحقه ولا يحيد نحو اللاعب
  P.g.position.set(300,0,-500);
  const pm = proj({pos:V(0,0,-300),speed:200,owner:'e',side:'enemy',mis:true,dmg:5,dir:V(0,0,-1)}); pm.target = m; W.projs.push(pm);
  for(let i=0;i<30;i++) combat.projectilesUpdate(1/30);
  ok(m.hp < 30 || W.projs.length === 0,'صاروخ العدو الموجّه يصيب الحليف','hp='+m.hp+' proj='+W.projs.length);
  ok(P.hp === 100,'ولا يلتفت إلى اللاعب');
}

console.log('4) الذكاء بالمحاكاة');
{ reset(); const t = gun('enemy',0,0); const al = unit('ally',-300,0,0,{kind:'drone'}); al.vel = V(); al.lp = al.g.position.clone();
  W.units.push(t,al); P.g.position.set(0,0,-1700); P.cur = 150;
  for(let i=0;i<240;i++){ W.G.t += .016; ai.enemiesUpdate(.016); if(W.units.indexOf(al)<0) break; }
  ok(t.tgt === al,'مدفع العدو يختار الحليف القريب هدفاً','tgt='+(t.tgt === P ? 'P' : t.tgt && t.tgt.side));
  const sh = C.shots.filter(s => s.side === 'enemy');
  ok(sh.length > 0 && sh.every(s => s.dir.x < -0.5),'طلقاته تتجه نحو الحليف (يسار) لا نحو اللاعب','shots='+sh.length+' dir='+(sh[0]&&sh[0].dir.x));
  ok(sh.every(s => s.owner === 'e'),'owner="e" للعدو');
}
{ reset(); const t = gun('ally',0,0); const en = unit('enemy',-300,0,0,{kind:'drone'}); en.vel = V(); en.lp = en.g.position.clone();
  W.units.push(t,en); P.g.position.set(0,0,-200);
  for(let i=0;i<240;i++){ W.G.t += .016; ai.enemiesUpdate(.016); }
  ok(t.tgt === en,'مدفع الحليف يستهدف العدو لا اللاعب (200م)');
  const sh = C.shots.filter(s => s.side === 'ally');
  ok(sh.length > 0 && sh.every(s => s.owner === 'a' && s.dir.x < -0.5),'طلقات الحليف علامتها owner="a" باتجاه العدو','shots='+sh.length);
  ok(P.hp === 100,'اللاعب لم يُصَب');
}
{ reset(); const sam = gun('enemy',0,0,'sam'); const aj = unit('ally',-500,300,0,{kind:'heli',g:{position:V(-500,300,0),rotation:rot,userData:{rotor:{rotation:{y:0}}}}}); aj.vel = V(); aj.lp = aj.g.position.clone();
  W.units.push(sam,aj); P.g.position.set(0,0,-1800);
  for(let i=0;i<400;i++){ W.G.t += .016; ai.enemiesUpdate(.016); if(C.shots.some(s => s.mis)) break; }
  const ms = C.shots.find(s => s.mis);
  ok(ms && ms.target === aj,'صاروخ SAM المعادي موجّه نحو الحليف (target = الوحدة)','shot='+JSON.stringify(ms&&ms.target&&ms.target.side));
}
{ reset(); const sam = gun('enemy',0,0,'sam'); W.units.push(sam); P.g.position.set(0,300,-800);
  for(let i=0;i<400;i++){ W.G.t += .016; ai.enemiesUpdate(.016); if(C.shots.some(s => s.mis)) break; }
  const ms = C.shots.find(s => s.mis);
  ok(sam.tgt === P && ms && ms.target === null,'بلا حلفاء: السلوك القديم (الهدف اللاعب، target=null)');
}
{ reset(); const t = gun('enemy',0,0); const al = unit('ally',-300,0,0,{kind:'drone'}); al.vel = V(); al.lp = al.g.position.clone();
  W.units.push(t,al); P.g.position.set(0,0,-1500);
  for(let i=0;i<40;i++){ W.G.t += .016; ai.enemiesUpdate(.016); }
  W.units.splice(W.units.indexOf(al),1);
  W.G.t += .016; ai.enemiesUpdate(.016);
  ok(t.tgt === P,'عند موت الحليف يعود الهدف للاعب فوراً');
}
{ reset(); const j = unit('ally',0,200,0); j.vel = V(); j.lp = j.g.position.clone(); W.units.push(j); P.g.position.set(0,200,-500);
  for(let i=0;i<60;i++){ W.G.t += .016; ai.enemiesUpdate(.016); }
  ok(j.tgt === null && C.shots.length === 0,'حليف بلا عدو: لا هدف ولا نيران ولا استهداف للاعب');
}
console.log(fail ? `✗ فشل ${fail}` : `✓ نجح الكل: ${pass} اختبار`); process.exit(fail ? 1 : 0);
