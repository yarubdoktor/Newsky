// اختبار دخان بمتصفح حقيقي (Playwright + Chromium) — بند #17 / KI-05.
// يبني اللعبة (vite build) ويقدّم dist بخادم ثابت، يفتح اللوبي، يبدأ جولة، ويتأكد من:
//   1) لا pageerror ولا console.error، ولا أي تحذير «failed» (فشل تحميل GLB/bin يرجع للبديل بصمت!).
//   2) اللوبي يظهر، والجولة تبدأ (W.run) وتجري ~6 ثوانٍ مع أعداء.
//   3) ميزانية الأداء (BUDGET أدناه) على renderer.info.
// تشغيل: node tools/test/smoke.mjs [--no-build] [--shots]   (يخرج 1 عند الفشل، 2 إن لم تتوفر البيئة)
// الميزانية BUDGET معايَرة (M7) على مسارح الحملة بمتصفح headless (SwiftShader)؛ ليست قياساً على جهاز حقيقي. PW_CHROME يحدد مسار Chromium إن لزم.
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {execSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
import {tmpdir} from 'node:os';

const require = createRequire(import.meta.url);
let chromium; try { ({chromium} = require('playwright')); } catch { console.error('Playwright غير متوفر'); process.exit(2); }
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const dist = resolve(root, 'dist');
const args = process.argv.slice(2);

const BUDGET = {drawCalls: 450, triangles: 600000, geometries: 350, textures: 50, enemies: 60};   // معايَرة M7: أسوأ مقاس 231/217k/159/17/12 (مسارح الحملة، swiftshader)
const PLAY_MS = 6000;
/* [فهرس المهمة, اسم]: m0 front · m6 highlands · m9 front_night · m10 gulf */
const SORTIES = [[0, 'front'], [6, 'highlands'], [9, 'front_night'], [10, 'gulf']];

if(!args.includes('--no-build')){
  try { execSync('npx vite build', {cwd: root, stdio: 'inherit'}); }
  catch { console.error('فشل vite build (أو vite غير مثبّت)'); process.exit(2); }
}
if(!existsSync(join(dist, 'index.html'))){ console.error('لا يوجد dist/index.html'); process.exit(2); }

const MIME = {'.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webp': 'image/webp', '.png': 'image/png',
  '.glb': 'model/gltf-binary', '.bin': 'application/octet-stream', '.webmanifest': 'application/manifest+json', '.json': 'application/json'};
const server = createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist, '.' + p);
  if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type': MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f));
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

const problems = [];
const browser = await chromium.launch({executablePath: process.env.PW_CHROME || undefined, args: ['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
try {
  const page = await browser.newPage({viewport: {width: 1280, height: 720}});
  page.on('pageerror', e => problems.push('pageerror: ' + e.message));
  page.on('console', m => {
    const t = m.type(), x = m.text();
    if(t === 'error') problems.push('console.error: ' + x);
    else if(t === 'warning' && /failed|unavailable/i.test(x)) problems.push('console.warn: ' + x);
  });
  page.on('requestfailed', r => problems.push('requestfailed: ' + r.url()));
  page.on('response', r => { if(r.status() >= 400) problems.push(`HTTP ${r.status()}: ${r.url()}`); });
  await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
  await page.goto(url, {waitUntil: 'load'});

  await page.waitForFunction(() => document.querySelector('#menu')?.children.length > 0 && !document.querySelector('#load.on') && globalThis.__ss, null, {timeout: 60000})
    .catch(() => problems.push('اللوبي لم يظهر خلال 60 ث (أو انتهى التحميل بخطأ)'));
  mkdirSync(join(tmpdir(), 'ss_smoke'), {recursive: true});
  if(args.includes('--shots')) await page.screenshot({path: join(tmpdir(), 'ss_smoke', 'lobby.png')});

  // M5/M6: نبدأ مهمة من كل مسرح (front · highlands · gulf · front_night) بدل startGame بلا مهمة
  const worst = {};
  for(const [mi, label] of SORTIES){
    await page.evaluate(i => { const s = globalThis.__ss;                       // افتح كل ما قبلها (التسلسل مقفول)
      for(let k = 0; k < i; k++) s.S.ms[s.MISSIONS[k].id] = {stars: 1, best: 0, bt: 0, n: 1, done: true};
      if(!s.__mx){ const r = s.renderer, o = r.render.bind(r); s.__mx = {calls: 0, triangles: 0};
        r.render = (a, b) => { o(a, b); const q = r.info.render; s.__mx.calls = Math.max(s.__mx.calls, q.calls); s.__mx.triangles = Math.max(s.__mx.triangles, q.triangles); }; }
      s.__mx.calls = 0; s.__mx.triangles = 0; s.startMission(i); }, mi);
    await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout: 60000}).catch(() => problems.push(label + ': الجولة لم تبدأ خلال 60 ث'));
    await page.waitForTimeout(PLAY_MS);
    if(args.includes('--shots')) await page.screenshot({path: join(tmpdir(), 'ss_smoke', label + '.png')});
    const m = await page.evaluate(() => { const s = globalThis.__ss, i = s.renderer.info;
      return {run: s.W.run, enemies: s.enemies.length, hp: s.P.hp, drawCalls: s.__mx.calls, triangles: s.__mx.triangles, geometries: i.memory.geometries, textures: i.memory.textures}; });
    console.log(label + ' المقاسة:', JSON.stringify(m));
    if(!m.run) problems.push(label + ': الجولة توقفت قبل الوقت');
    if(!(m.enemies > 0)) problems.push(label + ': لا وحدات بعد ' + PLAY_MS / 1000 + ' ث من بدء الجولة');
    for(const k of Object.keys(BUDGET)){ worst[k] = Math.max(worst[k] || 0, m[k]);
      if(m[k] > BUDGET[k]) problems.push(`${label}: تجاوز الميزانية ${k} = ${m[k]} > ${BUDGET[k]}`); }
    await page.evaluate(() => globalThis.__ss.finish(false, true));
  }
  console.log('أسوأ قيم:', JSON.stringify(worst), '| الميزانية:', JSON.stringify(BUDGET));
} finally { await browser.close(); server.close(); }

if(problems.length){ console.error('✗ فشل اختبار الدخان:\n' + [...new Set(problems)].map(p => '  - ' + p).join('\n')); process.exit(1); }
console.log('✓ نجح اختبار الدخان');
