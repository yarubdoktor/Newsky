// بند M0: محرّك المهمات — الجهات، الأهداف، آلة الحالات، تعريفات المهمات، مواضع الكيانات، نص الـHUD (كلها دوال صرفة).
import {readFileSync, existsSync, readdirSync} from 'node:fs';
import {SIDES,HOSTILE,FACTION,isHostile,isSide,colorOf} from '../../src/mission/factions.js';
import {makeObjective,feed,progressOf,objectiveTypes,hasType} from '../../src/mission/objectives.js';
import {createRuntime,pushEvent,stepRuntime} from '../../src/mission/mission_runtime.js';
import {MISSIONS,missionById,validateMission} from '../../src/mission/mission_defs.js';
import {anchorOf,headingDir,KINDS} from '../../src/mission/entity_pos.js';
import {objectiveLines} from '../../src/mission/mission_hud.js';
import {solveMission} from './solver.mjs';
import {MISSION_TEXT} from '../../src/mission/mission_text.js';
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const mk = o => ({id:'x', title:'x', entities:[], objectives:[{id:'o1', type:'destroy', text:'x', targets:['a','b']}],
  fail:[{type:'playerDead'}], ...o});

console.log('الجهات:');
ok(isSide('player') && isSide('ally') && isSide('enemy') && !isSide('boss'),'ثلاث جهات معروفة فقط');
ok(isHostile('enemy','player') && isHostile('enemy','ally') && isHostile('player','enemy') && isHostile('ally','enemy'),'العدو ↔ اللاعب والحليف');
ok(!isHostile('player','ally') && !isHostile('ally','player') && !isHostile('enemy','enemy') && !isHostile('player','player'),'لا عداء بين الأصدقاء ولا داخل الجهة');
ok(Object.keys(SIDES).length === 3 && Object.keys(FACTION).every(k => HOSTILE[k] && HOSTILE[k][k] === false),'الجداول متسقة');
ok(Object.keys(HOSTILE).every(a => Object.keys(HOSTILE).every(b => HOSTILE[a][b] === HOSTILE[b][a])),'جدول العداء متماثل');
ok(colorOf('ally') !== colorOf('enemy') && colorOf('zzz') === colorOf('enemy'),'ألوان مميّزة + الافتراضي لون العدو');

console.log('الأهداف:');
ok(hasType('destroy') && objectiveTypes().includes('destroy') && !hasType('nope'),'نوع destroy مسجّل');
let threw = false; try{ makeObjective({id:'q', type:'nope'}); }catch(e){ threw = true; } ok(threw,'نوع مجهول يرمي خطأ');
const o = makeObjective({id:'o', type:'destroy', text:'t', targets:['a','b']});
ok(feed(o,{type:'entityDead',id:'zzz'}) === null && o.left.length === 2,'كيان غير هدف لا يغيّر شيئاً');
ok(feed(o,{type:'entityDead',id:'a'}) === null && progressOf(o).done === 1,'نصف الأهداف: ما زال نشطاً (1/2)');
ok(feed(o,{type:'entityDead',id:'a'}) === null,'موت نفس الكيان مرتين لا يُحسب');
ok(feed(o,{type:'entityDead',id:'b'}) === 'done' && o.status === 'done','آخر هدف ← done');
ok(feed(o,{type:'entityDead',id:'b'}) === null,'هدف منتهٍ لا يتغيّر');

console.log('آلة الحالات:');
let rt = createRuntime(mk({}));
ok(stepRuntime(rt,1).length === 0 && rt.status === 'running' && rt.t === 1,'تعمل وتعدّ الزمن بلا أحداث');
pushEvent(rt,{type:'entityDead',id:'a'}); let out = stepRuntime(rt,.1);
ok(out.length === 0 && rt.status === 'running','هدف واحد من اثنين: المهمة مستمرة');
pushEvent(rt,{type:'entityDead',id:'b'}); out = stepRuntime(rt,.1);
ok(out.some(x => x.type === 'objective' && x.status === 'done') && out.some(x => x.type === 'end' && x.result === 'won'),'كل الأهداف ← نجاح');
ok(rt.status === 'won' && stepRuntime(rt,1).length === 0,'بعد النهاية لا مخرجات إضافية');
pushEvent(rt,{type:'playerDead'}); ok(rt.q.length === 0,'بعد النهاية الأحداث تُهمل');
rt = createRuntime(mk({})); pushEvent(rt,{type:'playerDead'}); out = stepRuntime(rt,.1);
ok(rt.status === 'lost' && rt.reason === 'playerDead' && out.some(x => x.type === 'end' && x.result === 'lost'),'موت اللاعب ← فشل');
rt = createRuntime(mk({fail:[{type:'timeout',t:5}]}));
ok(stepRuntime(rt,4.9).length === 0 && stepRuntime(rt,.2).some(x => x.type === 'end') && rt.reason === 'timeout','انتهاء الزمن ← فشل');
rt = createRuntime(mk({fail:[]})); pushEvent(rt,{type:'playerDead'}); stepRuntime(rt,.1);
ok(rt.status === 'running','موت اللاعب لا يفشل المهمة إن لم تُحدَّد له قاعدة');
rt = createRuntime(mk({objectives:[{id:'m', type:'destroy', text:'x', targets:['a']},
  {id:'s', type:'destroy', text:'y', targets:['b'], optional:true}]}));
pushEvent(rt,{type:'entityDead',id:'a'}); stepRuntime(rt,.1);
ok(rt.status === 'won','الهدف الثانوي غير شرط للنجاح');
rt = createRuntime(mk({objectives:[{id:'m', type:'destroy', text:'x', targets:['a']}]}));
pushEvent(rt,{type:'entityDead',id:'a'}); pushEvent(rt,{type:'playerDead'}); stepRuntime(rt,.1);
ok(rt.status === 'lost','موت اللاعب بنفس اللحظة يغلّب الفشل (قرار ثابت)');

console.log('تعريفات المهمات:');
ok(MISSIONS.length >= 1 && missionById('m0') === MISSIONS[0] && missionById('none') === null,'المهمة التجريبية m0 موجودة');
for(const m of MISSIONS){
  const err = validateMission(m,KINDS,objectiveTypes()); ok(err.length === 0,m.id+': تعريف سليم'+(err.length ? ' — '+err.join('; ') : ''));
  ok(m.entities.every(e => ['player','ally','enemy'].includes(e.side)),m.id+': كل كيان له جهة صحيحة');
  ok(m.difficulty >= 1 && Array.isArray(m.triggers) && Array.isArray(m.comms),m.id+': الصعوبة + حقلا triggers/comms');
  const keys = [m.title,m.intro,m.id+'d',...m.objectives.map(x => x.text)];
  ok(keys.every(k => MISSION_TEXT[k] && MISSION_TEXT[k].length === 2 && MISSION_TEXT[k].every(Boolean)),m.id+': نصوص عربي/إنجليزي كاملة');
  const tk = [...(m.comms || []).map(c => c.text)];
  ok(tk.every(k => MISSION_TEXT[k] && MISSION_TEXT[k].every(Boolean)),m.id+': نصوص الرسائل كاملة');
  ok(solveMission(m).status === 'won',m.id+': قابلة للإنجاز (لعب مثالي بالحلّال ← نجاح)');
}
ok(validateMission(mk({entities:[{id:'a',kind:'tank',pos:{d:1}}]}),KINDS,['destroy']).length >= 1,'الفاحص يرفض نوع كيان مجهول');
ok(validateMission(mk({entities:[{id:'a',kind:'sam',pos:{near:'b'}},{id:'b',kind:'sam',pos:{d:1}}]}),KINDS,['destroy']).length >= 1,'الفاحص يرفض near لكيان لاحق');
ok(validateMission(mk({objectives:[{id:'o',type:'destroy',targets:['zz']}]}),KINDS,['destroy']).length >= 1,'الفاحص يرفض هدفاً بلا كيان');

console.log('مواضع الكيانات:');
const sp = {x:100,z:200,yaw:0}, fw = headingDir(0);
ok(Math.abs(fw.x) < 1e-9 && fw.z === -1,'اتجاه الأمام عند yaw=0 هو -z (مثل ai.js)');
let an = anchorOf({d:1000},sp,{}); ok(Math.abs(an.x-100) < 1e-6 && Math.abs(an.z-(200-1000)) < 1e-6,'d=1000 أمام اللاعب');
an = anchorOf({d:1000,a:Math.PI/2},sp,{}); ok(Math.abs(an.x-(100-1000)) < 1e-6 && Math.abs(an.z-200) < 1e-6,'a=+90° يسار (−x)');
an = anchorOf({d:500},{x:0,z:0,yaw:Math.PI},{}); ok(Math.abs(an.z-500) < 1e-6,'يتبع yaw البداية');
an = anchorOf({near:'p',r:90},sp,{p:{x:5,z:6}}); ok(an.x === 5 && an.z === 6 && an.rad === 90,'near يقرأ الكيان الموضوع + نصف القطر');
an = anchorOf({x:1,z:2},sp,{}); ok(an.x === 1 && an.z === 2 && an.rad > 0,'إحداثيات مطلقة');
threw = false; try{ anchorOf({near:'nope'},sp,{}); }catch(e){ threw = true; } ok(threw,'near لكيان غير موضوع يرمي خطأ');
threw = false; try{ anchorOf({},sp,{}); }catch(e){ threw = true; } ok(threw,'موضع فارغ يرمي خطأ');

console.log('نص الـHUD:');
const tr = k => (MISSION_TEXT[k] ? MISSION_TEXT[k][0] : k);
rt = createRuntime(mk({objectives:[{id:'o', type:'destroy', text:'m0o1', targets:['a','b']},
  {id:'s', type:'destroy', text:'m0o1', targets:['c'], optional:true}]}));
pushEvent(rt,{type:'entityDead',id:'a'}); stepRuntime(rt,.1); const ln = objectiveLines(rt,tr);
ok(ln.length === 2 && ln[0].startsWith('◆') && ln[0].endsWith('1/2'),'سطر الهدف: ◆ + التقدّم 1/2');
ok(ln[1].includes(MISSION_TEXT.ms_opt[0]) && !/\d\/\d/.test(ln[1]),'الثانوي موسوم وبلا عدّاد لهدف مفرد');

console.log('ربط المحرك (فحص نصي):');
const src = f => readFileSync(new URL('../../src/'+f,import.meta.url),'utf8');
ok(/G\.ms && e\.mid/.test(src('combat.js')),'kill() يرسل حدث entityDead للمهمة');
ok(/missionUpdate\(dt\)/.test(src('game.js')) && /beginMission\(MS\)/.test(src('game.js')),'game.js يبدأ ويحدّث المهمة عبر الجسر');
ok(!existsSync(new URL('../../src/waves.js',import.meta.url)) && !existsSync(new URL('../../src/campaign.js',import.meta.url)),
  'waves.js و campaign.js محذوفان (M4)');
const GONE = /spawnWave|checkClear|CAMPAIGN|S\.mode|G\.wave|waves\.js|makeBeacon|BOSSES|submitScore|trackMis|weeklyInit|misInit/;
const files = [...readdirSync(new URL('../../src/',import.meta.url)).filter(f => f.endsWith('.js')).map(f => f),
  ...readdirSync(new URL('../../src/mission/',import.meta.url)).map(f => 'mission/'+f)].filter(f => f.endsWith('.js'));
const bad = files.filter(f => GONE.test(src(f)));
ok(bad.length === 0,'لا بقايا للموجات/الأنماط/الزعماء بالكود'+(bad.length ? ': '+bad.join(',') : ''));
for(const m of MISSIONS){
  ok(m.reward && m.reward.c > 0 && m.reward.xp > 0 && m.par > 0, m.id+': له مكافأة وزمن مرجعي');
}

if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
