/* حلّال مهمات للاختبار: ينفّذ "لعباً مثالياً" على آلة الحالات وحدها (بلا محرك): يقتل كل أهداف التدمير/القمع/الاعتراض،
   يوصل كل وحدات الإسناد، يضع اللاعب فوق نقطة العودة، ويترك الزمن يمر لأهداف الحماية. يرجع runtime النهائي. */
import {createRuntime, pushEvent, stepRuntime} from '../../src/mission/mission_runtime.js';
import {resolveRuntime} from '../../src/mission/mission_resolve.js';
import {entityIds} from '../../src/mission/convoy.js';

/* مواقع وهمية: أي معرّف موقع ← (0,0) (الفحص الحقيقي للمواقع بـ test_theater.mjs) */
export const ANY_SITES = new Proxy({}, {get:() => ({x:0, z:0})});

export function solveMission(m, maxT = 3000){
  const placed = {}; for(const e of m.entities) for(const id of entityIds(e)) placed[id] = {x:0, z:0};
  const rt = resolveRuntime(createRuntime(m), {x:0, z:0, yaw:0, sites:ANY_SITES}, placed);
  const rtb = rt.objectives.find(o => o.type === 'rtb');
  const snap = {px:rtb ? rtb.x : 0, pz:rtb ? rtb.z : 0, py:60, agl:60, units:{}};
  for(const o of rt.objectives){
    for(const id of o.type === 'escort' ? [] : (o.targets || [])) pushEvent(rt, {type:'entityDead', id});
    for(const id of o.type === 'escort' ? o.units.slice(0, o.need) : []) pushEvent(rt, {type:'entityArrived', id});
  }
  const outs = [];
  for(let t = 0; t < maxT && rt.status === 'running'; t++) outs.push(...stepRuntime(rt, 1, snap));
  rt.outs = outs; return rt;
}
