// M8: هوية الطيار: لا مرجع للاعب بـ F-35، MiG-29 مجانية، Su-57 بالشراء، مقاتلات العدو متنوعة وتعمل.
import {readFileSync, existsSync, readdirSync} from 'node:fs';
import {pickJetModel, ENEMY_JETS} from '../../src/jet_pick.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const rd = f => readFileSync(new URL('../../src/'+f, import.meta.url), 'utf8');

console.log('طائرات اللاعب:');
const data = rd('data.js');
const planesBlock = data.slice(data.indexOf('export const PLANES'), data.indexOf('export const level'));
const ids = [...planesBlock.matchAll(/^\s{2}(\w+):\s*\{n:/gm)].map(m => m[1]);
ok(ids.join(',') === 'mig29,su57', 'PLANES = mig29 و su57 فقط (وجدت: '+ids.join(',')+')');
ok(/mig29:\{[^}]*price:0\b/.test(planesBlock), 'MiG-29 مجانية (price:0)');
const su = +/su57:\s*\{[^}]*price:(\d+)/.exec(planesBlock)[1];
ok(su > 0, 'Su-57 بالشراء ('+su+')');
const sv = rd('save.js');
ok(/sel:'mig29', pl:\{mig29:1\}/.test(sv), 'الحفظ الجديد: sel:mig29 و pl:{mig29:1}');
const playerFiles = ['data.js','save.js','menu.js','menu_ms.js','previews.js','player.js','game.js','i18n.js','art.js'];
const bad = playerFiles.filter(f => /['"`.\s{,]f35\b|d_f35|ab_f35/.test(rd(f).replace(/f35\.webp[^\n]*/g,'')));
ok(bad.length === 0, 'لا مرجع للاعب بـ f35 في ملفات اللاعب/القوائم'+(bad.length ? ' (وجدت: '+bad.join(',')+')' : ''));
const jets = rd('jets.js');
ok(!/f35\.glb/.test(jets) && !/PM\[0\]/.test(jets), 'jets.js لا يحمّل f35.glb ولا نموذج لاعب kind 0');

console.log('مقاتلات العدو:');
ok(/f35:\s*new URL\('\.\/models\/f35\.glb',import\.meta\.url\)\.href/.test(rd('emodels.js')), 'emodels.js يحمّل f35.glb كنص ثابت (يلتقطه Vite)');
ok(existsSync(new URL('../../src/models/f35.glb', import.meta.url)) && existsSync(new URL('../../models_src/retired/enemy_f35_simplified.glb', import.meta.url)), 'ملفات F-35 GLB باقية (لم يُحذف شيء)');
const sp = rd('spawn.js');
ok(/mkAirJet\(/.test(sp) && !/mkJet\(rnd/.test(sp) && !/\bmkJet\b/.test(sp), 'spawn.js يستعمل mkAirJet ولا يوجد mkJet العشوائي');
const cnt = {f16:0, f15:0, f35:0}; for(let i = 0; i < 1000; i++) cnt[pickJetModel(i/1000)]++;
ok(cnt.f16 === 400 && cnt.f15 === 350 && cnt.f35 === 250, 'التوزيع 40/35/25 بين F-16/F-15/F-35 ('+JSON.stringify(cnt)+')');
ok(ENEMY_JETS.every(k => cnt[k] > 0), 'كل الطرازات تظهر');
ok([0, .3, .6, .99].every(r => pickJetModel(r, true) === 'f35'), 'القائد (ace) دائماً F-35');
ok([0, .5, .99].every(r => pickJetModel(r, false, false) !== 'f35') && pickJetModel(.9, true, false) === 'f16', 'إن لم يُحمَّل GLB F-35 يرجع F-16 برمجياً');
const ej = rd('enemy_jets.js');
ok(/mkF16/.test(ej) && /mkF15/.test(ej) && /mkEM\('f35'/.test(ej), 'مجسمات F-16/F-15 برمجية و F-35 من GLB');
ok(/side === 'ally'/.test(ej) && /mkJet\(k,color,true/.test(ej), 'الحليف يطير بطائرات اللاعب (MiG-29/Su-57) لا بمقاتلات العدو');
ok(ej.split('\n').length < 120, 'enemy_jets.js صغير (R4): '+ej.split('\n').length+' سطر');
if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
