/* اختبار M2: قيادة المركبات والأرتال، التصويب، سقف الأداء، واشتباك مركبات الجهات بالمحاكاة.
   التشغيل: node --import ./tools/test/register.mjs tools/test/test_vehicles.mjs  (جزء من npm test) */
import * as S from './stubs.mjs';
import * as C from './stub_combat.mjs';
import {makeBody, driveStep, leadAim, tiltOf, markActive, DRIVE, wrap} from '../../src/mission/friendly_ai.js';
import {entityIds, convoySlots, convoyYaw} from '../../src/mission/convoy.js';
import {createRuntime, stepRuntime} from '../../src/mission/mission_runtime.js';
import {pickTarget} from '../../src/mission/target_pick.js';
import {VEH} from '../../src/enemies.js';
const {W,P,V} = S;
const ai = await import('../../src/ai.js');

let pass = 0, fail = 0;
const ok = (c,name,extra='') => { if(c){ pass++; console.log('  ✓',name); } else { fail++; console.log('  ✗',name,extra); } };
S.world.ground = () => 0;                 // أرض مستوية للمحاكاة (الافتراضي بالـ stub = -1e9)
const D = {sp:14, turn:1};
const open = () => true;
function run(b, env, secs, dt = 1/30, hook){ for(let t = 0; t < secs; t += dt){ const o = driveStep(b, D, dt, env); if(hook) hook(o, t); } }

console.log('1) القيادة على المسار');
{ const b = makeBody(0,0,0,[{x:0,z:-300},{x:200,z:-300}]); let arrived = 0, maxV = 0;
  run(b, {ok:open, leadDist:null}, 60, 1/30, o => { if(o.arrived) arrived++; maxV = Math.max(maxV,b.v); });
  ok(b.state === 'arrived' && arrived === 1,'يصل آخر نقطة ويرسل الوصول مرة واحدة','state='+b.state+' n='+arrived);
  ok(Math.hypot(b.x-200,b.z+300) < DRIVE.arrive+2,'يقف قرب النقطة الأخيرة','(x='+b.x.toFixed(0)+' z='+b.z.toFixed(0)+')');
  ok(maxV <= D.sp+1e-6,'لا يتجاوز سرعته القصوى','v='+maxV);
  const h = makeBody(5,5,0,[]); run(h, {ok:open, leadDist:null}, 3);
  ok(h.state === 'hold' && h.x === 5 && h.z === 5,'بلا مسار = ثابت'); }
{ const b = makeBody(0,0,Math.PI,[{x:0,z:-400}]); const y0 = b.yaw; driveStep(b, D, .1, {ok:open, leadDist:null});
  ok(Math.abs(wrap(b.yaw-y0)) <= D.turn*.1+1e-9,'حد الدوران في الخطوة'); }

console.log('2) الالتفاف حول العوائق والعلوق');
{ const lake = (x,z) => Math.hypot(x,z+300) > 110;        // بحيرة نصف قطرها 110 على الطريق المباشر
  const b = makeBody(0,0,0,[{x:0,z:-700}]); let bad = 0;
  run(b, {ok:lake, leadDist:null}, 120, 1/30, () => { if(!lake(b.x,b.z)) bad++; });
  ok(bad === 0,'لا يدخل البحيرة أبداً'); ok(b.state === 'arrived','يلتف حولها ويصل','pos='+b.x.toFixed(0)+','+b.z.toFixed(0)); }
{ const box = (x,z) => Math.hypot(x,z) > 40 === false ? true : false;      // محبوس: الخارج كله مسدود
  const b = makeBody(0,0,0,[{x:0,z:-500}]); run(b, {ok:(x,z) => Math.hypot(x,z) < 6, leadDist:null}, 12);
  ok(b.stuck === true && b.state === 'drive','مسدود من كل الجهات = يُعلَّم عالقاً ولا يتحرك بعيداً'); }

console.log('3) حفظ المسافة بالرتل');
{ const lead = makeBody(0,0,0,[{x:0,z:-2000}]), fol = makeBody(0,40,0,[{x:0,z:-2000}]); let minGap = 1e9;
  const LD = {sp:6, turn:1};        // الرائد أبطأ بكثير
  for(let t = 0; t < 40; t += 1/30){
    driveStep(lead, LD, 1/30, {ok:open, leadDist:null});
    driveStep(fol, D, 1/30, {ok:open, leadDist:Math.hypot(lead.x-fol.x, lead.z-fol.z)});
    minGap = Math.min(minGap, Math.hypot(lead.x-fol.x, lead.z-fol.z)); }
  ok(minGap > DRIVE.gapMin-4,'التابع الأسرع لا يصطدم بالرائد','minGap='+minGap.toFixed(1)); }

console.log('4) التصويب والميلان وتوابع الرتل');
{ const o = {}; leadAim({x:0,y:0,z:0},{x:300,y:0,z:-400},{x:20,y:0,z:0},500,o);
  const t = o.t; const hit = {x:300+20*t, z:-400}; const dir = Math.hypot(o.x,o.z);
  ok(Math.abs(o.x*500*t-hit.x) < 6 && Math.abs(o.z*500*t-hit.z) < 6,'التصويب يسبق هدفاً متحركاً بدقة <6م','t='+t.toFixed(2)); }
{ const t = tiltOf(10,0,0,0,10,10);
  ok(t.pitch > .7 === false && t.pitch > 0 && t.roll === 0,'أمام أعلى = pitch موجب'); ok(tiltOf(0,0,5,0,10,10).roll > 0,'يمين أعلى = roll موجب');
  ok(tiltOf(100,0,0,0,10,10).pitch === .5,'الميلان محدود بـ .5 راد'); }
{ const s = convoySlots({x:0,z:0},{x:0,z:-100},3,30);
  ok(s[0].x === 0 && s[1].z === 30 && s[2].z === 60,'أعضاء الرتل خلف القائد على خط الحركة');
  ok(Math.abs(convoyYaw({x:0,z:0},{x:0,z:-1})) < 1e-9,'اتجاه الرتل: -Z ← yaw 0');
  ok(entityIds({id:'cv',kind:'convoy',units:['tank','truck']}).join() === 'cv1,cv2' && entityIds({id:'a',kind:'turret'}).join() === 'a','معرّفات الأعضاء'); }

console.log('5) سقف الأداء');
{ const mk = (x,pin) => ({g:{position:{x,y:0,z:0}},pin}); const us = Array.from({length:30},(_,i) => mk(i*100, i === 29));
  const n = markActive(us,{x:0,y:0,z:0},24);
  ok(n === 6 && us.filter(u => u.lite).length === 6,'30 وحدة بسقف 24: 6 مبسّطة');
  ok(us[29].lite === false,'الوحدة المثبّتة (هدف رئيسي) لا تُبسَّط وإن كانت بعيدة');
  ok(us[28].lite === true && us[0].lite === false,'الأبعد تُبسَّط والأقرب تبقى نشطة');
  ok(markActive(us.slice(0,10),{x:0,y:0,z:0},24) === 0,'تحت السقف: لا شيء يُبسَّط'); }

console.log('6) المحاكاة عبر ai.js');
function reset(){
  W.G = {dead:false,diff:2,hit:false,combo:0,ct:0,mult:1,kj:0,kg:0,score:1000,coins:0,xp:0,t:0};
  W.units.length = 0; W.projs.length = 0; W.flares.length = 0; C.shots.length = 0;
  P.g.position.set(0,2000,0); P.hp = 100; P.cur = 150; P.side = 'player';
}
const aimNode = () => ({rotation:{x:0,y:0,z:0,order:'XYZ'}});
function veh(kind,side,x,z,o = {}){
  const Dk = VEH[kind];
  const e = {kind,side,g:{position:V(x,0,z),rotation:{set(){}},scale:{setScalar(){}},userData:{aim:Dk.gun ? aimNode() : null,gk:kind}},hp:Dk.hp,max:Dk.hp,
    r:8,r0:8,boost:1,muz:Dk.muz,pts:Dk.pts,cd:0,mcd:0,ground:true,air:false,vehicle:true,sense:Dk.sense,unarmed:!Dk.gun,
    fl:0,pitch:0,roll:0,yaw:0,spd:o.speed||Dk.sp,drv:makeBody(x,z,o.yaw||0,o.route),follow:o.follow||null};
  e.accept = Dk.gun ? (c,d2) => !c.air || d2 <= Dk.gun.air**2 : () => false; W.units.push(e); return e;
}
const step = (n, dt = .033) => { for(let i = 0; i < n; i++){ W.G.t += dt; ai.enemiesUpdate(dt); } };
{ reset(); const a = veh('tank','ally',0,0,{yaw:0}), e = veh('tank','enemy',0,-700);
  step(180);
  ok(a.tgt === e && e.tgt === a,'دبابتان متقابلتان تختاران بعضهما (لا اللاعب)');
  const sa = C.shots.filter(s => s.side === 'ally'), se = C.shots.filter(s => s.side === 'enemy');
  ok(sa.length > 0 && se.length > 0,'كلاهما يطلق النار','ally='+sa.length+' enemy='+se.length);
  ok(sa.every(s => s.dir.z < -.9) && se.every(s => s.dir.z > .9),'القذائف تتجه نحو الخصم',JSON.stringify([sa[0]?.dir,se[0]?.dir]));
  ok(Math.abs(a.g.userData.aim.rotation.y) < .2,'برج الحليف مصوَّب على العدو في الأمام'); }
{ reset(); const t = veh('truck','ally',0,0,{route:[{x:0,z:-200}]}), e = veh('tank','enemy',0,-500);
  step(30); ok(t.tgt === null && C.shots.filter(s => s.side === 'ally').length === 0,'الشاحنة بلا سلاح ولا هدف');
  ok(e.tgt === t,'دبابة العدو تستهدف الشاحنة (أقرب هدف معادٍ بدل اللاعب البعيد)'); }
{ reset(); const e = veh('tank','enemy',0,0); P.g.position.set(0,300,-500); step(120);
  ok(e.tgt === P,'بلا حلفاء: هدف مركبة العدو هو اللاعب');
  ok(C.shots.filter(s => s.side === 'enemy').length > 0,'يطلق على اللاعب ضمن مدى المضاد الجوي (500م < 600)'); 
  reset(); const f = veh('tank','enemy',0,0); P.g.position.set(0,300,-1500); step(120);
  ok(C.shots.length === 0,'اللاعب بعيد (1500م): دبابة لا ترمي طائرة خارج مداها'); }
{ reset(); W.G.ms = createRuntime({id:'x',objectives:[{id:'o',type:'destroy',text:'t',targets:['zz']}],fail:[]});
  const a = veh('apc','ally',0,0,{speed:18,route:[{x:0,z:-120}]}); a.mid = 'cv2'; step(300);
  ok(a.drv.state === 'arrived','المركبة تصل نهاية مسارها بالمحاكاة');
  ok(W.G.ms.q.filter(ev => ev.type === 'entityArrived' && ev.id === 'cv2').length === 1,'حدث entityArrived مرة واحدة للمهمة');
  const out = stepRuntime(W.G.ms,.1); ok(Array.isArray(out),'حدث الوصول لا يكسر آلة الحالات'); }
{ reset(); P.g.position.set(0,2000,0);                      // سقف الأداء: 30 مركبة، الأبعد لا تطلق
  const near = veh('tank','ally',0,0), enemy = veh('tank','enemy',0,-600);
  for(let i = 0; i < 28; i++) veh('truck','ally',5000+i*30,0,{route:[{x:5000+i*30,z:-3000}]});
  const far = veh('tank','ally',9000,0), farE = veh('tank','enemy',9000,-500);
  W.G.actT = 0; step(90);
  ok(far.lite === true && farE.lite === true && near.lite === false,'الأبعد عن اللاعب مبسّطة والأقرب نشطة');
  const farShots = C.shots.filter(s => s.pos.x > 4000); ok(farShots.length === 0,'الوحدات المبسّطة لا ترمي');
  ok(C.shots.some(s => s.side === 'ally' || s.side === 'enemy'),'القريبة تشتبك');
  ok(W.units.slice(2,30).every(u => u.drv.z < -1 || u.drv.z === undefined),'المبسّطة تواصل التقدّم على مسارها'); }
console.log(fail ? `✗ فشل ${fail}` : `✓ نجح الكل: ${pass} اختبار`); process.exit(fail ? 1 : 0);
