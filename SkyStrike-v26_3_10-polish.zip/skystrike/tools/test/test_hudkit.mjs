/* HUD الرسائل: تقسيم الإحاطة، الاتجاهات الجغرافية وزاوية التوجيه، صفوف لوحة الأهداف، وأن كل نص i18n مطلوب موجود. دوال صرفة. */
import {splitBrief} from '../../src/mission/comms.js';
import {cardinalIdx, relBearing, objectiveRows} from '../../src/mission/mission_hud.js';
import {createRuntime} from '../../src/mission/mission_runtime.js';
import {MISSIONS} from '../../src/mission/mission_defs.js';
import {MISSION_TEXT} from '../../src/mission/mission_text.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if(!c) fail++; };
const near = (a, b) => Math.abs(a-b) < 1e-9;

let r = splitBrief('وزارة الدفاع ← الطيار: دمّر الرادار');
ok(r.head === 'وزارة الدفاع ← الطيار' && r.body === 'دمّر الرادار', 'splitBrief: مرسل + متن');
r = splitBrief('MoD to Pilot: destroy it: now'); ok(r.head === 'MoD to Pilot' && r.body === 'destroy it: now', 'splitBrief: أول نقطتين فقط');
r = splitBrief('دمّر الرادار فوراً'); ok(r.head === '' && r.body === 'دمّر الرادار فوراً', 'splitBrief: بلا مرسل ← head فارغ');
r = splitBrief('a'.repeat(50)+': x'); ok(r.head === '', 'splitBrief: مرسل أطول من 34 حرفاً لا يُعتبر مرسلاً');
ok(splitBrief(undefined).body === '', 'splitBrief: undefined آمن');

ok(cardinalIdx(0, -10) === 0 && cardinalIdx(10, 0) === 2 && cardinalIdx(0, 10) === 4 && cardinalIdx(-10, 0) === 6, 'cardinalIdx: ش/شرق/ج/غ (z سالب = شمال)');
ok(cardinalIdx(10, -10) === 1 && cardinalIdx(-10, 10) === 5, 'cardinalIdx: قُطري');
ok(near(relBearing(0, -100, 0), 0), 'relBearing: هدف أمامك (yaw 0 يواجه −Z) ← 0');
ok(relBearing(100, 0, 0) > 1.5 && relBearing(-100, 0, 0) < -1.5, 'relBearing: يمين +، يسار −');
ok(Math.abs(relBearing(0, 100, 0)) > 3.1, 'relBearing: خلفك ≈ π');
ok(near(relBearing(100, 0, -Math.PI/2), 0), 'relBearing: بعد دوران الطائرة نحو الشرق يصير الشرق أمامك');

const tr = k => k, rt = createRuntime(MISSIONS[0]);
try { const rows = objectiveRows(rt, tr); ok(rows.length === MISSIONS[0].objectives.length && rows.every(o => o.text && o.st), 'objectiveRows: صف لكل هدف'); }
catch(e){ ok(false, 'objectiveRows رمى: '+e.message); }

const need = ['c_cmd', 'c_gnd', 'c_ally', 'c_mod', 'cm_radio', 'cm_brief', 'cm_nav', 'cm_ahead', 'cm_left', 'cm_right', 'cm_back',
  ...['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'].map(x => 'cm_'+x)];
ok(need.every(k => MISSION_TEXT[k] && MISSION_TEXT[k].length === 2 && MISSION_TEXT[k][0] && MISSION_TEXT[k][1]), 'نصوص الراديو/التوجيه موجودة بلغتين');
const lens = []; for(const m of MISSIONS){ for(const c of m.comms || []){ for(const L of [0, 1]) lens.push([m.id+'.'+c.id, MISSION_TEXT[c.text][L].length]); } }
const longest = lens.reduce((a, b) => b[1] > a[1] ? b : a);
ok(longest[1] <= 130, 'أطول رسالة لاسلكي ≤ 130 حرفاً (قصيرة على البطاقة): '+longest[0]+' = '+longest[1]);
const heads = MISSIONS.map(m => [m.id, splitBrief(MISSION_TEXT[m.intro][0]), splitBrief(MISSION_TEXT[m.intro][1])]);
ok(heads.every(([, a, b]) => a.head && a.body && b.head && b.body), 'كل إحاطات الحملة (ar+en) فيها مرسل ومتن: '+heads.filter(([, a, b]) => !(a.head && a.body && b.head && b.body)).map(h => h[0]).join(','));
console.log(fail ? '\nFAILED '+fail : '\nOK'); process.exit(fail ? 1 : 0);
