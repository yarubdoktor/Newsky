// اختبار المسارح (M5): تضاريس/مواقع/طرق/نقطة بداية + أن كل موضع مسمّى بالمهمات موجود وصالح لوضع الوحدات الأرضية.
// لا يستورد maps.js (يحتاج DOM) — يستورد وحدات src/theater مباشرة (دوال صرفة).
import {TERRAINS} from '../../src/theater/terrains.js';
import {LOOKS} from '../../src/theater/looks.js';
import {makeShaper} from '../../src/theater/shape.js';
import {buildLayout} from '../../src/theater/layout.js';
import {mkNoise} from '../../src/noise.js';
import {mulberry} from '../../src/theater/math.js';
import {MISSIONS} from '../../src/mission/mission_defs.js';
import {anchorOf, GROUND_KINDS} from '../../src/mission/entity_pos.js';
let ok = 0, bad = 0; const t = (n, c,
  x = '') => { c ? ok++ : bad++; console.log((c ? '  ✓ ' : '  ✗ ')+n+(x ? ' — '+x : '')); };
const slope = (H, x, z) => Math.hypot(H(x+8, z)-H(x, z), H(x, z+8)-H(x, z));

const TH = {};
for(const id of Object.keys(TERRAINS)){
  const T = TERRAINS[id], n = mkNoise(T.seed), S = makeShaper(T, n);
  const t0 = Date.now(), lay = buildLayout(T, S), ms = Date.now()-t0;
  TH[id] = {T, S, lay};
  console.log('\n'+id+':');
  const L = T.limit; let sea = 0, tot = 0, steep = 0;
  for(let x = -L; x <= L; x += L/60) for(let z = -L; z <= L; z += L/60){
    const h = S.H(x, z); tot++; if(h < 0) sea++; else if(Math.atan(slope(S.H, x, z)/8) > .52) steep++; }
  t('ارتفاعات محدودة وصالحة', Number.isFinite(S.H(0, 0)) && S.H(L, L) > -500 && S.H(-L, -L) < 3000);
  if(id === 'gulf') t('الخليج: بحر 60–90%', sea/tot > .6 && sea/tot < .9, (sea/tot*100).toFixed(0)+'%');
  else t('اليابسة غالبة (بحر < 40%)', sea/tot < .4, (sea/tot*100).toFixed(0)+'%');
  t('انحدار >30° أقل من 30% من اليابسة', steep/Math.max(1, tot-sea) < .3, (steep/Math.max(1,
    tot-sea)*100).toFixed(1)+'%');
  t('بناء التخطيط سريع (< 400 مللي ث)', ms < 400, ms+' ms');
  const sp = T.spawn, gs = S.H(sp.x, sp.z);
  t('نقطة البداية على اليابسة وفوقها هواء', gs > 3 && !lay.hit(sp.x, gs+sp.alt, sp.z) && !lay.hit(sp.x, gs+sp.alt,
    sp.z-600),
    'h='+gs.toFixed(1));
  let flatBad = 0;
  for(const p of S.pads){
    if(p.shape === 'r') for(const [a, b] of [[-.8, -.8], [.8, .8], [-.8, .8], [.8, -.8], [0, 0]]){
      if(Math.abs(S.H(p.x+a*p.hx, p.z+b*p.hz)-p.h) > 2.5) flatBad++; }
    else for(const a of [0, 1.5, 3, 4.5]) if(Math.abs(S.H(p.x+Math.cos(a)*p.r*.7,
      p.z+Math.sin(a)*p.r*.7)-p.h) > 2.5) flatBad++;
  }
  t('أرضيات المواقع مسطّحة (±2.5م (طريق قد يعبر الموقع))', flatBad === 0, flatBad+' نقطة خارج التسطيح');
  let roadBad = 0, roadN = 0;
  for(const r of S.roads) for(let i = 1; i < r.nodes.length; i++){
    const [x0, z0] = r.nodes[i-1], [x1, z1] = r.nodes[i];
    for(let k = 0; k <= 4; k++){ const x = x0+(x1-x0)*k/4, z = z0+(z1-z0)*k/4; roadN++;
      if(Math.atan(slope(S.H, x, z)/8) > .35) roadBad++; } }
  t('الطرق متدرّجة (ميل < 20°)', roadBad/Math.max(1, roadN) < .02, roadBad+'/'+roadN);
  t('كل موقع له معرّف فريد', new Set(S.pads.map(p => p.id)).size === S.pads.length, S.pads.length+' موقعاً');
}

console.log('\nالمهمات ↔ المسارح:');
const rnd = mulberry(7);
function landOk(S, lay, water, cx, cz, rad){
  const minH = water ? 5 : -1e9;
  for(let i = 0; i < 120; i++){
    const x = cx+(rnd()*2-1)*rad, z = cz+(rnd()*2-1)*rad, h = S.H(x, z);
    if(h < minH || slope(S.H, x, z) > 5 || lay.hit(x, h+3, z)) continue; return true; }
  return false;
}
let hostAll = 0;
for(const m of MISSIONS){
  const look = LOOKS[m.map]; if(!look){ t(m.id+': خريطة المسرح '+m.map+' معرّفة', false); continue; }
  const th = TH[look.terrain], sites = {};
  for(const p of th.S.pads) sites[p.id] = p;
  const spawn = {x:th.T.spawn.x, z:th.T.spawn.z, yaw:th.T.spawn.yaw || 0, sites};
  const ents = [...m.entities]; for(const tr of m.triggers) for(const a of tr.do) if(a.spawn) ents.push(...a.spawn);
  const placed = {}; let err = '', fail = [], g = 0;
  const water = !!look.water;
  try{
    for(const e of ents){
      const a = anchorOf(e.pos, spawn, placed); placed[e.id] = a;
      if(GROUND_KINDS.includes(e.kind) || e.kind === 'convoy'){ g++;
        if(!landOk(th.S, th.lay, water, a.x, a.z, a.rad)) fail.push(e.id); }
      for(const p of e.route || []){ const b = anchorOf(p, spawn, placed); if(!landOk(th.S, th.lay, water, b.x, b.z,
        b.rad)) fail.push(e.id+'/route'); }
    }
    for(const o of m.objectives) if(o.pos) anchorOf(o.pos, spawn, placed);
    for(const tr of m.triggers) if(tr.when.zone) anchorOf(tr.when.zone.pos, spawn, placed);
  }catch(e){ err = e.message; }
  // مسار الرتل: نقاط متتالية بخط مستقيم، بلا عوائق طويلة
  for(const e of ents.filter(x => x.kind === 'convoy')){
    const pts = [e.pos, ...e.route].map(q => anchorOf(q, spawn, placed)); let worst = 0, blocked = 0, n = 0;
    for(let i = 1; i < pts.length; i++){
      const L = Math.hypot(pts[i].x-pts[i-1].x, pts[i].z-pts[i-1].z); let run = 0;
      for(let d = 0; d <= L; d += 8){ const k = d/L, x = pts[i-1].x+(pts[i].x-pts[i-1].x)*k,
        z = pts[i-1].z+(pts[i].z-pts[i-1].z)*k, h = th.S.H(x, z);
        const bad = (water && h < 1) || slope(th.S.H, x, z) > 6.5 || th.lay.hit(x, h+3, z); n++;
        if(bad){ blocked++; run += 8; worst = Math.max(worst, run); } else run = 0; } }
    t(m.id+': مسار الرتل '+e.id+' سالك (عوائق < 8% ولا مقطع متصل > 120م)', blocked/n < .08 && worst <= 120,
      (blocked/n*100).toFixed(1)+'% · أطول مقطع '+worst+'م');
  }
  t(m.id+' ('+m.map+'): كل المواضع المسمّاة موجودة', !err, err);
  t(m.id+': كل الوحدات الأرضية تجد أرضاً صالحة', fail.length === 0, fail.join(',') || g+' وحدة');
  hostAll += g;
}
console.log('\n'+ok+' نجح، '+bad+' فشل ('+hostAll+' وحدة أرضية فُحصت)');
if(bad) process.exit(1);
console.log('✓ نجح الكل');
