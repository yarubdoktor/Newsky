export class Vec3{
  constructor(x=0,y=0,z=0){ this.x=x; this.y=y; this.z=z; }
  set(x,y,z){ this.x=x; this.y=y; this.z=z; return this; }
  copy(v){ this.x=v.x; this.y=v.y; this.z=v.z; return this; }
  clone(){ return new Vec3(this.x,this.y,this.z); }
  add(v){ this.x+=v.x; this.y+=v.y; this.z+=v.z; return this; }
  sub(v){ this.x-=v.x; this.y-=v.y; this.z-=v.z; return this; }
  addScaledVector(v,s){ this.x+=v.x*s; this.y+=v.y*s; this.z+=v.z*s; return this; }
  multiplyScalar(s){ this.x*=s; this.y*=s; this.z*=s; return this; }
  divideScalar(s){ return this.multiplyScalar(1/s); }
  length(){ return Math.hypot(this.x,this.y,this.z); }
  normalize(){ return this.divideScalar(this.length()||1); }
  dot(v){ return this.x*v.x+this.y*v.y+this.z*v.z; }
  distanceToSquared(v){ return (this.x-v.x)**2+(this.y-v.y)**2+(this.z-v.z)**2; }
  distanceTo(v){ return Math.sqrt(this.distanceToSquared(v)); }
  lerp(v,t){ this.x+=(v.x-this.x)*t; this.y+=(v.y-this.y)*t; this.z+=(v.z-this.z)*t; return this; }
  applyEuler(){ return this; }
}
export const V = (x,y,z) => new Vec3(x,y,z);
export class Mesh{ constructor(){ this.position = new Vec3(); this.scale = {set(){}}; } lookAt(){} }
export const BULLET_GEO = {}, BULLET_P = {}, BULLET_E = {};
export const mkMsl = () => new Mesh(), mkBomb = () => new Mesh();
export const scene = {add(){}, remove(){}};
export const world = {ground:() => -1e9, H:() => 0, hasWater:() => false, cfg:{}};
export const counts = {explode:0};                       // عدّاد الانفجارات الكبيرة (fx.explode)
export const fx = {explode(){ counts.explode++; }, glow(){}, smk(){}};
export const vib = () => {}, panOf = () => 0, dirOfTo = (g,out) => out.set(0,0,-1);
export const $ = () => ({style:{}, classList:{add(){},remove(){},toggle(){}}});
export const clamp = (v,a,b) => Math.min(b,Math.max(a,v));
export const rnd = (a,b) => a+Math.random()*(b-a);
export const wrap = a => { while(a > Math.PI) a -= 2*Math.PI; while(a < -Math.PI) a += 2*Math.PI; return a; };
export const t = k => k, sfx = () => {}, setEngine = () => {}, banner = () => {}, addAir = () => {};
export const W = {run:true,paused:false,G:{},units:[],projs:[],flares:[],shake:0,tut:null,lockE:null,candE:null,lockT:0};
export const P = {side:"player",g:{position:new Vec3(),visible:true},hp:100,maxhp:100,speed:150,cur:150,ms:1};
export const shadow = {visible:false};
export const FW = new Vec3(0,0,-1);
