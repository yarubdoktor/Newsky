// أداة تطوير (M8): لقطات لكل طرازات مقاتلات العدو والحليف داخل المحرك. node tools/jet_shots.mjs out_dir
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url), {chromium} = require('playwright');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), dist = resolve(root, 'dist');
const out = process.argv[2] || 'jet_shots'; mkdirSync(out, {recursive:true});
const MIME = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.webp':'image/webp', '.png':'image/png', '.glb':'model/gltf-binary', '.bin':'application/octet-stream', '.json':'application/json'};
const server = createServer((req, res) => { let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist, '.'+p); if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type':MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f)); });
await new Promise(r => server.listen(0, '127.0.0.1', r));
const browser = await chromium.launch({executablePath:process.env.PW_CHROME || undefined, args:['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:1280, height:720}, locale:'ar'}); const errs = [];
page.on('pageerror', e => errs.push(e.stack.split('\n').slice(0, 3).join(' | ')));
await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
await page.goto(`http://127.0.0.1:${server.address().port}/`, {waitUntil:'load'});
await page.waitForFunction(() => globalThis.__ss && document.querySelector('#menu')?.children.length > 0, null, {timeout:60000});
await page.evaluate(() => { const s = globalThis.__ss; s.S.tut = 1; s.startMission(0); });
await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout:60000});
await page.evaluate(() => { const s = globalThis.__ss; s.setPause(true); for(const u of [...s.W.units]) u.g.visible = false; s.P.g.visible = false; });
await page.addStyleTag({content:'body > *:not(canvas){display:none !important}'});
const SIDES = [['enemy',0.1,false],['enemy',0.5,false],['enemy',0.9,false],['enemy',0.5,true],['ally',0.2,false],['ally',0.8,false]];
const names = [];
for(let i = 0; i < SIDES.length; i++){
  const nm = await page.evaluate(([side, r, elite, ang]) => { const s = globalThis.__ss, THREE_V = s.cam.position.clone();
    const g = s.mkAirJet(side, side === 'ally' ? 0x2f7a4a : (elite ? 0xd4af37 : 0xa03030), elite, r); s.scene.add(g); globalThis.__jet = g;
    const f = s.cam.getWorldDirection(THREE_V.clone()); g.position.copy(s.cam.position).addScaledVector(f, 38);
    g.rotation.order = 'YXZ'; g.rotation.set(-0.15, ang, 0.12); return g.userData.model + (elite ? '_ace' : ''); }, [...SIDES[i], 2.3]);
  names.push(SIDES[i][0]+'_'+nm);
  await page.waitForTimeout(700); await page.screenshot({path:join(out, String(i).padStart(2, '0')+'_'+SIDES[i][0]+'_'+nm+'.png')});
  await page.evaluate(() => { globalThis.__ss.scene.remove(globalThis.__jet); });
}
console.log(names.join(' '), 'errors', errs);
await browser.close(); server.close();
