// أداة تطوير: ترسم خريطة علوية (ارتفاع+مواقع+طرق) لكل مسرح إلى PPM ثم تُحوَّل لـ PNG بـ python. الاستعمال: node tools/viz_terrain.mjs id out.ppm
import {TERRAINS} from '../src/theater/terrains.js';
import {makeShaper} from '../src/theater/shape.js';
import {mkNoise} from '../src/noise.js';
import fs from 'node:fs';
const id = process.argv[2], out = process.argv[3], T = TERRAINS[id], n = mkNoise(T.seed), S = makeShaper(T, n);
const L = T.limit, N = 600, buf = Buffer.alloc(N*N*3); let t0 = Date.now(), stats = {sea:0, steep:0, tot:0, max:-1e9,
  min:1e9};
for(let j = 0; j < N; j++) for(let i = 0; i < N; i++){
  const x = -L+2*L*i/N, z = -L+2*L*j/N, h = S.H(x, z), e = 20;
  const gx = (S.H(x+e, z)-S.H(x-e, z))/(2*e), gz = (S.H(x, z+e)-S.H(x, z-e))/(2*e), sl = Math.atan(Math.hypot(gx,
    gz))*57.3;
  stats.tot++; if(h < 0) stats.sea++; else if(sl > 30) stats.steep++; stats.max = Math.max(stats.max,
    h); stats.min = Math.min(stats.min, h);
  const sh = Math.max(.35, Math.min(1.2, .8+(gx*.7+gz*.7)*-1.2)); let c;
  if(h < 0) c = [20, 70+h*.5, 130]; else if(h < 5) c = [220, 200, 140]; else if(h < 120) c = [70, 120,
    60]; else if(h < 400) c = [120, 110, 80]; else c = [150, 150, 150];
  if(sl > 30 && h >= 0) c = [200, 60, 60];
  const k = (j*N+i)*3; buf[k] = Math.min(255, c[0]*sh); buf[k+1] = Math.min(255, c[1]*sh); buf[k+2] = Math.min(255,
    c[2]*sh);
}
const px = (x, z, c, r = 2) => { const i = Math.round((x+L)/(2*L)*N), j = Math.round((z+L)/(2*L)*N);
  for(let a = -r; a <= r; a++) for(let b = -r; b <= r; b++){ const ii = i+a,
    jj = j+b; if(ii < 0 || jj < 0 || ii >= N || jj >= N) continue;
    const k = (jj*N+ii)*3; buf[k] = c[0]; buf[k+1] = c[1]; buf[k+2] = c[2]; } };
for(const r of S.roads) for(const p of r.nodes) px(p[0], p[1], [255, 255, 0], 0);
for(const s of S.pads) px(s.x, s.z, s.side === 'ally' ? [0, 255, 255] : s.side === 'enemy' ? [255, 0, 255] : [255,
  255, 255], 3);
px(T.spawn.x, T.spawn.z, [0, 255, 0], 4);
fs.writeFileSync(out, Buffer.concat([Buffer.from(`P6 ${N} ${N} 255\n`), buf]));
console.log(id, 'ms', Date.now()-t0, 'sea%', (stats.sea/stats.tot*100).toFixed(1), 'steep>30°%',
  (stats.steep/stats.tot*100).toFixed(1), 'h', stats.min.toFixed(0), stats.max.toFixed(0));
for(const s of S.pads) console.log(' ', s.id, s.type, 'h=', s.h.toFixed(0));
