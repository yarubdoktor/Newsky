// تقرير قرار الأصول (للمالك): يسرد كل GLB/bin وكل خريطة مع الحجم وأين تُستعمل فعلاً بالحملة، وتوصية keep/remove.
// يقرأ فقط ولا يحذف أي شيء أبداً.  تشغيل: node tools/asset_report.mjs > ASSET_REPORT.md
import fs from 'node:fs'; import path from 'node:path';
import {MISSIONS} from '../src/mission/mission_defs.js';
import {LOOKS} from '../src/theater/looks.js';
const root = new URL('..', import.meta.url).pathname;
const kb = f => (fs.statSync(path.join(root, f)).size/1024).toFixed(0)+' KB';

/* نماذج وقت التشغيل ← أين تُستعمل بالحملة (محسوبة من تعريفات المهمات) */
const kindsIn = m => { const out = []; const add = e => { if(e.kind === 'convoy') e.units.forEach(u => out.push({kind:u}));
  else out.push(e); };
  m.entities.forEach(add); m.triggers.forEach(t => t.do.forEach(a => (a.spawn || []).forEach(add))); return out; };
const MODEL_OF = e => e.kind === 'turret' ? ['e_aa_twin', 'e_aa_tank', 'gepard'][(e.tt|0)%3].replace(/^(?!e_)/, 'e_')
  : {sam:'e_sam', flak:'e_flak', heli:'e_heli', drone:'e_drone', tank:'e_tank', apc:'e_apc', truck:'e_truck'}[e.kind] || null;
const use = {}; for(const m of MISSIONS) for(const e of kindsIn(m)){ const k = MODEL_OF(e); if(k) (use[k] ||= new Set()).add(m.id); }
const campaignUse = k => use[k] ? [...use[k]].join('، ') : 'لا مهمة (جاهز للاستعمال)';

const RT = [  // [ملف, دور, توصية, ملاحظة]
  ['src/models/f35.glb', 'مقاتلة عدو (F-35) منذ M8 — كانت طائرة اللاعب الافتراضية', 'احتفظ', 'تُحمَّل في emodels.js'],
  ['src/models/mig29.glb', 'طائرة اللاعب الافتراضية المجانية (MiG-29)', 'احتفظ', 'أساسي بالحظيرة'],
  ['src/models/su57.glb', 'طائرة اللاعب (Su-57)', 'احتفظ', 'أساسي بالحظيرة'],
  ...['e_aa_twin', 'e_aa_tank', 'e_gepard', 'e_sam', 'e_flak', 'e_heli', 'e_drone', 'e_tank', 'e_apc', 'e_truck'].map(k =>
    ['src/models/'+k+'.glb', 'وحدة عدو/حليف أرضية أو جوية', 'احتفظ', 'مهمات: '+campaignUse(k)]),
  ['src/models/greenland.bin', 'خريطة غرينلاند (حزمة مبنية)', 'قرارك', 'غير مستعملة بالحملة؛ تدخل حزمة التطبيق (~0.6MB)'],
  ['src/models/map7.bin', 'خريطة 7 «القاعدتان والأساطيل» (حزمة مبنية)', 'قرارك', 'غير مستعملة بالحملة؛ تدخل حزمة التطبيق (~0.08MB)']
];
const SRC = [
  ['models_src/F35_Stealth_Fighter_Premium.glb', 'مصدر f35.glb (tools/optimize_glb.py)', 'احتفظ', 'لإعادة التوليد'],
  ['models_src/MIG29.glb', 'مصدر mig29.glb', 'احتفظ', 'لإعادة التوليد'],
  ['models_src/SU57.glb', 'مصدر su57.glb', 'احتفظ', 'لإعادة التوليد'],
  ['models_src/F35_Stealth_Fighter.glb', 'نسخة F-35 أبسط، لا تشير إليها أي أداة ولا كود', 'قرارك (يمكن حذفه بلا أثر)', 'مكرّر وظيفياً مع Premium'],
  ['models_src/retired/enemy_f35_simplified.glb', 'مقاتلة عدو قديمة مبسّطة (أُحيلت للتقاعد؛ مقاتلة F-35 للعدو الآن هي f35.glb الأساسي، وF-16/F-15 برمجيان)', 'قرارك (يمكن حذفه بلا أثر)', 'مجلد retired'],
  ['models_src/enemies/AA_Twin_Rotary_AAA.glb', 'مصدر e_aa_twin', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/tank_aaa.glb', 'مصدر e_aa_tank', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/anti_air_gepard_aaa.glb', 'مصدر e_gepard', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/sam_platform_aaa.glb', 'مصدر e_sam', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/SkyStrike_AA_Flak_Heavy_v1.glb', 'مصدر e_flak', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/helicopter_aaa.glb', 'مصدر e_heli', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/enemies/UAV_Lightweight_Mobile.glb', 'مصدر e_drone', 'احتفظ', 'tools/prep_enemy.py'],
  ['models_src/Greenland_World_20km.glb', 'مصدر greenland.bin (أكبر ملف بالمستودع)', 'قرارك', 'tools/convert_world.py'],
  ['models_src/map7_terrain.glb', 'مصدر map7.bin (تضاريس)', 'قرارك', 'tools/convert_map7.py'],
  ['models_src/map7_world.glb', 'مصدر map7.bin (مجسّمات)', 'قرارك', 'tools/convert_map7.py']
];
const mapUse = id => MISSIONS.filter(m => m.map === id).map(m => m.id).join('، ') || '—';
const MAPS = [
  ...Object.keys(LOOKS).map(id => [id, 'مسرح جديد (M5) مستوحى من الخرائط القديمة', mapUse(id), 'احتفظ']),
  ['island', 'خريطة قديمة إجرائية (الاحتياطي الافتراضي بالكود)', mapUse('island'), 'احتفظ (احتياطي)'],
  ['desert', 'خريطة قديمة (كانت لـ m0–m2 قبل نقلها إلى front)', mapUse('desert'), 'قرارك'],
  ['arctic', 'خريطة قديمة', mapUse('arctic'), 'قرارك'], ['canyon', 'خريطة قديمة', mapUse('canyon'), 'قرارك'],
  ['night', 'خريطة قديمة (ليلية)', mapUse('night'), 'قرارك'],
  ['greenland', 'خريطة GLB (greenland.bin)', mapUse('greenland'), 'قرارك'], ['map7', 'خريطة GLB (map7.bin)', mapUse('map7'), 'قرارك']
];
const row = (a, b, c, d) => `| ${a} | ${b} | ${c} | ${d} |`;
const out = ['# تقرير قرار الأصول (SkyStrike v26.3.8)', '',
  '> لم يُحذف أي ملف. هذا تقرير توصية فقط، والقرار النهائي لك. كل الأصول الأصلية محفوظة بلا تغيير ويحرسها ' +
  '`tools/test/test_assets_kept.mjs` (بصمة sha256).', '',
  '## النماذج والحزم المبنية (تدخل التطبيق)', '', '| الملف | الحجم | الدور / الاستعمال | التوصية |', '|---|---|---|---|'];
for(const [f, r, rec, n] of RT) out.push(row('`'+f+'`', kb(f), r+' — '+n, rec));
out.push('', '## مصادر النماذج (للتوليد فقط، لا تدخل التطبيق)', '', '| الملف | الحجم | الدور | التوصية |', '|---|---|---|---|');
for(const [f, r, rec, n] of SRC) out.push(row('`'+f+'`', kb(f), r+' — '+n, rec));
out.push('', '## الخرائط', '', '| الخريطة | الوصف | مهمات الحملة التي تستعملها | التوصية |', '|---|---|---|---|');
for(const [id, d, u, rec] of MAPS) out.push(row('`'+id+'`', d, u, rec));
console.log(out.join('\n'));
