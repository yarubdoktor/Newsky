// أداة تطوير: لقطات شاشة من المحرك الحقيقي (Chromium+SwiftShader) للمسارح. تشغيل: node tools/shots.mjs out_dir [map ...]
// تتطلب dist/ (npm run build). كل لقطة = تحريك الطائرة لنقطة ثم انتظار بضعة فريمات.
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url), {chromium} = require('playwright');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), dist = resolve(root, 'dist');
const [out, ...maps] = process.argv.slice(2); mkdirSync(out, {recursive:true});
const MIME = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.webp':'image/webp',
  '.png':'image/png', '.glb':'model/gltf-binary', '.bin':'application/octet-stream', '.json':'application/json'};
const server = createServer((req,
  res) => { let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist,
    '.'+p); if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type':MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f)); });
await new Promise(r => server.listen(0, '127.0.0.1', r));
const SHOTS = JSON.parse(readFileSync(join(root, 'tools/shots.json'), 'utf8'));
const browser = await chromium.launch({executablePath:process.env.PW_CHROME || undefined,
  args:['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:1280, height:720}}); const errs = [];
page.on('pageerror', e => errs.push(e.stack.split('\n').slice(0,4).join(' | '))); page.on('console',
  m => { if(m.type() === 'error') errs.push(m.text()); });
await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
await page.goto(`http://127.0.0.1:${server.address().port}/`, {waitUntil:'load'});
await page.waitForFunction(() => globalThis.__ss && document.querySelector('#menu')?.children.length > 0, null,
  {timeout:60000});
for(const id of (maps.length ? maps : Object.keys(SHOTS))){
  await page.evaluate(m => { const s = globalThis.__ss; s.MISSIONS[0].map = m; s.startMission(0); }, id);
  await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout:60000});
  for(const [i, sh] of SHOTS[id].entries()){
    await page.evaluate(sh => { const {P} = globalThis.__ss; P.g.position.set(sh.x, sh.y,
      sh.z); P.yaw = sh.yaw; P.pitch = sh.pitch; P.roll = 0; P.hp = 1e9; P.cur = 0.01; P.speed = 0.01; }, sh);
    await page.waitForTimeout(sh.wait || 5000);
    await page.screenshot({path:join(out, `${id}_${i}.png`)});
  }
  await page.reload({waitUntil:'load'});
  await page.waitForFunction(() => globalThis.__ss && document.querySelector('#menu')?.children.length > 0, null, {timeout:60000});
}
if(errs.length) console.log('errors:', [...new Set(errs)].slice(0, 10));
await browser.close(); server.close();
