// أداة تطوير: لقطات مشاهد قتال (مواقع أعداء، انفجار، مطاردة جوية) لتقييم الجودة البصرية. node tools/scene_shots.mjs out_dir mission_index
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url), {chromium} = require('playwright');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), dist = resolve(root, 'dist');
const [out, mi = '3'] = process.argv.slice(2); mkdirSync(out, {recursive:true});
const MIME = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.webp':'image/webp', '.png':'image/png', '.glb':'model/gltf-binary', '.bin':'application/octet-stream', '.json':'application/json'};
const server = createServer((req, res) => { let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist, '.'+p); if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type':MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f)); });
await new Promise(r => server.listen(0, '127.0.0.1', r));
const browser = await chromium.launch({executablePath:process.env.PW_CHROME || undefined, args:['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:1280, height:720}, locale:'ar'}); const errs = [];
page.on('pageerror', e => errs.push(e.stack.split('\n').slice(0, 3).join(' | ')));
await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
await page.goto(`http://127.0.0.1:${server.address().port}/`, {waitUntil:'load'});
await page.waitForFunction(() => globalThis.__ss && document.querySelector('#menu')?.children.length > 0, null, {timeout:60000});
await page.evaluate(i => { const s = globalThis.__ss; for(let k = 0; k < i; k++) s.S.ms[s.MISSIONS[k].id] = {stars:1, best:0, bt:0, n:1, done:true}; s.S.tut = 1; s.startMission(i); }, +mi);
await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout:60000});
const info = await page.evaluate(() => globalThis.__ss.units.map(u => ({k:u.kind || u.type, mid:u.mid, x:u.g.position.x|0, y:u.g.position.y|0, z:u.g.position.z|0})));
console.log(JSON.stringify(info.slice(0, 30)));
async function look(name, tx, ty, tz, dist, h, wait = 4000){
  await page.evaluate(([tx, ty, tz, dist, h]) => { const {P} = globalThis.__ss; const yaw = 0.6; // الطائرة تواجه (-sin,-cos)
    P.g.position.set(tx + Math.sin(yaw)*dist, ty + h, tz + Math.cos(yaw)*dist); P.yaw = yaw; P.pitch = -Math.atan2(h, dist); P.roll = 0; P.hp = 1e9; P.cur = 0.01; P.speed = 0.01; }, [tx, ty, tz, dist, h]);
  await page.waitForTimeout(wait); await page.screenshot({path:join(out, name+'.png')});
}
const grounds = info.filter(u => u.y < 60);
const pick = grounds.sort((a, b) => 0)[0];
if(pick){ await look('site', pick.x, pick.y, pick.z, 320, 70); await look('site_far', pick.x, pick.y, pick.z, 900, 160); 
  await page.evaluate(() => { const s = globalThis.__ss; for(const u of s.units.slice(0, 3)) { try { s.kill(u, true); } catch(e) { try { s.kill(u); } catch(_){} } } });
  await page.waitForTimeout(300); await page.screenshot({path:join(out, 'boom0.png')}); await page.waitForTimeout(900); await page.screenshot({path:join(out, 'boom1.png')}); }
console.log('errors', errs);
await browser.close(); server.close();
