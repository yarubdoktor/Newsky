// يولّد tools/test/assets_manifest.json: sha256 + حجم لكل GLB/bin أصلي (models_src و src/models). تشغيله يدوياً فقط عند
// إضافة أصل جديد؛ لا يُشغَّل مع الاختبارات. لا يحذف شيئاً أبداً.
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const root = new URL('..', import.meta.url).pathname, out = {};
const walk = d => fs.readdirSync(d, {withFileTypes:true}).flatMap(e => e.isDirectory() ? walk(path.join(d,
  e.name)) : [path.join(d, e.name)]);
for(const dir of ['models_src', 'src/models']){
  const p = path.join(root, dir); if(!fs.existsSync(p)) continue;
  for(const f of walk(p)) if(/\.(glb|bin)$/i.test(f)){
    const b = fs.readFileSync(f); out[path.relative(root, f)] = {bytes:b.length,
      sha256:crypto.createHash('sha256').update(b).digest('hex')}; }
}
fs.writeFileSync(path.join(root, 'tools/test/assets_manifest.json'), JSON.stringify(out, null, 1)+'\n');
console.log(Object.keys(out).length, 'أصل سُجّل');
