// أداة تطوير: لقطات HUD (رسائل اللاسلكي/اللافتات) من المحرك الحقيقي. تشغيل: node tools/hudshot.mjs out_dir [mission_index] [--w=1280 --h=720]
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url), {chromium} = require('playwright');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), dist = resolve(root, 'dist');
const args = process.argv.slice(2), flags = Object.fromEntries(args.filter(a => a.startsWith('--')).map(a => a.slice(2).split('=')));
const [out, mi = '3', lang = 'ar'] = args.filter(a => !a.startsWith('--')); mkdirSync(out, {recursive:true});
const W = +(flags.w || 1280), H = +(flags.h || 720);
const MIME = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.webp':'image/webp', '.png':'image/png', '.glb':'model/gltf-binary', '.bin':'application/octet-stream', '.json':'application/json'};
const server = createServer((req, res) => { let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist, '.'+p); if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type':MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f)); });
await new Promise(r => server.listen(0, '127.0.0.1', r));
const browser = await chromium.launch({executablePath:process.env.PW_CHROME || undefined, args:['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
const page = await browser.newPage({deviceScaleFactor:+(flags.s || 1), viewport:{width:W, height:H}, locale:lang === 'en' ? 'en-US' : 'ar'}); const errs = [];
page.on('pageerror', e => errs.push(e.stack.split('\n').slice(0, 4).join(' | '))); page.on('console', m => { if(m.type() === 'error') errs.push(m.text()); });
await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
await page.goto(`http://127.0.0.1:${server.address().port}/`, {waitUntil:'load'});
await page.waitForFunction(() => globalThis.__ss && document.querySelector('#menu')?.children.length > 0, null, {timeout:60000});
await page.evaluate(([i, flags]) => { const s = globalThis.__ss; for(let k = 0; k < i; k++) s.S.ms[s.MISSIONS[k].id] = {stars:1, best:0, bt:0, n:1, done:true}; if(!flags.tut) s.S.tut = 1; else s.S.tut = 0; s.startMission(i); }, [+mi, flags]);
await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout:60000});
await page.evaluate(flags => { const s = globalThis.__ss; if(flags.brief){ s.showBrief('وزارة الدفاع ← الطيار: دمّر رادار الإنذار المبكر شرق الجبهة', 'عملية العين المغمضة', 40); } else { s.showComm('cmd', 'm3c1', 40); s.showComm('gnd', 'm3c2', 40); } }, flags);
const marks = (flags.t || '0.3,1.5,3,5,8').split(',').map(Number); let prev = 0;
for(const m of marks){ if(flags.kind) await page.evaluate(k => globalThis.__ss.banner(k === 'warn' ? '⚠ نيران صديقة' : 'نجحت المهمة', k), flags.kind); await page.waitForTimeout(Math.max(0, (m-prev)*1000)); prev = m; await page.screenshot({path:join(out, `t${String(m).replace('.', '_')}.png`)}); }
console.log('NOTE_DBG', await page.evaluate(() => { const n = document.querySelector('#note'); return n ? n.outerHTML.slice(0, 200) + ' | ' + getComputedStyle(n).display : 'none'; }));
console.log('errors:', [...new Set(errs)]); await browser.close(); server.close();
