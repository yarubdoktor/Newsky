/* عناصر الواجهة المشتركة (HUD) + لافتة الرسائل. لا تستورد شي سوى util حتى ما تتكوّن دورات استيراد. */
import {$} from './util.js';

export const el = {hp:$('#hp'),sc:$('#sc'),st:$('#st'),cmb:$('#cmb'),lk:$('#lk'),lkb:$('#lkb'),warn:$('#warn'),fps:$('#fps'),bn:$('#note'),ld:$('#ld')};

/* تنبيه نظام صغير بإطار ملوّن (يمين/وسط أعلى الشاشة): kind = info | warn | win | fail. الإيموجي البادئ يُحذف لأن للإطار أيقونته. */
const NOTE_ICON = {info:'M12 8v.01M11 12h1v5h1M12 3a9 9 0 1 0 0 18a9 9 0 0 0 0-18z', warn:'M12 4l9 16H3zM12 10v4M12 17v.01',
  win:'M5 12.5l4.5 4.5L19 7.5', fail:'M6 6l12 12M18 6L6 18'};
const NS = 'http://www.w3.org/2000/svg';
export const stripLead = s => String(s).replace(/^[^\p{L}\p{N}(\[«"]+/u, '');
export function banner(txt, kind = 'info'){
  const n = el.bn; if(!n) return; n.textContent = '';
  const svg = document.createElementNS(NS, 'svg'), p = document.createElementNS(NS, 'path');
  svg.setAttribute('viewBox', '0 0 24 24'); p.setAttribute('d', NOTE_ICON[kind] || NOTE_ICON.info); svg.appendChild(p);
  const sp = document.createElement('span'); sp.textContent = stripLead(txt) || String(txt);
  n.append(svg, sp); n.className = 'on nk-'+kind;
  clearTimeout(banner.h); banner.h = setTimeout(() => n.classList.remove('on'), kind === 'win' || kind === 'fail' ? 2600 : 2000);
}
