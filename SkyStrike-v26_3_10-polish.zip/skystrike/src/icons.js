/* أيقونات الواجهة بهوية Sky Strike (v25).
   بدل إيموجي النظام (شكلها يختلف من جوال لجوال)، نستبدل الرموز الوظيفية بـ SVG بألوان الهوية (brand/BRAND.md).
   الكود يستبدل الإيموجي داخل نصوص #menu واللافتات تلقائياً (MutationObserver)، فما تحتاج تغيّر أي نص بـ i18n.js أو menu.js.
   إضافة أيقونة جديدة: أضف سطراً بـ SVG + حرفها بـ MAP. بدون استيراد من باقي الملفات. */
const GOLD = '#FFB52E', GOLD2 = '#FFE08A', ICE = '#9FD8FF', ICE2 = '#4CC3FF', HOT = '#FF7A2F', GO = '#5FE3A1', ALERT = '#FF4D5E', STEEL = '#EAF4FF', DEEP = '#0B1626';
const SVG = {
  coin:   `<circle cx="12" cy="12" r="10" fill="${GOLD}"/><circle cx="12" cy="12" r="7.3" fill="none" stroke="${GOLD2}" stroke-width="1.5"/><path d="M12 6.8l1.6 3.3 3.6.5-2.6 2.5.6 3.6-3.2-1.7-3.2 1.7.6-3.6-2.6-2.5 3.6-.5z" fill="${GOLD2}"/>`,
  gem:    `<path d="M6.2 3h11.6L22 9.2 12 21.5 2 9.2z" fill="${ICE2}"/><path d="M2 9.2h20L12 21.5z" fill="#2A8FD6"/><path d="M6.2 3L8.6 9.2h6.8L17.8 3z" fill="${ICE}"/>`,
  lock:   `<path d="M7.5 10V7.5a4.5 4.5 0 019 0V10" fill="none" stroke="${ICE}" stroke-width="2.2" stroke-linecap="round"/><rect x="4.5" y="10" width="15" height="11" rx="2.5" fill="${ICE}"/><circle cx="12" cy="15" r="1.7" fill="${DEEP}"/>`,
  unlock: `<path d="M7.5 10V7.5a4.5 4.5 0 018.7-1.6" fill="none" stroke="${GO}" stroke-width="2.2" stroke-linecap="round"/><rect x="4.5" y="10" width="15" height="11" rx="2.5" fill="${GO}"/><circle cx="12" cy="15" r="1.7" fill="${DEEP}"/>`,
  check:  `<circle cx="12" cy="12" r="10" fill="${GO}"/><path d="M7 12.4l3.3 3.3L17 9" fill="none" stroke="${DEEP}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>`,
  target: `<circle cx="12" cy="12" r="9.2" fill="none" stroke="${HOT}" stroke-width="2.2"/><circle cx="12" cy="12" r="4.6" fill="none" stroke="${HOT}" stroke-width="2.2"/><circle cx="12" cy="12" r="1.7" fill="${STEEL}"/><path d="M12 1v4M12 19v4M1 12h4M19 12h4" stroke="${HOT}" stroke-width="2" stroke-linecap="round"/>`,
  plane:  `<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 00-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z" fill="${STEEL}"/>`,
  bolt:   `<path d="M13.5 2L5 13.5h5.5L9.5 22 19 9.8h-5.7z" fill="${HOT}"/>`,
  gift:   `<rect x="3" y="9" width="18" height="12" rx="2" fill="${HOT}"/><rect x="2" y="6.5" width="20" height="4.5" rx="1.5" fill="#FFAA5A"/><rect x="10.7" y="6.5" width="2.6" height="14.5" fill="${STEEL}"/><path d="M12 6.5C10 2.5 6.5 3.4 7.4 5.4c.5 1.1 2.6 1.1 4.6 1.1zm0 0c2-4 5.5-3.1 4.6-1.1-.5 1.1-2.6 1.1-4.6 1.1z" fill="${STEEL}"/>`,
  trophy: `<path d="M7 3h10v6a5 5 0 01-10 0z" fill="${GOLD}"/><path d="M7 5H3.5v1.5A4 4 0 007.3 10.4M17 5h3.5v1.5a4 4 0 01-3.8 3.9" fill="none" stroke="${GOLD}" stroke-width="1.8"/><rect x="10.7" y="14" width="2.6" height="4" fill="${GOLD}"/><rect x="7" y="18" width="10" height="3" rx="1" fill="${GOLD2}"/>`,
  rocket: `<path d="M12 2c2.4 3 3.4 6.2 3.4 9.4V17H8.6v-5.6C8.6 8.2 9.6 5 12 2z" fill="${STEEL}"/><circle cx="12" cy="9.5" r="1.8" fill="${ICE2}"/><path d="M8.6 13.5L5 17.5V20l3.6-2zm6.8 0l3.6 4V20l-3.6-2z" fill="${HOT}"/><path d="M10 18h4l-2 4z" fill="${GOLD}"/>`,
  alert:  `<path d="M12 2.5L22.5 21h-21z" fill="${GOLD}"/><path d="M12 9v5.5" stroke="${DEEP}" stroke-width="2.4" stroke-linecap="round"/><circle cx="12" cy="17.6" r="1.4" fill="${DEEP}"/>`,
  shield: `<path d="M12 1.5L3.5 5v6c0 5.3 3.6 10 8.5 11.5 4.9-1.5 8.5-6.2 8.5-11.5V5z" fill="${ICE2}"/><path d="M12 1.5v21C7.1 21 3.5 16.3 3.5 11V5z" fill="#2A8FD6"/>`
};
const MAP = {'🪙':'coin','💎':'gem','🔒':'lock','🔓':'unlock','✅':'check','🎯':'target','✈':'plane','⚡':'bolt','🎁':'gift','🏆':'trophy','🚀':'rocket','⚠':'alert','🚨':'alert','🛡':'shield'};
const RE = new RegExp('(' + Object.keys(MAP).join('|') + ')\\uFE0F?'), RE_G = new RegExp('(' + Object.keys(MAP).join('|') + ')\\uFE0F?', 'g');
const SKIP = /^(INPUT|TEXTAREA|SCRIPT|STYLE|TITLE|svg)$/i;
const mk = (ch, key) => { const s = document.createElement('span'); s.className = 'bi'; s.setAttribute('role','img'); s.setAttribute('aria-label',ch); s.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${SVG[key]}</svg>`; return s; };

function fixText(n){
  const p = n.parentNode, v = n.nodeValue;
  if(!p || !v || SKIP.test(p.nodeName) || !RE.test(v)) return;
  const f = document.createDocumentFragment(); let last = 0, m; RE_G.lastIndex = 0;
  while((m = RE_G.exec(v))){ if(m.index > last) f.appendChild(document.createTextNode(v.slice(last,m.index))); f.appendChild(mk(m[1],MAP[m[1]])); last = m.index+m[0].length; }
  if(last < v.length) f.appendChild(document.createTextNode(v.slice(last)));
  p.replaceChild(f,n);
}
export function brandIcons(root){
  if(!root) return;
  if(root.nodeType === 3){ fixText(root); return; }
  if(root.nodeType !== 1 || SKIP.test(root.nodeName)) return;
  const w = document.createTreeWalker(root,NodeFilter.SHOW_TEXT), list = []; let n;
  while((n = w.nextNode())) if(RE.test(n.nodeValue)) list.push(n);
  for(const x of list) fixText(x);
}
export function initBrandIcons(){
  const obs = new MutationObserver(ms => { for(const m of ms){ if(m.type === 'characterData') fixText(m.target); else for(const a of m.addedNodes) brandIcons(a); } });
  for(const sel of ['#menu','#note','#tut','#pause']){ const e = document.querySelector(sel); if(e){ brandIcons(e); obs.observe(e,{childList:true,subtree:true,characterData:true}); } }
}
