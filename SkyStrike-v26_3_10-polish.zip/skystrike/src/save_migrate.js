/* ترحيل الحفظ (دالة صرفة، تعمل على كائن الحفظ بالمكان). مفتاح التخزين يبقى skystrike_v2 (قاعدة R9).
   mv = نسخة بنية المهمات: undefined = حفظ ما قبل المهمات (موجات/أنماط/حملة قديمة) ← 1.
   لا يُفقد شيء ذو قيمة: العملات/الجواهر/XP/الطائرات/الأسلحة/الألوان/الإعدادات/أعلى النتائج كلها تبقى.
   ما يُزال: حالة المهام اليومية/الأسبوعية (تتجدد أصلاً) ونمط اللعب القديم. تقدّم الحملة القديمة يُحفظ بـ cpOld
   ويبدأ S.cp من الصفر لأنه صار يعني «عدد المهمات المنجزة بالترتيب». */
import {normalizeMs} from './mission/progress.js';
export const MV = 2;
/* mv 2 (M8): F-35 لم يعد طائرة لاعب (صار عدواً). من كان يملكه/يستعمله ينتقل إلى MiG-29 (صارت مجانية).
   التعويض بالعملات = سعر F-35 القديم (0) + كل ما أنفقه على ترقيته (200×المستوى×معامل الترقية 1، مقرّب لـ10).
   الألوان المملوكة لـ F-35 تُنسخ لـ MiG-29. ما أُزيل يبقى مؤرشفاً بـ s.retired.f35 فلا يضيع شيء. */
export const F35_PRICE = 0, F35_UP = 1;
export const f35Refund = lv => { let c = F35_PRICE; for(let l = 1; l < (lv | 0); l++) c += Math.round(200*l*F35_UP/10)*10; return c; };
const PLAYER_PLANES = ['mig29', 'su57'];
function dropF35(s){
  s.pl = (s.pl && typeof s.pl === 'object') ? s.pl : {};
  const had = 'f35' in s.pl, lv = Math.max(1, s.pl.f35 | 0), isF = k => k === 'f35' || k.indexOf('f35:') === 0;
  if(had || s.sel === 'f35'){
    const r = {lv, refund: had ? f35Refund(lv) : 0, sk: s.sk && s.sk.f35 || null, sko: {}};
    if(s.sko && typeof s.sko === 'object') for(const k of Object.keys(s.sko)) if(isF(k)){
      r.sko[k] = s.sko[k]; if(k.indexOf(':') > 0) s.sko['mig29'+k.slice(3)] = s.sko[k]; delete s.sko[k]; }
    if(r.sk && s.sk && !s.sk.mig29) s.sk.mig29 = r.sk;
    if(s.sk) delete s.sk.f35;
    delete s.pl.f35; s.coins = (s.coins | 0) + r.refund; s.retired = Object.assign({}, s.retired, {f35: r});
  }
  if(!s.pl.mig29) s.pl.mig29 = 1;                                    // MiG-29 مجانية للجميع
  if(PLAYER_PLANES.indexOf(s.sel) < 0 || !s.pl[s.sel]) s.sel = 'mig29';
}
export function migrate(s){
  if(!s || typeof s !== 'object') return s;
  if(s.mv === undefined){
    s.cpOld = s.cp | 0; s.cp = 0;
    delete s.mode; delete s.mis; delete s.wk;
  }
  if((s.mv | 0) < 2) dropF35(s);
  s.ms = normalizeMs(s.ms);
  s.cp = Math.max(0, s.cp | 0);
  s.mv = MV;
  return s;
}
