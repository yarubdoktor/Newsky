/* اختيار طراز مقاتلة العدو (دالة صرفة بلا three فتُختبر بـ node). */
export const ENEMY_JETS = ['f16','f15','f35'];
const WEIGHT = {f16:.4, f15:.35, f35:.25};
// r بين 0 و1. القائد (ace) دائماً F-35 ذهبي. إن لم يُحمَّل GLB الخاص بـ F-35 يُستبدل بـ F-16
export function pickJetModel(r, elite = false, haveF35 = true){
  let m = 'f35';
  if(!elite){ let a = 0; m = ENEMY_JETS[ENEMY_JETS.length-1]; for(const k of ENEMY_JETS){ a += WEIGHT[k]; if(r < a){ m = k; break; } } }
  return (m === 'f35' && !haveF35) ? 'f16' : m;
}
