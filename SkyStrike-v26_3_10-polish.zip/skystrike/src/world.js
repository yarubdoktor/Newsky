import * as THREE from 'three';
import {buildMap} from './maps.js';
import {Q,CH} from './quality.js';
import {rnd,clamp,mulberry,smooth} from './util.js';

const _c = new THREE.Color(), _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3();
const key = (x,z) => (x+32768)*65536 + (z+32768);

const SKY_VS = 'varying vec3 vp;void main(){vp=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}';
const SKY_FS = `uniform vec3 top,hor,sunCol,sunDir;uniform float stars;varying vec3 vp;
void main(){vec3 d=normalize(vp);float h=clamp(d.y,0.,1.);vec3 c=mix(hor,top,pow(h,.55));
if(d.y<0.)c=hor*(1.+d.y*.5);
float s=max(dot(d,sunDir),0.);c+=sunCol*(pow(s,900.)*3.+pow(s,10.)*.28);
if(stars>0.&&d.y>0.){vec3 q=floor(d*230.);float r=fract(sin(dot(q,vec3(12.9898,78.233,37.719)))*43758.5453);c+=vec3(step(.9972,r))*(.4+.6*h)*stars;}
gl_FragColor=vec4(c,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;

function waterNormalTex(){
  const N = 128, c = document.createElement('canvas'); c.width = c.height = N; const x = c.getContext('2d'), img = x.createImageData(N,N);
  const hf = (i,j) => { const u = i/N*6.2832, v = j/N*6.2832;
    return Math.sin(u*3+Math.sin(v*2)*1.5)*.5 + Math.sin(v*5+u*2)*.3 + Math.sin((u+v)*7)*.2 + Math.sin(u*11-v*9)*.1; };
  for(let j=0;j<N;j++) for(let i=0;i<N;i++){
    const dx = hf(i+1,j)-hf(i-1,j), dy = hf(i,j+1)-hf(i,j-1), nx = -dx*2.2, ny = -dy*2.2, l = Math.hypot(nx,ny,1), o = (j*N+i)*4;
    img.data[o] = (nx/l*.5+.5)*255; img.data[o+1] = (ny/l*.5+.5)*255; img.data[o+2] = (1/l*.5+.5)*255; img.data[o+3] = 255;
  }
  x.putImageData(img,0,0); const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
function cloudTex(){
  const c = document.createElement('canvas'); c.width = 128; c.height = 64; const x = c.getContext('2d');
  for(let i=0;i<9;i++){ const px = 22+Math.random()*84, py = 22+Math.random()*20, r = 14+Math.random()*16, g = x.createRadialGradient(px,py,0,px,py,r);
    g.addColorStop(0,'rgba(255,255,255,.7)'); g.addColorStop(1,'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0,0,128,64); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function windowTex(){
  const c = document.createElement('canvas'); c.width = 64; c.height = 128; const x = c.getContext('2d'); x.fillStyle = '#04070d'; x.fillRect(0,0,64,128);
  for(let j=0;j<16;j++) for(let i=0;i<8;i++) if(Math.random()<.5){ x.fillStyle = Math.random()<.7 ? '#ffd88a' : '#bfe0ff'; x.fillRect(i*8+2,j*8+2,4,4); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function createWorld(scene,renderer,cam){
  const W = {cfg:null,H:()=>0,ground:()=>0,id:null,envTex:null,fogFar:3000};
  let cfg = null, props = null;
  const chunks = new Map();
  const hemi = new THREE.HemisphereLight(0xffffff,0x444444,1), sun = new THREE.DirectionalLight(0xffffff,1);
  scene.add(hemi,sun);

  // ---- السماء (shader) + بيئة PMREM للانعكاسات على الطائرات
  const skyU = {top:{value:new THREE.Color()},hor:{value:new THREE.Color()},sunDir:{value:new THREE.Vector3(0,1,0)},sunCol:{value:new THREE.Color()},stars:{value:0}};
  const skyMat = () => new THREE.ShaderMaterial({uniforms:skyU,vertexShader:SKY_VS,fragmentShader:SKY_FS,side:THREE.BackSide,depthWrite:false,fog:false});
  const sky = new THREE.Mesh(new THREE.SphereGeometry(1,24,16),skyMat()); sky.scale.setScalar(5000); sky.frustumCulled = false; sky.renderOrder = -10; scene.add(sky);
  const pm = new THREE.PMREMGenerator(renderer), envScene = new THREE.Scene(), envSky = new THREE.Mesh(new THREE.SphereGeometry(1,16,12),skyMat());
  envSky.scale.setScalar(50); envScene.add(envSky);
  let envRT = null;
  function buildEnv(){ if(envRT) envRT.dispose(); envRT = pm.fromScene(envScene,.02,1,100); W.envTex = envRT.texture; scene.environment = W.envTex; }

  // ---- الماء + رغوة الساحل (M9)
  const wTex = waterNormalTex();
  const water = new THREE.Mesh(new THREE.PlaneGeometry(1,1).rotateX(-Math.PI/2),
    new THREE.MeshPhongMaterial({color:0x1b78b0,transparent:true,opacity:.88,shininess:120,specular:0xffd6a8,normalMap:wTex,normalScale:new THREE.Vector2(.6,.6)}));
  water.frustumCulled = false; water.visible = false; scene.add(water);
  // شريط رغوة خفيف فوق الماء (plane شفافة متحركة)
  const foamTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const x = c.getContext('2d');
    for(let i=0;i<18;i++){
      const px = Math.random()*128, py = Math.random()*128, r = 8+Math.random()*22;
      const g = x.createRadialGradient(px,py,0,px,py,r);
      g.addColorStop(0,'rgba(255,255,255,.55)'); g.addColorStop(1,'rgba(255,255,255,0)');
      x.fillStyle = g; x.fillRect(0,0,128,128);
    }
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
  })();
  const foam = new THREE.Mesh(new THREE.PlaneGeometry(1,1).rotateX(-Math.PI/2),
    new THREE.MeshBasicMaterial({map:foamTex,transparent:true,opacity:.35,depthWrite:false}));
  foam.frustumCulled = false; foam.visible = false; foam.renderOrder = 2; scene.add(foam);

  // ---- الغيوم
  const cTex = cloudTex(), cMat = new THREE.SpriteMaterial({map:cTex,transparent:true,opacity:.8,depthWrite:false});
  let clouds = [];
  function buildClouds(){
    for(const s of clouds) scene.remove(s); clouds = [];
    const R = Q.view*CH*1.1, cy = cfg.cloudY || [300,560];
    for(let i=0;i<Q.clouds;i++){ const s = new THREE.Sprite(cMat), w = rnd(260,620); s.scale.set(w,w*rnd(.28,.45),1);
      s.position.set(rnd(-R,R),rnd(cy[0],cy[1]),rnd(-R,R)); scene.add(s); clouds.push(s); }
  }

  // ---- الثلج
  const SN = 600, snowPos = new Float32Array(SN*3);
  const snow = new THREE.Points((() => { const g = new THREE.BufferGeometry(); g.setAttribute('position',new THREE.BufferAttribute(snowPos,3)); return g; })(),
    new THREE.PointsMaterial({size:2.4,color:0xffffff,transparent:true,opacity:.85,depthWrite:false})); snow.frustumCulled = false; snow.visible = false; scene.add(snow);
  for(let i=0;i<SN;i++){ snowPos[i*3] = rnd(-300,300); snowPos[i*3+1] = rnd(-150,150); snowPos[i*3+2] = rnd(-300,300); }

  // ---- مواد وأشكال مشتركة
  // M9: أشجار بجذع + تاج (بدل كرة/مخروط فقط) — KI-35
  const terrainMat = new THREE.MeshLambertMaterial({vertexColors:true});
  const treeMat = new THREE.MeshLambertMaterial({color:0xffffff,flatShading:true});
  const trunkMat = new THREE.MeshLambertMaterial({color:0x5a3a22,flatShading:true});
  const treeGeo = {
    cone: new THREE.ConeGeometry(3.2,11,7).translate(0,7.5,0),
    ball: new THREE.IcosahedronGeometry(4.8,1).translate(0,7.2,0),
    cactus: new THREE.CylinderGeometry(.9,1,8,6).translate(0,4,0)
  };
  const trunkGeo = {
    cone: new THREE.CylinderGeometry(.55,.85,4.2,6).translate(0,2.1,0),
    ball: new THREE.CylinderGeometry(.6,.9,4.5,6).translate(0,2.25,0),
    cactus: null
  };
  const boxGeo = new THREE.BoxGeometry(1,1,1).translate(0,.5,0);
  const winT = windowTex();
  const cityDay = new THREE.MeshLambertMaterial({color:0xffffff});
  const cityNight = new THREE.MeshLambertMaterial({color:0x2a3040,emissive:0xffffff,emissiveMap:winT,emissiveIntensity:1.3});

  function prepPalette(c){
    if(c._pal) return;
    c._pal = c.pal.map(a => [a[0],new THREE.Color(a[1])]); c._rock = new THREE.Color(c.rock);
  }
  function colorAt(h,ny,out,x,z){
    if(cfg.colorFn) cfg.colorFn(x,z,out,h);
    else {
      const P = cfg._pal; let i = 0; while(i < P.length-1 && h > P[i][0]) i++;
      const up = P[i][0]; out.copy(P[i][1]);
      if(i < P.length-1){ const bw = clamp(up*.25,.4,12), t = clamp((h-(up-bw))/bw,0,1); if(t > 0) out.lerp(P[i+1][1],smooth(t)); }
    }
    if(ny < cfg.rockNy && h > cfg.rockMin) out.lerp(cfg._rock,clamp((cfg.rockNy-ny)*6,0,1));
    // M9: تدرج ساحلي (رمل فاتح قرب مستوى الماء)
    if(cfg.water){
      const wl = cfg.water.level, dh = h - wl;
      if(dh > -2 && dh < 14){
        const t = 1 - clamp(dh/12, 0, 1);
        out.lerp(_c.setHex(0xcbb896), t*t*.55);
      }
    }
    let j = 1 + (((Math.sin(x*12.9898+z*78.233)*43758.5453)%1)*.07);
    if(cfg.band) j *= .9 + .1*Math.sin(h*.45);
    return out.multiplyScalar(j);
  }

  function buildChunk(cx,cz){
    const n = Q.seg, g = new THREE.PlaneGeometry(CH,CH,n,n); g.rotateX(-Math.PI/2);
    const pos = g.attributes.position, nor = g.attributes.normal, cnt = pos.count, col = new Float32Array(cnt*3), ox = cx*CH+CH/2, oz = cz*CH+CH/2, H = W.H, e = 6;
    for(let i=0;i<cnt;i++){
      const x = pos.getX(i)+ox, z = pos.getZ(i)+oz, h = H(x,z);
      const gx = (H(x+e,z)-H(x-e,z))/(2*e), gz = (H(x,z+e)-H(x,z-e))/(2*e), l = Math.sqrt(gx*gx+1+gz*gz);
      pos.setXYZ(i,x,h,z); nor.setXYZ(i,-gx/l,1/l,-gz/l);
      colorAt(h,1/l,_c,x,z); col[i*3] = _c.r; col[i*3+1] = _c.g; col[i*3+2] = _c.b;
    }
    g.setAttribute('color',new THREE.BufferAttribute(col,3));
    const m = new THREE.Mesh(g,terrainMat); scene.add(m);
    return {m,cx,cz,trees:null,city:null,treesDone:false,cityDone:false};
  }
  function buildTrees(ch){
    const t = cfg.tree; if(!t || !Q.trees) return;
    const rng = mulberry((Math.imul(ch.cx,73856093) ^ Math.imul(ch.cz,19349663) ^ cfg.seed)>>>0), att = Q.trees*2, H = W.H;
    const type = t.type || 'ball';
    const crown = new THREE.InstancedMesh(treeGeo[type], treeMat, att);
    const hasTrunk = !!trunkGeo[type];
    const trunk = hasTrunk ? new THREE.InstancedMesh(trunkGeo[type], trunkMat, att) : null;
    let k = 0;
    for(let a=0;a<att;a++){
      const x = ch.cx*CH + rng()*CH, z = ch.cz*CH + rng()*CH, h = H(x,z), r1 = rng(), r2 = rng(), r3 = rng();
      if(h < t.hmin || h > t.hmax || r1 > t.p || (cfg.noTree && cfg.noTree(x,z))) continue;
      if(Math.hypot(H(x+3,z)-h,H(x,z+3)-h) > 1.7) continue;
      const s = t.sc[0] + r2*(t.sc[1]-t.sc[0]);
      const sy = s*(.9+r3*.5);
      _m.compose(_p.set(x,h-.2,z),_q,_s.set(s,sy,s));
      crown.setMatrixAt(k,_m);
      _c.setHex(t.col); _c.offsetHSL(0,0,(r3-.5)*.1); crown.setColorAt(k,_c);
      if(trunk){
        // الجذع أضيق قليلاً وأقصر نسبياً
        _m.compose(_p.set(x,h-.15,z),_q,_s.set(s*.95,s,s*.95));
        trunk.setMatrixAt(k,_m);
      }
      k++;
    }
    if(!k){ crown.dispose(); if(trunk) trunk.dispose(); return; }
    crown.count = k; crown.instanceMatrix.needsUpdate = true;
    if(crown.instanceColor) crown.instanceColor.needsUpdate = true;
    crown.frustumCulled = false; scene.add(crown);
    if(trunk){
      trunk.count = k; trunk.instanceMatrix.needsUpdate = true;
      trunk.frustumCulled = false; scene.add(trunk);
    }
    ch.trees = trunk ? [crown, trunk] : crown;
  }
  function buildCity(ch){
    const c = cfg.city; if(!c || !Q.city) return;
    const rng = mulberry((Math.imul(ch.cx,2654435761) ^ Math.imul(ch.cz,40503) ^ (cfg.seed*7))>>>0);
    if(rng() > c.p) return;
    const H = W.H, cx = ch.cx*CH + CH*(.3+rng()*.4), cz = ch.cz*CH + CH*(.3+rng()*.4), h0 = H(cx,cz);
    if(h0 < 6 || h0 > 70) return;
    const G = 7, mesh = new THREE.InstancedMesh(boxGeo,c.night?cityNight:cityDay,G*G); let k = 0;
    for(let i=0;i<G;i++) for(let j=0;j<G;j++){
      if(rng() < .18) continue;
      const x = cx+(i-G/2)*26+rng()*8, z = cz+(j-G/2)*26+rng()*8, h = H(x,z); if(h < 3) continue;
      const core = 1-Math.hypot(i-G/2,j-G/2)/(G*.7), hh = 10 + rng()*rng()*70*Math.max(.25,core), w = 11+rng()*8;
      _m.compose(_p.set(x,h-5,z),_q,_s.set(w,hh+5,w+rng()*5)); mesh.setMatrixAt(k,_m);
      const g = .45+rng()*.35; _c.setRGB(g,g*.97,g*.92); mesh.setColorAt(k,_c); k++;
    }
    if(!k){ mesh.dispose(); return; }
    mesh.count = k; mesh.instanceMatrix.needsUpdate = true; if(mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.frustumCulled = false; scene.add(mesh); ch.city = mesh;
  }
  function disposeChunk(ch){
    scene.remove(ch.m); ch.m.geometry.dispose();
    if(ch.trees){
      const ts = Array.isArray(ch.trees) ? ch.trees : [ch.trees];
      for(const m of ts){ scene.remove(m); m.dispose(); }
    }
    if(ch.city){ scene.remove(ch.city); ch.city.dispose(); }
  }
  function clearChunks(){ for(const ch of chunks.values()) disposeChunk(ch); chunks.clear(); }

  function atmosphere(){
    const c = cfg, sd = new THREE.Vector3(...c.sun.dir).normalize();
    skyU.top.value.setHex(c.sky.top); skyU.hor.value.setHex(c.sky.hor); skyU.stars.value = c.sky.stars;
    skyU.sunDir.value.copy(sd); skyU.sunCol.value.setHex(c.sun.col);
    hemi.color.setHex(c.hemi[0]); hemi.groundColor.setHex(c.hemi[1]); hemi.intensity = c.hemi[2];
    sun.color.setHex(c.sun.col); sun.intensity = c.sun.i; sun.position.copy(sd).multiplyScalar(1000);
    renderer.toneMappingExposure = c.exp || 1.1;
    cMat.color.setHex(c.cloud);
    if(c.water){
      water.visible = true; foam.visible = true;
      water.material.color.setHex(c.water.color); water.material.opacity = c.water.op; water.material.specular.setHex(c.water.spec);
    } else { water.visible = false; foam.visible = false; }
    snow.visible = c.weather === 'snow';
  }
  function fogAndSize(){
    const far = Math.min(cfg.fogFar||1e9,Q.view*CH*.92); W.fogFar = far;
    scene.fog = new THREE.Fog(cfg.fog,far*.18,far);
    const size = (Q.view*2+3)*CH; water.scale.set(size,1,size); wTex.repeat.set(size/180,size/180);
    foam.scale.set(size,1,size); foamTex.repeat.set(size/90,size/90);
    buildClouds();
  }

  function dropProps(){ if(!props) return; scene.remove(props); props.traverse(o => { if(o.geometry) o.geometry.dispose(); }); if(props.userData.mat) props.userData.mat.dispose(); props = null; }
  W.setMap = id => {
    clearChunks(); dropProps(); const m = buildMap(id); cfg = m.cfg; W.cfg = cfg; W.H = m.H; W.ground = m.ground; W.id = id;
    prepPalette(cfg); atmosphere(); fogAndSize(); buildEnv();
    if(cfg.buildProps){ props = cfg.buildProps(); scene.add(props); }
  };
  W.applyQuality = () => { if(!cfg) return; clearChunks(); fogAndSize(); };
  W.hasWater = () => !!(cfg && cfg.water);

  // تدفّق القطع حول اللاعب (بدون حدود للعالم). force = بناء كل شي دفعة وحدة (وقت التحميل)
  W.stream = (pos,force) => {
    if(!cfg) return;
    const pcx = Math.floor(pos.x/CH), pcz = Math.floor(pos.z/CH), R = Q.view;
    for(const [k,ch] of chunks) if(Math.abs(ch.cx-pcx) > R+1 || Math.abs(ch.cz-pcz) > R+1){ disposeChunk(ch); chunks.delete(k); }
    let budget = force ? 1e9 : 2;
    if(chunks.size < (R*2+1)*(R*2+1)){
      const need = [];
      for(let dz=-R;dz<=R;dz++) for(let dx=-R;dx<=R;dx++) if(!chunks.has(key(pcx+dx,pcz+dz))) need.push([dx*dx+dz*dz,pcx+dx,pcz+dz]);
      need.sort((a,b) => a[0]-b[0]);
      for(const n of need){ if(budget-- <= 0) break; chunks.set(key(n[1],n[2]),buildChunk(n[1],n[2])); }
    }
    let tb = force ? 1e9 : 1;
    for(const ch of chunks.values()){
      const d = Math.max(Math.abs(ch.cx-pcx),Math.abs(ch.cz-pcz));
      if(tb > 0 && !ch.treesDone && d <= Q.treeRing){ ch.treesDone = true; buildTrees(ch); tb--; }
      if(tb > 0 && !ch.cityDone && d <= Q.treeRing+1){ ch.cityDone = true; buildCity(ch); tb--; }
    }
  };
  // تتبّع الكاميرا: سماء، ماء، غيوم، ثلج
  W.follow = (cp,dt) => {
    sky.position.copy(cp);
    if(water.visible){
      const wx = Math.round(cp.x/180)*180, wz = Math.round(cp.z/180)*180;
      water.position.set(wx, cfg.water.level, wz);
      foam.position.set(wx, cfg.water.level + .08, wz);
      wTex.offset.x += dt*.012; wTex.offset.y += dt*.007;
      foamTex.offset.x += dt*.018; foamTex.offset.y -= dt*.011;
    }
    const R = Q.view*CH*1.1;
    for(const s of clouds){ s.position.x += dt*6;
      if(s.position.x-cp.x > R) s.position.x -= 2*R; else if(s.position.x-cp.x < -R) s.position.x += 2*R;
      if(s.position.z-cp.z > R) s.position.z -= 2*R; else if(s.position.z-cp.z < -R) s.position.z += 2*R; }
    if(snow.visible){
      for(let i=0;i<SN;i++){ const o = i*3; snowPos[o+1] -= dt*(16+(i%7)*2); snowPos[o] += dt*5;
        if(snowPos[o+1] < -150) snowPos[o+1] += 300; if(snowPos[o] > 300) snowPos[o] -= 600; }
      snow.position.set(cp.x,cp.y,cp.z); snow.geometry.attributes.position.needsUpdate = true;
    }
  };
  return W;
}
