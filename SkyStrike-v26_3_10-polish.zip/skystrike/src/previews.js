/* معاينات الطائرات والخرائط للّوبي (تُرسم من المحرك نفسه). */
import * as THREE from 'three';
import {PLANES,SKINS,skinOf} from './data.js';
import {MAP_IDS,MAPS} from './maps.js';
import {mkJet} from './jets.js';
import {renderer,scene,cam,world,resize} from './core.js';
import {W} from './state.js';
import {MISSIONS} from './mission/mission_defs.js';

export function makePreviews(){
  const sc = new THREE.Scene(); sc.background = new THREE.Color(0x15304d); sc.environment = world.envTex;
  sc.add(new THREE.HemisphereLight(0xbcd6ff,0x2a2a35,2.2)); const k = new THREE.DirectionalLight(0xffc48a,4); k.position.set(8,10,6); sc.add(k);
  const rim = new THREE.DirectionalLight(0x6fb4ff,2.5); rim.position.set(-8,3,-8); sc.add(rim);
  const cm = new THREE.PerspectiveCamera(36,1.6,1,100); cm.position.set(12,5,10); cm.lookAt(0,0,1);
  const out = {}, pr = renderer.getPixelRatio(); renderer.setPixelRatio(1); renderer.setSize(480,300,false);
  for(const [id,p] of Object.entries(PLANES)){ const j = mkJet(p.kind,p.col,true,SKINS[skinOf(id)].c); j.rotation.set(-.08,.5,.12); sc.add(j); renderer.render(sc,cm); out[id] = renderer.domElement.toDataURL('image/jpeg',.85); sc.remove(j); }
  renderer.setPixelRatio(pr); resize(); return out;
}

/* معاينات الخرائط: تُولَّد من المحرك نفسه أول مرة تفتح شاشة الخرائط، وتُحفظ بالذاكرة وlocalStorage */
const MP_KEY = 'ss_mp_v2'; let MPV = {}, genBusy = false;
try { MPV = JSON.parse(localStorage.getItem(MP_KEY) || '{}') || {}; } catch(e){ MPV = {}; }
export const isGenBusy = () => genBusy;
const hexc = n => '#'+n.toString(16).padStart(6,'0');
/* معاينات لخرائط الحملة فقط (الخرائط القديمة محفوظة بالكود لكن لا تُولَّد لها معاينة بلا داعٍ) */
const PV_IDS = () => [...new Set(MISSIONS.map(m => m.map))].filter(id => MAP_IDS.includes(id));
export const mapList = () => PV_IDS().map(id => { const c = MAPS[id], g = c.pal[2] ? c.pal[2][1] : c.pal[0][1];
  return {id,img:MPV[id]||'',grad:`linear-gradient(${hexc(c.sky.top)},${hexc(c.sky.hor)} 55%,${hexc(g)} 56%)`}; });
export const mapsPending = () => !W.run && !genBusy && PV_IDS().some(id => !MPV[id]);
export async function genMapPreviews(each,done){
  if(genBusy || W.run || W.starting){ done(); return; } genBusy = true;
  const pr = renderer.getPixelRatio(), cpos = cam.position.clone();
  try{
    renderer.setPixelRatio(1);
    for(const id of PV_IDS()){
      if(MPV[id]) continue; if(W.run || W.starting) break;
      world.setMap(id);
      const pv = world.cfg.prev;                      // مسارح M5: كاميرا معاينة مخصّصة {x,z,alt,tx,tz}
      if(pv){ cam.position.set(pv.x,world.ground(pv.x,pv.z)+pv.alt,pv.z); cam.lookAt(pv.tx,world.ground(pv.tx,pv.tz),pv.tz); cam.rotation.z = 0; }
      else {
      const gy = world.ground(0,0), a = .9, cx = Math.cos(a)*1100, cz = Math.sin(a)*1100;
      cam.position.set(cx,Math.max(world.ground(cx,cz)+140,gy+300),cz); cam.lookAt(0,gy+40,0); cam.rotation.z = 0; }
      world.stream(cam.position,true); world.follow(cam.position,0);
      renderer.setSize(384,240,false); cam.aspect = 1.6; cam.updateProjectionMatrix();
      renderer.render(scene,cam);
      MPV[id] = renderer.domElement.toDataURL('image/jpeg',.72); each(id,MPV[id]);
      await new Promise(r => setTimeout(r,60));
    }
    try { localStorage.setItem(MP_KEY,JSON.stringify(MPV)); } catch(e){}
  } catch(e){ console.warn('map previews failed',e); }
  finally { renderer.setPixelRatio(pr); resize(); cam.position.copy(cpos); genBusy = false; done(); }
}
