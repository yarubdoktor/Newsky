import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {loadEnemyModels,hasEM,mkEM} from './emodels.js';
import {GK,groundScale} from './gscale.js';
// كل الـ geometry والـ materials مشتركة ومخزّنة (cache) => ما في تسريب ذاكرة ولا إنشاء كل مرة
const GC = {}, MC = {};
export const geo = (k,f) => GC[k] || (GC[k] = f());
export const mkm = (k,f) => MC[k] || (MC[k] = f());
export const stdm = (c,m=.5,r=.45) => mkm(`s${c}_${m}_${r}`, () => new THREE.MeshStandardMaterial({color:c,metalness:m,roughness:r}));
export const basic = (c,o=1,add=false) => mkm(`b${c}_${o}_${add}`, () => new THREE.MeshBasicMaterial({color:c,transparent:o<1||add,opacity:o,
  blending:add?THREE.AdditiveBlending:THREE.NormalBlending,depthWrite:!(o<1||add)}));
export function planform(pts,th){
  const sh = new THREE.Shape(); pts.forEach((q,i) => i ? sh.lineTo(q[0],q[1]) : sh.moveTo(q[0],q[1]));
  const g = new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false}); g.rotateX(Math.PI/2); return g;
}
export function holder(){
  const g = new THREE.Group();
  g.add_ = (ge,ma,x=0,y=0,z=0,rx=0,ry=0,rz=0) => { const o = new THREE.Mesh(ge,ma); o.position.set(x,y,z); o.rotation.set(rx,ry,rz); g.add(o); return o; };
  return g;
}
const FUS = () => geo('fus', () => new THREE.LatheGeometry([[0,-6.8],[.5,-6.8],[.95,-5.4],[1.25,-2.5],[1.35,.5],[1.2,3.5],[.9,5.2],[.45,6.5],[0,7.6]].map(a => new THREE.Vector2(a[0],a[1])),20).rotateX(-Math.PI/2));
const WP = [[[1,-1.2],[4.8,1.8],[4.8,2.8],[1,3.6]],[[1,-3.2],[5.4,1.2],[5.4,2.4],[1,3.4]],[[1,-3.5],[5.6,1.8],[5.6,2.8],[1,3.8]]];

export function flames(g,xs,z,player,sc=1,noz=true,y=0,col=0){
  const fl = [];
  for(const x of xs){
    if(noz) g.add_(geo('noz',() => new THREE.CylinderGeometry(.62,.5,1.2,10).rotateX(Math.PI/2)),stdm(0x1b2027,.3,.6),x,0,z-.5);
    const f = new THREE.Group(); f.position.set(x,y,z);
    const o = new THREE.Mesh(geo('fo',() => new THREE.ConeGeometry(.55,4.5,10)),basic(col||(player?0xff8a2f:0xff5a2a),.7,true)); o.rotation.x = Math.PI/2; o.position.z = 2.25;
    const n = new THREE.Mesh(geo('fn',() => new THREE.ConeGeometry(.28,2.6,8)),basic(0xfff0c0,.9,true)); n.rotation.x = Math.PI/2; n.position.z = 1.3;
    f.add(o,n); f.scale.setScalar(sc); g.add(f); fl.push(f);
  }
  return fl;
}


/* ---------- نماذج GLB (اختيارية): إذا فشل التحميل تستعمل اللعبة المجسم البرمجي القديم ---------- */
const PM = {};   // نماذج اللاعب حسب kind: 1=MiG-29 ، 2=Su-57  (M8: F-35 لم يعد طائرة لاعب؛ صار مقاتلة عدو في enemy_jets.js)
// اللهب لكل نموذج: x مواضع المحركات، z مكان الفوهة، sc الحجم، y الارتفاع
// fc لون لهب العادم ، wt موضع طرف الجناح (لخطوط البخار Contrails)
const PFL = {1:{xs:[-.7,.7],z:7.2,sc:.7,y:-1.15,fc:0xffb347,wt:{x:5.4,y:-1.04,z:5.5}},
  2:{xs:[-.7,.7],z:7.45,sc:.75,y:-1.15,fc:0x7fc4ff,wt:{x:6.15,y:-1.14,z:5.5}}};
export const WT = {1:PFL[1].wt,2:PFL[2].wt};
// نسخ ملونة من نموذج اللاعب (Skins): مواد مخزّنة لكل (طائرة، لون)
const SKV = {};
function skinModel(kind,tint){
  const k = kind+'_'+tint;
  if(!SKV[k]){
    const tc = new THREE.Color(tint), r = PM[kind].clone(true), cm = {};
    r.traverse(o => { if(o.isMesh){ const u = o.material.uuid; if(!cm[u]){ const m = o.material.clone(); if(!m.transparent && !/canopy|glass/i.test(m.name||'')) m.color.lerp(tc,.7); cm[u] = m; } o.material = cm[u]; } });
    SKV[k] = r;
  }
  return SKV[k].clone(true);
}
function loadGLB(url,tune){
  return new Promise(res => {
    try {
      new GLTFLoader().load(url, gltf => {
        gltf.scene.traverse(o => { if(o.isMesh && o.material){ o.material.envMapIntensity = 1.3; if(o.material.transparent) o.material.depthWrite = false; } });
        tune(gltf.scene); res(true);
      }, undefined, err => { console.warn(url+' failed, using built-in model',err); res(false); });
    } catch(err){ console.warn(err); res(false); }
  });
}
// روابط new URL لازم تكون نصوصاً ثابتة (literal) حتى ينسخ Vite ملفات GLB للبناء (الدمج بـ '+' ما بينلقط)
export const loadModels = () => Promise.all([
  loadGLB(new URL('./models/mig29.glb',import.meta.url).href,r => PM[1] = r),loadGLB(new URL('./models/su57.glb',import.meta.url).href,r => PM[2] = r),
  loadEnemyModels()]);
export function mkJet(kind,color,player,tint){
  if(player && PM[kind]){             // طائرة اللاعب = النموذج الحقيقي (MiG-29 / Su-57)
    const f = PFL[kind], m = holder(); m.add(tint ? skinModel(kind,tint) : PM[kind].clone(true)); m.userData.fl = flames(m,f.xs,f.z,true,f.sc,false,f.y,f.fc); return m;
  }
  // مجسم برمجي احتياطي لطائرة اللاعب إن فشل تحميل GLB (مقاتلات العدو منذ M8 في enemy_jets.js)
  const g = holder(), m = stdm(player && tint ? tint : color,.55,.4), d = stdm(0x1b2027,.3,.6),
    gl = mkm('glass',() => new THREE.MeshStandardMaterial({color:0x0b1824,emissive:0x1d4a78,emissiveIntensity:.7,metalness:.95,roughness:.1}));
  g.add_(FUS(),m);
  const W = geo('w'+kind,() => planform(WP[kind],.16)), T = geo('tail',() => planform([[.9,3.8],[3,5.6],[3,6.4],[.9,6.4]],.1));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    g.add_(geo('fin'+kind,() => new THREE.BoxGeometry(.14,2.3+kind*.3,1.9)),m,s*(1.15+kind*.15),1.4,4.7,0,0,-s*(kind===1?0:.4-kind*.03));
    g.add_(geo('intake',() => new THREE.BoxGeometry(.8,.8,2.6)),d,s,-.45,-1.6);
    g.add_(geo('nav',() => new THREE.SphereGeometry(.14,6,4)),basic(s<0?0xff2222:0x22ff66),s*[4.8,5.4,5.6][kind],0,2.2);
    if(kind===2) g.add_(geo('canard',() => new THREE.BoxGeometry(2.2,.08,1.1)),m,s*1.9,.1,-3.4,0,s*.3,0);
    if(player) g.add_(geo('pyl',() => new THREE.CylinderGeometry(.16,.16,2.6,6).rotateX(Math.PI/2)),stdm(0xdde3ea,.3,.5),s*2.6,-.35,1.4);
  }
  g.add_(geo('can',() => new THREE.SphereGeometry(.85,12,10)),gl,0,.8,-2.6).scale.set(.75,.7,2.1);
  g.add_(geo('pitot',() => new THREE.CylinderGeometry(.04,.04,1.4,4).rotateX(Math.PI/2)),d,0,0,-8.2);
  g.userData.fl = flames(g,kind===0?[0]:[-.85,.85],6.7,player);
  return g;
}
export function mkBomber(){
  const g = holder(), m = stdm(0x59616b,.5,.5), d = stdm(0x252a30,.4,.6);
  g.add_(geo('bf',() => new THREE.CylinderGeometry(2.4,2.4,26,12).rotateX(Math.PI/2)),m);
  g.add_(geo('bn',() => new THREE.ConeGeometry(2.4,7,12).rotateX(-Math.PI/2)),m,0,0,-16.5);
  g.add_(geo('bt',() => new THREE.ConeGeometry(2.4,9,12).rotateX(Math.PI/2)),m,0,0,17.5);
  g.add_(geo('bcan',() => new THREE.SphereGeometry(1.5,10,8)),stdm(0x0b1824,.9,.1),0,1.8,-10).scale.set(.9,.7,1.6);
  const W = geo('bw',() => planform([[2,-2],[18,5],[18,8],[2,9]],.5)), T = geo('bwt',() => planform([[1.5,12],[7,16],[7,18],[1.5,18.5]],.25));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    for(const x of [6,11]) g.add_(geo('bnac',() => new THREE.CylinderGeometry(1,1.1,5,8).rotateX(Math.PI/2)),d,s*x,-.9,3.5-(x>8?2:0));
  }
  g.add_(geo('bfin',() => new THREE.BoxGeometry(.4,7,4)),m,0,4.5,16);
  g.userData.fl = flames(g,[-11,-6,6,11],6.5,false,.8).map(f => { f.position.y = -.9; return f; });
  g.scale.setScalar(1.15);
  return g;
}
export function mkHeli(){
  if(hasEM('heli')){                  // نموذج GLB: rotor = الرئيسية (تدور حول Y) ، rotor2 = الذيل (حول X)
    const g = mkEM('heli'); g.userData.rotor = g.getObjectByName('rotor') || new THREE.Group(); g.userData.rotor2 = g.getObjectByName('rotor2'); g.userData.fl = []; return g;
  }
  const g = holder(), m = stdm(0x3d4a3a,.4,.55), d = stdm(0x1a1f1a,.3,.6);
  g.add_(geo('hb',() => new THREE.SphereGeometry(2.2,12,9)),m).scale.set(1,1,1.8);
  g.add_(geo('hc',() => new THREE.SphereGeometry(1.5,10,8)),stdm(0x0b1824,.9,.1),0,.5,-2.8).scale.set(.9,.8,1.1);
  g.add_(geo('ht',() => new THREE.CylinderGeometry(.35,.6,9,6).rotateX(Math.PI/2)),m,0,.4,7);
  g.add_(geo('hf',() => new THREE.BoxGeometry(.2,2.2,1.4)),m,0,1.4,10.6);
  for(const s of [-1,1]){ g.add_(geo('hs',() => new THREE.BoxGeometry(.2,.2,5)),d,s*1.7,-2.3,0);
    g.add_(geo('hw',() => new THREE.BoxGeometry(2.4,.2,.8)),m,s*2.4,-.4,-.4); }
  const rotor = new THREE.Group(); rotor.position.y = 2.6;
  rotor.add(new THREE.Mesh(geo('hr',() => new THREE.BoxGeometry(16,.08,.7)),basic(0x222222,.55)));
  const r2 = new THREE.Mesh(geo('hr',() => new THREE.BoxGeometry(16,.08,.7)),basic(0x222222,.55)); r2.rotation.y = Math.PI/2; rotor.add(r2);
  g.add(rotor); g.userData.rotor = rotor; g.userData.fl = [];
  return g;
}
export function mkDrone(){          // مسيّرة انتحارية صغيرة بعين حمراء
  if(hasEM('drone')){                 // نموذج GLB مصبوغ بالأحمر (المروحة الدافعة بالخلف +Z)
    const g = holder(); g.add(mkEM('drone',0x8a2e2e,.5)); g.userData.fl = flames(g,[0],4.2,false,.35,false,0,0xff3a3a); return g;
  }
  const g = holder(), m = stdm(0x3a2226,.5,.4);
  g.add_(geo('dr_b',() => new THREE.SphereGeometry(1,10,8)),m).scale.set(.8,.5,2.2);
  const W = geo('dr_w',() => planform([[.6,-.6],[4,1.2],[4,2],[.6,2.2]],.1));
  for(const s of [-1,1]) g.add_(W,m).scale.x = s;
  g.add_(geo('dr_e',() => new THREE.SphereGeometry(.45,8,6)),basic(0xff2a2a),0,.3,-1.9);
  g.userData.fl = flames(g,[0],2.4,false,.35,false,0,0xff3a3a);
  return g;
}
// أنواع الأرضيات: 0 مدفع مزدوج ، 1 دبابة مضادة ، 2 جيبارد ، 3 صواريخ SAM ، 4 فلاك ثقيل (flak). كلها GLB (فوهتها +Z) والبرج 'aim' يدور نحو اللاعب
// M9: tint حسب الجهة (حليف أخضر · عدو بني محمر) — KI-17
const GK_SHADOW = [9,12,11,11,10];   // نصف قطر الظل لكل نوع (بعد التكبير)
const SIDE_TINT = {ally:0x3f8f55, enemy:0x8a5a3a, player:0x4a8fc8};
export function mkGround(t, side = 'enemy'){
  const tint = SIDE_TINT[side] ?? SIDE_TINT.enemy;
  if(hasEM(GK[t])){
    const m = mkEM(GK[t], tint, .45); m.rotation.y = Math.random()*Math.PI*2;
    const g = holder(); g.add(m); m.scale.setScalar(groundScale(GK[t]));
    g.add_(geo('gshadow',() => new THREE.CircleGeometry(1,24).rotateX(-Math.PI/2)),basic(0x000000,.38),0,.25,0).scale.setScalar(GK_SHADOW[t]);
    g.userData.aim = m.getObjectByName('aim') || m; g.userData.gk = GK[t]; return g;
  }
  if(t === 4) t = 2;
  // M12+: مركبات برمجية بتفصيل أعلى (جنوط · دروع · هوائيات · ألوان جهة)
  const base = side === 'ally' ? 0x3a6a48 : 0x56604a;
  const dark = side === 'ally' ? 0x1e3a28 : 0x2c3128;
  const accent = side === 'ally' ? 0x6a9a58 : 0x7a8468;
  const g = holder(), a = stdm(base,.15,.75), b = stdm(dark,.12,.7), c = stdm(accent,.2,.65);
  const steel = stdm(0x3a3e42,.4,.5), red = stdm(0xb83a2a,.25,.55);
  const tur = new THREE.Group();
  const box = (w,h,d,mt,x,y,z,par) => { const o = new THREE.Mesh(geo(`bx${w}_${h}_${d}`,() => new THREE.BoxGeometry(w,h,d)),mt); o.position.set(x,y,z); (par||g).add(o); return o; };
  const cyl = (rt,rb,h,mt,x,y,z,par,rx) => { const o = new THREE.Mesh(geo(`cy${rt}_${rb}_${h}`,() => new THREE.CylinderGeometry(rt,rb,h,8)),mt); o.position.set(x,y,z); if(rx) o.rotation.x = rx; (par||g).add(o); return o; };
  // tracks helper
  const tracks = (len, gap) => {
    box(1.5,1.2,len,b,-gap,0.7,0); box(1.5,1.2,len,b,gap,0.7,0);
    for(const s of [-1,1]) for(let i=-2;i<=2;i++) cyl(0.55,0.55,1.3,steel,s*gap,0.55,i*(len/5),null,Math.PI/2);
  };
  if(t===0){ // flak
    tracks(9, 3.2);
    box(6.5,1.8,8,a,0,1.8,0); box(5,0.4,6,c,0,2.8,0);
    tur.position.y = 3.2;
    box(3.2,1.6,3.2,b,0,0,0,tur);
    for(const x of [-1.0,1.0]){ const gun = box(0.45,0.45,9,steel,x,0.4,4.2,tur); }
    cyl(0.3,0.3,2.2,steel,0,1.4,0,tur); // antenna
  } else if(t===1){ // tank
    tracks(12, 4.0);
    box(7.2,2.2,11,a,0,1.8,0); box(6.4,0.5,9,c,0,3.0,0); // hull + applique
    box(2.2,1.0,2.5,b,0,2.5,-4.5); // rear engine deck
    tur.position.y = 3.8;
    box(4.6,1.9,5.2,a,0,0,0,tur); box(3.6,0.35,4,c,0,1.05,0,tur);
    const barrel = box(0.55,0.55,8.5,steel,0,0.25,6.2,tur);
    box(0.7,0.7,1.2,b,0,0.25,2.2,tur); // mantlet
    cyl(0.15,0.15,1.8,steel,1.4,1.2,-1.5,tur); // antenna
  } else if(t===2){ // turret battery
    tracks(7, 3.0);
    box(6.2,1.6,6.2,b,0,1.4,0); box(5,0.35,5,c,0,2.3,0);
    tur.position.y = 2.8;
    for(const x of [-1.7,0,1.7]) for(const yi of [0,1.5]) box(0.85,0.85,7.2,steel,x,yi,2.5,tur);
    box(4.5,1.2,3,a,0,0.6,0,tur);
  } else { // SAM
    tracks(9, 3.5);
    box(7.5,1.8,8,b,0,1.5,0); box(5.2,0.5,5.2,a,0,2.5,0);
    tur.position.y = 3.0;
    box(3.2,1.5,3.2,a,0,0,0,tur);
    for(const x of [-1.3,1.3]){
      const rail = box(0.8,0.8,7,steel,x,1.0,-1.5,tur); rail.rotation.x = 0.45;
      const tip = box(0.65,0.65,1.2,red,x,2.5,-4.6,tur); tip.rotation.x = 0.45;
    }
    cyl(0.2,0.2,2.5,steel,0,1.6,0.8,tur);
  }
  g.add(tur); g.userData.aim = tur; return g;
}
/* v: 0 مستودع ذخيرة · 1 محطة رادار (طبق) · 2 خزانات وقود · 3 مركز قيادة (م5). كلها بنفس قاعدة 34×30 وحجم تصادم المستودع. */
export function mkDepot(v = 0, side = 'enemy'){
  const tint = SIDE_TINT[side] ?? SIDE_TINT.enemy;
  const base = side === 'ally' ? 0x3f7a55 : 0x5b6458;
  const dark = side === 'ally' ? 0x1e3a28 : 0x2c3128;
  const g = holder(), a = stdm(base,.2,.7), b = stdm(dark,.2,.7), red = basic(0xff3322);
  g.add_(geo('db',() => new THREE.BoxGeometry(34,1.2,30)),b,0,.6,0);
  if(v === 1){
    g.add_(geo('rdb',() => new THREE.BoxGeometry(14,7,10)),a,-8,4.7,4);
    g.add_(geo('rdm',() => new THREE.CylinderGeometry(1.1,1.6,24,8)),stdm(0x8b8f8d,.3,.6),6,13,-3);
    g.add_(geo('rdd',() => new THREE.ConeGeometry(8,3.4,18,1,true).rotateX(Math.PI*.62)),stdm(0xc9ccc8,.3,.5),6,25,-3);
    g.add_(geo('rdt',() => new THREE.SphereGeometry(1.5,8,6)),red,6,27.5,-3);
  } else if(v === 2){
    for(const p of [[-9,-7],[9,-7],[-9,8],[9,8]]) g.add_(geo('ft',() => new THREE.CylinderGeometry(5.6,5.6,9,16)),stdm(0xb7b9b4,.25,.6),p[0],5.7,p[1]);
    g.add_(geo('fp',() => new THREE.BoxGeometry(22,1,2)),b,0,3,0.5); g.add_(geo('ftw',() => new THREE.SphereGeometry(2,8,6)),red,0,13,0);
  } else if(v === 3){
    g.add_(geo('cb1',() => new THREE.BoxGeometry(20,6,13)),a,-3,4.2,-3); g.add_(geo('cb2',() => new THREE.BoxGeometry(8,5,8)),b,-3,9.7,-3);
    for(const x of [-12,8]) g.add_(geo('cm',() => new THREE.CylinderGeometry(.5,.8,22,6)),stdm(0x8b8f8d,.3,.6),x,12,9);
    g.add_(geo('ctw',() => new THREE.SphereGeometry(1.4,8,6)),red,8,23.5,9);
  } else {
    for(const p of [[-9,0],[9,0],[0,-10]]) g.add_(geo('dt',() => new THREE.CylinderGeometry(5,5,7,14)),a,p[0],4.7,p[1]);
    g.add_(geo('dtw',() => new THREE.CylinderGeometry(2,3,20,8)),a,0,11,8);
    g.add_(geo('dtop',() => new THREE.SphereGeometry(2.4,10,8)),red,0,22.5,8);
  }
  g.userData.aim = new THREE.Group(); g.add(g.userData.aim); return g;
}
export const BULLET_GEO = new THREE.SphereGeometry(.35,6,4);
export const BULLET_P = basic(0xffe27a), BULLET_E = basic(0xff4040);
export function mkMsl(enemy){
  const g = new THREE.Group(), w = stdm(enemy?0x3a3a3a:0xe8edf2,.2,.4), r = stdm(enemy?0xff5522:0xc23b2e,.2,.5);
  g.add(new THREE.Mesh(geo('mbody',() => new THREE.CylinderGeometry(.28,.28,3.4,8).rotateX(Math.PI/2)),w),
        new THREE.Mesh(geo('mnose',() => new THREE.ConeGeometry(.28,1.1,8).rotateX(Math.PI/2).translate(0,0,2.2)),r));
  const f = new THREE.Mesh(geo('mfin',() => new THREE.BoxGeometry(.08,1.3,.8).translate(0,0,-1.3)),r); g.add(f);
  const f2 = f.clone(); f2.rotation.z = Math.PI/2; g.add(f2); return g;
}
export function mkBomb(){
  const g = new THREE.Group(), m = stdm(0x3b4a2c,.2,.6);
  g.add(new THREE.Mesh(geo('bobody',() => new THREE.CylinderGeometry(.5,.5,2.2,8).rotateX(Math.PI/2)),m),
        new THREE.Mesh(geo('bonose',() => new THREE.ConeGeometry(.5,.9,8).rotateX(Math.PI/2).translate(0,0,1.5)),m));
  return g;
}
