/* واجهات المهمات داخل القائمة (HTML): العمليات · الإحاطة · التقييم · السجل + بطاقات اللوبي.
   المنطق (نجوم، تقدّم، إحاطة، تقرير) بملفات صرفة بـ src/mission/. هنا الرسم فقط. h = أدوات من menu.js */
import './menu_ms.css';
import {S} from './save.js';
import {t} from './i18n.js';
import {esc} from './util.js';
import {PLANES,loginInfo} from './data.js';
import {MISSIONS} from './mission/mission_defs.js';
import {summary,isUnlocked,nextIndex} from './mission/progress.js';
import {briefOf} from './mission/briefing.js';
import {normalizeLoad, AA_OPTS, AG_OPTS} from './mission/loadout.js';
import {fmtTime} from './mission/mission_hud.js';

export const stars = (n, max = 3) =>
  `<span class="stars">${Array.from({length:max}, (_, i) => `<i class="${i < n ? 'on' : ''}">★</i>`).join('')}</span>`;
const entry = m => S.ms[m.id] || {stars:0, best:0, bt:0, n:0, done:false};
const lines = s => esc(s).replace(/\n/g, '<br>');
const starText = (k, b) => t('st_'+k, {t:fmtTime(b.par)});

export function createMsViews(h){
  const {ic, plain, pimg, maps} = h;
  const MARK = {done:'✔', failed:'✖', open:'◇'}, opt = o => o.optional ? ' <small>('+t('ms_opt')+')</small>' : '';
  const missionCard = (m, i) => {
    const e = entry(m), open = isUnlocked(S.ms, MISSIONS, i);
    return `<div class="card ms ${open ? '' : 'lk'}">
      <div class="grow"><b class="tx">${i+1}. ${t(m.title)} ${e.done ? '✅' : ''}</b>
      <small class="tx">${open ? t(m.id+'d') : t('ops_locked')}</small>
      <small class="tx">${plain(t('map_'+m.map))} · ${stars(e.stars)}${e.best ? ' · '+t('ops_best')+' '+e.best : ''}
      </small></div>
      <button data-a="brief" data-i="${i}" ${open ? '' : 'disabled'}>${open ? t('ops_open') : '🔒'}</button></div>`;
  };
  const loginCard = () => { const lg = loginInfo();
    return `<div class="card"><div class="grow"><b class="tx">${t('loginT')}</b><small class="tx">${t('loginS',
      {d:lg.day, c:lg.coins, g:lg.gems ? ' +'+lg.gems+'💎' : ''})}</small></div>
      <button data-a="login" ${lg.can ? '' : 'disabled'}>${lg.can ? t('claim') : t('done')}</button></div>`; };
  const ops = () => { const sm = summary(S.ms, MISSIONS);
    return `<div class="chip tx">${t('ops_prog', {a:sm.done, b:sm.total, s:sm.stars})}</div>
      <div class="grid g2">${loginCard()}</div><div class="sec tx">${t('opsT')}</div>
      <div class="grid g2">${MISSIONS.map(missionCard).join('')}</div>`; };

  const brief = (i, PREV) => { const m = MISSIONS[i], b = briefOf(m), pl = PLANES[S.sel];
    const mp = maps().find(x => x.id === m.map), grad = mp ? mp.grad : '',
      img = `<img data-mi="${m.map}" src="${mp && mp.img || ''}" alt="" ${mp && mp.img ? '' : 'hidden'}>`;
    const objs = b.objectives.map(o => `
      <li class="tx">${t(o.text)}${opt(o)}</li>`).join('');
    const thr = b.threats.map(x => `<span class="chip tx">${x.n}× ${t('th_'+x.kind)}</span>`).join('');
    const sts = b.starKeys.map(k => `<li class="tx">★ ${starText(k, b)}</li>`).join('');
    const e = entry(m);
    return `<div class="bf"><div class="bf-map"><div class="bf-img" style="background:${grad}">${img}</div>
      <div><b class="tx">${t(m.title)}</b>
      <small class="tx">${t('bf_map')}: ${plain(t('map_'+m.map))}</small>${stars(e.stars)}</div></div>
      <div class="sec tx">${t('bf_order')}</div><p class="bf-order tx">${lines(t(b.order))}</p>
      <div class="sec tx">${t('bf_obj')}</div><ul class="bf-list">${objs}</ul>
      <div class="sec tx">${t('bf_threat')}</div><div class="bf-chips">${thr}</div>
      <div class="sec tx">${t('bf_roe')}</div><p class="tx bf-roe">${t('bf_roe_body')}</p>
      <div class="sec tx">${t('bf_stars')}</div><ul class="bf-list">${sts}</ul>
      <div class="card"><div class="grow"><b class="tx">${t('bf_reward')}</b>
        <small>${b.reward.c}🪙${b.reward.g ? ' +'+b.reward.g+'💎' : ''} · ${b.reward.xp} XP</small></div></div>
      <div class="card"><div class="grow"><b class="tx">${t('bf_plane')}</b><small class="tx">${pl.n}</small></div>
      <img class="bf-pl" src="${pimg(PREV, S.sel)}" alt="">
        <button data-a="scr" data-i="hangar">${t('bf_change')}</button></div>
      <div class="sec tx">${t('ld_title')}</div>
      ${loadoutPanel()}
      </div>`;
  };
  function loadoutPanel(){
    const L = normalizeLoad(S.load);
    const chip = (a, i, on, lab) =>
      `<button data-a="${a}" data-i="${i}" class="chip ${on?'on':''}">${lab}</button>`;
    const aa = AA_OPTS.map(k => chip('ldaa', k, L.aa===k, t('w_'+k))).join('');
    const ag = AG_OPTS.map(k => {
      const locked = k!=='bomb' && !(S[k]>0);
      return `<button data-a="ldag" data-i="${k}" class="chip ${L.ag===k?'on':''}" ${locked?'disabled':''}>${t('w_'+k)}</button>`;
    }).join('');
    const diffs = [0,1,2].map(d => chip('lddiff', d, L.diff===d, t('diff_'+d))).join('');
    const wing = chip('ldwing', L.wing?0:1, !!L.wing, t('ld_wing')+': '+(L.wing?t('ld_on'):t('ld_off')));
    return `<div class="bf-load">
      <div class="tx"><small>${t('ld_aa')}</small><div class="bf-chips">${aa}</div></div>
      <div class="tx"><small>${t('ld_ag')}</small><div class="bf-chips">${ag}</div></div>
      <div class="tx"><small>${t('ld_diff')}</small><div class="bf-chips">${diffs}</div></div>
      <div class="bf-chips">${wing}</div>
      <small class="tx">C · ${t('cas_call')}</small>
    </div>`;
  }

  const money = r => '+'+r.c+'🪙'+(r.g ? ' +'+r.g+'💎' : '')+' · +'+r.xp+' XP';
  const row = (k, v, cls = '') => `<div class="db-r ${cls}"><span class="tx">${t(k)}</span><b>${v}</b></div>`;
  const debrief = d => { const sc = d.score, r = d.reward;
    const title = d.quit ? 'db_quit' : d.win ? 'db_win' : 'db_fail';
    const objs = d.rows.map(o => `
      <li class="st-${o.status} tx">${MARK[o.status]} ${t(o.text)}${opt(o)}</li>`).join('');
    const crit = d.criteria.map(c => `
      <li class="${c.ok ? 'ok' : 'no'} tx">${c.ok ? '★' : '☆'} ${starText(c.k, {par:d.par})}</li>`).join('');
    const rw = d.win ? `<div class="card">
      <div class="grow"><b class="tx">${t('db_reward')} · ${t(r.first ? 'db_first' : 'db_repeat')}</b>
      <small>${money(r)}${r.newStars ? ' · '+t('db_newstars', {n:r.newStars}) : ''}</small></div></div>` : '';
    const chip = (txt) => `<span class="chip tx">${txt}</span>`, sg = n => n > 0 ? '+'+n : n;
    const scoreRows = [['db_s_combat', sc.combat], ['db_s_win', sc.win], ['db_s_time', sc.time], ['db_s_hp', sc.hp],
      ['db_s_ally', sc.ally]].filter(([k, v], i) => i === 0 || v)
      .map(([k, v]) => row(k, k === 'db_s_combat' ? v : sg(v), v < 0 ? 'neg' : '')).join('');
    return `<div class="db">
      <div class="db-h ${d.win ? 'ok' : 'no'}"><b class="tx">${t(title)}</b><em>${t(d.title)}</em>
        ${stars(d.stars)}</div>
      <div class="sec tx">${t('db_obj')}</div><ul class="bf-list db-obj">${objs}</ul>
      <div class="sec tx">${t('db_stars')}</div><ul class="bf-list db-crit">${crit}</ul>
      <div class="sec tx">${t('db_score')}</div>
        <div class="db-sc">${scoreRows}
      ${row('db_total', sc.total, 'tot')}</div>
      <div class="db-m">${chip(t('db_time')+' '+fmtTime(d.t))}${chip(t('db_kills', {a:d.kj, g:d.kg}))}
      ${d.allyLost ? chip(t('db_ally', {n:d.allyLost})) : ''}${d.loot ? chip(t('db_battle')+' '+d.loot) : ''}</div>
      ${rw}${d.lvUp ? `<div class="card info"><b class="tx">${d.lvUp}</b></div>` : ''}
      <div class="db-btn"><button data-a="mission" data-i="${d.idx}">${t('db_retry')}</button>
      ${d.next >= 0 ? `<button data-a="brief" data-i="${d.next}">${t('db_next')}</button>` : ''}
      <button data-a="scr" data-i="ops">${t('db_back')}</button></div></div>`;
  };

  const record = () => { const sm = summary(S.ms, MISSIONS), runs = (S.st && S.st.n) | 0;
    const rows = MISSIONS.map(m => { const e = entry(m);
      return `<div class="card"><div class="grow"><b class="tx">${t(m.title)}</b>
        <small class="tx">${e.done ? t('rc_time')+' '+fmtTime(e.bt)+' · '
        : t('rc_none')+' · '}${t('rc_tries')} ${e.n}</small></div>
          <div class="rc-v">${stars(e.stars)}<em>${e.best}</em></div></div>`; }).join('');
    return `<div class="grid g2">
      <div class="card"><b class="tx">${t('rc_done')}</b><em>${sm.done} / ${sm.total}</em></div>
      <div class="card"><b class="tx">${t('rc_stars')}</b><em>${sm.stars} / ${sm.maxStars}</em></div>
      <div class="card"><b class="tx">${t('rc_best')}</b><em>${sm.best}</em></div>
      <div class="card"><b class="tx">${t('rc_runs')}</b><em>${runs}</em></div></div>
      <div class="sec tx">${t('opsT')}</div><div class="grid g2">${rows}</div>`; };

  /* بطاقات اللوبي: العملية التالية + ملخص السجل (تحل مكان المهام اليومية والترتيب) */
  const nextCard = PREV => { const i = nextIndex(S.ms, MISSIONS), m = MISSIONS[i], e = entry(m);
    return `<button class="lb-event" data-a="brief" data-i="${i}"><img src="${pimg(PREV, S.sel)}" alt=""><div>
      <span class="tag">${t(e.done ? 'ops_open' : 'ops_new')}</span><b class="tx">${t(m.title)}</b>
      <small class="tx">${plain(t('map_'+m.map))}</small>${stars(e.stars)}</div></button>`; };
  const miniRecord = () => { const sm = summary(S.ms, MISSIONS);
    const r = (k, v) => `<div class="rk"><span class="tx">${t(k)}</span><b>${v}</b></div>`;
    return `<button class="lb-rank" data-a="scr" data-i="record">
      <div class="rk-h">${ic('trophy')}<b class="tx">${t('recT')}</b></div>
      ${r('rc_done', sm.done+' / '+sm.total)}${r('rc_stars', sm.stars+' / '+sm.maxStars)}
      ${r('rc_best', sm.best)}</button>`; };
  return {ops, brief, debrief, record, nextCard, miniRecord};
}
