/* سجل أنواع الأهداف + دورة حياة الهدف (دالة صرفة، بلا DOM/three). تفاصيل كل نوع بـ obj_types.js (أضف نوعاً هناك).
   حالة الهدف: {id,type,textKey,optional,after[],status:'locked'|'active'|'done'|'failed', ...حقول النوع}
   after:['o1'] ← يبقى locked حتى تنجح تلك الأهداف (للأنواع التي لا تعتمد على تاريخ أحداث: rtb/defend/intercept). */
import {TYPES} from './obj_types.js';

export const objectiveTypes = () => Object.keys(TYPES);
export const hasType = type => Object.prototype.hasOwnProperty.call(TYPES, type);
export const AFTER_TYPES = ['rtb', 'defend', 'intercept'];

export function makeObjective(d){
  if(!hasType(d.type)) throw new Error('objectives: unknown type '+d.type);
  const after = d.after ? d.after.slice() : [];
  const base = {id:d.id, type:d.type, textKey:d.text, optional:!!d.optional, after,
    status:after.length ? 'locked' : 'active'};
  return Object.assign(base, TYPES[d.type].init(d));
}
/* يمرّر حدثاً لهدف نشط؛ يرجع الحالة الجديدة إن تغيّرت وإلا null */
export function feed(o, ev){
  if(o.status !== 'active') return null;
  const r = TYPES[o.type].on(o, ev); if(r) o.status = r; return r;
}
/* تقدّم الزمن/العالم (أهداف الزمن والمواقع) */
export function tickObjective(o, dt, snap){
  const f = TYPES[o.type].tick; if(o.status !== 'active' || !f) return null;
  const r = f(o, dt, snap); if(r) o.status = r; return r;
}
export const progressOf = o => TYPES[o.type].progress(o);
export const pointsOf = (o, snap) => o.status === 'active' ? TYPES[o.type].points(o, snap) : [];
/* معرّفات الوحدات التي يجب تعليمها (e.obj) لأهداف نشطة */
export function trackedIds(objs){
  const ids = [];
  for(const o of objs){ if(o.status !== 'active') continue;
    for(const k of ['left', 'units', 'sites']) if(o[k]) ids.push(...o[k]); }
  return ids;
}
