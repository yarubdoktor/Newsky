/* المحفّزات (دالة صرفة): شرط واحد ← إجراءات مكتوبة بالمهمة (تعزيزات/رسائل) — ليست موجات لانهائية. تُطلَق مرة واحدة.
   trigger: {id, when, do:[…]}
   when:  {t:ث} مرور زمن المهمة · {zone:{pos, r}} دخول اللاعب منطقة (pos بصيغ entity_pos؛ يحوّلها الجسر لـ x,z)
          {dead:id} موت كيان · {arrived:id} وصول مركبة · {done:objectiveId} نجاح هدف
   do:    {spawn:[كيانات]} تظهر قرب اللاعب لحظتها ({d,a} تُقاس من موضع اللاعب واتجاهه الآن؛ {x,z} مطلق؛ {near:id}
   موضع البداية)
          · {comm:commId} رسالة لاسلكي معرّفة بـ def.comms
   ينتج: [{type:'trigger',id}, {type:'spawn',list,trig}, {type:'comm',id}] */
export const WHEN_KEYS = ['t', 'zone', 'dead', 'arrived', 'done'];
export const whenKey = w => WHEN_KEYS.find(k => w && w[k] !== undefined) || null;

export function createTriggers(list){ return (list || []).map(d => ({def:d, fired:false, x:null, z:null})); }

/* seen = {dead:Set, arrived:Set, done:Set} تراكمي (لا يضيع الحدث لو سبق الشرط الآخر) */
export function stepTriggers(trigs, rt, snap){
  const out = [];
  for(const tr of trigs){
    if(tr.fired) continue; const w = tr.def.when, k = whenKey(w); let hit = false;
    if(k === 't') hit = rt.t >= w.t;
    else if(k === 'dead') hit = rt.seen.dead.has(w.dead);
    else if(k === 'arrived') hit = rt.seen.arrived.has(w.arrived);
    else if(k === 'done') hit = rt.seen.done.has(w.done);
    else if(k === 'zone') hit = !!snap && tr.x !== null && Math.hypot(snap.px-tr.x, snap.pz-tr.z) <= w.zone.r;
    if(!hit) continue;
    tr.fired = true; out.push({type:'trigger', id:tr.def.id});
    for(const a of tr.def.do || []){
      if(a.spawn) out.push({type:'spawn', list:a.spawn, trig:tr.def.id});
      if(a.comm) out.push({type:'comm', id:a.comm});
    }
  }
  return out;
}
