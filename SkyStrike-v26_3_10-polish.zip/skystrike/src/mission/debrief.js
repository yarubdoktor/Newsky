/* تقرير ما بعد المهمة (دالة صرفة): يجمع نتيجة التقييم + حالة كل هدف + المكافأة بكائن واحد لشاشة التقييم (menu_ms.js).
   rt = آلة الحالات (rt.objectives بحالاتها) · res = evaluate() · rew = rewardFor() · extra = {kj, kg, allyLost, hpFrac, lvUp?} */
import {progressOf} from './objectives.js';

export function makeReport(def, rt, res, rew, extra, idx){
  const rows = rt.objectives.map(o => {
    const p = progressOf(o);
    const open = o.status === 'active' || o.status === 'locked';
    return {id:o.id, text:o.textKey, optional:o.optional, status:open ? 'open' : o.status,
      done:p.done || 0, total:p.total || 0};
  });
  return {idx, id:def.id, title:def.title, par:def.par || 0, win:res.win, quit:res.quit, stars:res.stars,
    criteria:res.criteria, score:res.score, t:res.t, rows, reward:rew, kj:extra.kj | 0, kg:extra.kg | 0,
    allyLost:extra.allyLost | 0, hpFrac:extra.hpFrac, lvUp:extra.lvUp || '', loot:extra.loot || '',
    next:extra.next === undefined ? -1 : extra.next};
}
