/* M11: اختيار العتاد (صرف). يُحفظ في S.load = {aa, ag, wing, diff} */
export const AA_OPTS = ['msl', 'bvr'];
export const AG_OPTS = ['bomb', 'agm', 'arm'];
export const DIFFS = [0, 1, 2]; // سهل · عادي · صعب

export function defaultLoad(){
  return {aa:'msl', ag:'bomb', wing:0, diff:1};
}
export function normalizeLoad(L){
  const d = defaultLoad();
  if(!L || typeof L !== 'object') return d;
  return {
    aa: AA_OPTS.includes(L.aa) ? L.aa : d.aa,
    ag: AG_OPTS.includes(L.ag) ? L.ag : d.ag,
    wing: L.wing ? 1 : 0,
    diff: DIFFS.includes(L.diff) ? L.diff : d.diff
  };
}
/* مضاعف صعوبة: صحة/ضرر/عدوانية العدو */
export const DIFF_MUL = [
  {hp:0.70, dmg:0.75, ai:0.70, name:'easy'},   // M12
  {hp:1.0,  dmg:1.0,  ai:1.0,  name:'normal'},
  {hp:1.40, dmg:1.25, ai:1.30, name:'hard'}
];
export function diffMul(d){ return DIFF_MUL[d] || DIFF_MUL[1]; }
