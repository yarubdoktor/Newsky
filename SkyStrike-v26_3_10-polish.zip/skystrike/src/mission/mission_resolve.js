/* يحوّل مواضع الأهداف/المحفّزات الرمزية ({d,a} / {near} / {x,z}) إلى إحداثيات مطلقة عند بدء المهمة (دالة صرفة).
   spawn = {x,z,yaw} نقطة بداية اللاعب · placed = مواضع الكيانات بعد إنشائها (entities.js). */
import {anchorOf} from './entity_pos.js';
import {whenKey} from './triggers.js';

export function resolveRuntime(rt, spawn, placed){
  for(const o of rt.objectives){
    const pos = o.pos; if(!pos) continue;
    const a = anchorOf(pos, spawn, placed); o.x = a.x; o.z = a.z;
  }
  for(const tr of rt.trigs){
    if(whenKey(tr.def.when) !== 'zone') continue;
    const a = anchorOf(tr.def.when.zone.pos, spawn, placed); tr.x = a.x; tr.z = a.z;
  }
  return rt;
}
