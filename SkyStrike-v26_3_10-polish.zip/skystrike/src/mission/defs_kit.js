/* مساعدات كتابة تعريفات الحملة (M6): مواضع المسارح المسمّاة + صيغ شائعة. بيانات صرفة. */
/* موقع مسمّى (src/theater/terrains.js) · نصف قطر بحث r · إزاحة اختيارية (dx,dz) بالمتر عن مركز الموقع */
export const at = (site, r = 90, dx, dz) => dx === undefined ? {site, r} : {site, r, dx, dz};
export const near = (id, r = 120) => ({near:id, r});
/* مدفع/صاروخ دفاع جوي قرب كيان */
export const aa = (id, nearId, r, side = 'enemy', tt = 0) => ({id, kind:'turret', tt, side, pos:near(nearId, r)});
export const sam = (id, pos, side = 'enemy') => ({id, kind:'sam', side, pos});
export const dep = (id, pos, tt = 0, side = 'enemy', obj = true) => ({id, kind:'depot', tt, side, pos, obj});
export const FAIL = [{type:'playerDead'}, {type:'timeout', t:1200}];
/* عدو جوي يُنشأ بمحفّز عند إحداثيات مطلقة */
export const air = (id, kind, x, z) => ({id, kind, side:'enemy', pos:{x, z, r:60}});
