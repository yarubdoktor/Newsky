/* نصوص الفصل الثالث (m9–m11). [عربي، إنجليزي] */
const FROM = ['من: وزارة الدفاع — إلى: الطيار.\n', 'From: Ministry of Defense — To: Pilot.\n'];
const B = (ar, en) => [FROM[0]+ar, FROM[1]+en];

export const TEXT_CH3 = {
  m9t:['عملية قلب الليل', 'Operation Midnight Heart'],
  m9i:['وزارة الدفاع ← الطيار: ضربة ليلية لمركز القيادة ومستودع الوقود',
    'MoD to Pilot: night strike on the command center and fuel depot'],
  m9d:['مركز قيادة معادٍ ومستودع وقود في عمق الجبهة ليلاً. أضواء المواقع هي دليلك. مقاتلتان ستعترضانك.',
       'A hostile command center and fuel depot deep behind the front at night. Site lights are your guide.'],
  m9b:B('ضربة ليلية في عمق الأراضي المعادية. الرؤية محدودة، والأضواء تدل على المواقع. دمّر مركز القيادة ومستودع الوقود ' +
        'ثم عُد إلى القاعدة.',
        'A night strike deep in hostile territory. Visibility is limited; site lights mark the targets. Destroy the command ' +
        'center and the fuel depot, then return to base.'),
  m9o1:['دمّر مركز القيادة', 'Destroy the command center'],
  m9o2:['دمّر مستودع الوقود', 'Destroy the fuel depot'],
  m9o4:['أسقط المقاتلتين المعترضتين', 'Shoot down the two intercepting fighters'],
  m9c1:['الرؤية ضعيفة ليلاً؛ ارتفع فوق التلال واعتمد على الأضواء والخريطة.',
    'Visibility is poor at night; stay above the hills and trust the lights and the map.'],
  m9c2:['أضواء مركز القيادة أمامك. مدافع ثقيلة حوله.', 'Command center lights ahead. Heavy guns around it.'],
  m9c3:['مقاتلتان معاديتان أقلعتا من القاعدة الشمالية. الرؤية ضعيفة، انتبه.',
    'Two hostile fighters scrambled from the northern base. Visibility is poor, be careful.'],
  m9c4:['مركز القيادة دُمّر. أنهِ الوقود وعُد.', 'Command center destroyed. Finish the fuel depot and come home.'],

  m10t:['عملية مدّ الخليج', 'Operation Gulf Tide'],
  m10i:['وزارة الدفاع ← الطيار: اضرب الحصنين والميناء والرادار واعترض القاذفات',
    'MoD to Pilot: strike two forts, the port and the radar, and intercept the bombers'],
  m10d:['حصنان بحريان وميناء وقود ورادار على قمة الجزيرة، وقاذفتان تتجهان نحو الجزيرة الصديقة. العدو يحمي كل شيء بالصواريخ.',
        'Two sea forts, a fuel port and a radar on the island peak, with two bombers heading for the friendly isle.'],
  m10b:B('مسرح الخليج: الحصنان البحريان يقصفان خطوطنا، والميناء يمدّ الأسطول، والرادار المركزي يغطي الجميع. ' +
         'دمّرها كلها، واعترض القاذفتين اللتين ستهاجمان جزيرتنا، ثم عُد إلى المهبط.',
         'Gulf theater: the sea forts shell our lines, the port supplies the fleet, and the central radar covers everything. ' +
         'Destroy them all, intercept the two bombers that will attack our island, then return.'),
  m10o1:['دمّر الحصنين البحريين', 'Destroy the two sea forts'],
  m10o2:['دمّر ميناء الوقود والرادار', 'Destroy the fuel port and the radar'],
  m10o3:['اعترض القاذفتين', 'Intercept the two bombers'],
  m10o4:['عُد إلى قاعدة الخليج', 'Return to the gulf base'],
  m10o5:['احمِ الجزيرة الصديقة', 'Defend the friendly island'],
  m10c1:['ارتفاع منخفض فوق الماء يحميك من الرادار. لا تتسرع.', 'Fly low over the water to avoid radar. Do not rush.'],
  m10c2:['الحصن الشمالي أمامك. صواريخ وقذائف على حوافه.',
    'The northern fort is ahead. Missiles and flak on its parapets.'],
  m10c3:['قاذفتان معاديتان أقلعتا نحو جزيرتنا. اعترضهما فوراً.',
    'Two hostile bombers took off toward our island. Intercept at once.'],
  m10c4:['القاذفتان سقطتا. الجزيرة بأمان، أكمل المهمة.',
    'Both bombers are down. The island is safe; finish the mission.'],

  m11t:['الفجر', 'Dawn'],
  m11i:['وزارة الدفاع ← الطيار: الضربة الأخيرة — اكسر الحزام واضرب القاعدة الشمالية',
    'MoD to Pilot: the final strike — break the belt and hit the northern base'],
  m11d:['اكسر حزام الصواريخ ثم تقدّم إلى القاعدة الشمالية: دمّر الرادار والوقود والقيادة واسقط طياري النخبة. الدبابات ثانوية.',
        'Break the SAM belt, then hit the northern base: destroy radar, fuel and command, and down the elite pilots.'],
  m11b:B('هذه هي الطلعة الأخيرة. اكسر حزام الصواريخ أولاً، فتنكشف القاعدة الشمالية: الرادار والوقود ومركز القيادة، ' +
         'وتقلع مقاتلات النخبة لاعتراضك. أسقط اثنتين منها على الأقل، ثم عُد إلى القاعدة.',
         'This is the final sortie. Break the SAM belt first, which exposes the northern base: radar, fuel and the command ' +
         'center, while elite fighters scramble to stop you. Down at least two, then return to base.'),
  m11o1:['اقمع حزام الصواريخ (2 من 3)', 'Suppress the SAM belt (2 of 3)'],
  m11o2:['دمّر الرادار والوقود والقيادة بالقاعدة الشمالية', 'Destroy the radar, fuel and command at the northern base'],
  m11o3:['أسقط طياري النخبة (2 من 3)', 'Shoot down the elite pilots (2 of 3)'],
  m11o4:['دمّر مصنع المدرعات', 'Destroy the armor assembly'],
  m11c1:['الحزام ثلاث بطاريات على خط الجبل. بعدها الطريق مفتوح.',
    'The belt is three batteries on the ridge line. After that the road is open.'],
  m11c2:['الصواريخ تلتقطك. اقصف وانسحب.', 'Missiles have you. Strike and break away.'],
  m11c3:['القاعدة الشمالية انكشفت وطيارو النخبة أقلعوا. أهدافك: الرادار والوقود والقيادة.',
    'The northern base is exposed and the elite pilots took off. Your targets: radar, fuel and command.'],
  m11c4:['القاعدة تحترق. عُد إلى القاعدة الأم.', 'The base is burning. Return to the home base.']
};
