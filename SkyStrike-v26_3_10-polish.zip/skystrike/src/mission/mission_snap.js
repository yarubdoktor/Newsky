/* لقطة العالم لآلة المهمة كل فريم (محرك: تقرأ W/P/world) — {px,pz,py,agl,units:{mid:{x,z,hp,max}}}.
   تعيد استعمال كائن واحد لتقليل التخصيص. وتحدّد علامات الأهداف الحيّة (e.obj لرسم الحلقات/الرادار، e.pin
   لإبقائها نشطة). */
import {W, P} from '../state.js';
import {world} from '../core.js';
import {trackedIds, pointsOf} from './objectives.js';

const SNAP = {px:0, pz:0, py:0, agl:0, units:{}};
export function makeSnap(){
  const p = P.g.position, us = SNAP.units;
  for(const k in us) delete us[k];
  for(const e of W.units){ if(e.mid) us[e.mid] = {x:e.g.position.x, z:e.g.position.z, hp:e.hp, max:e.max}; }
  SNAP.px = p.x; SNAP.pz = p.z; SNAP.py = p.y; SNAP.agl = p.y-world.ground(p.x, p.z);
  return SNAP;
}
/* علامات: وحدات الأهداف النشطة ترسم حلقة/نقطة زرقاء وتبقى خارج تبسيط الأداء؛ G.mark = نقطة منطقة (رجوع للقاعدة) */
export function updateMarks(rt, snap){
  const set = new Set(trackedIds(rt.objectives)), G = W.G;
  for(const e of W.units) if(e.mid){ const on = set.has(e.mid) || !!e.fixObj; e.obj = on; e.pin = on; }
  G.mark = null;
  for(const o of rt.objectives) for(const p of pointsOf(o, snap)) if(p.r){ G.mark = p; break; }
}
