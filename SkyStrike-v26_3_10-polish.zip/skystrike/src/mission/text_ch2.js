/* نصوص الفصل الثاني (m5–m8). [عربي، إنجليزي] */
const FROM = ['من: وزارة الدفاع — إلى: الطيار.\n', 'From: Ministry of Defense — To: Pilot.\n'];
const B = (ar, en) => [FROM[0]+ar, FROM[1]+en];

export const TEXT_CH2 = {
  m5t:['عملية فتح الحزام', 'Operation Belt Breaker'],
  m5i:['وزارة الدفاع ← الطيار: اخترق حزام الصواريخ ودمّر مستودع الوقود',
    'MoD to Pilot: break the SAM belt and destroy the fuel depot'],
  m5d:['خمس بطاريات SAM على خط الجبل تحمي مستودع وقود. اقمع أربعاً منها ثم دمّر المستودع.',
       'Five SAM batteries on the ridge line cover a fuel depot. Suppress four, then destroy the depot.'],
  m5b:B('حزام الصواريخ يمنع أي هجوم عميق. اقمع أربع بطاريات من أصل خمس، ثم اضرب مستودع الوقود خلفها وعُد. ' +
        'ستقلع مقاتلتان لاعتراضك بعد دقيقة ونصف.',
        'The SAM belt blocks any deep strike. Suppress four of the five batteries, then hit the fuel depot behind them and ' +
        'return. Two fighters will scramble to intercept you after ninety seconds.'),
  m5o1:['اقمع بطاريات الصواريخ (4 من 5)', 'Suppress the SAM batteries (4 of 5)'],
  m5o2:['دمّر مستودع الوقود', 'Destroy the fuel depot'],
  m5o4:['أسقط المقاتلتين المعترضتين', 'Shoot down the two intercepting fighters'],
  m5c1:['الحزام ممتد على خط الجبل. ادخل منخفضاً واستخدم الوديان.',
    'The belt runs along the ridge. Go in low and use the valleys.'],
  m5c2:['رادارات البطاريات تعمل. لا تحلّق فوق القمم.', 'Battery radars are active. Do not cross the peaks.'],
  m5c3:['الحزام انكسر. مستودع الوقود مكشوف، اضربه الآن.', 'The belt is broken. The fuel depot is exposed; strike now.'],
  m5c4:['مقاتلتان معاديتان أقلعتا من القاعدة الشمالية.', 'Two hostile fighters have scrambled from the northern base.'],

  m6t:['عملية قمة الرادار', 'Operation Radar Peak'],
  m6i:['وزارة الدفاع ← الطيار: دمّر الرادار ومستودع الوقود في المرتفعات',
    'MoD to Pilot: destroy the radar and the fuel depot in the highlands'],
  m6d:['رادار ومستودع وقود في مرتفعات وعرة تحميهما ثلاث بطاريات SAM وثلاثة مدافع. الوديان ضيقة، فحلّق بحذر.',
       'A radar and a fuel depot in rugged highlands guarded by three SAM batteries and three guns. Valleys are narrow.'],
  m6b:B('المرتفعات الشمالية تحجب الرادار الأرضي عنا. دمّر الرادار والوقود المخزّن في الوادي، ثم عُد إلى المهبط ' +
        'الجبلي. تضاريس ضيقة: الاصطدام بالسفح أخطر من النار.',
        'The northern highlands blind our ground radar. Destroy the radar and the fuel stored in the valley, then return to ' +
        'the mountain strip. Terrain is tight: hitting a slope is deadlier than enemy fire.'),
  m6o1:['دمّر الرادار', 'Destroy the radar'],
  m6o2:['دمّر مستودع الوقود', 'Destroy the fuel depot'],
  m6o3:['اقمع بطاريتي صواريخ', 'Suppress two SAM batteries'],
  m6o4:['عُد إلى المهبط الجبلي', 'Return to the mountain strip'],
  m6o5:['أسقط مروحيتي الدعم', 'Shoot down the two support helicopters'],
  m6c1:['الرادار في أعلى الوادي الغربي. اتبع مجرى الوادي.',
    'The radar is at the head of the western valley. Follow the valley floor.'],
  m6c2:['صواريخ على الحافة الشرقية. ابقَ في منتصف الوادي.', 'Missiles on the eastern rim. Stay mid-valley.'],
  m6c3:['مروحيتان معاديتان أقلعتا من مركز القيادة بعد سقوط الرادار.',
    'Two hostile helicopters lifted off from the command site after the radar fell.'],
  m6c4:['الوقود اشتعل. عُد إلى المهبط قبل أن يشتد الطقس.',
    'The fuel is burning. Return to the strip before the weather closes in.'],

  m7t:['عملية حارس المخفر', 'Operation Outpost Guard'],
  m7i:['وزارة الدفاع ← الطيار: احمِ المخفر الجبلي من ثلاث موجات جوية',
    'MoD to Pilot: protect the mountain outpost from three air waves'],
  m7d:['مخفر قيادة صديق على سفح الجبل يتعرض لمقاتلتين ثم ثلاث مروحيات ثم قاذفتين. اعترض القاذفتين واحمِ المخفر.',
       'A friendly command outpost on the mountain face faces two fighters, three helicopters, then two bombers.'],
  m7b:B('المخفر الجبلي نقطة الاتصال الوحيدة مع القوات في الوادي. ثلاث موجات متتالية متوقعة: مقاتلات ثم مروحيات ثم ' +
        'قاذفات. القاذفات هي الخطر الأكبر.',
        'The mountain outpost is the only link with the forces in the valley. Three waves are expected: fighters, helicopters, ' +
        'then bombers. The bombers are the greatest threat.'),
  m7o1:['احمِ المخفر الجبلي', 'Defend the mountain outpost'],
  m7o2:['اعترض القاذفتين', 'Intercept the two bombers'],
  m7o3:['أسقط مروحيتين على الأقل', 'Shoot down at least two helicopters'],
  m7c1:['المخفر تحت حمايتك. الموجة الأولى قادمة.', 'The outpost is under your cover. The first wave is inbound.'],
  m7c2:['مقاتلتان معاديتان فوق القمة. نحن نغطي من الأرض.',
    'Two hostile fighters over the summit. We cover from the ground.'],
  m7c3:['ثلاث مروحيات خلف الحافة. ستظهر فجأة، كن مستعداً.',
    'Three helicopters behind the ridge. They will pop up suddenly, be ready.'],
  m7c4:['قاذفتان معاديتان تتجهان نحو المخفر. هذه هي الضربة الحقيقية.',
    'Two hostile bombers heading for the outpost. This is the real strike.'],

  m8t:['عملية اختراق الوادي', 'Operation Valley Run'],
  m8i:['وزارة الدفاع ← الطيار: أمّن رتلاً عبر ثلاثة كمائن في الوادي',
    'MoD to Pilot: escort a convoy through three ambushes in the valley'],
  m8d:['رتل صديق يعبر وادياً طويلاً به أربع دبابات كامنة وبطارية مضادة للطيران وصاروخان. افتح الطريق قبله.',
       'A friendly convoy crosses a long valley holding four ambush tanks, an AA gun and two SAMs. Open the road ahead of it.'],
  m8b:B('الرتل ينقل ذخيرة وإمدادات إلى المخفر الشمالي، وطريقه الوحيد وادٍ ضيق ملغوم بالكمائن. دمّر ثلاثاً من الدبابات ' +
        'الأربع، اقمع الدفاع الجوي، أوصل ثلاثة من أربعة، ثم عُد إلى المهبط.',
        'The convoy carries ammunition and supplies to the northern outpost; its only route is a narrow valley full of ambushes. ' +
        'Destroy three of the four tanks, suppress the air defenses, get three of four vehicles through, then return.'),
  m8o1:['دمّر دبابات الكمائن (3 من 4)', 'Destroy the ambush tanks (3 of 4)'],
  m8o2:['اقمع الدفاع الجوي (2 من 3)', 'Suppress the air defenses (2 of 3)'],
  m8o3:['أوصل الرتل (3 من 4 على الأقل)', 'Get the convoy through (at least 3 of 4)'],
  m8o5:['أسقط المروحية المعادية', 'Shoot down the hostile helicopter'],
  m8c1:['الرتل يتحرك. الكمين الأول عند الانحناءة الأولى للوادي.',
    'The convoy is moving. The first ambush is at the first bend of the valley.'],
  m8c2:['دبابات كامنة خلف الصخور. ابحث عن وهج المحركات.', 'Tanks lie hidden behind the rocks. Look for engine glow.'],
  m8c3:['مروحية معادية تظهر من الشمال لدعم الكمائن.',
    'A hostile helicopter appears from the north to support the ambushes.'],
  m8c4:['الرتل اجتاز الممر الأخير. شكراً على الإسناد، عُد إلى المهبط.',
    'The convoy cleared the last pass. Thanks for the cover; return to the strip.']
};
