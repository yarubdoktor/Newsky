/* أنواع الأهداف (دالة صرفة، بلا DOM/three). كل نوع:
     init(def) ← حقول الحالة · on(o, ev) ← 'done'|'failed'|null عند وصول حدث · tick(o, dt, snap) ← نفس الشيء كل فريم
     progress(o) ← {done, total, left?} للعرض · points(o, snap) ← مواضع تُعلَّم بالرادار/البوصلة [{x,z}]
   الأحداث: entityDead{id} · entityArrived{id} · playerDead. snap = لقطة العالم من الجسر (انظر mission_snap.js).
   الأنواع: destroy (تدمير كل الأهداف) · suppress (قمع: تدمير need من أصل targets) · escort (إسناد رتل: يصل need
   من units حياً)
   · intercept (اعتراض مجموعة قبل limit ث) · defend (حماية مواقع صديقة لمدة t) · rtb (عودة لنقطة x,z بارتفاع ≤ alt). */
const had = (list, id) => list.indexOf(id) >= 0;
const alive = (snap, id) => snap && snap.units ? snap.units[id] : null;
const where = (snap, ids) => ids.map(id => alive(snap, id)).filter(Boolean).map(u => ({x:u.x, z:u.z}));

/* تدمير مجموعة: يكفي need منها (الافتراضي كلها) */
function killsInit(d){
  const n = d.targets.length;
  return {targets:d.targets.slice(), left:d.targets.slice(), need:Math.min(d.need ?? n, n)};
}
function killsOn(o, ev){
  if(ev.type !== 'entityDead') return null;
  const i = o.left.indexOf(ev.id); if(i < 0) return null;
  o.left.splice(i, 1);
  return o.targets.length-o.left.length >= o.need ? 'done' : null;
}
const killsProgress = o => ({done:Math.min(o.targets.length-o.left.length, o.need), total:o.need});

export const TYPES = {
  destroy:{
    init:d => killsInit({targets:d.targets}), on:killsOn, progress:killsProgress,
    points:(o, snap) => where(snap, o.left)
  },
  suppress:{
    init:killsInit, on:killsOn, progress:killsProgress, points:(o, snap) => where(snap, o.left)
  },
  escort:{
    init:d => ({units:d.units.slice(), need:Math.min(d.need ?? d.units.length, d.units.length), arrived:[], dead:[]}),
    on(o, ev){
      if(!had(o.units, ev.id)) return null;
      if(ev.type === 'entityArrived' && !had(o.arrived, ev.id)) o.arrived.push(ev.id);
      else if(ev.type === 'entityDead' && !had(o.dead, ev.id)) o.dead.push(ev.id);
      else return null;
      if(o.arrived.length >= o.need) return 'done';
      const can = o.units.filter(u => had(o.arrived, u) || !had(o.dead, u)).length;      // من يمكنه الوصول بعد
      return can < o.need ? 'failed' : null;
    },
    progress:o => ({done:o.arrived.length, total:o.need, lost:o.dead.length}),
    points:(o, snap) => where(snap, o.units.filter(u => !had(o.arrived, u)))
  },
  intercept:{
    init:d => ({targets:d.targets.slice(), left:d.targets.slice(), limit:d.limit || 0, t:0}),
    on(o, ev){
      if(!had(o.targets, ev.id)) return null;
      if(ev.type === 'entityArrived') return 'failed';                    // وصلت المجموعة لوجهتها قبل اعتراضها
      if(ev.type !== 'entityDead') return null;
      const i = o.left.indexOf(ev.id); if(i >= 0) o.left.splice(i, 1);
      return o.left.length ? null : 'done';
    },
    tick(o, dt){ o.t += dt; return o.limit && o.t >= o.limit ? 'failed' : null; },
    progress:o => ({done:o.targets.length-o.left.length, total:o.targets.length,
      left:o.limit ? Math.max(0, o.limit-o.t) : null}),
    points:(o, snap) => where(snap, o.left)
  },
  defend:{
    init:d => ({sites:d.sites.slice(), need:Math.min(d.need ?? d.sites.length, d.sites.length),
      dead:[], total:d.t, t:0}),
    on(o, ev){
      if(ev.type !== 'entityDead' || !had(o.sites, ev.id) || had(o.dead, ev.id)) return null;
      o.dead.push(ev.id); return o.sites.length-o.dead.length < o.need ? 'failed' : null;
    },
    tick(o, dt){ o.t += dt; return o.t >= o.total ? 'done' : null; },
    progress:o => ({done:Math.min(o.t, o.total)|0, total:o.total, left:Math.max(0, o.total-o.t)}),
    points:(o, snap) => where(snap, o.sites)
  },
  rtb:{
    init:d => ({pos:d.pos, r:d.r ?? 450, alt:d.alt ?? 220, x:d.x ?? null, z:d.z ?? null}),
    on:() => null,
    tick(o, dt, snap){
      if(!snap || o.x === null) return null;
      return Math.hypot(snap.px-o.x, snap.pz-o.z) <= o.r && snap.agl <= o.alt ? 'done' : null;
    },
    progress:() => ({done:0, total:1}),
    points:o => o.x === null ? [] : [{x:o.x, z:o.z, r:o.r}]
  }
};
