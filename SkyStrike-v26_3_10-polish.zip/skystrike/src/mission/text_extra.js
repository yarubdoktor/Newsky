/* نصوص المهمتين الإضافيتين m12–m13 (M11) */
const FROM = ['من: وزارة الدفاع — إلى: الطيار.\n', 'From: Ministry of Defense — To: Pilot.\n'];
const B = (ar, en) => [FROM[0]+ar, FROM[1]+en];

export const TEXT_EXTRA = {
  m12t:['عملية الظل الأسود', 'Operation Black Shadow'],
  m12i:['وزارة الدفاع ← الطيار: اقطع رتل إمداد معادٍ ليلاً',
    'MoD to Pilot: cut a hostile night supply convoy'],
  m12d:['رتل شاحنات معادٍ يتحرك ليلاً تحت حماية خفيفة. دمّر أغلب المركبات واقمع دفاعه الجوي.',
    'A hostile truck convoy moves at night under light cover. Destroy most vehicles and suppress its air defenses.'],
  m12b:B('رتل إمداد معادٍ يتحرك تحت جنح الظلام. أوقف الرتل قبل أن يبلغ خط التماس، واقمع المدافع والـSAM المرافقة.',
    'A hostile supply convoy is moving under cover of night. Stop it before it reaches the line and suppress its guns and SAM.'),
  m12o1:['دمّر مركبات الرتل (3 من 4)', 'Destroy convoy vehicles (3 of 4)'],
  m12o2:['اقمع الدفاع الجوي المرافق (2 من 3)', 'Suppress escort air defenses (2 of 3)'],
  m12o3:['أسقط المقاتلات المعترضة (ثانوي)', 'Shoot down interceptors (optional)'],
  m12c1:['الرتل تحرك. استخدم الظلام والاقتراب المنخفض.', 'Convoy is moving. Use darkness and low approach.'],
  m12c2:['شاحنات معادية أمامك مع مدافع مرافقة.', 'Hostile trucks ahead with escort guns.'],
  m12c3:['الرتل متوقف. أحسنت. عُد عند الجاهزية.', 'Convoy stopped. Good work. RTB when ready.'],
  m12c4:['مروحية معادية تقترب من القطاع.', 'Hostile helicopter entering the sector.'],

  m13t:['عملية السماء المفتوحة', 'Operation Open Sky'],
  m13i:['وزارة الدفاع ← الطيار: اعتراض موجات جوية معادية فوق المرتفعات',
    'MoD to Pilot: intercept hostile air waves over the highlands'],
  m13d:['موجات مقاتلات معادية فوق المرتفعات. أسقط ثلاثة على الأقل ثم عُد.',
    'Hostile fighter waves over the highlands. Shoot down at least three, then return.'],
  m13b:B('الرادار يرصد تشكيلاً معادياً فوق المرتفعات. مهمتك اعتراض بحت: أسقط ثلاثة مقاتلات على الأقل وارجع.',
    'Radar tracks a hostile formation over the highlands. Pure intercept: down at least three fighters and return.'),
  m13o1:['أسقط المقاتلات المعادية (3 من 4)', 'Shoot down hostile fighters (3 of 4)'],
  m13o2:['أسقط المروحية (ثانوي)', 'Shoot down the helicopter (optional)'],
  m13c1:['تشكيل معادٍ على الرادار. ارتفع واشتبك.', 'Hostile formation on radar. Climb and engage.'],
  m13c2:['موجة ثانية تقترب من القطاع.', 'Second wave entering the sector.'],
  m13c3:['السماء صافية. عُد إلى القاعدة.', 'Skies clear. Return to base.']
};
