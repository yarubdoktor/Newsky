/* M11: منطق مرافقة (صرف قدر الإمكان) — التنفيذ البصري في ai/spawn */
export const WM = {
  offset: {x: 80, y: 30, z: 120}, // موقع نسبي خلف يمين اللاعب
  engageR: 1400,
  rejoinR: 2200,
  fireCd: 1.4
};

/** موضع مرافقة مرغوب خلف اللاعب */
export function wingSlot(px, py, pz, yaw){
  const s = Math.sin(yaw), c = Math.cos(yaw);
  const o = WM.offset;
  return {
    x: px + c * o.x + s * o.z,
    y: py + o.y,
    z: pz - s * o.x + c * o.z
  };
}

/** هل يشتبك أم يعود للتشكيل؟ */
export function wingMode(distToPlayer, hasTarget){
  if(distToPlayer > WM.rejoinR) return 'rejoin';
  if(hasTarget && distToPlayer < WM.engageR) return 'engage';
  return 'form';
}
