/* نصوص الفصل الأول (m0 المكمّلة · m3 · m4). المهمات m1/m2 نصوصها بـ mission_text.js. [عربي، إنجليزي] */
const FROM = ['من: وزارة الدفاع — إلى: الطيار.\n', 'From: Ministry of Defense — To: Pilot.\n'];
const B = (ar, en) => [FROM[0]+ar, FROM[1]+en];

export const TEXT_CH1 = {
  m0o2:['عُد إلى القاعدة', 'Return to base'],
  m0c1:['المستودع خلف الممر الغربي. اتبع الوادي ولا ترتفع كثيراً قبل الهدف.',
    'The depot sits behind the western pass. Follow the valley and stay low until the target.'],
  m0c2:['مدفعان وبطارية SAM حول المستودع. ابدأ الهجوم من الجهة الشمالية.',
    'Two guns and a SAM around the depot. Attack from the north side.'],

  m3t:['عملية العين المغمضة', 'Operation Blind Eye'],
  m3i:['وزارة الدفاع ← الطيار: دمّر رادار الإنذار المبكر شرق الجبهة',
    'MoD to Pilot: destroy the early-warning radar east of the front'],
  m3d:['رادار إنذار مبكر معادٍ تحميه بطاريتا SAM ومدفعان. دمّره لفتح الأجواء، وأسقط المروحيتين إن ظهرتا.',
       'A hostile early-warning radar guarded by two SAM batteries and two guns. Destroy it to open the airspace.'],
  m3b:B('الرادار الشرقي يكشف كل طلعاتنا. دمّره بضربة دقيقة، ويُستحسن قمع بطاريتي الصواريخ قبل الاقتراب. ' +
        'قد تصل مروحيتان لحمايته.',
        'The eastern radar sees every sortie we fly. Destroy it with a precise strike; suppressing the two SAM batteries ' +
        'first is advised. Two helicopters may arrive to protect it.'),
  m3o1:['دمّر رادار الإنذار المبكر', 'Destroy the early-warning radar'],
  m3o2:['اقمع إحدى بطاريتي الصواريخ', 'Suppress one of the two SAM batteries'],
  m3o3:['أسقط المروحيتين المعاديتين', 'Shoot down the two hostile helicopters'],
  m3c1:['الرادار على التلة الشرقية. حلّق منخفضاً بين الأودية قبل الاقتراب.',
    'The radar is on the eastern hill. Fly low between the valleys before approaching.'],
  m3c2:['بطاريات الصواريخ تضيء رادارها. ابقَ تحت الأفق حتى بداية الغطسة.',
    'SAM batteries are lighting up. Stay below the horizon until your dive.'],
  m3c3:['مروحيتان معاديتان تقلعان من الممر الشرقي. انتبه لخلفك.',
    'Two hostile helicopters are lifting off from the eastern pass. Watch your six.'],
  m3c4:['الرادار سقط. أجواء الجبهة مفتوحة، عُد إلى القاعدة.',
    'The radar is down. The airspace is open; return to base.'],

  m4t:['عملية سرب الدرون', 'Operation Drone Swarm'],
  m4i:['وزارة الدفاع ← الطيار: احمِ مركز القيادة المتقدم من هجوم المسيّرات',
    'MoD to Pilot: protect the forward command post from a drone attack'],
  m4d:['مركز قيادة صديق في بلدة المنتصف يتعرض لموجتي مسيّرات ثم مقاتلتين. أسقط المسيّرات واحمِ المركز.',
       'A friendly command post in the central town faces two drone waves then two fighters. Shoot down the drones and hold.'],
  m4b:B('مركز القيادة المتقدم هدف لسرب مسيّرات انتحارية يتبعه مقاتلات. المسيّرات بطيئة وصغيرة، فاستخدم المدفع. ' +
        'يجب ألا يسقط المركز.',
        'The forward command post is the target of a suicide-drone swarm followed by fighters. Drones are slow and small, ' +
        'so use the gun. The post must not fall.'),
  m4o1:['احمِ مركز القيادة حتى وصول الدعم', 'Defend the command post until relief arrives'],
  m4o2:['اعترض المسيّرات (5 من 6)', 'Intercept the drones (5 of 6)'],
  m4o3:['أسقط المقاتلتين المرافقتين', 'Shoot down the two escort fighters'],
  m4c1:['المركز تحت حمايتك. الرادار يلتقط أهدافاً صغيرة من الشمال.',
    'The post is under your cover. Radar is picking up small contacts from the north.'],
  m4c2:['الموجة الأولى: ثلاث مسيّرات من الشمال الغربي. اعترضها بالمدفع.',
    'First wave: three drones from the north-west. Take them with the gun.'],
  m4c3:['موجة ثانية من الشمال الشرقي. لا تدعها تصل إلى المركز.',
    'Second wave from the north-east. Do not let them reach the post.'],
  m4c4:['مقاتلتان معاديتان خلف المسيّرات. حان وقت الصواريخ.',
    'Two hostile fighters behind the drones. Time for missiles.']
};
