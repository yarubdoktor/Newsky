/* تقدّم المهمات المحفوظ (دوال صرفة على الكائن S.ms): { [missionId]: {stars, best, bt, n, done} }
   stars = أفضل نجوم (0..3) · best = أعلى نقاط · bt = أقصر زمن نجاح (ث) · n = عدد المحاولات · done = أُنجزت مرة على الأقل
   الفتح بالترتيب: المهمة i مفتوحة إذا i=0 أو أُنجزت التي قبلها. S.cp = طول سلسلة المنجز من البداية (يُحدَّث عند التسجيل). */
const num = (v, lo, hi) => (typeof v === 'number' && isFinite(v)) ? Math.min(hi, Math.max(lo, v)) : 0;

/* ينظّف S.ms (حفظ تالف/يدوي) ← كائن سليم جديد */
export function normalizeMs(ms){
  const out = {};
  if(!ms || typeof ms !== 'object' || Array.isArray(ms)) return out;
  for(const id of Object.keys(ms)){
    const e = ms[id]; if(!e || typeof e !== 'object') continue;
    out[id] = {stars:Math.round(num(e.stars, 0, 3)), best:Math.round(num(e.best, 0, 1e9)),
      bt:Math.round(num(e.bt, 0, 1e6)), n:Math.round(num(e.n, 0, 1e6)), done:!!e.done};
  }
  return out;
}
/* يسجّل نتيجة محاولة (win=false تزيد المحاولات فقط). يرجع الإدخال الجديد */
export function record(ms, id, res){
  const p = ms[id] || {stars:0, best:0, bt:0, n:0, done:false};
  const e = {stars:p.stars, best:Math.max(p.best, res.quit ? 0 : res.score.total), bt:p.bt, n:p.n+1, done:p.done};
  if(res.win){
    e.done = true; e.stars = Math.max(p.stars, res.stars);
    e.bt = p.bt ? Math.min(p.bt, Math.round(res.t)) : Math.round(res.t);
  }
  ms[id] = e; return e;
}
const ids = defs => defs.map(d => d.id);
export function chain(ms, defs){
  let n = 0;
  for(const id of ids(defs)){ if(ms[id] && ms[id].done) n++; else break; }
  return n;
}
export const isUnlocked = (ms, defs, i) => i >= 0 && i < defs.length && i <= chain(ms, defs);
/* المهمة المقترحة: أول مفتوحة غير منجزة؛ وإن أُنجزت كلها فآخر مهمة */
export const nextIndex = (ms, defs) => Math.min(chain(ms, defs), defs.length-1);
export function summary(ms, defs){
  let done = 0, stars = 0, best = 0;
  for(const d of defs){ const e = ms[d.id]; if(!e) continue; if(e.done) done++; stars += e.stars; best += e.best; }
  return {done, total:defs.length, stars, maxStars:defs.length*3, best};
}
