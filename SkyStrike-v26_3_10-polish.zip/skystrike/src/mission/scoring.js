/* تقييم المهمة (دالة صرفة، بلا DOM/state): نجوم + نقاط + مكافأة. يستعملها game.js › finish وشاشة التقييم.
   النجوم (تتطلب نجاح المهمة):
     ★1 إنجاز كل الأهداف الرئيسية
     ★2 إنجاز الأهداف الثانوية كلها؛ وإن لم يكن للمهمة أهداف ثانوية: الإنجاز خلال الزمن المرجعي par (ثانية)
     ★3 طلعة نظيفة: لا خسائر صديقة ولا نيران صديقة وصحة الطائرة ≥ CLEAN_HP عند النهاية
   النقاط = نقاط القتال + مكافآت (نجاح، زمن، صحة) − عقوبة الخسائر الصديقة. أرقام التوازن بالأعلى. */
export const CLEAN_HP = .35;  // M12: أسهل قليلاً لـ★3
export const SCORE = {win:1200, perSecond:4, hp:600, allyLost:250};  // M12
export const REWARD = {repeat:.35, perStar:.22};  // M12: إعادة أقل قساوة      // نسبة مكافأة الإعادة · نسبة مكافأة كل نجمة جديدة

const countOpt = def => def.objectives.filter(o => o.optional).length;

/* run = {win, quit?, t, hpFrac, allyLost, ff, score, kj, kg, objectives:[{id,status,optional}]} */
export function evaluate(def, run){
  const win = !!run.win && !run.quit;
  const hasOpt = countOpt(def) > 0;
  const optDone = run.objectives.filter(o => o.optional).every(o => o.status === 'done');
  const clean = !run.allyLost && !run.ff && run.hpFrac >= CLEAN_HP;
  const second = hasOpt ? optDone : run.t <= (def.par || Infinity);
  const criteria = [
    {k:'win', ok:win},
    {k:hasOpt ? 'opt' : 'par', ok:win && second},
    {k:'clean', ok:win && clean}
  ];
  const stars = criteria.filter(c => c.ok).length;
  const sc = {combat:Math.max(0, Math.round(run.score)), win:0, time:0, hp:0, ally:0, total:0};
  if(win){
    sc.win = SCORE.win;
    sc.time = Math.max(0, Math.round(((def.par || 0)-run.t)*SCORE.perSecond));
    sc.hp = Math.round(Math.max(0, Math.min(1, run.hpFrac))*SCORE.hp);
  }
  sc.ally = -Math.min(sc.combat+sc.win+sc.time+sc.hp, (run.allyLost || 0)*SCORE.allyLost);
  sc.total = sc.combat+sc.win+sc.time+sc.hp+sc.ally;
  return {win, quit:!!run.quit, stars, criteria, score:sc, t:run.t};
}

/* مكافأة الإنهاء (فوق ما كسبه اللاعب بالقتال): أول نجاح = كاملة ؛ الإعادة = ربعها بلا جواهر ؛ كل نجمة جديدة تضيف عملات */
export function rewardFor(def, prev, res){
  const z = {c:0, g:0, xp:0, first:false, newStars:0};
  if(!res.win) return z;
  const r = def.reward || {c:0, g:0, xp:0}, p = prev || {};
  const first = !p.done, k = first ? 1 : REWARD.repeat;
  const ns = Math.max(0, res.stars-(p.stars | 0));
  return {c:Math.round(r.c*k)+ns*Math.round(r.c*REWARD.perStar), g:first ? r.g : 0,
    xp:Math.round(r.xp*k), first, newStars:ns};
}
