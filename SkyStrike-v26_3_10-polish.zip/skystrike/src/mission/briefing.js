/* بيانات شاشة الإحاطة (دالة صرفة): من تعريف المهمة ← أمر + خريطة + أهداف + تهديدات متوقعة + مكافأة + شروط النجوم.
   النصوص كلها مفاتيح i18n (mission_text.js)؛ الرسم HTML بـ menu_ms.js. */
const FOE_KINDS = ['tank', 'apc', 'truck', 'turret', 'flak', 'sam', 'depot', 'jet', 'ace', 'heli', 'drone', 'bomber'];

/* كل كيانات العدو: المبدئية + المستدعاة بالمحفّزات (تهديدات متوقعة) ← [{kind, n}] مرتبة بالعدد */
export function threatsOf(def){
  const all = [...def.entities];
  for(const tr of def.triggers || []) for(const a of tr.do || []) if(a.spawn) all.push(...a.spawn);
  const n = {};
  for(const e of all){
    if(e.side !== 'enemy' || !FOE_KINDS.includes(e.kind)) continue;
    n[e.kind] = (n[e.kind] || 0)+1;
  }
  return Object.keys(n).map(kind => ({kind, n:n[kind]})).sort((a, b) => b.n-a.n || (a.kind < b.kind ? -1 : 1));
}
export function briefOf(def){
  const hasOpt = def.objectives.some(o => o.optional);
  return {
    id:def.id, map:def.map, title:def.title, order:def.id+'b', desc:def.id+'d',
    objectives:def.objectives.map(o => ({id:o.id, text:o.text, optional:!!o.optional})),
    threats:threatsOf(def), reward:def.reward || {c:0, g:0, xp:0}, par:def.par || 0,
    starKeys:['win', hasOpt ? 'opt' : 'par', 'clean']
  };
}
