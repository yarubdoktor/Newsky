/* M11: مهمتان إضافيتان نوعيتان */
import {at, near, aa, sam, dep, FAIL} from './defs_kit.js';

const A = (id, kind, site, r, side = 'enemy') => ({id, kind, side, pos:at(site, r)});

export const EXTRA = [
  /* m12: ضربة ليلية على رتل إمداد */
  { id:'m12', map:'front_night', title:'m12t', intro:'m12i', difficulty:3,
    reward:{c:2600, g:22, xp:900}, par:640,
    entities:[
      {id:'cv', kind:'convoy', side:'enemy', units:['truck', 'truck', 'apc', 'truck'], gap:36, speed:9,
       pos:at('e_pass_w', 80),
       route:[at('e_pass_w', 100), at('t_ridge', 120, 0, -400), at('f_stage', 150)]},
      aa('aa1', 'cv', 180), aa('aa2', 'cv', 220, 'enemy', 1),
      sam('sam1', near('cv', 260)),
      A('j1', 'jet', 'e_pass_w', 350), A('j2', 'jet', 't_ridge', 400)
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m12o1', targets:['cv1', 'cv2', 'cv3', 'cv4'], need:3},
      {id:'o2', type:'suppress', text:'m12o2', targets:['aa1', 'aa2', 'sam1'], need:2},
      {id:'o3', type:'destroy', text:'m12o3', targets:['j1', 'j2'], need:1, optional:true},
      {id:'o4', type:'rtb', text:'m0o2', pos:at('alpha', 0), r:700, alt:300, after:['o1', 'o2']}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('e_pass_w'), r:2000}}, do:[{comm:'c2'}]},
      {id:'t2', when:{done:'o1'}, do:[{comm:'c3'}]},
      {id:'t3', when:{t:180}, do:[{spawn:[A('j3', 'heli', 't_ridge', 300)]}, {comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m12c1', at:2}, {id:'c2', from:'gnd', text:'m12c2'},
      {id:'c3', from:'cmd', text:'m12c3'}, {id:'c4', from:'ally', text:'m12c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1100}] },

  /* m13: اعتراض جوي بحت */
  { id:'m13', map:'highlands', title:'m13t', intro:'m13i', difficulty:4,
    reward:{c:3000, g:25, xp:1000}, par:580,
    entities:[
      A('j1', 'jet', 'h_peak', 280), A('j2', 'jet', 'h_peak', 320),
      A('j3', 'ace', 'h_ridge', 350), A('j4', 'jet', 'h_ridge', 400),
      A('h1', 'heli', 'h_valley', 200)
    ],
    objectives:[
      {id:'o1', type:'intercept', text:'m13o1', targets:['j1', 'j2', 'j3', 'j4'], need:3},
      {id:'o2', type:'destroy', text:'m13o2', targets:['h1'], optional:true},
      {id:'o3', type:'rtb', text:'m0o2', pos:at('h_strip', 0), r:700, alt:300, after:['o1']}
    ],
    triggers:[
      {id:'t1', when:{t:40}, do:[{spawn:[A('j5', 'jet', 'h_peak', 450), A('j6', 'ace', 'h_ridge', 500)]}, {comm:'c2'}]},
      {id:'t2', when:{done:'o1'}, do:[{comm:'c3'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m13c1', at:2}, {id:'c2', from:'cmd', text:'m13c2'},
      {id:'c3', from:'cmd', text:'m13c3'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}] }
];
