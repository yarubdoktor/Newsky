/* تعريفات المهمات كبيانات. الحقول:
   id · map · title/intro (مفاتيح i18n بـ mission_text.js) · difficulty (يحل مكان رقم الموجة: يضبط صحة/عدوانية الأعداء)
   entities[]: {id, kind, side, pos, obj?, tt?, alt?, route?[]}  kind: 'depot'|'turret'|'sam'|'flak'|'tank'|'apc'|
               'truck'|'jet'|'ace'|'heli'|'drone'|'bomber'|'convoy'  (route = نقاط مسار للمركبات)
               convoy: {units:[مركبات], gap?, speed?, route[]} ← معرّفات الأعضاء id+1..
   objectives[]: {id, type, text, optional?, after?[]} + حسب النوع (obj_types.js):
       destroy/suppress/intercept: targets[] (+ need? · limit?) · escort: units[] (+ need) · defend: sites[], t
       · rtb: pos, r?, alt?
   triggers[]: {id, when, do[]} (triggers.js) · comms[]: {id, from, text, at?, hold?} (comms.js) · fail[]:
   playerDead | timeout
   reward: {c, g, xp} مكافأة أول نجاح (الإعادة ربعها) · par: الزمن المرجعي بالثانية (نجمة ثانية إن لا أهداف ثانوية)
   الحملة (M6): 12 مهمة بثلاثة ملفات: defs_ch1.js (m0–m4) · defs_ch2.js (m5–m8) · defs_ch3.js (m9–m11)،
   ومواضعها بأسماء المواقع {site,r,dx?,dz?} (defs_kit.js). لإضافة مهمة: أضفها بملف فصل + نصوصها بـ text_ch*.js (title, intro, <id>d، الأهداف، الرسائل). */
import {validateMission} from './mission_check.js';
import {CH1} from './defs_ch1.js';
import {CH2} from './defs_ch2.js';
import {CH3} from './defs_ch3.js';
import {EXTRA} from './defs_extra.js';
export {validateMission};

export const MISSIONS = [...CH1, ...CH2, ...CH3, ...EXTRA];

export const missionById = id => MISSIONS.find(m => m.id === id) || null;
