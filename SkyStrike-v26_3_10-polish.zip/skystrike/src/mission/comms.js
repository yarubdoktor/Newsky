/* رسائل اللاسلكي (دالة صرفة): طابور مرتّب زمنياً بفاصل أدنى بين رسالتين حتى لا تتراكم على الشاشة.
   def.comms: [{id, from:'cmd'|'gnd'|'ally', text:مفتاح i18n, at?:ث (تلقائية بوقت المهمة), hold?:ث (مدة العرض)}]
   الرسالة بلا at تُطلَق فقط من محفّز {comm:id}. المخرج: {type:'comm', id, from, text, hold}. */
export const COMM_GAP = 3.2, COMM_HOLD = 6;
export const FROMS = ['cmd', 'gnd', 'ally'];

export function createComms(list){
  const defs = {}; (list || []).forEach(c => { defs[c.id] = c; });
  const timed = (list || []).filter(c => c.at !== undefined).sort((a, b) => a.at-b.at).map(c => c.id);
  return {defs, timed, q:[], cool:0};
}
export const queueComm = (cs, id) => { if(cs.defs[id] && !cs.q.includes(id)) cs.q.push(id); };

/* يضيف المستحق زمنياً ويطلق رسالة واحدة على الأكثر عند انتهاء فاصل التبريد */
export function stepComms(cs, t, dt){
  while(cs.timed.length && cs.defs[cs.timed[0]].at <= t) queueComm(cs, cs.timed.shift());
  cs.cool -= dt; if(cs.cool > 0 || !cs.q.length) return null;
  const c = cs.defs[cs.q.shift()], hold = c.hold ?? COMM_HOLD; cs.cool = Math.max(COMM_GAP, hold*.6);
  return {type:'comm', id:c.id, from:c.from, text:c.text, hold};
}

/* تقسيم نص الإحاطة «المرسل: المتن» (مثل «وزارة الدفاع ← الطيار: دمّر…») ← {head, body}. بلا مرسل واضح يرجع head فارغاً */
export function splitBrief(s){
  s = String(s ?? ''); const i = s.indexOf(':');
  if(i < 2 || i > 34) return {head:'', body:s.trim()};
  return {head:s.slice(0, i).trim(), body:s.slice(i+1).trim()};
}
