/* الفصل الثاني «خط الدفاع الجوي والمرتفعات» (m5–m8): m5 على front، m6–m8 على highlands */
import {at, near, aa, sam, dep, air, FAIL} from './defs_kit.js';

const STRIP = at('h_strip', 0);

export const CH2 = [
  { id:'m5', map:'front', title:'m5t', intro:'m5i', difficulty:3,
    reward:{c:1500, g:12, xp:520}, par:560,
    entities:[
      sam('sam1', at('s1', 60)), sam('sam2', at('s2', 60)), sam('sam3', at('s3', 60)),
      sam('sam4', at('s4', 60)), sam('sam5', at('s5', 60)),
      aa('aa1', 'sam2', 110), aa('aa2', 'sam3', 110, 'enemy', 1), aa('aa3', 'sam4', 110, 'enemy', 2),
      dep('fuel', at('e_depot', 40), 2), aa('aa4', 'fuel', 120, 'enemy', 1)
    ],
    objectives:[
      {id:'o1', type:'suppress', text:'m5o1', targets:['sam1', 'sam2', 'sam3', 'sam4', 'sam5'], need:4},
      {id:'o2', type:'destroy', text:'m5o2', targets:['fuel']},
      {id:'o3', type:'rtb', text:'m0o2', pos:at('alpha', 0), r:700, alt:300, after:['o2']},
      {id:'o4', type:'destroy', text:'m5o4', targets:['j1', 'j2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('s3'), r:3000}}, do:[{comm:'c2'}]},
      {id:'t2', when:{done:'o1'}, do:[{comm:'c3'}]},
      {id:'t3', when:{t:90}, do:[{spawn:[air('j1', 'jet', 1500, -4200), air('j2', 'jet', 2200, -4000)]}, {comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m5c1', at:2}, {id:'c2', from:'gnd', text:'m5c2'},
      {id:'c3', from:'cmd', text:'m5c3'}, {id:'c4', from:'gnd', text:'m5c4'}
    ],
    fail:FAIL },

  { id:'m6', map:'highlands', title:'m6t', intro:'m6i', difficulty:3,
    reward:{c:1700, g:14, xp:580}, par:560,
    entities:[
      dep('rad', at('h_radar', 40), 1), dep('fuel', at('h_fuel', 40), 2),
      sam('sam1', near('rad', 140)), sam('sam2', at('h_sam1', 60)), sam('sam3', at('h_sam2', 60)),
      aa('aa1', 'rad', 100), aa('aa2', 'fuel', 100, 'enemy', 1), aa('aa3', 'fuel', 130, 'enemy', 2)
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m6o1', targets:['rad']},
      {id:'o2', type:'destroy', text:'m6o2', targets:['fuel']},
      {id:'o3', type:'suppress', text:'m6o3', targets:['sam1', 'sam2', 'sam3'], need:2, optional:true},
      {id:'o4', type:'rtb', text:'m6o4', pos:STRIP, r:600, alt:260, after:['o1', 'o2']},
      {id:'o5', type:'destroy', text:'m6o5', targets:['rh1', 'rh2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('h_radar'), r:2400}}, do:[{comm:'c2'}]},
      {id:'t2', when:{dead:'rad'}, do:[{spawn:[
        {id:'rh1', kind:'heli', side:'enemy', pos:at('h_cmd', 200)}, {id:'rh2', kind:'heli', side:'enemy',
          pos:at('h_cmd', 300)}]},
        {comm:'c3'}]},
      {id:'t3', when:{done:'o2'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m6c1', at:2}, {id:'c2', from:'gnd', text:'m6c2'},
      {id:'c3', from:'gnd', text:'m6c3'}, {id:'c4', from:'cmd', text:'m6c4'}
    ],
    fail:FAIL },

  { id:'m7', map:'highlands', title:'m7t', intro:'m7i', difficulty:3,
    reward:{c:1900, g:16, xp:620}, par:480,
    entities:[
      dep('post', at('h_outpost', 40), 3, 'ally', false),
      aa('g1', 'post', 90, 'ally'), aa('g2', 'post', 110, 'ally', 1), sam('s1', near('post', 120), 'ally')
    ],
    objectives:[
      {id:'o1', type:'defend', text:'m7o1', sites:['post'], t:190},
      {id:'o2', type:'intercept', text:'m7o2', targets:['b1', 'b2'], limit:240},
      {id:'o3', type:'destroy', text:'m7o3', targets:['rh1', 'rh2', 'rh3'], need:2, optional:true}
    ],
    triggers:[
      {id:'t1', when:{t:20}, do:[{spawn:[air('j1', 'jet', -1800, -2500), air('j2', 'jet', -1200, -2700)]},
        {comm:'c2'}]},
      {id:'t2', when:{t:60}, do:[{spawn:[
        {id:'rh1', kind:'heli', side:'enemy', pos:at('h_radar2', 200)}, {id:'rh2', kind:'heli', side:'enemy',
          pos:at('h_radar2', 260)},
        {id:'rh3', kind:'heli', side:'enemy', pos:at('h_cmd', 200)}]}, {comm:'c3'}]},
      {id:'t3', when:{t:110}, do:[{spawn:[air('b1', 'bomber', -2200, -3000), air('b2', 'bomber', -1600, -3200)]},
        {comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m7c1', at:2}, {id:'c2', from:'ally', text:'m7c2'},
      {id:'c3', from:'gnd', text:'m7c3'}, {id:'c4', from:'cmd', text:'m7c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1000}] },

  { id:'m8', map:'highlands', title:'m8t', intro:'m8i', difficulty:3,
    reward:{c:2100, g:18, xp:720}, par:650,
    entities:[
      {id:'cv', kind:'convoy', side:'ally', units:['tank', 'apc', 'truck', 'truck'], gap:34, speed:14,
       pos:at('h_town1', 60), route:[at('h_amb1', 100), at('h_amb2', 100), at('h_amb3', 100)]},
      {id:'et1', kind:'tank', side:'enemy', pos:at('h_amb1', 120, 80, 0)}, {id:'et2', kind:'tank', side:'enemy',
        pos:near('et1', 120)},
      {id:'et3', kind:'tank', side:'enemy', pos:at('h_amb2', 120, -80, 0)}, {id:'et4', kind:'tank', side:'enemy',
        pos:at('h_amb3', 120)},
      aa('aa1', 'et3', 200), sam('sam1', at('h_sam1', 60)), sam('sam2', at('h_sam2', 60))
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m8o1', targets:['et1', 'et2', 'et3', 'et4'], need:3},
      {id:'o2', type:'suppress', text:'m8o2', targets:['aa1', 'sam1', 'sam2'], need:2},
      {id:'o3', type:'escort', text:'m8o3', units:['cv1', 'cv2', 'cv3', 'cv4'], need:3},
      {id:'o4', type:'rtb', text:'m6o4', pos:STRIP, r:600, alt:260, after:['o1', 'o2', 'o3']},
      {id:'o5', type:'destroy', text:'m8o5', targets:['rh1'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('h_amb1'), r:2000}}, do:[{comm:'c2'}]},
      {id:'t2', when:{arrived:'cv1'}, do:[{comm:'c4'}]},
      {id:'t3', when:{dead:'et3'}, do:[{spawn:[{id:'rh1', kind:'heli', side:'enemy', pos:at('h_goal', 200)}]},
        {comm:'c3'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m8c1', at:2}, {id:'c2', from:'gnd', text:'m8c2'},
      {id:'c3', from:'cmd', text:'m8c3'}, {id:'c4', from:'ally', text:'m8c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1400}] }
];
