/* الفصل الثالث «الحسم» (m9–m11): ليل الجبهة، خليج الجزر، ثم «الفجر» الختامية */
import {at, near, aa, sam, dep, air, FAIL} from './defs_kit.js';

const A = (id, kind, site, r) => ({id, kind, side:'enemy', pos:at(site, r)});

export const CH3 = [
  { id:'m9', map:'front_night', title:'m9t', intro:'m9i', difficulty:3,
    reward:{c:2400, g:20, xp:820}, par:620,
    entities:[
      dep('cmd', at('e_cmd', 40), 3), dep('fuel', at('e_fuel', 40), 2),
      aa('aa1', 'cmd', 100, 'enemy', 2), aa('aa2', 'cmd', 120, 'enemy', 1), sam('sam1', near('cmd', 160)),
      aa('aa3', 'fuel', 100, 'enemy', 1), {id:'fl1', kind:'flak', side:'enemy', pos:near('fuel', 120)}
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m9o1', targets:['cmd']},
      {id:'o2', type:'destroy', text:'m9o2', targets:['fuel']},
      {id:'o3', type:'rtb', text:'m0o2', pos:at('alpha', 0), r:700, alt:300, after:['o1', 'o2']},
      {id:'o4', type:'destroy', text:'m9o4', targets:['j1', 'j2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('e_cmd'), r:3000}}, do:[{comm:'c2'}]},
      {id:'t2', when:{zone:{pos:at('e_cmd'), r:1500}}, do:[{spawn:[A('j1', 'jet', 'bravo', 300), A('j2', 'jet',
        'bravo', 400)]},
        {comm:'c3'}]},
      {id:'t3', when:{done:'o1'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m9c1', at:2}, {id:'c2', from:'gnd', text:'m9c2'},
      {id:'c3', from:'gnd', text:'m9c3'}, {id:'c4', from:'cmd', text:'m9c4'}
    ],
    fail:FAIL },

  { id:'m10', map:'gulf', title:'m10t', intro:'m10i', difficulty:4,
    reward:{c:2800, g:24, xp:950}, par:680,
    entities:[
      dep('f1', at('g_fort1', 40)), dep('f2', at('g_fort2', 40)),
      aa('k1', 'f1', 90), {id:'k2', kind:'flak', side:'enemy', pos:near('f2', 90)},
      sam('ss1', near('f1', 120)), sam('ss2', near('f2', 120)),
      dep('port', at('g_port', 50), 2), aa('p1', 'port', 110, 'enemy', 1),
      {id:'p2', kind:'flak', side:'enemy', pos:near('port', 130)},
      dep('rad', at('g_radar', 40), 1), sam('rs1', near('rad', 130)),
      dep('isle', at('g_isle', 40), 0, 'ally', false)
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m10o1', targets:['f1', 'f2']},
      {id:'o2', type:'destroy', text:'m10o2', targets:['port', 'rad']},
      {id:'o3', type:'intercept', text:'m10o3', targets:['b1', 'b2'], limit:300},
      {id:'o4', type:'defend', text:'m10o5', sites:['isle'], t:240},
      {id:'o5', type:'rtb', text:'m10o4', pos:at('g_alpha', 0), r:700, alt:300, after:['o1', 'o2', 'o3', 'o4']}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('g_fort1'), r:2500}}, do:[{comm:'c2'}]},
      {id:'t2', when:{t:100}, do:[{spawn:[A('b1', 'bomber', 'g_bravo', 400), A('b2', 'bomber', 'g_bravo', 500)]},
        {comm:'c3'}]},
      {id:'t3', when:{done:'o3'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m10c1', at:2}, {id:'c2', from:'gnd', text:'m10c2'},
      {id:'c3', from:'ally', text:'m10c3'}, {id:'c4', from:'cmd', text:'m10c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1300}] },

  { id:'m11', map:'front', title:'m11t', intro:'m11i', difficulty:4,
    reward:{c:3500, g:35, xp:1200}, par:850,
    entities:[
      sam('sam1', at('s1', 60)), sam('sam2', at('s2', 60)), sam('sam3', at('s3', 60)),
      aa('aa1', 'sam1', 110), aa('aa2', 'sam2', 110, 'enemy', 1), aa('aa3', 'sam3', 110, 'enemy', 2),
      A('as1', 'tank', 'e_assy', 140), A('as2', 'tank', 'e_assy', 160), A('as3', 'apc', 'e_assy', 180)
    ],
    objectives:[
      {id:'o1', type:'suppress', text:'m11o1', targets:['sam1', 'sam2', 'sam3'], need:2},
      {id:'o2', type:'destroy', text:'m11o2', targets:['br', 'bf', 'bc'], need:3},
      {id:'o3', type:'destroy', text:'m11o3', targets:['a1', 'a2', 'a3'], need:2},
      {id:'o4', type:'destroy', text:'m11o4', targets:['as1', 'as2', 'as3'], need:2, optional:true},
      {id:'o5', type:'rtb', text:'m0o2', pos:at('alpha', 0), r:700, alt:300, after:['o2', 'o3']}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('s3'), r:3200}}, do:[{comm:'c2'}]},
      {id:'t2', when:{done:'o1'}, do:[{spawn:[
        dep('br', at('bravo', 40, -420, 150), 1), dep('bf', at('bravo', 40, 0, 150), 2), dep('bc', at('bravo', 40,
          420, 150), 3),
        aa('ba1', 'bf', 120, 'enemy', 1), aa('ba2', 'bc', 120), sam('bs1', near('br', 150)),
        A('a1', 'ace', 'bravo', 300), A('a2', 'ace', 'bravo', 400), A('a3', 'ace', 'bravo', 500)]}, {comm:'c3'}]},
      {id:'t3', when:{done:'o2'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m11c1', at:2}, {id:'c2', from:'gnd', text:'m11c2'},
      {id:'c3', from:'cmd', text:'m11c3'}, {id:'c4', from:'cmd', text:'m11c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1500}] }
];
