/* M11: طلب إسناد جوي (CAS) — صرف منطقياً، التنفيذ من mission_bridge/game */
export const CAS_CD = 45;      // ثوانٍ بين طلبين
export const CAS_RANGE = 2200; // مدى أقصى من اللاعب

export function canCall(G, now){
  if(!G || G.dead) return false;
  if((G.casCd || 0) > 0) return false;
  return true;
}
/* يختار حتى 3 أهداف معادية أرضية قريبة من اللاعب */
export function pickCasTargets(units, playerPos, max = 3){
  const list = [];
  for(const e of units){
    if(!e || e.hp <= 0) continue;
    if(e.side !== 'enemy') continue;
    if(!e.ground && e.kind !== 'depot' && e.kind !== 'sam' && e.kind !== 'flak') continue;
    const d = e.g.position.distanceTo(playerPos);
    if(d > CAS_RANGE) continue;
    list.push({e, d});
  }
  list.sort((a, b) => a.d - b.d);
  return list.slice(0, max).map(x => x.e);
}
