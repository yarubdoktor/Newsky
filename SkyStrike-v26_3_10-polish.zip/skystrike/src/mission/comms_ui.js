/* عرض رسائل اللاسلكي والإحاطة على الـHUD (DOM): بطاقة صغيرة بإطار مخصّص لكل رسالة (حتى 2 بالتزامن).
   كل بطاقة: شارة المرسل + اسمه + إشارة «لاسلكي» + المتن (يظهر كلمة كلمة) + شريط توجيه حي (سهم نحو الهدف،
   الاتجاه، المسافة، يمينك/يسارك) + شريط زمن العرض. النص من i18n (t). الإحاطة الافتتاحية تمرّ من نفس البطاقة. */
import {$} from '../util.js';
import {t} from '../i18n.js';
import {splitBrief} from './comms.js';
import {nearestPoint, relBearing, cardinalIdx, fmtDist} from './mission_hud.js';

const MAX = 2, NS = 'http://www.w3.org/2000/svg';
const CARD = ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'];
/* أيقونات المرسل (مسارات خطية 24×24) — لا تعتمد على إيموجي الجهاز */
const ICON = {
  cmd:'M12 10m-2 0a2 2 0 1 0 4 0a2 2 0 1 0-4 0M7.6 5.6a6.2 6.2 0 0 0 0 8.8M16.4 5.6a6.2 6.2 0 0 1 0 8.8M12 12v8M8 20h8',
  gnd:'M7 15m-4 0a4 4 0 1 0 8 0a4 4 0 1 0-8 0M17 15m-4 0a4 4 0 1 0 8 0a4 4 0 1 0-8 0M7 11V4h3v7M17 11V4h-3v7M11 15h2',
  ally:'M12 3l7 3v5c0 5-3 8-7 10c-4-2-7-5-7-10V6zM9 12l2 2l4-4',
  mod:'M12 3l2.6 5.6l6 .8l-4.4 4.2l1.1 6L12 16.7L6.7 19.6l1.1-6L3.4 9.4l6-.8z'
};
let box = null;
const host = () => box || (box = $('#comm'));

const svg = (d, cls) => {
  const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 24 24'); if(cls) s.setAttribute('class', cls);
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); s.appendChild(p); return s;
};
const el = (tag, cls, txt) => { const e = document.createElement(tag); if(cls) e.className = cls; if(txt !== undefined) e.textContent = txt; return e; };

/* المتن كلمات متتابعة الظهور (animation-delay) — بلا مؤقتات JS ولا كسر لوصل الحروف العربية */
function bodyOf(text){
  const b = el('div', 'cb'), words = String(text).split(/\s+/).filter(Boolean), step = Math.min(70, 1100/Math.max(1, words.length));
  words.forEach((w, i) => { const s = el('span', '', w); s.style.animationDelay = Math.round(i*step)+'ms'; b.appendChild(s); b.appendChild(document.createTextNode(' ')); });
  return b;
}
function card({who, name, tag, text, hold, guide}){
  const h = host(); if(!h) return null;
  const d = el('div', 'cc cc-'+who); d.style.setProperty('--hold', hold+'s');
  const top = el('div', 'ch'), badge = el('span', 'cg'); badge.appendChild(svg(ICON[who] || ICON.cmd));
  const nm = el('span', 'cn', name), sig = el('span', 'cs'); for(let i = 0; i < 4; i++) sig.appendChild(el('i'));
  const tg = el('span', 'ct', tag);
  top.append(badge, nm, tg, sig); d.appendChild(top); d.appendChild(bodyOf(text));
  if(guide){
    const g = el('div', 'cv'); g.hidden = true; const a = svg('M12 3l6 15l-6-3.2L6 18z', 'ca');
    const c1 = el('span', 'cd'), c2 = el('span', 'cd cx'), c3 = el('span', 'cd');
    g.append(a, el('span', 'cl', t('cm_nav')), c1, el('span', 'cz', '·'), c2, el('span', 'cz', '·'), c3);
    d.appendChild(g); d._g = {root:g, arrow:a, c1, c2, c3};
  }
  d.appendChild(el('div', 'cp'));
  h.appendChild(d); while(h.children.length > MAX) h.removeChild(h.firstChild);
  setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 600); }, hold*1000);
  return d;
}
/* رسالة لاسلكي من from = cmd|gnd|ally. التوجيه الحي للقيادة والمراقب فقط (رسائل الرتل إخبارية) */
export function showComm(from, textKey, hold = 6){
  return card({who:from, name:t('c_'+from), tag:t('cm_radio'), text:t(textKey), hold, guide:from !== 'ally'});
}
/* إحاطة افتتاحية «المرسل: المتن» + اسم العملية */
export function showBrief(text, title, hold = 8){
  const {head, body} = splitBrief(text);
  return card({who:'mod', name:head || t('c_mod'), tag:title || t('cm_brief'), text:body, hold, guide:true});
}
export function clearComms(){ const h = host(); if(h) h.textContent = ''; }

/* تحديث التوجيه الحي (يُنادى من HUD كل ~0.09ث): rt = حالة المهمة، snap = لقطة العالم، yaw = اتجاه الطائرة */
export function commUpdate(rt, snap, yaw){
  const h = host(); if(!h || !h.firstChild) return;
  const n = rt && snap ? nearestPoint(rt, snap) : null;
  for(const c of h.children){
    const g = c._g; if(!g) continue;
    if(!n){ g.root.hidden = true; continue; }
    const dx = n.x-snap.px, dz = n.z-snap.pz, rel = relBearing(dx, dz, yaw), a = Math.abs(rel);
    const side = a < .52 ? 'cm_ahead' : a > 2.62 ? 'cm_back' : rel > 0 ? 'cm_right' : 'cm_left';
    g.root.hidden = false; g.arrow.style.transform = 'rotate('+rel.toFixed(3)+'rad)';
    g.c1.textContent = t('cm_'+CARD[cardinalIdx(dx, dz)]); g.c2.textContent = fmtDist(n.dist); g.c3.textContent = t(side);
  }
}
