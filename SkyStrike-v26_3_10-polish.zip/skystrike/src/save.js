import {migrate, MV} from './save_migrate.js';
const KEY = 'skystrike_v2', OLD = 'skystrike_v1';
const def = () => ({ v:2, coins:300, xp:0, sel:'mig29', pl:{mig29:1}, gun:1, msl:1, multi:0, bomb:0,
  name:'Pilot'+(100+Math.random()*900|0),
  scores:[], gems:0, sk:{}, sko:{}, lg:{last:'',st:0}, st:{n:0,c:0}, ms:{}, mv:MV,
  sens:1, fm:1, invY:0, cam:0, cp:0, tut:0, snd:1, mus:1, rad:1, vib:1, load:{aa:'msl',ag:'bomb',wing:0,diff:1}, tilt:0, tiltInv:0, assist:1, fps:0, q:'auto',
  lang:(navigator.language||'ar').toLowerCase().startsWith('ar') ? 'ar' : 'en', map:'island' });
function load(){
  let s = null;
  try { s = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e){}
  if(!s){ try { s = JSON.parse(localStorage.getItem(OLD) || 'null'); } catch(e){} }
  return Object.assign(def(), s ? migrate(s) : {});
}
export const S = load();
export const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch(e){} };
