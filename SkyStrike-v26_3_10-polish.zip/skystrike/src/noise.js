/* ضجيج Perlin ثنائي الأبعاد + fbm (دوال صرفة، بلا three/DOM فتُختبر بـ node). نُقلت من maps.js بـ M5. */
export function mkNoise(seed){
  const p = new Uint8Array(512), a = Array.from({length:256},(_,i)=>i); let s = (seed|0) || 1;
  for(let i=255;i>0;i--){ s = (Math.imul(s,1664525)+1013904223)>>>0; const j = s%(i+1); [a[i],a[j]] = [a[j],a[i]]; }
  for(let i=0;i<512;i++) p[i] = a[i&255];
  const fade = t => t*t*t*(t*(t*6-15)+10), lerp = (a,b,t) => a+(b-a)*t;
  const grad = (h,x,y) => { switch(h&7){
    case 0:return x+y;case 1:return -x+y;case 2:return x-y;case 3:return -x-y;
    case 4:return x;case 5:return -x;case 6:return y;default:return -y;} };
  return (x,y) => {
    const fx = Math.floor(x), fy = Math.floor(y), X = fx&255, Y = fy&255; x -= fx; y -= fy;
    const u = fade(x), v = fade(y), A = p[X]+Y, B = p[X+1]+Y;
    return lerp(lerp(grad(p[A],x,y),grad(p[B],x-1,y),u), lerp(grad(p[A+1],x,y-1),grad(p[B+1],x-1,y-1),u), v);
  };
}
export const fbm = (n,x,y,o) => { let a = 1, f = 1, s = 0, m = 0;
  for(let i=0;i<o;i++){ s += n(x*f+i*17.3,y*f-i*9.1)*a; m += a; a *= .5; f *= 2; } return s/m; };

