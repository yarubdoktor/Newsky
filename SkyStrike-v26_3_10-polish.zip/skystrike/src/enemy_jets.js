/* مقاتلات الجو (M8): الجهة المعادية تطير بـ F-35 (GLB) وF-16 وF-15 (مجسمات برمجية)،
   والحليفة بـ MiG-29 وSu-57 (نفس طائرات اللاعب). pickJetModel دالة صرفة قابلة للاختبار بلا three.
   كل المحاور كبقية الطائرات: الأنف نحو -Z، الذيل +Z، الجناح على x. */
import * as THREE from 'three';
import {hasEM,mkEM} from './emodels.js';
import {mkJet,geo,mkm,stdm,basic,planform,holder,flames} from './jets.js';

import {pickJetModel} from './jet_pick.js';
const DARK = () => stdm(0x1b2027,.3,.6);
const GLASS = () => mkm('glass',() => new THREE.MeshStandardMaterial({color:0x0b1824,emissive:0x1d4a78,emissiveIntensity:.7,metalness:.95,roughness:.1}));
const lathe = (k,pts) => geo(k,() => new THREE.LatheGeometry(pts.map(a => new THREE.Vector2(a[0],a[1])),18).rotateX(-Math.PI/2));
const box = (k,w,h,l) => geo(k,() => new THREE.BoxGeometry(w,h,l));

/* F-16: محرك واحد، مدخل هواء تحت البطن، ذيل عمودي واحد، جناح دلتا مقصوص */
function mkF16(color){
  const g = holder(), m = stdm(color,.55,.4);
  g.add_(lathe('f16_fus',[[0,-7],[.5,-7],[.85,-5.6],[1.05,-3],[1.15,0],[1.05,3.2],[.8,5.6],[.4,6.8],[0,7.2]]),m);
  const W = geo('f16_w',() => planform([[.9,-2.6],[4.6,2.4],[4.6,3.5],[.9,4.4]],.14)), T = geo('f16_t',() => planform([[.8,4.4],[3.2,6],[3.2,6.8],[.8,6.8]],.1));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    g.add_(geo('f16_rail',() => new THREE.CylinderGeometry(.14,.14,3,6).rotateX(Math.PI/2)),stdm(0xdde3ea,.3,.5),s*4.75,0,2.1);
    g.add_(geo('nav',() => new THREE.SphereGeometry(.14,6,4)),basic(s<0?0xff2222:0x22ff66),s*4.6,0,3.2);
  }
  g.add_(box('f16_fin',.12,2.7,2.3),m,0,1.9,5.1,.1,0,0);
  g.add_(box('f16_in',1.5,.9,2.6),DARK(),0,-.95,-2.4);
  g.add_(geo('can',() => new THREE.SphereGeometry(.85,12,10)),GLASS(),0,.85,-2.7).scale.set(.7,.65,2.3);
  g.userData.fl = flames(g,[0],6.9,false,.85);
  return g;
}
/* F-15: محرّكان، مدخلا هواء جانبيان، ذيلان عموديان مائلان للخارج، جناح كبير شبه منحرف */
function mkF15(color){
  const g = holder(), m = stdm(color,.55,.4);
  g.add_(lathe('f15_fus',[[0,-7],[.7,-7],[1.2,-5.8],[1.45,-3],[1.5,0],[1.4,3.4],[1.1,5.6],[.6,6.9],[0,7.8]]),m).scale.set(1.15,.8,1);
  const W = geo('f15_w',() => planform([[1.3,-2.4],[6.2,1.8],[6.2,2.8],[1.3,4.7]],.16)), T = geo('f15_t',() => planform([[1.2,4.4],[4,5.9],[4,6.7],[1.2,6.9]],.1));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    g.add_(box('f15_fin',.14,3.3,2.4),m,s*1.9,2,4.5,0,0,-s*.22);
    g.add_(box('f15_in',1.1,1.3,3.4),DARK(),s*1.7,-.1,-2.3);
    g.add_(geo('nav',() => new THREE.SphereGeometry(.14,6,4)),basic(s<0?0xff2222:0x22ff66),s*6.2,0,2.8);
  }
  g.add_(geo('can',() => new THREE.SphereGeometry(.85,12,10)),GLASS(),0,.95,-3.3).scale.set(.8,.7,2.4);
  g.userData.fl = flames(g,[-1,1],7.1,false,.85);
  return g;
}
/* F-35 عدو: نفس GLB اللاعب القديم لكن مصبوغ (أحمر/ذهبي) ومحرك واحد */
function mkF35(color){
  const g = holder(); g.add(mkEM('f35',color,.6)); g.userData.fl = flames(g,[0],6.7,false,.9,false,.07,0); return g;
}
const MK = {f16:mkF16, f15:mkF15, f35:mkF35};
export const hasF35 = () => hasEM('f35');
// side 'enemy' ← F-16/F-15/F-35 ، side 'ally' ← MiG-29/Su-57 خضراء. تُرجع المجسم مع اسم النموذج بـ userData.model
export function mkAirJet(side, color, elite = false, r = Math.random()){
  if(side === 'ally'){ const k = r < .5 ? 1 : 2, g = mkJet(k,color,true,color); g.userData.model = k === 1 ? 'mig29' : 'su57'; return g; }
  const model = pickJetModel(r, elite, hasF35()), g = MK[model](color); g.userData.model = model; return g;
}
