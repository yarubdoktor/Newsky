/* الذكاء الاصطناعي للأعداء: دالة سلوك لكل نوع في الجدول AI. أرقام التوازن كلها بـ enemies.js.
   نوع عدو جديد = مجسم بـ jets.js + أرقام بـ enemies.js + دالة هنا (AI.اسمه) + سطر بـ spawn.js.
   v26.3.2 (M1): كل وحدة تختار هدفها (e.tgt) من أقرب معادٍ لجهتها: اللاعب أو أي وحدة (mission/target_pick.js).
   كل دالة تستلم (e, dt, c): c = {pos: موقع الهدف, w: الصعوبة, alive: الهدف حي, dist: المسافة للهدف, ep: موقع الوحدة,
   tf: اتجاه الهدف الأمامي, ts: سرعته, tv: متجه سرعته}. اسم enemies بالملف قديم: يشمل كل الجهات. */
import {clamp,wrap,rnd} from './util.js';
import {JET,ACE,BOMBER,HELI,DRONE,FLAK,TURRET,SAM,AGGR,ACTIVE_CAP} from './enemies.js';
import {sfx} from './audio.js';
import {world,fx,V,vib,dirOfTo} from './core.js';
import {W,P,FW} from './state.js';
import {shoot,hurt,boom,removeEnemy,kill} from './combat.js';
import {farBoost} from './gscale.js';
import {jetThink,maxAttackers} from './ai_jet.js';
import {groundThink,maxCrew} from './ai_ground.js';
import {pickTarget,fallbackTarget,TARGET} from './mission/target_pick.js';
import {sideOf} from './mission/factions.js';
import {pushEvent} from './mission/mission_runtime.js';
import {markActive} from './mission/friendly_ai.js';
import {vehicleThink,vehicleLite} from './mission/vehicle_ai.js';

const _a = V(), _b = V(), _c = V(), _d = V(), _to = V();   // _to = اتجاه واحد من الوحدة نحو هدفها (قبل استدعاء سلوكها)
const rr = ([a,b]) => rnd(a,b);
const JC = {};   // سياق مشترك لعقل المقاتلة (يُعاد استعماله بدون إنشاء كائن بالفريم)
/* كل طلقات الذكاء تمر من هنا: تضيف جهة الوحدة (owner: 'e' للمعادي للاعب، 'a' للحليف) والهدف للصواريخ الموجّهة */
function fire(e,o){
  const s = sideOf(e); o.owner = s === 'ally' ? 'a' : 'e'; o.side = s;
  if(o.mis) o.target = e.tgt === P ? null : e.tgt;
  shoot(o);
}
/* ضرر مباشر على هدف الوحدة (تصادم المسيّرة...) */
function hitTarget(e,d){
  const T = e.tgt; if(T === P){ hurt(d); return; }
  T.hp -= d; if(T.hp <= 0) kill(T,sideOf(e));
}

function steer(o,ty,tp,rate,dt){
  const dy = wrap(ty-o.yaw); o.yaw += clamp(dy,-rate*dt,rate*dt); o.pitch += clamp(tp-o.pitch,-rate*dt,rate*dt);
  o.g.rotation.set(o.pitch,o.yaw,clamp(-dy*1.2,-1.1,1.1)*.6); return dy;
}
const GJ = {};   // سياق مشترك لعقل الأرضيات
function ground(e,dt,{pos,w,alive,dist,ep,tv}){     // v26.2.6: العقل بـ ai_ground.js؛ هنا تدوير البرج (تدريجي) + الرمي فقط
  const k = e.kind, G = W.G, m = k === 'sam', D = m ? SAM.msl : k === 'flak' ? FLAK.gun : TURRET.gun;
  let crew = 0; for(const o of W.units) if(o !== e && o.ground && o.side === e.side && (o.gst === 'wrn' || o.gst === 'fir')) crew++;
  Object.assign(GJ,{px:pos.x,py:pos.y,pz:pos.z,vx:tv.x,vy:tv.y,vz:tv.z,ex:ep.x,ey:ep.y+e.muz,ez:ep.z,
    dist,alive,canFire:!m || pos.y > world.ground(pos.x,pos.z)+D.minAlt,rmin:D.min||0,rmax:m ? D.max : D.range,
    gunSp:D.speed,spread:D.spread||0,ag:Math.min(1,AGGR.base+w*AGGR.w),w,crew,maxCrew:maxCrew(w),since:(G.t||0)-(G.gStart ?? -9)});
  const o = groundThink(e,GJ,dt,Math.random);
  if(o.moved) e.g.userData.aim.lookAt(ep.x+o.dx*1e3,ep.y+e.muz+o.dy*1e3,ep.z+o.dz*1e3);
  if(o.start){ G.gStart = G.t; if(dist < 1000 && G.t-(G.gwT ?? -9) > .9){ sfx('warn'); G.gwT = G.t; } }    // تحذير صوتي (البصري: لاحقاً)
  if(!o.shots) return;
  _c.copy(ep); _c.y += e.muz;
  if(m){ _b.set(o.dx,o.dy,o.dz); fire(e,{pos:_c,dir:_b,speed:D.speed,dmg:D.dmg+w*D.dmgw,mis:true,turn:D.turn,life:D.life}); }
  else for(let i = 0, n = k === 'flak' ? D.burst : 1; i < n; i++){
    _b.set(o.dx+rnd(-o.spread,o.spread),o.dy+rnd(-o.spread,o.spread),o.dz+rnd(-o.spread,o.spread)).normalize();
    fire(e,{pos:_c,dir:_b,speed:D.speed,dmg:D.dmg+w*D.dmgw}); }
}

const AI = {
  jet(e,dt,{pos,w,alive,dist,ep,tf,ts,tv}){                 // v26.2.5 (بند #9): العقل بـ ai_jet.js (آلة حالات)؛ هنا فقط التنفيذ: توجيه + حركة + رمي
    const D = e.elite ? ACE : JET, gun = D.gun, msl = D.msl;
    let atk = 0; for(const o of W.units) if(o !== e && o.kind === 'jet' && o.bst === 'atk' && o.tgt === e.tgt) atk++;          // المهاجمون الآخرون (حدّ التزامن)
    Object.assign(JC,{px:pos.x,py:pos.y,pz:pos.z,vx:tv.x,vy:tv.y,vz:tv.z,fx:tf.x,fy:tf.y,fz:tf.z,sp:ts,dist,alive,gh:world.ground(ep.x,ep.z)+60,atk,maxAtk:maxAttackers(w),dodge:D.dodge,gunSp:gun.speed});
    const o = jetThink(e,JC,dt,Math.random,ep);
    const dy = steer(e,o.ty,o.tp,e.tn*o.tnMul,dt); ep.addScaledVector(dirOfTo(e.g,_d),Math.min(e.sp*o.spMul,o.cap)*dt);
    if(alive && o.fire){
      if(dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = (gun.cd-e.ag*gun.cdAg)*gun.cdMul; fire(e,{pos:ep,dir:_d,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
      else if(w >= msl.from && e.mcd <= 0 && dist > msl.min && dist < msl.max && Math.abs(dy) < msl.aim){ e.mcd = rr(msl.cd)*(1.3-e.ag*.5);
        for(let k=0;k<msl.n;k++){ _b.copy(ep); if(k) _b.x += 7; fire(e,{pos:_b,dir:_d,speed:msl.speed,dmg:msl.dmg+w*msl.dmgw,mis:true,turn:msl.turn,life:msl.life}); } }
    }
  },
  bomber(e,dt,{pos,w,alive,dist,ep}){
    const gun = BOMBER.gun;
    _a.set(pos.x-ep.x,0,pos.z-ep.z); const ty = Math.atan2(-_a.x,-_a.z);
    steer(e,ty,clamp((e.alt-ep.y)*.012,-.3,.3),e.tn,dt); ep.addScaledVector(dirOfTo(e.g,_d),e.sp*dt);
    if(alive && dist < gun.range && e.cd <= 0){ e.cd = gun.cd; fire(e,{pos:ep,dir:_to,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
  },
  heli(e,dt,{pos,w,alive,dist,ep}){
    const gun = HELI.gun;
    e.g.userData.rotor.rotation.y += dt*30;
    const r2 = e.g.userData.rotor2; if(r2) r2.rotation.x += dt*40;                // مروحة الذيل (نموذج GLB)
    const dy = steer(e,Math.atan2(-_to.x,-_to.z),0,e.tn,dt); dirOfTo(e.g,_d); _d.y = 0; _d.normalize();
    if(dist > HELI.far) ep.addScaledVector(_d,e.sp*dt); else if(dist < HELI.near) ep.addScaledVector(_d,-e.sp*.6*dt);
    ep.x += -_d.z*e.sd*e.sp*.3*dt; ep.z += _d.x*e.sd*e.sp*.3*dt;
    const wantY = Math.max(world.ground(ep.x,ep.z)+50,pos.y-30); ep.y += clamp(wantY-ep.y,-35,35)*dt;
    if(alive && dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = gun.cd;
      for(let k=-1;k<=1;k++){ _b.copy(_to); _b.x += k*gun.spread; fire(e,{pos:ep,dir:_b,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); } }
  },
  drone(e,dt,{w,alive,dist,ep}){          // مسيّرة انتحارية: تلاحقك وتصطدم، ورشقة خفيفة من بعيد
    const gun = DRONE.gun;
    const dy = steer(e,Math.atan2(-_to.x,-_to.z),Math.asin(clamp(_to.y,-.8,.8)),e.tn,dt); ep.addScaledVector(dirOfTo(e.g,_d),e.sp*dt);
    const gh = world.ground(ep.x,ep.z)+25; if(ep.y < gh) ep.y = gh;
    if(alive && dist < DRONE.ramDist){ hitTarget(e,DRONE.ram+w); boom(ep,12); vib(40); removeEnemy(e); }
    else if(alive && dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = gun.cd; fire(e,{pos:ep,dir:_d,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
  },
  flak:ground, turret:ground, sam:ground         // v26.2.6 (بند #9): عقل الأرضيات بـ ai_ground.js
};

const ctx = {pos:null,w:0,alive:true,dist:0,ep:null,tf:V(),ts:0,tv:V()};   // سياق مشترك يُعاد استعماله (بلا كائن جديد بالفريم)
/* ما تحتاجه المركبات من المحرك (vehicle_ai.js لا يستورد three/state ليُختبر بـ node) */
const VX = {world, units:W.units, V, w:0, fire,
  event:id => { const ms = W.G.ms; if(ms) pushEvent(ms,{type:'entityArrived',id}); }};
const IDLE = {jet:1,ace:1,heli:1,drone:1,bomber:1};
/* وحدة جوية بلا هدف: تطير للأمام بدوران خفيف (دوريّة) وتحافظ على ارتفاعها. الأرضيات تنتظر */
function idle(e,dt,ep){
  if(!IDLE[e.kind]) return;
  steer(e,e.yaw+.25*(e.sd||1),0,.25,dt); ep.addScaledVector(dirOfTo(e.g,_d),e.sp*.5*dt);
  const gh = world.ground(ep.x,ep.z)+90; if(ep.y < gh) ep.y += 40*dt;
}
/* هدف الوحدة: إعادة اختيار كل ~0.5ث (موزّعة عشوائياً)، واللاعب هو البديل عند عدم وجود أقرب */
function retarget(e,dt){
  if(e.unarmed){ e.tgt = null; return; }                     // شاحنة: بلا سلاح ولا استهداف
  e.tcd = (e.tcd ?? 0)-dt;
  if(e.tcd > 0 && e.tgt && (e.tgt === P ? !W.G.dead : W.units.includes(e.tgt))) return;
  e.tcd = rr(TARGET.recheck);
  e.tgt = pickTarget(e,W.units,P,{playerDead:W.G.dead}) || fallbackTarget(e,P,W.G.dead);
}
export function enemiesUpdate(dt){
  const G = W.G, units = W.units;
  ctx.w = G.diff; VX.w = G.diff;
  G.actT = (G.actT||0)-dt; if(G.actT <= 0){ G.actT = .5; markActive(units,P.g.position,ACTIVE_CAP); }   // سقف الأداء
  for(let ei=units.length-1;ei>=0;ei--){
    const e = units[ei], ep = e.g.position;
    if(e.lite){ e.lp = null; if(e.drv) vehicleLite(e,dt,VX); continue; }     // خارج سقف الأداء: حركة فقط
    e.cd -= dt; e.mcd -= dt;
    if(e.lp){ e.vel.copy(ep).sub(e.lp).divideScalar(Math.max(dt,.001)); e.lp.copy(ep); }
    else { e.vel = V(); e.lp = ep.clone(); }
    if(e.hp < e.max*.5 && Math.random() < dt*14) fx.smk(ep.x,ep.y+(e.air?0:6),ep.z,0x222222,e.r*.35,e.r,1.4,0,8,0,.7);
    if(e.ground && e.g.userData.gk){            // تعزيز المسافة (v26.2.4): حسب بُعده عن اللاعب (الكاميرا) لا عن هدفه
      const b = farBoost(ep.distanceTo(P.g.position));
      if(Math.abs(b-e.boost) > .01){ e.boost = b; e.g.scale.setScalar(b); e.r = e.r0*b; } }
    retarget(e,dt); const T = e.tgt;
    if(!T){ if(e.drv) vehicleThink(e,dt,null,VX); else idle(e,dt,ep); continue; }
    const tp = T.g.position; _to.copy(tp).sub(ep); const dist = _to.length() || 1; _to.divideScalar(dist);
    if(T === P){ ctx.tv.copy(FW).multiplyScalar(P.cur); ctx.tf.copy(FW); ctx.ts = P.cur; }
    else {
      ctx.tv.copy(T.vel || _a.set(0,0,0)); ctx.ts = ctx.tv.length();
      if(ctx.ts > 1) ctx.tf.copy(ctx.tv).divideScalar(ctx.ts); else ctx.tf.set(0,0,-1);
    }
    ctx.pos = tp; ctx.alive = T === P ? !G.dead : true;
    ctx.dist = dist; ctx.ep = ep;
    if(e.drv){ vehicleThink(e,dt,ctx,VX); continue; }
    const ai = AI[e.kind]; if(ai) ai(e,dt,ctx);
  }
}
