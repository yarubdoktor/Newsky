/* M10 AAA — نظام صوت عسكري احترافي (Web Audio إجرائي بالكامل)
   باصات: master ← sfx / music / radio
   طبقات: محرك متعدد · أسلحة · انفجارات متعددة الطبقات · لاسلكي واقعي · أجواء · إنذار صاروخ */
let ac, master, sfxBus, musBus, radBus;
let eng = [], engF, engG, engNoise, engNoiseG, engAB, engABG; // طبقات المحرك
let windG, windSrc;
let nb, muted = false, musOn = true, radOn = true;
let musNode = null, musTimer = 0, nextT = 0, step = 0, intensity = 0;
let ambOn = false, ambNodes = [];
let lastIncoming = 0;

export function setMute(m){ muted = !!m; applyMix(); }
export function setMusic(on){ musOn = !!on; if(!on) stopMusic(); applyMix(); }
export function setRadio(on){ radOn = !!on; applyMix(); }
function applyMix(){
  if(!master) return;
  master.gain.value = muted ? 0 : 0.62;
  if(sfxBus) sfxBus.gain.value = 1;
  if(musBus) musBus.gain.value = musOn ? 1 : 0;
  if(radBus) radBus.gain.value = radOn ? 1 : 0;
}

export function initAudio(){
  if(ac){ try{ ac.resume(); }catch(e){} return; }
  const C = window.AudioContext || window.webkitAudioContext; if(!C) return;
  ac = new C();
  master = ac.createGain(); master.gain.value = muted ? 0 : 0.62; master.connect(ac.destination);
  sfxBus = ac.createGain(); sfxBus.connect(master);
  musBus = ac.createGain(); musBus.gain.value = musOn ? 1 : 0; musBus.connect(master);
  radBus = ac.createGain(); radBus.gain.value = radOn ? 1 : 0; radBus.connect(master);

  // ضجيج أبيض مشترك
  nb = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate);
  const d = nb.getChannelData(0);
  for(let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

  // ---- محرك متعدد الطبقات (أساسي + توافقي + ضجيج + afterburner)
  engG = ac.createGain(); engG.gain.value = 0; engG.connect(sfxBus);
  engF = ac.createBiquadFilter(); engF.type = 'lowpass'; engF.frequency.value = 400; engF.Q.value = 0.7;
  engF.connect(engG);

  for(let i = 0; i < 3; i++){
    const o = ac.createOscillator();
    o.type = i === 0 ? 'sawtooth' : (i === 1 ? 'sawtooth' : 'triangle');
    o.frequency.value = 55 * (i + 1);
    const g = ac.createGain(); g.gain.value = i === 0 ? 1 : (i === 1 ? 0.35 : 0.15);
    o.connect(g); g.connect(engF); o.start();
    eng.push({o, g});
  }

  // ضجيج المحرك (توربين)
  const ns = ac.createBufferSource(); ns.buffer = nb; ns.loop = true;
  const nf = ac.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 600; nf.Q.value = 0.8;
  engNoiseG = ac.createGain(); engNoiseG.gain.value = 0;
  ns.connect(nf); nf.connect(engNoiseG); engNoiseG.connect(sfxBus); ns.start();
  engNoise = {s: ns, f: nf};

  // afterburner: ضجيج عالي + نغمة
  engAB = ac.createOscillator(); engAB.type = 'sawtooth'; engAB.frequency.value = 90;
  const abf = ac.createBiquadFilter(); abf.type = 'highpass'; abf.frequency.value = 800;
  engABG = ac.createGain(); engABG.gain.value = 0;
  engAB.connect(abf); abf.connect(engABG); engABG.connect(sfxBus); engAB.start();

  // ريح المقصورة (تتغير مع السرعة)
  const ws = ac.createBufferSource(); ws.buffer = nb; ws.loop = true;
  const wf = ac.createBiquadFilter(); wf.type = 'bandpass'; wf.frequency.value = 400; wf.Q.value = 0.5;
  windG = ac.createGain(); windG.gain.value = 0;
  ws.connect(wf); wf.connect(windG); windG.connect(sfxBus); ws.start();
  windSrc = {s: ws, f: wf};
}

export function suspendAudio(s){ if(!ac) return; try{ s ? ac.suspend() : ac.resume(); }catch(e){} }

/* ملفات تعريف المحرك لكل طائرة */
const EP = {
  0: {base: 48, span: 28, ab: 40, cut: 260, cutAb: 500, noise: 1.0,  gain: 0.11, det: 4,  gp: 1.0},
  1: {base: 70, span: 42, ab: 58, cut: 340, cutAb: 820, noise: 1.3,  gain: 0.105, det: 18, gp: 1.25}, // MiG-29
  2: {base: 54, span: 34, ab: 52, cut: 280, cutAb: 620, noise: 1.15, gain: 0.09,  det: 28, gp: 0.9}  // Su-57
};
let ep = EP[0], gp = 1;

export function setEngineKind(k){
  ep = EP[k] || EP[0]; gp = ep.gp;
  if(!ac || !eng.length) return;
  eng[1].o.detune.value = ep.det;
  eng[2].o.detune.value = -ep.det * 0.6;
}

/** r = نسبة السرعة 0..1+ ، b = boost 0..1 */
export function setEngine(r, b = 0){
  if(!ac || !engG) return;
  const t = ac.currentTime;
  if(r <= 0.02){
    engG.gain.setTargetAtTime(0, t, 0.12);
    engNoiseG.gain.setTargetAtTime(0, t, 0.12);
    engABG.gain.setTargetAtTime(0, t, 0.1);
    if(windG) windG.gain.setTargetAtTime(0, t, 0.15);
    return;
  }
  const f0 = ep.base + r * ep.span + b * ep.ab;
  eng[0].o.frequency.setTargetAtTime(f0, t, 0.12);
  eng[1].o.frequency.setTargetAtTime(f0 * 2.01, t, 0.12);
  eng[2].o.frequency.setTargetAtTime(f0 * 3.02, t, 0.14);
  engF.frequency.setTargetAtTime(ep.cut + b * (ep.cutAb - ep.cut) + r * 80, t, 0.18);

  const body = (ep.gain + b * 0.05) * (0.55 + r * 0.45);
  engG.gain.setTargetAtTime(body, t, 0.12);
  engNoiseG.gain.setTargetAtTime((0.03 + r * 0.04 + b * 0.08) * ep.noise, t, 0.15);
  engNoise.f.frequency.setTargetAtTime(450 + r * 400 + b * 500, t, 0.2);

  // afterburner
  engAB.frequency.setTargetAtTime(80 + b * 60, t, 0.1);
  engABG.gain.setTargetAtTime(b * 0.07, t, 0.1);

  // ريح
  if(windG){
    windG.gain.setTargetAtTime(0.008 + r * 0.025 + b * 0.01, t, 0.2);
    windSrc.f.frequency.setTargetAtTime(300 + r * 500, t, 0.25);
  }
}

/* ---------- أدوات توليف ---------- */
function panNode(bus, pan){
  const dest = bus || sfxBus;
  if(pan == null || !ac.createStereoPanner) return dest;
  const p = ac.createStereoPanner();
  p.pan.value = Math.max(-1, Math.min(1, pan));
  p.connect(dest); return p;
}

function noiseBurst(dur, f0, f1, type, vol, q, delay, pan, bus){
  if(!ac) return;
  const t = ac.currentTime + (delay || 0);
  const s = ac.createBufferSource(); s.buffer = nb;
  const f = ac.createBiquadFilter(); f.type = type || 'lowpass'; f.Q.value = q || 1;
  f.frequency.setValueAtTime(Math.max(30, f0), t);
  f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
  const g = ac.createGain();
  g.gain.setValueAtTime(Math.max(0.0001, vol), t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(panNode(bus, pan));
  s.start(t, Math.random() * 0.4, dur + 0.08);
}

function oscTone(f0, f1, dur, type, vol, delay, pan, bus){
  if(!ac) return;
  const t = ac.currentTime + (delay || 0);
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = type || 'sine';
  o.frequency.setValueAtTime(Math.max(20, f0), t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(Math.max(0.0001, vol), t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(panNode(bus, pan));
  o.start(t); o.stop(t + dur + 0.03);
}

/* لاسلكي عسكري: فتح قناة + تشويش + نغمات حاملة */
function playRadio(){
  if(!ac || !radOn) return;
  const t = ac.currentTime;
  // squelch open
  noiseBurst(0.08, 4000, 1200, 'bandpass', 0.09, 1.2, 0, null, radBus);
  // carrier hiss
  noiseBurst(0.45, 2200, 1600, 'bandpass', 0.07, 0.6, 0.05, null, radBus);
  // beeps (نمط لاسلكي)
  oscTone(1800, 1800, 0.045, 'square', 0.055, 0.1, null, radBus);
  oscTone(1400, 1400, 0.05, 'square', 0.05, 0.18, null, radBus);
  oscTone(1600, 1200, 0.06, 'square', 0.04, 0.28, null, radBus);
  // formant-ish "voice" blur
  noiseBurst(0.25, 900, 700, 'bandpass', 0.04, 2.5, 0.12, null, radBus);
  noiseBurst(0.2, 1400, 1100, 'bandpass', 0.035, 2, 0.22, null, radBus);
}

/** إنذار صاروخ مقترب — يتصاعد مع التكرار */
function playIncoming(urgency, pan){
  if(!ac) return;
  const now = ac.currentTime;
  if(now - lastIncoming < 0.35) return;
  lastIncoming = now;
  const u = Math.max(0.3, Math.min(1, urgency || 0.7));
  const base = 650 + u * 400;
  oscTone(base, base * 1.8, 0.35 + u * 0.2, 'sawtooth', 0.09 * u, 0, pan);
  oscTone(base * 1.3, base * 2.2, 0.3 + u * 0.15, 'triangle', 0.05 * u, 0.04, pan);
  noiseBurst(0.25, 3500, 900, 'bandpass', 0.06 * u, 1.5, 0, pan);
  if(u > 0.7) oscTone(1100, 1100, 0.07, 'square', 0.08, 0.15, pan);
}

/* انفجار متعدد الطبقات (AAA) */
function playBoom(v, big, pan){
  const V = Math.max(0.15, Math.min(1.2, v || 1));
  // sub-bass
  oscTone(big ? 55 : 80, 18, big ? 1.4 : 0.9, 'sine', 0.7 * V, 0, pan);
  // body
  noiseBurst(big ? 1.5 : 1.0, big ? 700 : 1100, 40, 'lowpass', 0.85 * V, 0.6, 0, pan);
  // mid crack
  noiseBurst(0.35, 2500, 400, 'bandpass', 0.35 * V, 0.9, 0.02, pan);
  // high shatter
  if(big){
    noiseBurst(0.45, 5000, 800, 'highpass', 0.22 * V, 0.7, 0.04, pan);
    oscTone(120, 40, 0.8, 'triangle', 0.25 * V, 0.05, pan);
    // dirt/debris tail
    noiseBurst(1.2, 600, 80, 'lowpass', 0.2 * V, 0.5, 0.15, pan);
  }
}

export function sfx(k, v = 1, big = false, pan){
  if(!ac || muted) return;
  const V = Math.max(0, Math.min(1.5, v));
  switch(k){
    case 'gun':
      noiseBurst(0.05, 4200 * gp, 900 * gp, 'bandpass', 0.18, 1.6);
      oscTone(280 * gp, 60 * gp, 0.04, 'square', 0.06);
      noiseBurst(0.03, 8000, 3000, 'highpass', 0.06, 1);
      break;
    case 'efire':
      noiseBurst(0.06, 2400, 500, 'bandpass', 0.1 * V, 1.1, 0, pan);
      break;
    case 'msl':
      noiseBurst(0.7, 300, 2600, 'lowpass', 0.3);
      oscTone(90, 260, 0.5, 'sawtooth', 0.1);
      oscTone(500, 2000, 0.45, 'triangle', 0.045, 0.06);
      noiseBurst(0.35, 4000, 1200, 'highpass', 0.08, 1, 0.1);
      break;
    case 'emsl':
      noiseBurst(0.55, 400, 2000, 'lowpass', 0.2 * V, 1, 0, pan);
      oscTone(110, 300, 0.35, 'sawtooth', 0.06 * V, 0, pan);
      break;
    case 'boom':
      playBoom(V, big, pan);
      break;
    case 'bgboom':
      oscTone(50, 22, 0.7, 'sine', 0.12 * V, 0, pan);
      noiseBurst(0.8, 350, 50, 'lowpass', 0.14 * V, 0.5, 0, pan);
      break;
    case 'hit':
      noiseBurst(0.14, 1600, 150, 'lowpass', 0.45);
      oscTone(200, 50, 0.12, 'square', 0.12);
      noiseBurst(0.08, 4000, 1000, 'highpass', 0.1);
      break;
    case 'lock':
      oscTone(1500, 1500, 0.055, 'sine', 0.12);
      oscTone(1500, 1500, 0.055, 'sine', 0.12, 0.1);
      oscTone(900, 900, 0.04, 'triangle', 0.04, 0.2);
      break;
    case 'radio':
      playRadio();
      break;
    case 'warn':
      oscTone(880, 640, 0.14, 'square', 0.085);
      break;
    case 'alarm':
      oscTone(1200, 1200, 0.07, 'square', 0.11);
      oscTone(1200, 1200, 0.07, 'square', 0.11, 0.12);
      oscTone(900, 900, 0.07, 'square', 0.07, 0.24);
      break;
    case 'incoming':
      playIncoming(V, pan);
      break;
    case 'flare':
      noiseBurst(0.5, 8000, 2000, 'highpass', 0.16);
      oscTone(2200, 800, 0.2, 'triangle', 0.05);
      noiseBurst(0.3, 5000, 1500, 'bandpass', 0.08, 1.2, 0.05);
      break;
    case 'wave':
      oscTone(520, 520, 0.1, 'triangle', 0.16);
      oscTone(660, 660, 0.1, 'triangle', 0.16, 0.11);
      oscTone(880, 880, 0.2, 'triangle', 0.16, 0.22);
      break;
    case 'win':
      for(let i = 0; i < 6; i++)
        oscTone(523 * Math.pow(1.25, i), 523 * Math.pow(1.25, i), 0.18, 'triangle', 0.14, i * 0.11);
      break;
    case 'ui':
      oscTone(880, 1200, 0.06, 'sine', 0.06);
      break;
  }
}

/* ---- أجواء ساحة المعركة (طبقة بعيدة مستمرة) ---- */
export function setAmbience(on){
  if(!ac) return;
  if(on && !ambOn){
    ambOn = true;
    const g = ac.createGain(); g.gain.value = 0; g.connect(sfxBus);
    const s = ac.createBufferSource(); s.buffer = nb; s.loop = true;
    const f1 = ac.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.value = 220;
    const f2 = ac.createBiquadFilter(); f2.type = 'bandpass'; f2.frequency.value = 90; f2.Q.value = 0.4;
    s.connect(f1); f1.connect(f2); f2.connect(g); s.start();
    g.gain.setTargetAtTime(0.028, ac.currentTime, 1.2);
    ambNodes = [{s, g}];
  } else if(!on && ambOn){
    ambOn = false;
    for(const n of ambNodes){
      try{ n.g.gain.setTargetAtTime(0, ac.currentTime, 0.6); }catch(e){}
    }
    setTimeout(() => {
      for(const n of ambNodes){
        try{ n.s.stop(); }catch(e){}
        try{ n.g.disconnect(); }catch(e){}
      }
      ambNodes = [];
    }, 900);
  }
}

/* ---- موسيقى توليدية عسكرية أكثر توتراً ---- */
const ROOTS = [45, 45, 41, 43, 38, 41];
const ARP = [0, 7, 12, 7, 15, 12, 10, 3];
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

function mOsc(f, t, d, type, v, cut){
  const o = ac.createOscillator(), g = ac.createGain(), fl = ac.createBiquadFilter();
  o.type = type; o.frequency.value = f;
  fl.type = 'lowpass'; fl.frequency.value = cut;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(v, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(fl); fl.connect(g); g.connect(musNode);
  o.start(t); o.stop(t + d + 0.05);
}
function mKick(t){
  const o = ac.createOscillator(), g = ac.createGain();
  o.frequency.setValueAtTime(150, t);
  o.frequency.exponentialRampToValueAtTime(38, t + 0.14);
  g.gain.setValueAtTime(0.6, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
  o.connect(g); g.connect(musNode); o.start(t); o.stop(t + 0.22);
}
function mHat(t, v){
  const s = ac.createBufferSource(); s.buffer = nb;
  const f = ac.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000;
  const g = ac.createGain();
  g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
  s.connect(f); f.connect(g); g.connect(musNode);
  s.start(t, Math.random() * 0.5, 0.05);
}
function sched(){
  if(!ac || !musNode || muted || !musOn) return;
  const bpm = 88 + intensity * 40;
  const st = 60 / bpm / 2;
  while(nextT < ac.currentTime + 0.45){
    const bar = (step >> 4) % ROOTS.length;
    const s = step & 15;
    const root = ROOTS[bar];
    // باص
    if(s % 2 === 0) mOsc(mtof(root), nextT, st * 1.7, 'sawtooth', 0.42, 300 + intensity * 450);
    // أكورد
    if(s === 0){
      for(const iv of [0, 7, 12]) mOsc(mtof(root + 12 + iv), nextT, st * 12, 'sawtooth', 0.07, 850);
      if(intensity > 0.35) mOsc(mtof(root + 19), nextT, st * 8, 'triangle', 0.05, 1400);
    }
    // أربيجيو
    if(intensity > 0.2)
      mOsc(mtof(root + 24 + ARP[s % 8]), nextT, st * 0.85, 'triangle', 0.12 * (0.35 + intensity), 1600 + intensity * 1800);
    // إيقاع
    if(s % 4 === 0 && intensity > 0.04) mKick(nextT);
    if(intensity > 0.15 && s % 2 === 1) mHat(nextT, 0.07 * intensity + 0.02);
    if(intensity > 0.55 && s === 8) mKick(nextT);
    nextT += st; step++;
  }
}

export function startMusic(){
  if(!ac || !musOn || musTimer) return;
  musNode = ac.createGain(); musNode.gain.value = 0.17; musNode.connect(musBus);
  nextT = ac.currentTime + 0.08; step = 0;
  musTimer = setInterval(sched, 100);
}
export function stopMusic(){
  if(musTimer){ clearInterval(musTimer); musTimer = 0; }
  if(musNode){
    const g = musNode;
    try{ g.gain.setTargetAtTime(0, ac.currentTime, 0.3); }catch(e){}
    setTimeout(() => { try{ g.disconnect(); }catch(e){} }, 1600);
    musNode = null;
  }
}
export function setIntensity(x){ intensity = Math.max(0, Math.min(1, x)); }
