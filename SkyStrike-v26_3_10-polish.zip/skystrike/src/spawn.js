/* إنشاء الوحدات الجوية والأرضية (يستدعيها mission/entities.js). الأرقام كلها من enemies.js.
   w = رقم الصعوبة (من difficulty بتعريف المهمة). */
import {rnd} from './util.js';
import {HP_SCALE,AGGR,MCD0,JET,ACE,BOMBER,HELI,DRONE,FLAK,TURRET,SAM,DEPOT} from './enemies.js';
import {groundRadius,groundMuzzle} from './gscale.js';
import {mkAirJet} from './enemy_jets.js';
import {mkBomber,mkHeli,mkDrone,mkGround,mkDepot} from './jets.js';
import {scene,world} from './core.js';
import {W,P} from './state.js';

const JETC = [0xa03030,0x7a2a2a,0x5a2a40], ALLYC = [0x2f7a4a,0x3a6a52,0x2a5a3a];   // ألوان الطائرات: عدو أحمر · حليف أخضر
const rr = ([a,b]) => rnd(a,b);
const DV = [1, .8, .9, 1.3];            // مضاعف صحة المستودع حسب النوع: ذخيرة · رادار · وقود · قيادة

export function addAir(kind,pos,w,side = 'enemy'){
  const elite = kind === 'ace'; if(elite) kind = 'jet';
  const f = 1+w*HP_SCALE; let g, hp, r, pts, sp, tn;
  if(kind === 'jet'){ const D = elite ? ACE : JET;
    g = mkAirJet(side,elite ? 0xd4af37 : (side === 'ally' ? ALLYC : JETC)[rnd(0,3)|0],elite); hp = D.hp*f; r = D.r; pts = D.pts;
    sp = Math.min(D.spMax,D.sp+w*D.spw); tn = Math.min(D.tnMax,D.tn+w*D.tnw); if(elite) g.scale.setScalar(D.scale); }
  else if(kind === 'bomber'){ g = mkBomber(); hp = BOMBER.hp*f; r = BOMBER.r; pts = BOMBER.pts; sp = BOMBER.sp; tn = BOMBER.tn; }
  else if(kind === 'heli'){ g = mkHeli(); hp = HELI.hp*f; r = HELI.r; pts = HELI.pts; sp = HELI.sp; tn = HELI.tn; }
  else { g = mkDrone(); hp = DRONE.hp*f; r = DRONE.r; pts = DRONE.pts; sp = DRONE.sp+w*DRONE.spw; tn = DRONE.tn; }
  const e = {kind,g,hp,max:hp,r,pts,sp,tn,cd:rnd(1,3),mcd:elite ? rr(ACE.mcd0) : rr(MCD0),st:0,state:0,sd:Math.random()<.5?-1:1,pitch:0,air:true,alt:pos.y,jk:0,fl:kind === 'jet' ? (elite ? ACE.fl : JET.fl) : 0,ag:Math.min(1,AGGR.base+w*AGGR.w),elite};
  e.yaw = Math.atan2(-(P.g.position.x-pos.x),-(P.g.position.z-pos.z)); g.rotation.order = 'YXZ'; g.position.copy(pos); scene.add(g); e.side = side; W.units.push(e); return e;
}
export function addGround(kind,x,z,h,w,tt,side = 'enemy'){
  let g, hp, r, pts;
  if(kind === 'depot'){ g = mkDepot(tt | 0, side); hp = (DEPOT.hp+w*DEPOT.hpw)*(DV[tt | 0] || 1); r = DEPOT.r; pts = DEPOT.pts; }
  else if(kind === 'sam'){ g = mkGround(3, side); hp = SAM.hp+w*SAM.hpw; r = SAM.r; pts = SAM.pts; }
  else if(kind === 'flak'){ g = mkGround(4, side); hp = FLAK.hp+w*FLAK.hpw; r = FLAK.r; pts = FLAK.pts; }
  else { g = mkGround(tt%3, side); hp = TURRET.hp+w*TURRET.hpw; r = TURRET.r; pts = TURRET.pts; }
  const gk = g.userData.gk; if(gk){ r = groundRadius(gk); }                // v26.2.4: نصف قطر التصادم من حجم النموذج الفعلي (إن كان GLB)
  g.position.set(x,h,z); scene.add(g);
  const e = {kind,g,hp,max:hp,r,r0:r,boost:1,muz:gk ? groundMuzzle(gk) : (kind === 'sam' ? 8 : 6),pts,cd:rnd(1,3),mcd:0,ground:true,air:false,side}; W.units.push(e); return e;
}
export function landPos(cx,cz,rad,tries=80){
  const minH = world.hasWater() ? world.cfg.water.level+5 : -1e9;
  for(let i=0;i<tries;i++){ const x = cx+rnd(-rad,rad), z = cz+rnd(-rad,rad), h = world.H(x,z);
    if(h < minH) continue; if(Math.hypot(world.H(x+8,z)-h,world.H(x,z+8)-h) > 5) continue;
    if(world.cfg.hit && world.cfg.hit(x,h+3,z)) continue;      // لا تضع مدفعاً/صاروخاً داخل مبنى أو هنغر أو تحت جسر
    return {x,z,h}; }
  return null;
}
