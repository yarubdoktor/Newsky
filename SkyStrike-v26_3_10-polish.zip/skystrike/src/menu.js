import {$,clamp,esc} from './util.js';
import {S,save} from './save.js';
import {MISSIONS} from './mission/mission_defs.js';
import {nextIndex,isUnlocked,summary} from './mission/progress.js';
import {createMsViews} from './menu_ms.js';
import {lvReward,PLANES,level,stats,rankKey,MAXL,upCost,wCost,WPN,loginInfo,claimLogin,SKINS,skinOf,skinOwned,useSkin,buySkin,avgCoins} from './data.js';
import {t,setLang,getLang} from './i18n.js';
import {setMute,setMusic,setRadio} from './audio.js';
import LOGO from './assets/logo-horizontal.webp';
import {ART,planeArt} from './art.js';

/* ---------- أيقونات (Material Icons، Apache-2.0) ---------- */
const ICON = {
  home:'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
  plane:'M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z',
  rocket:'M12 2c2 3 3 6 3 9v6l2 3h-3l-2 3-2-3H7l2-3v-6c0-3 1-6 3-9zm0 6a1.5 1.5 0 100 3 1.5 1.5 0 000-3z',
  gear:'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
  clip:'M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z',
  mail:'M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z',
  users:'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
  map:'M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z',
  trophy:'M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z',
  plus:'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  x:'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  shield:'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z',
  bolt:'M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66L13 3h1l-1 7h3.5c.49 0 .56.33.47.51L11 21z',
  monitor:'M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7v2H8v2h8v-2h-2v-2h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H3V4h18v12z',
  vol:'M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02z',
  pad:'M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v3H6v-3H3v-2h3V8h2v3h3v2zm4.5 2c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4-3c-.83 0-1.5-.67-1.5-1.5S18.67 9 19.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z',
  target:'M12 8a4 4 0 100 8 4 4 0 000-8zm0-6C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z'
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICON[n]}"/></svg>`;
const avatar = (l,pct,cls='') => { const img = ART.ui && ART.ui.avatar;
  return `<div class="av ${cls} ${rankKey(l)}" style="--p:${pct}"><div class="avi">${img?`<img src="${img}" alt="">`:'<span>🧑‍✈️</span>'}</div><em class="lvb">${l}</em></div>`; };
const rb = (l,c='') => { const im = ART.ui && ART.ui['rank_'+rankKey(l)]; return im ? `<img class="rb ${c}" src="${im}" alt="">` : ''; };
const plain = s => s.replace(/^[^\p{L}\p{N}]+/u,'').replace(/\s*\(.*\)\s*$/,'');
const bar = (v,m) => `<i class="sb"><b style="width:${Math.min(100,v/m*100)}%"></b></i>`;
const NAV = [['lobby','home','nLobby'],['hangar','plane','nPlanes'],['weapons','rocket','nWeapons'],['settings','gear','nSettings'],['ops','clip','nMissions']];
const TITLES = {profile:'profileT',hangar:'hangarT',weapons:'weaponsT',ops:'opsT',brief:'briefT',debrief:'debT',record:'recT',
  skins:'skinsT',settings:'tSet'};
const ALIAS = {planes:'lobby',wpn:'weapons',set:'settings',campaign:'ops',missions:'ops',mis:'ops',setup:'ops',
  ranking:'record',top:'record'};

export function createMenu(api){
  let screen = 'lobby', shown = '', msg = '', mapsBusy = false, sel = 0, dbf = null;
  const M = {};
  const wd = {
    gun:l => t('wd_gun',{d:7+3*l}),
    msl:l => t('wd_msl',{d:55+28*l,n:5+l*2}),
    bvr:l => t('wd_bvr',{d:75+32*l,n:2+l}),
    multi:l => t('wd_multi',{d:35+16*l,n:2+l}),
    bomb:l => t('wd_bomb',{d:100+45*l,n:5+2*l}),
    agm:l => t('wd_agm',{d:120+50*l,n:3+l}),
    arm:l => t('wd_arm',{d:110+45*l,n:2+l})
  };
  const claimable = () => (loginInfo().can ? 1 : 0);
  const nextLv = l => 60*l*l, baseLv = l => 60*(l-1)*(l-1);

  /* ---------- أجزاء اللوبي ---------- */
  const topBar = l => {
    const lo = baseLv(l), hi = nextLv(l), pct = clamp((S.xp-lo)/(hi-lo)*100,0,100);
    return `<div class="lb-top">
      <div class="lb-prof ${rankKey(l)}" role="button" tabindex="0" data-a="scr" data-i="profile">${avatar(l,pct)}<div class="lb-pi"><b class="tx">${esc(S.name)}</b><span class="rkchip">${rb(l)}${t(rankKey(l))}</span><i class="xpb"><b style="width:${pct}%"></b></i><small>${S.xp} / ${hi} ${t('xp')}</small></div></div>
      <div class="lb-cur">
        <div class="cur"><span class="ci">🪙</span><b>${S.coins}</b><button data-a="scr" data-i="ops" aria-label="+">${ic('plus')}</button></div>
        <div class="cur"><span class="ci">💎</span><b>${S.gems|0}</b><button data-a="scr" data-i="ops" aria-label="+">${ic('plus')}</button></div>
      </div>
      <div class="lb-ico"><button data-a="soon" aria-label="${t('soon')}">${ic('mail')}</button><button data-a="soon" aria-label="${t('soon')}">${ic('users')}</button><button data-a="scr" data-i="settings" aria-label="${t('nSettings')}">${ic('gear')}</button></div>
    </div>`;
  };
  const nav = () => `<nav class="lb-nav">${NAV.map(([k,i,n]) => `<button data-a="scr" data-i="${k}" class="${screen===k?'on':''}">${ic(i)}<span class="tx">${t(n)}</span>${k==='ops'&&claimable()?'<em></em>':''}</button>`).join('')}</nav>`;
  const pimg = (PREV,id) => planeArt(id,skinOf(id)) || PREV[id] || '';       // صورة احترافية إن وُجدت، وإلا معاينة المحرك
  const planePanel = PREV => {
    const id = S.sel, p = PLANES[id], lv = S.pl[id] || 1, st = stats(id);
    return `<div class="lb-right"><div class="lb-logo"><img src="${LOGO}" alt="SKY STRIKE"></div><div class="lb-plane">
      <div class="pp-h"><div><b class="tx">${p.n}</b><p class="tx">${t('d_'+id)}</p></div><span class="lvb">${t('lvl')} ${lv}</span></div>
      <div class="st">${[['SPD',st.speed,280],['TURN',st.turn,2.3],['HP',st.hp,300]].map(([k,v,m]) => `<span>${k}</span>${bar(v,m)}<em>${Math.round(v*(k==='TURN'?10:1))}</em>`).join('')}</div>
      <div class="ths">${Object.keys(PLANES).map(k => { const own = !!S.pl[k]; return `<button class="th ${S.sel===k?'on':''} ${own?'':'lk'}" data-a="${own?'pick':'scr'}" data-i="${own?k:'hangar'}"><img src="${pimg(PREV,k)}" alt="">${own?'':'<span>🔒</span>'}</button>`; }).join('')}</div>
    </div></div>`;
  };
  const views = createMsViews({ic, plain, pimg, maps:() => api.maps()});
  const lobby = PREV => `${planePanel(PREV)}${views.nextCard(PREV)}${views.miniRecord()}`;
  const bottomBar = () => `<div class="lb-bot"><button data-a="scr" data-i="ops" class="${screen==='ops'?'on':''}">${ic('map')}<span class="tx">${t('bMissions')}</span></button><button data-a="scr" data-i="record" class="${screen==='record'?'on':''}">${ic('trophy')}<span class="tx">${t('bRecord')}</span></button></div>`;
  const cta = () => `<button class="lb-cta" data-a="go"><i></i><span class="tx">${t(screen==='brief'?'start':screen==='debrief'?'db_retry':'briefT')}</span>${ic('plane')}</button>`;

  /* ---------- الشاشات الداخلية ---------- */
  const tog = (a,on,label) => `<div class="card"><b class="tx">${label}</b><button data-a="${a}" class="${on?'on':''}">${on?t('on'):t('off')}</button></div>`;
  const sheets = {
    hangar:PREV => `<div class="grid g1">${Object.entries(PLANES).map(([id,p]) => { const lv = S.pl[id], st = lv ? stats(id) : {speed:p.speed,turn:p.turn,hp:p.hp};
      return `<div class="pc ${S.sel===id?'sel':''}"><div class="im ${lv?'':'lk'}"><img src="${pimg(PREV,id)}" alt=""><span>🔒</span></div><div class="pb"><div class="inf"><b class="tx">${p.n}</b>${lv?`<em>${t('lvl')} ${lv}</em>`:''}<p class="tx">${t('d_'+id)}</p><p class="tx hint">⚡ ${t('ab_'+id)}</p>
      <div class="st">${[['SPD',st.speed,280],['TURN',st.turn,2.3],['HP',st.hp,300]].map(([k,v,m]) => `<span>${k}</span>${bar(v,m)}<em>${Math.round(v*(k==='TURN'?10:1))}</em>`).join('')}</div>
      <p class="tx hint">${lv?(S.sel===id?t('usedNow'):t('tapUse')):t('unlockHow',{p:p.price})}</p></div>
      <div class="acts">`+(lv?`<button data-a="sel" data-i="${id}" ${S.sel===id?'disabled':''}>${t('use')}</button><button data-a="upl" data-i="${id}" class="alt" ${lv>=MAXL||S.coins<upCost(lv,id)?'disabled':''}>${t('upg')} ${lv>=MAXL?t('max'):upCost(lv,id)+'🪙'}</button><button data-a="skn" data-i="${id}" class="alt" aria-label="${t('skinsT')}">🎨</button>`
        :`<button data-a="buy" data-i="${id}" ${S.coins<p.price?'disabled':''}>${t('buy')} ${p.price}🪙</button>`)+`</div></div></div>`; }).join('')}</div>`,
    weapons:() => `<div class="grid g2">${Object.entries(WPN).map(([k,w]) => { const lv = S[k], cost = lv ? wCost(lv) : w.price;
      const im = ART.weapons[k];
      return `<div class="card wc ${im?'hasimg':''} ${lv?'':'lk'}">${im?`<div class="wim"><img src="${im}" alt=""></div>`:''}<div><b class="tx">${im?'':w.ic+' '}${t('w_'+k)}</b> <em>${lv?t('lvl')+' '+lv:t('locked')}</em><small class="tx">${wd[k](lv||1)}</small></div><button data-a="upw" data-i="${k}" ${lv>=MAXL||S.coins<cost?'disabled':''}>${lv?(lv>=MAXL?t('max'):t('upg')+' '+cost+'🪙'):t('buy')+' '+cost+'🪙'}</button></div>`; }).join('')}</div>`,
    skins:() => { const id = S.sel, cur = skinOf(id);
      return `<div class="chip tx">${PLANES[id].n} · 💎 ${S.gems|0}</div><div class="grid g2">${Object.entries(SKINS).map(([k,sn]) => { const own = skinOwned(id,k);
        return `<div class="card"><b class="tx"><i class="sw" style="background:#${sn.sw.toString(16).padStart(6,'0')}"></i>${t('sk_'+k)}</b>${own?`<button data-a="skuse" data-i="${k}" ${cur===k?'disabled':''}>${cur===k?t('skOn'):t('use')}</button>`:`<button data-a="skbuy" data-i="${k}" ${(S.gems|0)<sn.g?'disabled':''}>${t('buy')} ${sn.g}💎</button>`}</div>`; }).join('')}</div>`; },
    profile:() => { const l = level(), lo = baseLv(l), hi = nextLv(l), pct = clamp((S.xp-lo)/(hi-lo)*100,0,100), sm = summary(S.ms,MISSIONS), own = Object.keys(S.pl).length;
      return `<div class="prof">${avatar(l,pct,'big')}<div class="pf-in"><label class="tx">${t('pName')}</label><input id="pname" type="text" maxlength="16" value="${esc(S.name)}" autocomplete="off" spellcheck="false"></div></div>
      <div class="card col"><div class="pf-lv"><b>${rb(l,'lg')}Lv ${l} · ${t(rankKey(l))}</b><span>${S.xp} / ${hi} ${t('xp')}</span></div><i class="xpb big"><b style="width:${pct}%"></b></i></div>
      <div class="card info"><div><b class="tx">🎁 ${t('lvRwT')}</b><small class="dr">${[1,2,3].map(k => { const r = lvReward(l+k); return `Lv ${l+k}: +${r.c}🪙${r.g?' +'+r.g+'💎':''}${r.sk?' 🎨 '+t('sk_'+r.sk):''}`; }).join('<br>')}</small></div></div>
      <div class="grid g2"><div class="card"><b class="tx">🪙 ${t('pCoins')}</b><em>${S.coins}</em></div><div class="card"><b class="tx">⭐ ${t('rc_stars')}</b><em>${sm.stars} / ${sm.maxStars}</em></div>
      <div class="card"><b class="tx">✈️ ${t('pPlanes')}</b><em>${own} / ${Object.keys(PLANES).length}</em></div><div class="card"><b class="tx">🎯 ${t('rc_done')}</b><em>${sm.done} / ${sm.total}</em></div>
      <div class="card"><b class="tx">📊 ${t('pAvg')}</b><em>${avgCoins()}🪙</em></div><div class="card"><b class="tx">🛫 ${t('pRuns')}</b><em>${(S.st&&S.st.n)|0}</em></div></div>`; },
    ops:() => views.ops(), record:() => views.record(), brief:PREV => views.brief(sel,PREV),
    debrief:() => dbf ? views.debrief(dbf) : views.ops(),
    settings:() => { const qs = [['auto','qAuto'],['lite','qLite'],['low','qLow'],['med','qMed'],['high','qHigh']];
      const sw = (a,on,label) => `<button class="srow" data-a="${a}" role="switch" aria-checked="${on?'true':'false'}"><span class="tx">${label}</span><i class="swt ${on?'on':''}"><b></b></i></button>`;
      const seg = (a,items,cur) => `<div class="seg">${items.map(([v,lb]) => `<button data-a="${a}" data-i="${v}" class="${String(cur)===String(v)?'on':''}">${lb}</button>`).join('')}</div>`;
      const grp = (icon,title,body) => `<section class="sgrp"><h3>${ic(icon)}<span class="tx">${title}</span></h3>${body}</section>`;
      const lab = (txt,body) => `<div class="slab"><span class="tx">${txt}</span>${body}</div>`;
      const sp = Math.max(0,Math.min(100,(S.sens-.5)/1.1*100));
      return `<div class="sgs">`
      + grp('monitor',t('sgGfx'), lab(t('sQual'),seg('q',qs.map(q => [q[0],t(q[1])]),S.q)) + lab(t('sCam'),seg('cam',[0,1,2].map(k => [k,t('cam'+k)]),S.cam|0)) + sw('fps',S.fps,t('sFps')))
      + grp('vol',t('sgSnd'), sw('snd',S.snd,t('sSnd')) + sw('mus',S.mus,t('sMus')) + sw('rad',S.rad??1,t('sRad')) + sw('vib',S.vib,t('sVib')))
      + grp('pad',t('sgCtl'), lab(t('sFm'),seg('fm',[[0,t('fm0')],[1,t('fm1')]],S.fm|0)) + `<div class="srow static"><span class="tx">${t('sSens')}</span><div class="stp"><button data-a="sens" data-i="-1" aria-label="-">−</button><i class="sbar"><b style="width:${sp}%"></b></i><span class="sv">${S.sens.toFixed(1)}</span><button data-a="sens" data-i="1" aria-label="+">+</button></div></div>` + sw('assist',S.assist,t('sAssist')) + sw('tilt',S.tilt,t('sTilt')) + sw('tiltInv',S.tiltInv,t('sTiltInv')) + sw('invY',S.invY,t('sInvY')))
      + grp('gear',t('sgGame'), sw('tutOn',!S.tut,t('sTut')) + lab(t('sLang'),seg('lang',[['ar','العربية'],['en','English']],S.lang)))
      + `</div>`; },
  };

  /* ---------- العرض ---------- */
  M.setMsg = m => { msg = m; };
  M.setDebrief = r => { dbf = r; };
  M.show = to => {
    if(to) screen = ALIAS[to] || to; if(!sheets[screen] && screen !== 'lobby') screen = 'lobby';
    const m = $('#menu'), l = level(), PREV = api.previews(), prevScroll = m.querySelector('.sh-b'), y = prevScroll && shown === screen ? prevScroll.scrollTop : 0; shown = screen;
    m.style.display = 'block'; m.dataset.s = screen; m.style.setProperty('--dir',getLang() === 'ar' ? 'rtl' : 'ltr');
    const inner = screen === 'lobby' ? lobby(PREV)
      : `<div class="lb-sheet"><div class="sh-h"><h2 class="tx">${t(TITLES[screen])}</h2><button class="sh-x" data-a="scr" data-i="lobby" aria-label="${t('close')}">${ic('x')}</button></div><div class="sh-b">${sheets[screen](PREV)}</div></div>`;
    m.innerHTML = `${topBar(l)}${nav()}${msg?`<div class="lb-msg tx">${msg}</div>`:''}${inner}${bottomBar()}${cta()}`;
    if(y){ const sb = m.querySelector('.sh-b'); if(sb) sb.scrollTop = y; }
    if(screen === 'brief' && !mapsBusy && api.mapsPending()){
      mapsBusy = true; setTimeout(() => api.genMapPreviews(
        (id,url) => { const im = document.querySelector(`#menu img[data-mi="${id}"]`); if(im){ im.src = url; im.hidden = false; } },
        () => { mapsBusy = false; if(screen === 'brief') M.show(); }),250);
    }
  };
  $('#menu').addEventListener('change',e => {
    if(e.target.id !== 'pname') return; const v = e.target.value.trim().slice(0,16);
    if(!v){ e.target.value = S.name; return; } S.name = v; save(); toast(t('pSaved'));
  });
  const toast = txt => { const d = document.createElement('div'); d.className = 'lb-toast tx'; d.textContent = txt; $('#menu').appendChild(d); setTimeout(() => d.remove(),1700); };

  $('#menu').addEventListener('click',e => {
    const b = e.target.closest('[data-a]'); if(!b || b.disabled) return; const a = b.dataset.a, i = b.dataset.i;
    if(a === 'soon') return toast(t('soon'));
    msg = '';
    if(a === 'go' && screen === 'brief') return api.startMission(sel);
    if(a === 'go' && screen === 'debrief' && dbf) return api.startMission(dbf.idx);
    if(a === 'go'){ sel = nextIndex(S.ms,MISSIONS); screen = 'brief'; }
    if(a === 'brief' && isUnlocked(S.ms,MISSIONS,+i)){ sel = +i; screen = 'brief'; }
    if(a === 'mission') return api.startMission(+i);
    if(a === 'scr'){ screen = i; }
    if(a === 'pick') S.sel = i;
    if(a === 'sel') S.sel = i;
    if(a === 'buy' && S.coins >= PLANES[i].price){ S.coins -= PLANES[i].price; S.pl[i] = 1; S.sel = i; }
    if(a === 'upl' && S.coins >= upCost(S.pl[i],i)){ S.coins -= upCost(S.pl[i],i); S.pl[i]++; }
    if(a === 'upw'){ const c = S[i] ? wCost(S[i]) : WPN[i].price; if(S.coins >= c){ S.coins -= c; S[i]++; } }
    if(a === 'login'){ const r = claimLogin(); if(r) msg = t('claimedL',{r:r.coins})+(r.gems?' +'+r.gems+'💎':''); }
    if(a === 'skn'){ S.sel = i; screen = 'skins'; }
    if(a === 'skuse'){ if(useSkin(S.sel,i)) api.rePrev(); }
    if(a === 'skbuy'){ if(buySkin(S.sel,i)){ api.rePrev(); msg = t('skBought'); } }
    if(a === 'cam') S.cam = +i;
    if(a === 'fm') S.fm = +i;
    if(a === 'q'){ S.q = i; api.applyQuality(); }
    if(a === 'snd'){ S.snd = S.snd ? 0 : 1; setMute(!S.snd); }
    if(a === 'mus'){ S.mus = S.mus ? 0 : 1; setMusic(!!S.mus); }
    if(a === 'rad'){ S.rad = S.rad ? 0 : 1; setRadio(!!S.rad); }
    if(a === 'ldaa' || a === 'ldag' || a === 'lddiff' || a === 'ldwing'){
      S.load = S.load || {aa:'msl',ag:'bomb',wing:0,diff:1};
      if(a === 'ldaa') S.load.aa = i;
      if(a === 'ldag') S.load.ag = i;
      if(a === 'lddiff') S.load.diff = +i;
      if(a === 'ldwing') S.load.wing = +i;
    }
    if(a === 'vib') S.vib = S.vib ? 0 : 1;
    if(a === 'fps') S.fps = S.fps ? 0 : 1;
    if(a === 'assist') S.assist = S.assist ? 0 : 1;
    if(a === 'tilt') S.tilt = S.tilt ? 0 : 1;
    if(a === 'tiltInv') S.tiltInv = S.tiltInv ? 0 : 1;
    if(a === 'invY') S.invY = S.invY ? 0 : 1;
    if(a === 'tutOn') S.tut = S.tut ? 0 : 1;
    if(a === 'sens') S.sens = clamp(Math.round((S.sens+i*.1)*10)/10,.5,1.6);
    if(a === 'lang'){ S.lang = i; setLang(i); }
    save(); M.show();
  });
  return M;
}
