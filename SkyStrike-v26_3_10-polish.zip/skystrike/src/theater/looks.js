/* مظاهر المسارح (سماء/ضباب/إضاءة/ألوان/أشجار). كل مظهر يشير لتضاريس بـ terrain؛ المظهران front و front_night يتشاركان التضاريس نفسها. */
const SEA = {level:0, color:0x1d6f8f, op:.9, spec:0xffffff};
const FRONT = {terrain:'front', exp:1.1, water:{...SEA, color:0x1f6a8c},
  sky:{top:0x2f6bb8, hor:0xe2d3ba, stars:0}, fog:0xd3d0bf, fogFar:5200,
  sun:{dir:[-.55, .55, -.45], col:0xfff0d8, i:3.7}, hemi:[0xbcd6ff, 0x66604a, 2.3], cloud:0xffffff,
  pal:[[.6, 0x2a6a82], [4, 0xd9c795], [110, 0x5e8a42], [300, 0x7d7a58], [520, 0x77746a], [1e9, 0xd8dce0]],
  fields:[0x6f9448, 0x8f9a4c, 0xa89a58, 0x5c8440], fieldH:130, roadCol:0x4a4a48,
  rock:0x7a7466, rockNy:.72, rockMin:60, cloudY:[500, 900],
  tree:{type:'ball', col:0x4a7a35, hmin:5, hmax:220, p:.35, sc:[.8, 1.6]}};
const FRONT_NIGHT = {...FRONT, night:true, exp:.95, water:{level:0, color:0x061a30, op:.9, spec:0x9fb8ff},
  sky:{top:0x050c20, hor:0x1a2b4d, stars:1.1}, fog:0x0f1c36, fogFar:4800,
  sun:{dir:[.5, .6, -.4], col:0xa9bfff, i:2.6}, hemi:[0x6a82c0, 0x222c40, 2.7], cloud:0x3c4c78,
  pal:[[.6, 0x10304a], [4, 0x56564a], [110, 0x365a3e], [300, 0x4a5444], [520, 0x555a5c], [1e9, 0x8a90a0]],
  fields:[0x3c5e3a, 0x4a5836, 0x55523a, 0x33523a], roadCol:0x35373b, rock:0x474c54,
  tree:{type:'cone', col:0x24482f, hmin:5, hmax:220, p:.4, sc:[.8, 1.5]}};
const HIGH = {terrain:'highlands', exp:1.1, water:null,
  sky:{top:0x3a76c0, hor:0xcfe0ee, stars:0}, fog:0xc4d4de, fogFar:5200,
  sun:{dir:[-.5, .5, .4], col:0xfff0dc, i:3.5}, hemi:[0xbfd6f2, 0x5c6a58, 2.2], cloud:0xf2f6fb,
  pal:[[150, 0x6c8a4a], [320, 0x7d8560], [560, 0x80796a], [800, 0x8b8b88], [1e9, 0xe8eef2]],
  fields:[0x6a8a48, 0x7a9050, 0x5f7f42], fieldH:230, roadCol:0x6b6458,
  rock:0x6f6b64, rockNy:.75, rockMin:120, cloudY:[900, 1300],
  tree:{type:'cone', col:0x2b5636, hmin:70, hmax:520, p:.75, sc:[.9, 1.9]}};
const GULF = {terrain:'gulf', exp:1.08, water:SEA,
  sky:{top:0x2b64b0, hor:0xbcd9ec, stars:0}, fog:0xb8d4e6, fogFar:5600,
  sun:{dir:[-.5, .62, -.45], col:0xfff1dc, i:3.7}, hemi:[0xbfd9ff, 0x5b6a55, 2.3], cloud:0xffffff,
  pal:[[.6, 0x1d6f8f], [3.5, 0xe0c88a], [70, 0x4c8a3c], [150, 0x6a7a4a], [1e9, 0x6f6a5c]],
  fields:[0x4c8a3c, 0x5a9444], fieldH:70, roadCol:0x55524c,
  rock:0x6f6a5c, rockNy:.78, rockMin:40, cloudY:[800, 1300],
  tree:{type:'ball', col:0x3f7a3a, hmin:5, hmax:120, p:.5, sc:[.8, 1.5]}};
export const LOOKS = {front:FRONT, highlands:HIGH, gulf:GULF, front_night:FRONT_NIGHT};
export const LOOK_IDS = Object.keys(LOOKS);
