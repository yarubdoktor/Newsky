/* تخطيط المسرح: يحوّل مواقع التضاريس إلى مجسمات (كيتات مُقسَّمة لبلاطات 1600م للـ frustum culling) + مُشخِّص تصادم.
   دالة صرفة (بلا three) فتُختبر بـ node. المخرجات: {tiles:[{kit,lights}], hit(x,y,z), count}. */
import {makeKit, solidIndex} from './kit.js';
import {mulberry} from './math.js';
import {airbase, port, fort} from './lay_air.js';
import {town, camp, radar} from './lay_ground.js';

const TILE = 1600, ROAD = 0x44464a, ROAD_W = 6;
const BUILD = {airbase, port, fort, town, camp, radar};

export function buildLayout(T, S, opts = {}){
  const rng = mulberry(T.seed*7+3), tiles = new Map(), key = (x, z) => Math.floor(x/TILE)*1000+Math.floor(z/TILE);
  const tile = (x, z) => { const k = key(x, z); let t = tiles.get(k);
    if(!t){ t = {kit:makeKit(1), lights:makeKit(1), k}; tiles.set(k, t); } return t; };
  const C = {S, rng, H:S.H, k:(x, z) => tile(x, z).kit, l:(x, z) => tile(x, z).lights};
  for(const s of S.pads){ const f = BUILD[s.type]; if(f) f(C, s); }
  // ---- الطرق: شرائح بين العقد (تُتخطّى داخل القواعد الجوية حيث المدرج)
  const inAir = (x, z) => S.pads.some(s => s.type === 'airbase' &&
    Math.abs(x-s.x) < (s.hx || s.r)+20 && Math.abs(z-s.z) < (s.hz || s.r)+20);
  for(const r of S.roads) for(let i = 0; i < r.nodes.length-1; i++){
    const a = r.nodes[i], b = r.nodes[i+1];
    if(inAir((a[0]+b[0])/2, (a[1]+b[1])/2)) continue;
    C.k(a[0], a[1]).strip(a[0], a[1], r.hs[i]+.5, b[0], b[1], r.hs[i+1]+.5, ROAD_W*(r.id === 'valley' ? .8 : 1), ROAD);
  }
  const solids = []; let count = 0, list = [];
  for(const t of tiles.values()){ solids.push(...t.kit.solids); count += t.kit.count()+t.lights.count();
    list.push({k:t.k, kit:t.kit.done(), lights:t.lights.done()}); }
  list = list.filter(t => t.kit.idx.length || t.lights.idx.length);
  return {tiles:list, hit:solidIndex(solids, 200), count, solidCount:solids.length};
}
