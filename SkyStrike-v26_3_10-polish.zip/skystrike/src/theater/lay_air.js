/* مباني المواقع الكبيرة: قاعدة جوية (مدرج+ممر+ساحة+هناجر+برج+خزانات+طائرات رابضة) · ميناء · حصن بحري.
   كل دالة (C, s): C = سياق layout.js (C.k(x,z) كيت الصلب للبلاطة · C.l(x,z) كيت الأضواء الليلية · C.rng) و s = الموقع. */
const ASPH = 0x3b3d40, CONC = 0x8d8f8a, STRIPE = 0xe6e6dc, GREY = 0x6d7276;

const frame = s => { const zz = s.orient === 'z';
  return {P:(u, v) => zz ? [s.x+v, s.z+u] : [s.x+u, s.z+v], S:(a, b) => zz ? [b, a] : [a, b]}; };

export function airbase(C, s){
  const f = frame(s), h = s.h, L = (s.orient === 'z' ? s.hz : s.hx)*.9, sm = !!s.small, en = s.side === 'enemy',
    rng = C.rng;
  const B = (u, v, y, su, sv, sy, hex, solid) => { const [x, z] = f.P(u, v), [sx, sz] = f.S(su, sv);
    C.k(x, z).box(x, y, z, sx, sy, sz, hex, 0, solid); };
  const lamp = (u, v, hex) => { const [x, z] = f.P(u, v); C.l(x, z).box(x, h+.3, z, 1.6, 1.4, 1.6, hex); };
  for(let u = -L; u < L; u += 100){                                        // المدرج: بلاطات 100م
    B(u+50, 0, h-.1, 100, 36, .5, ASPH);
    if(!sm || u % 200 === 0) B(u+50, 0, h+.38, 22, 1.2, .14, STRIPE);
    lamp(u+50, -19, 0xfff2c0); lamp(u+50, 19, 0xfff2c0);
    lamp(u, -19, 0xfff2c0); lamp(u, 19, 0xfff2c0);
  }
  for(const e of [-1, 1]){ B(e*(L-12), 0, h+.38, 3, 26, .14, STRIPE); B(e*(L-30), 0, h+.38, 3, 26, .14, STRIPE);
    lamp(e*L, -10, 0x66ff88); lamp(e*L, 10, 0xff6655); }                    // أضواء العتبات
  if(sm){                                                                   // مدرج صغير: ساحة + هنغران + برج
    B(0, 52, h-.1, 120, 40, .5, CONC);
    for(const u of [-40, 40]) { const [x, z] = f.P(u, 100), [sx, sz] = f.S(30, 24);
      C.k(x, z).house(x, h, z, sx, 8, sz, 5, GREY, 0x4f5a4a); }
    B(-70, 80, h, 7, 7, 14, CONC, true); B(-70, 80, h+14, 10, 10, 3.5, 0x4a5a66);
    return;
  }
  B(0, 70, h-.1, 2*L, 16, .5, CONC);                                        // ممر الإقلاع الموازي
  for(let u = -L+200; u < L; u += 400) B(u, 35, h-.1, 16, 36, .5, CONC);
  for(let u = -300; u < 300; u += 60) B(u+30, 120, h-.1, 60, 60, .5, CONC);  // ساحة الطائرات
  for(let i = 0; i < 4; i++){ const [x, z] = f.P(-240+i*160, 225), [sx, sz] = f.S(54, 40);
    C.k(x, z).house(x, h, z, sx, 11, sz, 7, en ? 0x5d6358 : GREY, en ? 0x40493a : 0x55606a);
    lamp(-240+i*160, 203, 0xffd070); }
  B(-120, 160, h, 9, 9, 20, CONC, true); B(-120, 160, h+20, 14, 14, 4.5, 0x3f5568, true);   // البرج
  lamp(-120, 160, 0xff5544);
  for(let i = 0; i < 3; i++){ const [x, z] = f.P(330, 160+i*30); C.k(x, z).cyl(x, h, z, 10, 10, 9, 0xb7b9b4, 10,
    true); }
  for(let i = 0; i < 3; i++) B(-330, 190+i*16, h, 12, 9, 4, 0x56604c, true);   // مخابئ ذخيرة
  for(let i = 0; i < 6; i++){                                                 // طائرات رابضة (غير صلبة)
    const u = -250+i*100, c = en ? 0x55595c : 0x8a9096;
    B(u, 128, h+.4, 3.2, 17, 3.2, c); B(u, 130, h+1.2, 14, 5, .6, c); B(u, 138, h+1.5, 6, 2, 3.8, c);
  }
}

export function port(C, s){
  const h = s.h, rng = C.rng, k = C.k(s.x, s.z), R = s.r;
  for(let i = -3; i <= 3; i++) k.box(s.x-R*.75, h-.1, s.z+i*80, 70, .5, 82, CONC);          // رصيف الميناء (غرباً)
  k.box(s.x-R*.2, h-.1, s.z, R*1.2, .5, R*1.6, 0x6f716e);
  for(let i = 0; i < 3; i++){ const x = s.x-R*.78, z = s.z-100+i*100;                       // رافعات
    k.box(x+14, h, z, 3, 40, 3, 0xc4552b); k.box(x, h+38, z, 34, 2.4, 3, 0xc4552b); k.box(x-14, h, z, 3, 40, 3,
      0xc4552b, 0, true); }
  const cols = [0x9c3b2a, 0x2f5f8a, 0xc19b2d, 0x3f7a4a, 0x7a2f2f];
  for(let i = 0; i < 26; i++){ const x = s.x-R*.35+(i%6)*15, z = s.z-R*.4+Math.floor(i/6)*17;
    k.box(x, h+.4, z, 12, 2.6, 5.5, cols[(rng()*5) | 0], 0, true); if(rng() < .5) k.box(x, h+3, z, 12, 2.6, 5.5,
      cols[(rng()*5) | 0]); }
  for(let i = 0; i < 2; i++){ const [x, z] = [s.x+R*.45, s.z-R*.3+i*R*.55]; k.house(x, h, z, 46, 9, 22, 5, 0x8a8f8f,
    0x4e5558); }
  for(let i = 0; i < 4; i++) k.cyl(s.x+R*.2+(i%2)*28, h, s.z+R*.7+Math.floor(i/2)*28, 11, 11, 12, 0xcfd2cd, 10, true);
  const l = C.l(s.x, s.z); for(let i = -3; i <= 3; i++) l.box(s.x-R*1.05, h+.4, s.z+i*80, 1.6, 6, 1.6, 0xfff2c0);
}

export function fort(C, s){
  const h = s.h, rng = C.rng, k = C.k(s.x, s.z), R = s.r, l = C.l(s.x, s.z);
  k.cyl(s.x, h-6, s.z, R*.9, R*.84, 6.8, 0x77797a, 16);                                       // منصّة خرسانية
  k.cyl(s.x, h+.8, s.z, 18, 14, 30, 0x8a8d8f, 10, true); k.cyl(s.x, h+30.8, s.z, 20, 20, 5, 0x4a5a66, 10);
  l.box(s.x, h+36, s.z, 3, 2, 3, 0xff4a3a);
  for(let i = 0; i < 4; i++){ const a = i*Math.PI/2+Math.PI/4, x = s.x+Math.cos(a)*R*.55, z = s.z+Math.sin(a)*R*.55;
    k.box(x, h+.8, z, 20, 6, 14, 0x6c7075, a, true); k.box(x, h+6.8, z, 22, 1.2, 16, 0x585d61, a); }
  k.box(s.x, h+.8, s.z+R*.3, 54, 7, 16, 0x7a7d78, 0, true); k.box(s.x, h+7.8, s.z+R*.3, 58, 1.4, 20, 0x4c5156);
  for(let i = 0; i < 6; i++){ const a = i/6*Math.PI*2+rng()*.3; k.cyl(s.x+Math.cos(a)*R*.8, h+.8,
    s.z+Math.sin(a)*R*.8, 3, 2.4, 2, 0x4a4e52, 8); }
  for(let i = 0; i < 8; i++){ const a = i/8*Math.PI*2; l.box(s.x+Math.cos(a)*R*.86, h+.9, s.z+Math.sin(a)*R*.86, 1.4,
    1.4, 1.4, 0xffc050); }
}
