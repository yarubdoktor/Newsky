/* مجسمات المسرح (three): كل بلاطة = Mesh واحد بألوان رؤوس، وأضواء ليلية (MeshBasic) في مظاهر الليل فقط. */
import * as THREE from 'three';

function mesh(d, mat){
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(d.pos, 3)); g.setAttribute('color',
    new THREE.BufferAttribute(d.col, 3));
  g.setIndex(new THREE.BufferAttribute(d.idx, 1)); g.computeBoundingSphere();
  return new THREE.Mesh(g, mat);
}
export function buildProps(lay, night){
  const grp = new THREE.Group(), mat = new THREE.MeshLambertMaterial({vertexColors:true, flatShading:true});
  const glow = new THREE.MeshBasicMaterial({vertexColors:true});
  for(const t of lay.tiles){
    if(t.kit.idx.length) grp.add(mesh(t.kit, mat));
    if(night && t.lights.idx.length) grp.add(mesh(t.lights, glow));
  }
  const od = mat.dispose.bind(mat); mat.dispose = () => { od(); glow.dispose(); };
  grp.userData.mat = mat; return grp;
}
