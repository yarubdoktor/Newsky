/* عدّة بناء المجسمات الثابتة للمسارح (دوال صرفة، بلا three): تجمع صناديق وأسطوانات ومخاريط بألوان رؤوس (خطية)
   بمصفوفات جاهزة لـ BufferGeometry، وتسجّل صناديق التصادم الصلبة. الألوان تُمرَّر hex sRGB وتُحوَّل لخطية هنا. */
const lin = c => { c /= 255; return c <= .04045 ? c/12.92 : Math.pow((c+.055)/1.055, 2.4); };
export const hexLin = hex => [lin((hex >> 16) & 255), lin((hex >> 8) & 255), lin(hex & 255)];

export function makeKit(dim = 1){
  const pos = [], col = [], idx = [], solids = [];
  const vtx = (x, y, z, c) => { pos.push(x, y, z); col.push(c[0]*dim, c[1]*dim, c[2]*dim); return pos.length/3-1; };
  const quad = (a, b, c, d) => idx.push(a, c, b, a, d, c);      // الترتيب المعاكس للدوران = وجه للخارج
  // صندوق: مركز (cx,cz) · قاعدة y0 · أبعاد sx,sy,sz · دوران yaw حول Y
  function box(cx, y0, cz, sx, sy, sz, hex, yaw = 0, solid = false){
    const c = hexLin(hex), cs = Math.cos(yaw), sn = Math.sin(yaw), hx = sx/2, hz = sz/2, v = [];
    for(const [px, pz] of [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]]){
      const x = cx+px*cs-pz*sn, z = cz+px*sn+pz*cs; v.push([x, z]);
    }
    const lo = v.map(p => vtx(p[0], y0, p[1], c)), hi = v.map(p => vtx(p[0], y0+sy, p[1], c));
    quad(hi[0], hi[1], hi[2], hi[3]);
    for(let i = 0; i < 4; i++){ const j = (i+1) % 4; quad(lo[i], lo[j], hi[j], hi[i]); }
    if(solid){
      const xs = v.map(p => p[0]), zs = v.map(p => p[1]);
      solids.push([Math.min(...xs), y0, Math.min(...zs), Math.max(...xs), y0+sy, Math.max(...zs)]);
    }
  }
  // أسطوانة/مخروط مقطوع: نصف قطر r0 بالقاعدة و r1 بالقمة
  function cyl(cx, y0, cz, r0, r1, h, hex, seg = 10, solid = false){
    const c = hexLin(hex), lo = [], hi = [];
    for(let i = 0; i < seg; i++){
      const a = i/seg*Math.PI*2, ca = Math.cos(a), sa = Math.sin(a);
      lo.push(vtx(cx+ca*r0, y0, cz+sa*r0, c)); hi.push(vtx(cx+ca*r1, y0+h, cz+sa*r1, c));
    }
    const top = vtx(cx, y0+h, cz, c);
    for(let i = 0; i < seg; i++){ const j = (i+1) % seg; quad(lo[i], lo[j], hi[j], hi[i]); idx.push(top, hi[j],
      hi[i]); }
    if(solid) solids.push([cx-r0, y0, cz-r0, cx+r0, y0+h, cz+r0]);
  }
  // سقف جملوني: صندوق بقاعدة sx×sz وارتفاع جدران sy ثم سقف بارتفاع rh
  function house(cx, y0, cz, sx, sy, sz, rh, wall, roof, yaw = 0){
    box(cx, y0, cz, sx, sy, sz, wall, yaw, true);
    if(rh > 0) cyl(cx, y0+sy, cz, Math.min(sx, sz)*.62, Math.min(sx, sz)*.18, rh, roof, 4, false);
  }
  // شريط مسطّح مائل (طريق/مدرج): من (x0,z0,y0) إلى (x1,z1,y1) بعرض w؛ وجه علوي فقط
  function strip(x0, z0, y0, x1, z1, y1, w, hex){
    const c = hexLin(hex), L = Math.hypot(x1-x0, z1-z0) || 1, nx = -(z1-z0)/L*w/2, nz = (x1-x0)/L*w/2;
    const a = vtx(x0-nx, y0, z0-nz, c), b = vtx(x0+nx, y0, z0+nz, c), d = vtx(x1+nx, y1, z1+nz, c), e = vtx(x1-nx, y1,
      z1-nz, c);
    idx.push(a, b, d, a, d, e);
  }
  const done = () => ({pos:new Float32Array(pos), col:new Float32Array(col), idx:new Uint32Array(idx), solids});
  return {box, cyl, house, strip, done, solids, count:() => idx.length/3};
}

/* فهرس شبكي للصناديق الصلبة (AABB) + اختبار نقطة. cell = حجم الخلية (م). m = هامش أمان */
export function solidIndex(solids, cell = 200){
  const map = new Map(), k = (i, j) => i*100003+j;
  solids.forEach((b, n) => {
    for(let i = Math.floor(b[0]/cell); i <= Math.floor(b[3]/cell); i++)
      for(let j = Math.floor(b[2]/cell); j <= Math.floor(b[5]/cell); j++){
        const key = k(i, j); let a = map.get(key); if(!a){ a = []; map.set(key, a); } a.push(n);
      }
  });
  return (x, y, z, m = 3) => {
    const a = map.get(k(Math.floor(x/cell), Math.floor(z/cell))); if(!a) return false;
    for(const n of a){ const b = solids[n];
      if(x > b[0]-m && x < b[3]+m && z > b[2]-m && z < b[5]+m && y < b[4]+m && y > b[1]-2) return true; }
    return false;
  };
}
