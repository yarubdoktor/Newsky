/* تضاريس المسارح الحربية (بيانات + دوال ارتفاع صرفة). مستوحاة من الخرائط القديمة المحفوظة بالمشروع:
     front     «الجبهة»     ← island (ساحل) + desert (سهول) + greenland (قاعدة جوية بهضبة): ساحل غرباً، سهول، تلال خط التماس بممرّين،
                                جبال شرقية، هضبة شمالية؛ قاعدتان جويتان وبلدات ومنصّات.
     highlands «المرتفعات»  ← greenland + canyon + arctic: وادٍ رئيسي متعرّج بين سلاسل شاهقة، مدرج صغير جنوباً، رادارات على القمم.
     gulf      «الخليج»     ← map7: جزيرة قواعد جنوب-غرب وجزيرة مركزية جبلية وساحل معادٍ شرقاً وحصون بحرية على جزر مسطّحة.
   الإحداثيات: x شرقاً · z جنوباً (الأمام yaw=0 نحو -z). كل موقع: {x, z, r | hx,hz, type, side, minH?,
     b?}. المعاني بـ layout.js.
   ‎spawn.alt = الارتفاع فوق الأرض عند البداية. ‎sites هي ما تشير إليه المهمات بـ pos:{site:'id'}. */
import {clamp, smooth} from './math.js';
import {fbm} from '../noise.js';

/* ---------------- الجبهة ---------------- */
const frontMacro = n => (x, z) => {
  const coast = -5400+900*fbm(n, z*.00025+3, 7, 3)+260*Math.sin(z*.0011);
  const land = smooth(clamp((x-coast)/620, 0, 1));
  let h = 24+20*fbm(n, x*.0006, z*.0006, 3)+4*n(x*.004, z*.004);
  const zr = -800+380*Math.sin(x*.00065+1.1)+200*fbm(n, x*.0004+9, 3, 2), dz = z-zr;       // خط التماس
  let ridge = 240*(.65+.35*fbm(n, x*.0012-4, z*.0012, 2))*Math.exp(-dz*dz/(560*560));
  for(const px of [-2100, 1900]) ridge *= 1-.9*Math.exp(-(x-px)*(x-px)/(430*430));            // الممرّان
  h += ridge;
  const e = smooth(clamp((x-3300)/2400, 0, 1)), rg = 1-Math.abs(fbm(n, x*.00042+21, z*.00042-5, 3));
  h += e*(70+560*Math.pow(rg, 2.2));                                                           // السلسلة الشرقية
  const nn = smooth(clamp((-z-6300)/2400, 0, 1)); h += nn*(150+170*fbm(n, x*.0007, z*.0007+3, 3));
  const sea = -46+16*fbm(n, x*.0009, z*.0009, 2);
  return land*h+(1-land)*sea;
};
const FRONT = {
  id:'front', seed:101, limit:9600, ceil:1200, macro:frontMacro,
  spawn:{x:0, z:4350, alt:130, pitch:.04, yaw:0}, prev:{x:-1500, z:2600, alt:520, tx:300, tz:-1600},
  sites:{
    alpha:{x:100, z:5100, hx:280, hz:1060, type:'airbase', side:'ally', orient:'z', minH:9},
    bravo:{x:1500, z:-5100, hx:1060, hz:280, type:'airbase', side:'enemy', orient:'x', minH:9},
    t_coast:{x:-3900, z:2400, r:300, type:'town', side:'ally', n:70},
    t_mid:{x:900, z:1300, r:300, type:'town', side:'ally', n:80},
    t_ridge:{x:-2500, z:-100, r:260, type:'town', side:'ally', n:44},
    t_east:{x:4350, z:1100, r:250, type:'town', side:'ally', n:36},
    t_n1:{x:-3000, z:-4000, r:300, type:'town', side:'enemy', n:60},
    t_n2:{x:3000, z:-3500, r:300, type:'town', side:'enemy', n:56},
    f_depot:{x:-650, z:2650, r:150, type:'camp', side:'ally'},
    f_post:{x:1300, z:500, r:130, type:'camp', side:'ally'},
    f_stage:{x:-250, z:3600, r:140, type:'camp', side:'ally'},
    e_depot:{x:-1000, z:-3100, r:170, type:'camp', side:'enemy'},
    e_radar:{x:3100, z:-1900, r:110, type:'radar', side:'enemy', minH:30},
    e_cmd:{x:-300, z:-4400, r:170, type:'camp', side:'enemy'},
    e_fuel:{x:2300, z:-4100, r:170, type:'camp', side:'enemy'},
    e_assy:{x:-2000, z:-2750, r:200, type:'camp', side:'enemy'},
    e_pass_w:{x:-2100, z:-1250, r:130, type:'camp', side:'enemy'},
    e_pass_e:{x:1900, z:-1250, r:130, type:'camp', side:'enemy'},
    s1:{x:-3100, z:-1900, r:100, type:'camp', side:'enemy'},
    s2:{x:-1300, z:-2500, r:100, type:'camp', side:'enemy'},
    s3:{x:500, z:-2850, r:100, type:'camp', side:'enemy'},
    s4:{x:2300, z:-2650, r:100, type:'camp', side:'enemy'},
    s5:{x:3700, z:-1450, r:100, type:'camp', side:'enemy'}
  },
  roads:[
    {id:'main', pts:['alpha', 'f_stage', [-700, 2000], [-1700, 500], [-2100, -900], 'e_pass_w', 'e_assy', 't_n1'],
      w:28},
    {id:'east', pts:['t_mid', 'f_post', [1700, -100], 'e_pass_e', [2200, -2400], 'e_fuel'], w:26},
    {id:'link', pts:['alpha', [100, 3400], 't_mid'], w:26},
    {id:'coast', pts:['t_coast', [-2200, 2900], 'f_depot', 'f_stage'], w:24},
    {id:'north', pts:['bravo', [500, -4600], 'e_cmd', 'e_depot'], w:24},
    {id:'hill', pts:['t_east', [3200, 1000], 'f_post'], w:22}
  ]
};

/* ---------------- المرتفعات ---------------- */
const valleyX = z => 380*Math.sin(z*.00075)+150*Math.sin(z*.0019+2);
const highMacro = n => (x, z) => {
  const dx = x-valleyX(z), vw = 640+180*Math.sin(z*.0011);
  let mask = smooth(clamp((Math.abs(dx)-vw)/1500, 0, 1));
  mask *= 1-.8*Math.exp(-(z+1900)*(z+1900)/(520*520))*smooth(clamp(1-Math.abs(x)/3600, 0, 1));      // وادٍ جانبي
  const rg = 1-Math.abs(fbm(n, x*.00042+4, z*.00042+9, 3)), mount = 150+640*Math.pow(rg, 1.6);
  const floor = 90+(5600-z)*.014+14*fbm(n, x*.003, z*.003, 3);
  return floor+mask*mount+n(x*.01, z*.01)*mask*4;
};
const vroad = (z0, z1, off = 0) => { const a = []; for(let z = z0; z >= z1; z -= 600) a.push([valleyX(z)+off,
  z]); return a; };
const HIGH = {
  id:'highlands', seed:211, limit:8600, ceil:1500, macro:highMacro,
  spawn:{x:0, z:6050, alt:120, pitch:.04, yaw:0}, prev:{x:-1700, z:2800, alt:760, tx:300, tz:-2600},
  sites:{
    h_strip:{x:0, z:5650, hx:110, hz:900, type:'airbase', side:'ally', orient:'z', minH:60, small:true},
    h_town1:{x:valleyX(2600)+60, z:2600, r:230, type:'town', side:'ally', n:36},
    h_town2:{x:valleyX(-2900)+40, z:-2900, r:220, type:'town', side:'enemy', n:30},
    h_outpost:{x:valleyX(500)+1250, z:500, r:170, type:'camp', side:'ally', minH:120},
    h_camp:{x:valleyX(3800)-120, z:3800, r:130, type:'camp', side:'ally'},
    h_radar:{x:valleyX(-3700)-1350, z:-3700, r:90, type:'radar', side:'enemy', minH:150},
    h_radar2:{x:valleyX(-5600)+1500, z:-5600, r:90, type:'radar', side:'enemy', minH:150},
    h_fuel:{x:valleyX(-4400)+70, z:-4400, r:150, type:'camp', side:'enemy'},
    h_cmd:{x:valleyX(-6300)-50, z:-6300, r:160, type:'camp', side:'enemy'},
    h_amb1:{x:valleyX(-900)+40, z:-900, r:110, type:'camp', side:'enemy'},
    h_amb2:{x:valleyX(-2200)-40, z:-2200, r:110, type:'camp', side:'enemy'},
    h_amb3:{x:valleyX(-3600)+30, z:-3600, r:110, type:'camp', side:'enemy'},
    h_goal:{x:valleyX(-5000), z:-5000, r:140, type:'camp', side:'ally'},
    h_sam1:{x:valleyX(-1500)+1300, z:-1500, r:90, type:'camp', side:'enemy', minH:100},
    h_sam2:{x:valleyX(-3000)-1250, z:-3000, r:90, type:'camp', side:'enemy', minH:100}
  },
  roads:[{id:'valley', pts:['h_strip', 'h_camp', 'h_town1', ...vroad(1600, -4400), 'h_fuel'], w:26, b:130}]
};

/* ---------------- الخليج ---------------- */
const BLOBS = [[-5200, 4800, 2900, 1900, 55], [0, 0, 1800, 1400, 200], [-2600, -5200, 1300, 900, 70], [900, 5600, 800,
  600, 38]];
const gulfMacro = n => (x, z) => {
  let m = -58+10*fbm(n, x*.0008, z*.0008, 2);
  for(const [cx, cz, rx, rz, hh] of BLOBS){
    const t = 1-Math.hypot((x-cx)/rx, (z-cz)/rz), g = smooth(clamp((t+.1)/.85, 0, 1));
    m = Math.max(m, -58+(hh+58)*g+n(x*.004, z*.004)*8*g);
  }
  const coast = 6100+500*fbm(n, z*.0003+5, 2, 3), l = smooth(clamp((x-coast)/700, 0, 1));         // الساحل الشرقي
  m = Math.max(m, -58+(70+58)*l+l*(x-coast)*.03+n(x*.002, z*.002)*14*l);
  return m;
};
const GULF = {
  id:'gulf', seed:307, limit:10600, ceil:1500, macro:gulfMacro,
  spawn:{x:-6150, z:4800, alt:110, pitch:.04, yaw:-Math.PI/2}, prev:{x:-2800, z:2600, alt:640, tx:1500, tz:-1500},
  sites:{
    g_alpha:{x:-5200, z:4800, hx:1050, hz:240, type:'airbase', side:'ally', orient:'x', minH:9},
    g_bravo:{x:7700, z:-3300, hx:250, hz:1050, type:'airbase', side:'enemy', orient:'z', minH:9},
    g_port:{x:6560, z:900, r:260, type:'port', side:'enemy', h:8},
    g_town:{x:7100, z:-800, r:240, type:'town', side:'enemy', n:44},
    g_isle:{x:900, z:5600, r:240, type:'camp', side:'ally', minH:8},
    g_radar:{x:0, z:0, r:90, type:'radar', side:'enemy', minH:60},
    g_north:{x:-2600, z:-5200, r:170, type:'camp', side:'enemy', minH:8},
    g_fort1:{x:-1000, z:-2500, r:170, type:'fort', side:'enemy', minH:9},
    g_fort2:{x:2700, z:2900, r:170, type:'fort', side:'enemy', minH:9},
    g_fort3:{x:3300, z:-5400, r:170, type:'fort', side:'enemy', minH:9},
    g_fort4:{x:-4300, z:-800, r:170, type:'fort', side:'enemy', minH:9}
  },
  roads:[{id:'coast', pts:['g_port', [6900, -100], 'g_town', [7600, -1800], 'g_bravo'], w:26}]
};

export const TERRAINS = {front:FRONT, highlands:HIGH, gulf:GULF};
export {valleyX};
