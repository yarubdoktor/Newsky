/* ألوان رؤوس التضاريس للمسارح: تدرّج ارتفاع + حقول زراعية + طرق + أرضيات المواقع. مخرجها دالة (x,z,out,h) تكتب RGB خطياً. */
import {hexLin} from './kit.js';
import {clamp, smooth} from './math.js';

const PAD = {airbase:0x7d8460, town:0x8a8470, camp:0x6f624a, radar:0x66665f, port:0x6b6e6c, fort:0x6a6c6c};

export function makeColors(L, S, n){
  const P = L.pal.map(([h, hex]) => [h, hexLin(hex)]), F = L.fields.map(hexLin), rc = hexLin(L.roadCol);
  const pc = Object.fromEntries(Object.entries(PAD).map(([k, v]) => [k, hexLin(L.night ? (v >> 1) & 0x7f7f7f : v)]));
  const c = [0, 0, 0], mix = (t, d) => { c[0] += (d[0]-c[0])*t; c[1] += (d[1]-c[1])*t; c[2] += (d[2]-c[2])*t; };
  return (x, z, out, h = 0) => {
    let i = 0; while(i < P.length-1 && h > P[i][0]) i++;
    c[0] = P[i][1][0]; c[1] = P[i][1][1]; c[2] = P[i][1][2];
    if(i < P.length-1){ const up = P[i][0], bw = clamp(up*.25, .4, 12), t = clamp((h-(up-bw))/bw, 0,
      1); if(t > 0) mix(smooth(t), P[i+1][1]); }
    if(h > 5 && h < L.fieldH){                                                         // حقول: رقع بتدرّج ألوان
      const v = n(x*.0021+z*.0006, z*.0023-x*.0005)*.5+.5, w = smooth(clamp((h-5)/10, 0,
        1))*(1-smooth(clamp((h-L.fieldH*.6)/(L.fieldH*.4), 0, 1)));
      mix(.7*w, F[Math.min(F.length-1, (clamp(v, 0, .999)*F.length) | 0)]);
    }
    const q = S.info(x, z);
    if(q.pad && q.d < 30) mix(clamp(1-q.d/30, 0, 1)*(q.pad.type === 'airbase' ? .55 : .9), pc[q.pad.type] || pc.camp);
    if(q.road < 14) mix((1-q.road/14)*.85, rc);
    out.setRGB(c[0], c[1], c[2]);
  };
}
