/* مشكّل التضاريس للمسارح (دالة صرفة): ارتفاع كلي (macro) + تسطيح مواقع (دائرية/مستطيلة بتدرّج) + طرق مُسَوّاة.
   ‎H(x,z) = macro ← المواقع ← أقرب مقطع طريق. فهرس شبكي (خلية 256م) يجعل كل استدعاء O(قليل).
   ‎info(x,z) يرجع {road: مسافة لأقرب طريق, pad: أقوى موقع {site,w}} لتلوين التضاريس ومنع الأشجار. */
import {clamp, smooth} from './math.js';

const CELL = 256;
const cellKey = (i, j) => i*100003+j;

function sdSite(s, x, z){
  const dx = x-s.x, dz = z-s.z;
  if(s.shape === 'r'){
    const qx = Math.abs(dx)-s.hx, qz = Math.abs(dz)-s.hz;
    return Math.hypot(Math.max(qx, 0), Math.max(qz, 0))+Math.min(Math.max(qx, qz), 0);
  }
  return Math.hypot(dx, dz)-s.r;
}
const padBox = s => s.shape === 'r' ? [s.x-s.hx-s.b, s.z-s.hz-s.b, s.x+s.hx+s.b, s.z+s.hz+s.b]
  : [s.x-s.r-s.b, s.z-s.r-s.b, s.x+s.r+s.b, s.z+s.r+s.b];

function addIndexed(map, box, item){
  for(let i = Math.floor(box[0]/CELL); i <= Math.floor(box[2]/CELL); i++)
    for(let j = Math.floor(box[1]/CELL); j <= Math.floor(box[3]/CELL); j++){
      const k = cellKey(i, j); let a = map.get(k); if(!a){ a = []; map.set(k, a); } a.push(item);
    }
}

export function makeShaper(terrain, n){
  const macro = terrain.macro(n), pads = [], padMap = new Map(), segMap = new Map(), segs = [];
  // ---- المواقع: ارتفاع الهدف = متوسط macro حول المركز (وأدنى حد minH)
  for(const [id, d] of Object.entries(terrain.sites)){
    const s = {id, ...d, b:d.b ?? Math.max(120, (d.r || Math.max(d.hx, d.hz))*.7), shape:d.hx ? 'r' : 'c'};
    if(s.pad === false) continue;
    const rr = s.shape === 'r' ? Math.min(s.hx, s.hz) : s.r;
    let sum = macro(s.x, s.z), k = 1;
    for(const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]){ sum += macro(s.x+a*rr*.6, s.z+b*rr*.6); k++; }
    s.h = s.h ?? Math.max(sum/k, s.minH ?? 4);
    pads.push(s); addIndexed(padMap, padBox(s), s);
  }
  const byId = Object.fromEntries(pads.map(p => [p.id, p]));
  const baseH = (x, z) => {                                   // macro + المواقع (بلا طرق)
    let h = macro(x, z); const c = padMap.get(cellKey(Math.floor(x/CELL), Math.floor(z/CELL)));
    if(c) for(const s of c){ const d = sdSite(s, x, z);
      if(d < s.b) h += (s.h-h)*(d <= 0 ? 1 : 1-smooth(d/s.b)); }
    return h;
  };
  // ---- الطرق: كل طريق سلسلة نقاط (معرّف موقع أو [x,z]) ← عقد كل ≤120م بارتفاعات مُسَوّاة
  const roads = [];
  for(const r of terrain.roads || []){
    const pts = r.pts.map(p => typeof p === 'string' ? [byId[p].x, byId[p].z] : p), nodes = [];
    for(let i = 0; i < pts.length-1; i++){
      const [x0, z0] = pts[i], [x1, z1] = pts[i+1], L = Math.hypot(x1-x0, z1-z0), k = Math.max(1, Math.ceil(L/120));
      for(let q = 0; q < k; q++) nodes.push([x0+(x1-x0)*q/k, z0+(z1-z0)*q/k]);
    }
    nodes.push(pts[pts.length-1]);
    let hs = nodes.map(p => baseH(p[0], p[1]));
    const fix = nodes.map((p, i) => i === 0 || i === nodes.length-1 || pads.some(s => sdSite(s, p[0], p[1]) <= 0));
    for(let pass = 0; pass < 6; pass++){
      const nh = hs.slice();
      for(let i = 1; i < hs.length-1; i++) if(!fix[i]){
        let s = 0, c = 0; for(let q = Math.max(0, i-4); q <= Math.min(hs.length-1, i+4); q++){ s += hs[q]; c++; }
        nh[i] = s/c;
      }
      hs = nh;
    }
    const w = r.w ?? 26, b = r.b ?? 110;
    for(let i = 0; i < nodes.length-1; i++){
      const sg = {x0:nodes[i][0], z0:nodes[i][1], h0:hs[i], x1:nodes[i+1][0], z1:nodes[i+1][1], h1:hs[i+1], w, b,
        road:r.id};
      sg.dx = sg.x1-sg.x0; sg.dz = sg.z1-sg.z0; sg.l2 = sg.dx*sg.dx+sg.dz*sg.dz || 1; segs.push(sg);
      addIndexed(segMap, [Math.min(sg.x0, sg.x1)-w-b, Math.min(sg.z0, sg.z1)-w-b,
        Math.max(sg.x0, sg.x1)+w+b, Math.max(sg.z0, sg.z1)+w+b], sg);
    }
    roads.push({id:r.id, nodes, hs});
  }
  const near = {d:1e9, h:0, sg:null};
  function nearestRoad(x, z){
    near.d = 1e9; near.sg = null;
    const c = segMap.get(cellKey(Math.floor(x/CELL), Math.floor(z/CELL)));
    if(c) for(const s of c){
      const t = clamp(((x-s.x0)*s.dx+(z-s.z0)*s.dz)/s.l2, 0, 1), px = s.x0+s.dx*t, pz = s.z0+s.dz*t;
      const d = Math.hypot(x-px, z-pz);
      if(d < near.d){ near.d = d; near.h = s.h0+(s.h1-s.h0)*t; near.sg = s; }
    }
    return near;
  }
  const H = (x, z) => {
    let h = baseH(x, z); const r = nearestRoad(x, z);
    if(r.sg){ const e = r.d-r.sg.w; if(e < r.sg.b) h += (r.h-h)*(e <= 0 ? 1 : 1-smooth(e/r.sg.b)); }
    return h;
  };
  const out = {road:1e9, pad:null, w:0, d:1e9};
  function info(x, z){
    out.road = nearestRoad(x, z).d; out.pad = null; out.w = 0; out.d = 1e9;
    const c = padMap.get(cellKey(Math.floor(x/CELL), Math.floor(z/CELL)));
    if(c) for(const s of c){ const d = sdSite(s, x, z), w = d <= 0 ? 1 : d < s.b ? 1-d/s.b : 0;
      if(w > out.w){ out.w = w; out.pad = s; out.d = d; } }
    return out;
  }
  return {H, macro, info, pads, roads, byId, baseH};
}
