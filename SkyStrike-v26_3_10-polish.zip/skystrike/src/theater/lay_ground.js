/* مباني المواقع الأرضية: بلدة (بيوت على شبكة مُزاحة) · معسكر/منصّة (حلقة مبانٍ حول ساحة حرّة للأهداف) · محطة رادار.
   المنتصف (≈ نصف القطر) يُترك فارغاً دائماً كي تنزل فيه كيانات المهمة (مدافع/مستودعات) دون اصطدام بالمجسمات. */
const TOWN_WALL = [0xd8cdb6, 0xc9bda2, 0xb9a98c, 0xe0d8c8, 0xa89b84];
const TOWN_ROOF = [0x8a4a36, 0x6b4a3a, 0x5a5f66, 0x7a3f2f];
const SHED = [0x5b6350, 0x6d6a55, 0x4c5648];

export function town(C, s){
  const rng = C.rng, G = 30, cnt = s.n || 40; let placed = 0;
  const cells = [];
  for(let i = -Math.ceil(s.r/G); i <= Math.ceil(s.r/G); i++) for(let j = -Math.ceil(s.r/G); j <= Math.ceil(s.r/G); j++){
    const d = Math.hypot(i, j)*G; if(d <= s.r) cells.push([i, j, d]);
  }
  cells.sort((a, b) => a[2]-b[2]+(rng()-.5)*40);
  for(const [i, j, d] of cells){
    if(placed >= cnt) break;
    const x = s.x+i*G+(rng()-.5)*9, z = s.z+j*G+(rng()-.5)*9;
    if(C.S.info(x, z).road < 22) continue;
    const core = 1-d/s.r, sx = 9+rng()*6, sz = 9+rng()*5, floors = rng() < core*.7 ? 2+(rng() < .4 ? 1 : 0) : 1;
    const sy = 3.6*floors+1, h = C.H(x, z)-.3, yaw = rng() < .5 ? 0 : Math.PI/2;
    const wall = TOWN_WALL[(rng()*TOWN_WALL.length) | 0], roof = TOWN_ROOF[(rng()*TOWN_ROOF.length) | 0];
    C.k(x, z).house(x, h, z, sx, sy, sz, 3, wall, roof, yaw);
    C.l(x, z).box(x+sx/2+.2, h+sy*.55, z, .5, 1.5, 1.5, rng() < .6 ? 0xffd070 : 0xbfe0ff);
    placed++;
  }
  const k = C.k(s.x, s.z), h = C.H(s.x+s.r*.7, s.z);                                  // خزّان ماء مرتفع على الأطراف
  k.cyl(s.x+s.r*.7, h, s.z, 5, 5, 16, 0x9fa3a0, 8, true);
}

export function camp(C, s){
  const rng = C.rng, k = C.k(s.x, s.z), R = s.r, h = s.h, en = s.side === 'enemy';
  k.cyl(s.x, h-.1, s.z, R*.92, R*.92, .35, en ? 0x6e6350 : 0x76705e, 14);                // أرضية ترابية
  const n = 5+((rng()*3) | 0);
  for(let i = 0; i < n; i++){
    const a = i/n*Math.PI*2+rng()*.3, d = R*(.62+rng()*.22), x = s.x+Math.cos(a)*d, z = s.z+Math.sin(a)*d;
    if(i % 2) k.house(x, h, z, 14, 4.5, 7, 2, SHED[i % 3], 0x44493e, a);
    else k.cyl(x, h, z, 5, .6, 3.2, en ? 0x56603f : 0x6b6f58, 6);                         // خيمة
  }
  // أكياس رمل حول الساحة الحرّة
  for(let i = 0; i < 12; i++){
    const a = i/12*Math.PI*2+.13, x = s.x+Math.cos(a)*R*.5, z = s.z+Math.sin(a)*R*.5;
    k.box(x, h+.3, z, 10, 1.3, 1.8, 0x8a7d5a, a+Math.PI/2);
  }
  const a = rng()*6.28, x = s.x+Math.cos(a)*R*.85, z = s.z+Math.sin(a)*R*.85;               // برج مراقبة
  k.box(x, h, z, 3, 8, 3, 0x6a5f48, 0, true); k.box(x, h+8, z, 5.5, 2.8, 5.5, 0x4c4a40);
  C.l(x, z).box(x, h+9.5, z, 1.4, 1.4, 1.4, 0xffd070);
  for(let i = 0; i < 4; i++) k.cyl(s.x+Math.cos(a+2)*R*.7+(i%2)*3, h, s.z+Math.sin(a+2)*R*.7+((i/2) | 0)*3, 1.1, 1.1,
    1.6, 0x3d4d33, 6);
}

export function radar(C, s){
  const k = C.k(s.x, s.z), h = s.h, R = s.r;
  k.cyl(s.x, h-.1, s.z, R*.9, R*.9, .4, 0x6a6c68, 12);
  k.box(s.x+R*.45, h, s.z, 16, 6, 11, 0x7b7f7c, 0, true); k.box(s.x+R*.45, h+6, s.z, 17, .8, 12, 0x4a4f52);
  k.cyl(s.x, h, s.z, 2.4, 1.8, 30, 0x8b8f8d, 8, true);                                     // الصاري
  k.cyl(s.x, h+30, s.z, 11, 1.6, 4.5, 0xc9ccc8, 14);                                      // الطبق
  k.cyl(s.x-R*.5, h, s.z+R*.3, 3.2, 3.2, 4, 0x4f5a47, 8, true);                            // مولّد
  C.l(s.x, s.z).box(s.x, h+35, s.z, 2.2, 2.2, 2.2, 0xff3b30);
  for(let i = 0; i < 8; i++){ const a = i/8*Math.PI*2; k.box(s.x+Math.cos(a)*R*.78, h, s.z+Math.sin(a)*R*.78, 9, 2.2,
    .6, 0x5d6358, a+Math.PI/2); }
}
