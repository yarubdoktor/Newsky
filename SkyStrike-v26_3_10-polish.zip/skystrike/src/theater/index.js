/* واجهة المسارح: makeTheater(lookId) ← إعداد خريطة متوافق مع MAPS. كل شيء ثقيل (مُشكّل/تخطيط/ألوان) كسول ومُخزَّن. */
import {mkNoise} from '../noise.js';
import {TERRAINS} from './terrains.js';
import {LOOKS} from './looks.js';
import {makeShaper} from './shape.js';
import {makeColors} from './colors.js';
import {buildLayout} from './layout.js';
import {buildProps} from './props.js';

const TC = {}, CC = {};
function terr(tid){
  if(!TC[tid]){ const T = TERRAINS[tid], n = mkNoise(T.seed); TC[tid] = {T, n, S:makeShaper(T, n), lay:null}; }
  return TC[tid];
}
const layOf = tid => { const t = terr(tid); return t.lay || (t.lay = buildLayout(t.T, t.S)); };
export function sitesOf(tid){
  const out = {}; for(const p of terr(tid).S.pads)
    out[p.id] = {id:p.id, x:p.x, z:p.z, r:p.r || Math.max(p.hx, p.hz), hx:p.hx, hz:p.hz, h:p.h, type:p.type,
      side:p.side};
  return out;
}

export function makeTheater(id){
  const L = LOOKS[id], tid = L.terrain, T = TERRAINS[tid];
  const cfg = {seed:T.seed, exp:L.exp, water:L.water, sky:L.sky, fog:L.fog, fogFar:L.fogFar, sun:L.sun, hemi:L.hemi,
    cloud:L.cloud,
    pal:L.pal, rock:L.rock, rockNy:L.rockNy, rockMin:L.rockMin, tree:L.tree, city:null, cloudY:L.cloudY,
    ceil:T.ceil, limit:T.limit, spawn:T.spawn, prev:T.prev, theater:tid, night:!!L.night,
    h:() => terr(tid).S.H,
    colorFn:(x, z, o, h) => { const c = CC[id] || (CC[id] = makeColors(L, terr(tid).S, terr(tid).n)); c(x, z, o, h); },
    noTree:(x, z) => { const q = terr(tid).S.info(x, z); return q.d < 25 || q.road < 30; },
    hit:(x, y, z) => layOf(tid).hit(x, y, z),
    buildProps:() => buildProps(layOf(tid), !!L.night)};
  Object.defineProperty(cfg, 'sites', {get:() => sitesOf(tid), enumerable:true});
  return cfg;
}
export {terr, layOf};
