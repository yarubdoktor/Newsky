/* الذكاء الاصطناعي للأعداء: دالة سلوك لكل نوع في الجدول AI. أرقام التوازن كلها بـ enemies.js.
   نوع عدو جديد = مجسم بـ jets.js + أرقام بـ enemies.js + دالة هنا (AI.اسمه) + سطر بـ spawn.js.
   كل دالة تستلم (e, dt, c): c = {pos: موقع اللاعب, w: رقم الموجة, alive: اللاعب حي, dist: المسافة للاعب, ep: موقع العدو}. */
import {clamp,wrap,rnd} from './util.js';
import {JET,ACE,BOMBER,HELI,DRONE,FLAK,TURRET,SAM,AGGR,BOSS_FIRE,bossPhase} from './enemies.js';
import {t} from './i18n.js';
import {sfx} from './audio.js';
import {world,fx,V,vib,dirOfTo} from './core.js';
import {W,P,FW} from './state.js';
import {banner} from './ui.js';
import {shoot,hurt,boom,baseLost,removeEnemy} from './combat.js';
import {checkClear} from './waves.js';
import {addAir} from './spawn.js';
import {farBoost} from './gscale.js';
import {jetThink,maxAttackers} from './ai_jet.js';
import {groundThink,maxCrew} from './ai_ground.js';

const _a = V(), _b = V(), _c = V(), _d = V(), _to = V();   // _to = اتجاه واحد من العدو نحو اللاعب (يُحسب لكل عدو قبل استدعاء سلوكه)
const rr = ([a,b]) => rnd(a,b);
const JC = {};   // سياق مشترك لعقل المقاتلة (يُعاد استعماله بدون إنشاء كائن بالفريم)

function steer(o,ty,tp,rate,dt){
  const dy = wrap(ty-o.yaw); o.yaw += clamp(dy,-rate*dt,rate*dt); o.pitch += clamp(tp-o.pitch,-rate*dt,rate*dt);
  o.g.rotation.set(o.pitch,o.yaw,clamp(-dy*1.2,-1.1,1.1)*.6); return dy;
}
function onBossPhase(e){         // انتقال الزعيم لمرحلة جديدة
  const ph = e.ph; banner(t('bph'+ph)); sfx('alarm'); W.shake = Math.max(W.shake,1.2); boom(e.g.position,e.r); e.cd = 1.2;
  for(let i=0;i<(ph === 1 ? 3 : 4);i++) addAir('drone',V(rnd(-120,120),rnd(-40,40),rnd(-120,120)).add(e.g.position),W.G.wave);
  if(ph === 2){ e.sp *= 1.2; e.tn *= 1.25; e.mcd = Math.min(e.mcd,1); }
}

const GJ = {};   // سياق مشترك لعقل الأرضيات
function ground(e,dt,{pos,w,alive,dist,ep}){     // v26.2.6: العقل بـ ai_ground.js؛ هنا تدوير البرج (تدريجي) + الرمي فقط
  const k = e.kind, G = W.G, m = k === 'sam', D = m ? SAM.msl : k === 'flak' ? FLAK.gun : TURRET.gun;
  let crew = 0; for(const o of W.enemies) if(o !== e && o.ground && (o.gst === 'wrn' || o.gst === 'fir')) crew++;
  Object.assign(GJ,{px:pos.x,py:pos.y,pz:pos.z,vx:FW.x*P.cur,vy:FW.y*P.cur,vz:FW.z*P.cur,ex:ep.x,ey:ep.y+e.muz,ez:ep.z,
    dist,alive,canFire:!m || pos.y > world.ground(pos.x,pos.z)+D.minAlt,rmin:D.min||0,rmax:m ? D.max : D.range,
    gunSp:D.speed,spread:D.spread||0,ag:Math.min(1,AGGR.base+w*AGGR.w),w,crew,maxCrew:maxCrew(w),since:(G.t||0)-(G.gStart ?? -9)});
  const o = groundThink(e,GJ,dt,Math.random);
  if(o.moved) e.g.userData.aim.lookAt(ep.x+o.dx*1e3,ep.y+e.muz+o.dy*1e3,ep.z+o.dz*1e3);
  if(o.start){ G.gStart = G.t; if(dist < 1000 && G.t-(G.gwT ?? -9) > .9){ sfx('warn'); G.gwT = G.t; } }    // تحذير صوتي (البصري: لاحقاً)
  if(!o.shots) return;
  _c.copy(ep); _c.y += e.muz;
  if(m){ _b.set(o.dx,o.dy,o.dz); shoot({owner:'e',pos:_c,dir:_b,speed:D.speed,dmg:D.dmg+w*D.dmgw,mis:true,turn:D.turn,life:D.life}); }
  else for(let i = 0, n = k === 'flak' ? D.burst : 1; i < n; i++){
    _b.set(o.dx+rnd(-o.spread,o.spread),o.dy+rnd(-o.spread,o.spread),o.dz+rnd(-o.spread,o.spread)).normalize();
    shoot({owner:'e',pos:_c,dir:_b,speed:D.speed,dmg:D.dmg+w*D.dmgw}); }
}

const AI = {
  jet(e,dt,{pos,w,alive,dist,ep}){                 // v26.2.5 (بند #9): العقل بـ ai_jet.js (آلة حالات)؛ هنا فقط التنفيذ: توجيه + حركة + رمي
    const D = e.elite ? ACE : JET, gun = D.gun, msl = D.msl, f = P.cur;
    let atk = 0; for(const o of W.enemies) if(o !== e && o.kind === 'jet' && o.bst === 'atk') atk++;          // المهاجمون الآخرون (حدّ التزامن)
    Object.assign(JC,{px:pos.x,py:pos.y,pz:pos.z,vx:FW.x*f,vy:FW.y*f,vz:FW.z*f,fx:FW.x,fy:FW.y,fz:FW.z,sp:f,dist,alive,gh:world.ground(ep.x,ep.z)+60,atk,maxAtk:maxAttackers(w),dodge:D.dodge,gunSp:gun.speed});
    const o = jetThink(e,JC,dt,Math.random,ep);
    const dy = steer(e,o.ty,o.tp,e.tn*o.tnMul,dt); ep.addScaledVector(dirOfTo(e.g,_d),Math.min(e.sp*o.spMul,o.cap)*dt);
    if(alive && o.fire){
      if(dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = (gun.cd-e.ag*gun.cdAg)*gun.cdMul; shoot({owner:'e',pos:ep,dir:_d,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
      else if(w >= msl.from && e.mcd <= 0 && dist > msl.min && dist < msl.max && Math.abs(dy) < msl.aim){ e.mcd = rr(msl.cd)*(1.3-e.ag*.5);
        for(let k=0;k<msl.n;k++){ _b.copy(ep); if(k) _b.x += 7; shoot({owner:'e',pos:_b,dir:_d,speed:msl.speed,dmg:msl.dmg+w*msl.dmgw,mis:true,turn:msl.turn,life:msl.life}); } }
    }
  },
  bomber(e,dt,{w,alive,dist,ep}){
    const G = W.G, gun = BOMBER.gun;
    _a.set(G.obj.x-ep.x,0,G.obj.z-ep.z); const hd = _a.length(), ty = Math.atan2(-_a.x,-_a.z);
    steer(e,ty,clamp((e.alt-ep.y)*.012,-.3,.3),e.tn,dt); ep.addScaledVector(dirOfTo(e.g,_d),e.sp*dt);
    if(alive && dist < gun.range && e.cd <= 0){ e.cd = gun.cd; shoot({owner:'e',pos:ep,dir:_to,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
    if(hd < BOMBER.hit){ G.base -= e.bd; boom(ep,26); sfx('alarm'); vib(60); removeEnemy(e); if(G.base <= 0) baseLost(); else { banner(t('baseHit')); checkClear(); } }
  },
  heli(e,dt,{pos,w,alive,dist,ep}){
    const gun = HELI.gun;
    e.g.userData.rotor.rotation.y += dt*30;
    const r2 = e.g.userData.rotor2; if(r2) r2.rotation.x += dt*40;                // مروحة الذيل (نموذج GLB)
    const dy = steer(e,Math.atan2(-_to.x,-_to.z),0,e.tn,dt); dirOfTo(e.g,_d); _d.y = 0; _d.normalize();
    if(dist > HELI.far) ep.addScaledVector(_d,e.sp*dt); else if(dist < HELI.near) ep.addScaledVector(_d,-e.sp*.6*dt);
    ep.x += -_d.z*e.sd*e.sp*.3*dt; ep.z += _d.x*e.sd*e.sp*.3*dt;
    const wantY = Math.max(world.ground(ep.x,ep.z)+50,pos.y-30); ep.y += clamp(wantY-ep.y,-35,35)*dt;
    if(alive && dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = gun.cd;
      for(let k=-1;k<=1;k++){ _b.copy(_to); _b.x += k*gun.spread; shoot({owner:'e',pos:ep,dir:_b,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); } }
  },
  boss(e,dt,{w,alive,dist,ep}){
    const B = e.b, F = BOSS_FIRE, ph = bossPhase(e); W.G.boss = e; if(ph > e.ph){ e.ph = ph; onBossPhase(e); }
    const dy = steer(e,Math.atan2(-_to.x,-_to.z),Math.asin(clamp(_to.y,-.4,.4)),e.tn,dt);
    if(ep.y < world.ground(ep.x,ep.z)+120) ep.y += 60*dt;
    ep.addScaledVector(dirOfTo(e.g,_d),e.sp*dt); _a.set(1,0,0).applyEuler(e.g.rotation);
    if(alive && dist < F.gun.range && Math.abs(dy) < F.gun.aim && e.cd <= 0){ e.cd = B.gun*(1-ph*F.gun.phCd);
      for(const s of B.guns){ _b.copy(ep).addScaledVector(_a,s*B.span).addScaledVector(_d,12); _c.copy(_to); _c.x += rnd(-F.gun.spread,F.gun.spread); _c.y += rnd(-F.gun.spread,F.gun.spread); shoot({owner:'e',pos:_b,dir:_c,speed:F.gun.speed,dmg:F.gun.dmg+w*F.gun.dmgw}); } }
    if(alive && e.mcd <= 0 && dist > F.msl.min && dist < F.msl.max){ e.mcd = B.msl-ph*F.msl.phCd;
      for(let k=0;k<2+(ph>>1);k++){ const s = k%2 ? 1 : -1; _b.copy(ep).addScaledVector(_a,s*(10+(k>>1)*8)); shoot({owner:'e',pos:_b,dir:_d,speed:F.msl.speed,dmg:F.msl.dmg+w*F.msl.dmgw,mis:true,turn:F.msl.turn,life:F.msl.life}); } }
  },
  drone(e,dt,{w,alive,dist,ep}){          // مسيّرة انتحارية: تلاحقك وتصطدم، ورشقة خفيفة من بعيد
    const gun = DRONE.gun;
    const dy = steer(e,Math.atan2(-_to.x,-_to.z),Math.asin(clamp(_to.y,-.8,.8)),e.tn,dt); ep.addScaledVector(dirOfTo(e.g,_d),e.sp*dt);
    const gh = world.ground(ep.x,ep.z)+25; if(ep.y < gh) ep.y = gh;
    if(alive && dist < DRONE.ramDist){ hurt(DRONE.ram+w); boom(ep,12); vib(40); removeEnemy(e); checkClear(); }
    else if(alive && dist < gun.range && Math.abs(dy) < gun.aim && e.cd <= 0){ e.cd = gun.cd; shoot({owner:'e',pos:ep,dir:_d,speed:gun.speed,dmg:gun.dmg+w*gun.dmgw}); }
  },
  flak:ground, turret:ground, sam:ground         // v26.2.6 (بند #9): عقل الأرضيات بـ ai_ground.js
};

const ctx = {pos:null,w:0,alive:true,dist:0,ep:null};     // سياق مشترك يُعاد استعماله (بدون إنشاء كائن لكل عدو بالفريم)
export function enemiesUpdate(dt){
  const G = W.G, enemies = W.enemies, pos = P.g.position; G.boss = null;
  ctx.pos = pos; ctx.w = G.wave; ctx.alive = !G.dead;
  for(let ei=enemies.length-1;ei>=0;ei--){
    const e = enemies[ei], ep = e.g.position; _to.copy(pos).sub(ep); const dist = _to.length() || 1; _to.divideScalar(dist);
    e.cd -= dt; e.mcd -= dt;
    if(e.lp){ e.vel.copy(ep).sub(e.lp).divideScalar(Math.max(dt,.001)); e.lp.copy(ep); } else { e.vel = V(); e.lp = ep.clone(); }
    if(e.hp < e.max*.5 && Math.random() < dt*14) fx.smk(ep.x,ep.y+(e.air?0:6),ep.z,0x222222,e.r*.35,e.r,1.4,0,8,0,.7);
    if(e.ground && e.g.userData.gk){ const b = farBoost(dist); if(Math.abs(b-e.boost) > .01){ e.boost = b; e.g.scale.setScalar(b); e.r = e.r0*b; } }   // تعزيز المسافة (v26.2.4): يكبر من بعيد، وتصادمه معه
    ctx.dist = dist; ctx.ep = ep;
    const ai = AI[e.kind]; if(ai) ai(e,dt,ctx);
  }
}
