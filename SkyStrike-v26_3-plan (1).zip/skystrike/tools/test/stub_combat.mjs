export const shots = [];
export const shoot = o => shots.push(o);
export const hurt = () => {}, boom = () => {}, baseLost = () => {}, removeEnemy = () => {};
