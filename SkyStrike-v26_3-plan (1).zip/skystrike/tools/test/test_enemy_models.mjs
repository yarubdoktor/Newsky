// يتأكد أن نماذج الأعداء GLB (src/models/e_*.glb) سليمة وفيها العقد اللي تقرأها اللعبة (aim / rotor / rotor2) وحجمها منطقي.
// بدون three: يقرأ JSON الـ GLB مباشرة.
import {readFileSync} from 'node:fs';
const dir = new URL('../../src/models/', import.meta.url);
const NEED = {e_drone:[], e_heli:['rotor','rotor2'], e_aa_twin:['aim'], e_aa_tank:['aim'], e_gepard:['aim'], e_flak:['aim'], e_sam:['aim']};
const GROUND = new Set(['e_aa_twin','e_aa_tank','e_gepard','e_flak','e_sam']);
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
console.log('نماذج الأعداء:');
for(const [k,need] of Object.entries(NEED)){
  const b = readFileSync(new URL(k+'.glb',dir)), len = b.readUInt32LE(12), j = JSON.parse(b.subarray(20,20+len).toString());
  const names = j.nodes.map(n => n.name); const lo = [1e9,1e9,1e9], hi = [-1e9,-1e9,-1e9];
  j.nodes.forEach(n => { const t = n.translation || [0,0,0];
    for(const p of j.meshes[n.mesh].primitives){ const a = j.accessors[p.attributes.POSITION]; for(let i=0;i<3;i++){ lo[i] = Math.min(lo[i],a.min[i]+t[i]); hi[i] = Math.max(hi[i],a.max[i]+t[i]); } } });
  const size = hi.map((v,i) => v-lo[i]);
  ok(names.includes('body') && need.every(n => names.includes(n)),`${k}: عقد ${need.concat('body').join('/')}`);
  ok(Math.max(...size) > 6 && Math.max(...size) < 25,`${k}: أكبر بُعد ${Math.max(...size).toFixed(1)} (المطلوب 6..25)`);
  if(GROUND.has(k)) ok(Math.abs(lo[1]) < .01,`${k}: قاعدته على الأرض y=${lo[1].toFixed(2)}`);
  ok(j.nodes.every(n => j.meshes[n.mesh].primitives.every(p => p.attributes.NORMAL !== undefined)),`${k}: كل المجسمات فيها normals`);
}
// بند #1 (v26.2.2): مقاتلات العدو ما تستعمل نموذج F-35 (enemy.glb) حتى لا تشبه طائرات اللاعب
import {existsSync} from 'node:fs';
const jets = readFileSync(new URL('../../src/jets.js',import.meta.url),'utf8');
console.log('شكل مقاتلة العدو:');
ok(!/enemy\.glb|ENEMY\b/.test(jets),'jets.js ما يرجع لنموذج enemy.glb');
ok(!existsSync(new URL('enemy.glb',dir)),'enemy.glb خارج src/models (انتقل لـ models_src/retired)');
if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
