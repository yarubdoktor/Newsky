/* إنشاء الأعداء والموجات. الأرقام كلها من enemies.js. */
import * as THREE from 'three';
import {rnd} from './util.js';
import {S} from './save.js';
import {HP_SCALE,AGGR,MCD0,JET,ACE,BOMBER,HELI,DRONE,FLAK,TURRET,SAM,DEPOT,BOSS_FIRE,bossFor,dronesFor,elitesFor} from './enemies.js';
import {groundRadius,groundMuzzle} from './gscale.js';
import {mkJet,mkBomber,mkHeli,mkBoss,mkDrone,mkGround,mkDepot} from './jets.js';
import {t} from './i18n.js';
import {sfx} from './audio.js';
import {scene,world,V} from './core.js';
import {W,P} from './state.js';
import {banner} from './ui.js';

const JETC = [0xa03030,0x7a2a2a,0x5a2a40];
const rr = ([a,b]) => rnd(a,b);

export function addAir(kind,pos,w){
  const G = W.G;
  const elite = kind === 'ace'; if(elite) kind = 'jet';
  const f = 1+w*HP_SCALE; let g, hp, r, pts, sp, tn, B = null;
  if(kind === 'jet'){ const D = elite ? ACE : JET;
    g = mkJet(rnd(0,3)|0,elite ? 0xd4af37 : JETC[rnd(0,3)|0],false); hp = D.hp*f; r = D.r; pts = D.pts;
    sp = Math.min(D.spMax,D.sp+w*D.spw); tn = Math.min(D.tnMax,D.tn+w*D.tnw); if(elite) g.scale.setScalar(D.scale); }
  else if(kind === 'bomber'){ g = mkBomber(); hp = BOMBER.hp*f; r = BOMBER.r; pts = BOMBER.pts; sp = BOMBER.sp; tn = BOMBER.tn; }
  else if(kind === 'heli'){ g = mkHeli(); hp = HELI.hp*f; r = HELI.r; pts = HELI.pts; sp = HELI.sp; tn = HELI.tn; }
  else if(kind === 'drone'){ g = mkDrone(); hp = DRONE.hp*f; r = DRONE.r; pts = DRONE.pts; sp = DRONE.sp+w*DRONE.spw; tn = DRONE.tn; }
  else { B = bossFor(w); g = mkBoss(B.id); hp = B.hp+w*B.hpw; r = B.r; pts = BOSS_FIRE.pts; sp = B.sp; tn = B.tn; }
  const e = {kind,g,hp,max:hp,r,pts,sp,tn,cd:rnd(1,3),mcd:elite ? rr(ACE.mcd0) : rr(MCD0),st:0,state:0,sd:Math.random()<.5?-1:1,pitch:0,air:true,alt:pos.y,bd:BOMBER.bd,jk:0,fl:kind === 'jet' ? (elite ? ACE.fl : JET.fl) : 0,ag:Math.min(1,AGGR.base+w*AGGR.w),elite,b:B,ph:0};
  const tx = (G.obj && kind === 'bomber') ? G.obj.x : P.g.position.x, tz = (G.obj && kind === 'bomber') ? G.obj.z : P.g.position.z;
  e.yaw = Math.atan2(-(tx-pos.x),-(tz-pos.z)); g.rotation.order = 'YXZ'; g.position.copy(pos); scene.add(g); W.enemies.push(e); return e;
}
export function addGround(kind,x,z,h,w,tt){
  let g, hp, r, pts;
  if(kind === 'depot'){ g = mkDepot(); hp = DEPOT.hp+w*DEPOT.hpw; r = DEPOT.r; pts = DEPOT.pts; }
  else if(kind === 'sam'){ g = mkGround(3); hp = SAM.hp+w*SAM.hpw; r = SAM.r; pts = SAM.pts; }
  else if(kind === 'flak'){ g = mkGround(4); hp = FLAK.hp+w*FLAK.hpw; r = FLAK.r; pts = FLAK.pts; }
  else { g = mkGround(tt%3); hp = TURRET.hp+w*TURRET.hpw; r = TURRET.r; pts = TURRET.pts; }
  const gk = g.userData.gk; if(gk){ r = groundRadius(gk); }                // v26.2.4: نصف قطر التصادم من حجم النموذج الفعلي (إن كان GLB)
  g.position.set(x,h,z); scene.add(g);
  const e = {kind,g,hp,max:hp,r,r0:r,boost:1,muz:gk ? groundMuzzle(gk) : (kind === 'sam' ? 8 : 6),pts,cd:rnd(1,3),mcd:0,ground:true,air:false}; W.enemies.push(e); return e;
}
function airPos(r0,r1,y0,y1,cx,cz){
  cx = cx ?? P.g.position.x; cz = cz ?? P.g.position.z;
  const a = rnd(0,6.28), r = rnd(r0,r1), x = cx+Math.cos(a)*r, z = cz+Math.sin(a)*r;
  return V(x,Math.max(world.ground(x,z)+90,rnd(y0,y1)),z);
}
export function landPos(cx,cz,rad,tries=80){
  const minH = world.hasWater() ? world.cfg.water.level+5 : -1e9;
  for(let i=0;i<tries;i++){ const x = cx+rnd(-rad,rad), z = cz+rnd(-rad,rad), h = world.H(x,z);
    if(h < minH) continue; if(Math.hypot(world.H(x+8,z)-h,world.H(x,z+8)-h) > 5) continue;
    if(world.cfg.hit && world.cfg.hit(x,h+3,z)) continue;      // لا تضع مدفعاً/صاروخاً داخل مبنى أو هنغر أو تحت جسر
    return {x,z,h}; }
  return null;
}

/* ---------- الأنماط: بقاء / هجوم قواعد / دفاع ---------- */
function spawnSurvive(w){
  const boss = w%5 === 0, nj = boss ? 2 : Math.min(1+w,8), ne = boss ? 0 : elitesFor(w);
  for(let i=0;i<nj;i++) addAir(i < ne ? 'ace' : 'jet',airPos(700,1100,120,260),w);
  if(w >= 2 && !boss) for(let i=0;i<Math.min(1+((w-2)/3|0),3);i++) addAir('heli',airPos(650,950,100,200),w);
  if(!boss) for(let i=0;i<dronesFor(w);i++) addAir('drone',airPos(600,900,100,240),w);
  if(boss) addAir('boss',airPos(1100,1300,260,320),w);
  const ng = boss ? 2 : Math.min(2+w,8), px = P.g.position.x, pz = P.g.position.z;
  for(let i=0;i<ng;i++){ const c = landPos(px,pz,1300); if(!c) continue; addGround(w >= 3 && i%4 === 3 ? 'sam' : w >= 4 && i%4 === 2 ? 'flak' : 'turret',c.x,c.z,c.h,w,i); }
  banner(boss ? t('boss')+' — '+t('bn_'+bossFor(w).id) : t('wave')+' '+w); if(boss) sfx('alarm');
}
function spawnAssault(st){
  const G = W.G;
  const a = rnd(0,6.28), d = rnd(1000,1500), px = P.g.position.x, pz = P.g.position.z;
  const c = landPos(px+Math.cos(a)*d,pz+Math.sin(a)*d,500) || landPos(px,pz,2400,200);
  if(!c){ spawnSurvive(G.wave); return; }
  G.obj = {x:c.x,z:c.z}; addGround('depot',c.x,c.z,c.h,st,0);
  for(let i=0;i<3+st;i++){ const q = landPos(c.x,c.z,170); if(q) addGround('turret',q.x,q.z,q.h,st,i); }
  for(let i=0;i<1+st;i++){ const q = landPos(c.x,c.z,200); if(q) addGround('sam',q.x,q.z,q.h,st,0); }
  if(st >= 2) for(let i=0;i<st;i++) addAir(st === 3 && i === 0 ? 'ace' : 'jet',airPos(250,500,130,220,c.x,c.z),st);
  if(st >= 2){ for(let i=0;i<2;i++) addAir('drone',airPos(250,500,100,200,c.x,c.z),st); for(let i=0;i<st-1;i++){ const q = landPos(c.x,c.z,190); if(q) addGround('flak',q.x,q.z,q.h,st,0); } }
  banner(t('stage')+' '+st+'/'+(G.camp ? G.camp.c.goal : 3));
}
function spawnDefend(w){
  const b = W.G.obj, nb = Math.min(1+w,6), nj = Math.min(w,4);
  for(let i=0;i<nb;i++) addAir('bomber',airPos(2000,2400,260,300,b.x,b.z),w);
  for(let i=0;i<nj;i++) addAir('jet',airPos(1600,2200,150,260,b.x,b.z),w);
  if(w >= 3) addAir('heli',airPos(900,1300,100,180,b.x,b.z),w);
  if(w >= 4) for(let i=0;i<2;i++) addAir('drone',airPos(1200,1600,150,240,b.x,b.z),w);
  banner(t('wave')+' '+w);
}
export function spawnWave(){
  const G = W.G;
  G.hit = false; const w = G.wave;
  if(S.mode === 'assault') spawnAssault(w); else if(S.mode === 'defend') spawnDefend(w); else spawnSurvive(w);
}
export function makeBeacon(){
  const G = W.G;
  const g = new THREE.Group(), m = new THREE.MeshBasicMaterial({color:0x5fd8ff,transparent:true,opacity:.22,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide});
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(6,6,500,16,1,true),m); beam.position.y = 250; g.add(beam);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(46,1.6,8,40),new THREE.MeshBasicMaterial({color:0x5fd8ff})); ring.rotation.x = Math.PI/2; ring.position.y = 2; g.add(ring);
  const pad = new THREE.Mesh(new THREE.CircleGeometry(44,32),new THREE.MeshBasicMaterial({color:0x1d6a8a,transparent:true,opacity:.5})); pad.rotation.x = -Math.PI/2; pad.position.y = 1.4; g.add(pad);
  g.position.set(G.obj.x,Math.max(world.ground(G.obj.x,G.obj.z),0)+.2,G.obj.z); scene.add(g); G.beacon = g;
}
