/* الجهات وجدول العداء. دالة صرفة بلا استيراد. الأسماء والعلامات هنا (والنصوص بـ mission_text.js)
   حتى يسهل تحويلها لأسماء عامة عند الحاجة (سياسات المتجر). */
export const SIDES = {PLAYER:'player', ALLY:'ally', ENEMY:'enemy'};

/* HOSTILE[a][b] = هل الجهة a معادية للجهة b؟ (متماثل) */
export const HOSTILE = {
  player:{player:false, ally:false, enemy:true},
  ally:{player:false, ally:false, enemy:true},
  enemy:{player:true, ally:true, enemy:false}
};

/* nameKey: مفتاح الاسم بـ i18n · color: لون الرادار/العلامات */
export const FACTION = {
  player:{nameKey:'f_player', color:'#5fd8ff'},
  ally:{nameKey:'f_ally', color:'#5fe3a1'},
  enemy:{nameKey:'f_enemy', color:'#ff3b3b'}
};

export const isSide = s => Object.prototype.hasOwnProperty.call(HOSTILE, s);
export const isHostile = (a, b) => !!(HOSTILE[a] && HOSTILE[a][b]);
export const colorOf = s => (FACTION[s] || FACTION.enemy).color;
