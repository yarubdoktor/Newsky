/* إنشاء الكيانات الموضوعة مسبقاً بالمهمة (بدل الظهور العشوائي حول اللاعب). يستعمل addAir/addGround من spawn.js
   ويضيف: side (الجهة) · mid (معرّف المهمة) · obj (هدف رئيسي: علامة بالرادار/الشاشة). المسارات والسلوك: بند M2. */
import {addAir, addGround, landPos} from '../spawn.js';
import {world, V} from '../core.js';
import {anchorOf, GROUND_KINDS} from './entity_pos.js';

/* أقرب أرض صالحة حول المركز؛ يوسّع البحث تدريجياً، وآخر حل: أي نقطة (حتى لا تختفي مهمة بلا هدف) */
function findLand(a){
  for(const m of [1, 2, 4, 8]){ const c = landPos(a.x, a.z, a.rad*m, 120); if(c) return c; }
  return {x:a.x, z:a.z, h:world.ground(a.x, a.z)};
}
export function spawnEntities(def, spawn){
  const placed = {}, w = def.difficulty, out = [];
  def.entities.forEach((d, i) => {
    const a = anchorOf(d.pos, spawn, placed); let e;
    if(GROUND_KINDS.includes(d.kind)){
      const c = findLand(a); placed[d.id] = c; e = addGround(d.kind, c.x, c.z, c.h, w, d.tt ?? i);
    } else {
      placed[d.id] = {x:a.x, z:a.z};
      e = addAir(d.kind, V(a.x, Math.max(world.ground(a.x, a.z)+90, d.alt ?? 180), a.z), w);
    }
    e.side = d.side; e.mid = d.id; e.obj = !!d.obj; out.push(e);
  });
  return out;
}
