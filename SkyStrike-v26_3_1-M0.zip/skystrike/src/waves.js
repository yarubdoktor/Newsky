/* إنهاء الموجة: يُستدعى لما يموت آخر عدو (من combat.kill ومن ai). التقدّم للموجة التالية يتم بـ game.update. */
import {S} from './save.js';
import {mslMax,mulMax,bombMax,planeFlares} from './data.js';
import {t} from './i18n.js';
import {sfx} from './audio.js';
import {W,P} from './state.js';
import {banner} from './ui.js';

export function checkClear(){ const G = W.G; if(G.ms || !W.run || G.dead || G.wait > 0 || W.enemies.length) return; clearWave(); }   // G.ms = مهمة جديدة: لا موجات
function clearWave(){
  const G = W.G;
  G.coins += 40;
  const goal = G.camp ? G.camp.c.goal : (S.mode === 'assault' ? 3 : 0);
  if(goal && G.wave >= goal){ G.win = true; G.wait = 2.8; G.coins += 300; G.xp += 300; banner(t('victory')); sfx('win'); return; }
  const clean = !G.hit; if(clean) G.coins += 60;
  G.wave++; P.hp = Math.min(P.maxhp,P.hp+P.maxhp*.3); P.msl = mslMax(); P.mul = mulMax(); P.bmb = bombMax(); P.flr = planeFlares(); G.wait = 2.2;
  banner(clean ? t('waveClean') : t('waveDown')); sfx('wave');
}
