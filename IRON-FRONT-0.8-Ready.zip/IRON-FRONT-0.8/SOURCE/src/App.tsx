import { useEffect, useRef, useState } from 'react';
import { FortressScene } from './game/FortressScene';
import { RadarMinimap } from './game/RadarMinimap';
import { BUILDINGS, BUILDING_LABELS } from './game/catalog';
import { queueBuilding, upgradeBuilding } from './game/buildingSystem';
import { holdSelected, issueAttack, issueAttackBuilding, issueMove, type Formation } from './game/combatSystem';
import { newGame } from './game/initialState';
import { recruit, repairBase, stepGame, upgrade, UNIT_SPECS } from './game/simulation';
import { RESEARCH } from './game/productionSystem';
import { canAfford } from './game/economy';
import { decodeSave, encodeSave } from './game/saveSystem';
import { buildingArabic, buildingDescription, words, type Language } from './game/i18n';
import { visibleTo } from './game/visibility';
import { battleAudio } from './game/audioSystem';
import type { BuildingKind, GameState, ResearchKind, UnitKind } from './game/types';

declare global {
  interface Window { render_game_to_text:()=>string; advanceTime:(ms:number)=>void; }
}
const time=(seconds:number)=>`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(Math.floor(seconds%60)).padStart(2,'0')}`;
export default function App() {
  const [game,setGame]=useState<GameState>(()=>newGame());
  const [language,setLanguage]=useState<Language>('ar');
  const [tab,setTab]=useState<'command'|'build'|'army'|'support'>('command');
  const [running,setRunning]=useState(true);
  const [moveMode,setMoveMode]=useState(false);
  const [formation,setFormation]=useState<Formation>('line');
  // Tap a friendly building on the map to open its own contextual card (training, upgrades).
  const [selectedBuildingId,setSelectedBuildingId]=useState<string|null>(null);
  const [rallyMode,setRallyMode]=useState(false);
  // The 3D camera reports its orbit target so the radar minimap can frame it, and the
  // minimap pans the camera back through this ref.
  const [camView,setCamView]=useState({x:-8,z:4,dist:48});
  const jumpRef=useRef<((x:number,z:number)=>void)|null>(null);
  // Generals-style phone layout: the command HUD collapses to the bottom so the map fills the screen.
  const [panelOpen,setPanelOpen]=useState(()=>window.innerWidth>=700);
  const [modal,setModal]=useState<'briefing'|'help'|'restart'|null>('briefing');
  const [biome,setBiome]=useState<GameState['biome']>('forest');
  const [difficulty,setDifficulty]=useState<GameState['difficulty']>('normal');
  const [sound,setSound]=useState(false);
  const [speed,setSpeed]=useState(1);
  const [notice,setNotice]=useState('');
  const file=useRef<HTMLInputElement>(null);
  const frameRemainder=useRef(0);
  const previousAudio=useRef({kills:0,losses:0,tick:0});
  const t=words[language],ar=language==='ar';
  const effectiveRunning=running&&!modal&&game.phase==='playing';
  const selected=game.units.filter(u=>u.faction==='player'&&u.selected);
  const friendlies=game.units.filter(u=>u.faction==='player');
  const enemies=game.units.filter(u=>u.faction==='enemy'&&visibleTo(game,'player',u));
  const buildingName=(kind:BuildingKind)=>ar?buildingArabic[kind]:BUILDING_LABELS[kind];
  const unitName=(kind:UnitKind)=>ar?UNIT_SPECS[kind].ar:UNIT_SPECS[kind].name;
  useEffect(()=>{document.documentElement.lang=language;},[language]);
  // (The 3D scene's own PerformanceMeter writes the FPS label; no separate loop needed.)
  useEffect(()=>{
    if(!effectiveRunning)return;
    const interval=window.setInterval(()=>setGame(g=>{
      let next=g;for(let i=0;i<speed;i++)next=stepGame(next,.1);return next;
    }),100);
    return ()=>window.clearInterval(interval);
  },[effectiveRunning,speed]);
  useEffect(()=>{
    window.render_game_to_text=()=>JSON.stringify({
      coordinates:'World x east, z south. Friendly HQ (-12,4); enemy HQ (58,-4).',
      paused:!effectiveRunning,language,...game,
    });
    window.advanceTime=(ms:number)=>{
      if(!effectiveRunning||!Number.isFinite(ms)||ms<0)return;
      frameRemainder.current+=Math.min(ms,120000);
      const steps=Math.floor((frameRemainder.current+1e-6)/100);frameRemainder.current-=steps*100;
      setGame(g=>{let next=g;for(let i=0;i<steps;i++)next=stepGame(next,.1);return next;});
    };
  },[game,effectiveRunning,language]);
  useEffect(()=>{
    const previous=previousAudio.current;
    if(effectiveRunning&&sound){
      if(game.kills>previous.kills||game.losses>previous.losses)battleAudio.play('explosion');
      else if(game.shots.length&&game.tick!==previous.tick)battleAudio.play('shot');
    }
    previousAudio.current={kills:game.kills,losses:game.losses,tick:game.tick};
  },[game.tick,game.kills,game.losses,game.shots.length,sound,effectiveRunning]);
  const selectAll=()=>setGame(g=>({...g,units:g.units.map(u=>({...u,selected:u.faction==='player'}))}));
  useEffect(()=>{
    const handle=(event:KeyboardEvent)=>{
      if(event.target instanceof HTMLInputElement||event.target instanceof HTMLSelectElement||modal)return;
      if(event.code==='Space'&&event.target instanceof HTMLButtonElement)return;
      if(event.code==='Space'){event.preventDefault();setRunning(v=>!v);}
      if(event.key.toLowerCase()==='a'){event.preventDefault();selectAll();}
      if(event.key.toLowerCase()==='m'&&selected.length)setMoveMode(v=>!v);
      if(event.key==='Escape'){setMoveMode(false);setSelectedBuildingId(null);}
    };
    window.addEventListener('keydown',handle);return ()=>window.removeEventListener('keydown',handle);
  },[modal,selected.length]);
  const selectUnit=(id:number,isEnemy:boolean,multi:boolean)=>{
    if(isEnemy){setGame(g=>issueAttack(g,id));setMoveMode(false);return;}
    setGame(g=>({...g,units:g.units.map(u=>u.id===id?{...u,selected:multi?!u.selected:true}:multi?u:{...u,selected:false})}));
  };
  const moveUnits=(x:number,z:number)=>{
    if(!moveMode)return;
    setGame(g=>issueMove(g,x,z,formation));setMoveMode(false);
  };
  const placeRally=(x:number,z:number)=>{
    if(!rallyMode)return;
    setGame(g=>({...g,rally:{x,z},message:'RALLY POINT SET / تم تحديد نقطة التجمع'}));
    setRallyMode(false);
  };
  const attackHQ=()=>{setGame(g=>issueAttack(g,-1));setMoveMode(false);};
  const attackBuilding=(id:string)=>{setGame(g=>issueAttackBuilding(g,id));setMoveMode(false);};
  const rectSelectIds=(ids:number[],additive:boolean)=>setGame(g=>({...g,units:g.units.map(u=>
    u.faction!=='player'?u:ids.includes(u.id)?{...u,selected:additive?!u.selected:true}:additive?u:{...u,selected:false})}));
  const selectBuilding=(id:string)=>{
    setSelectedBuildingId(current=>current===id?null:id);
    setGame(g=>({...g,units:g.units.map(u=>({...u,selected:false}))}));
    setMoveMode(false);
  };
  const begin=()=>{
    setGame(newGame(biome,difficulty));setRunning(true);setModal(null);setMoveMode(false);
    setTab('command');setNotice('');frameRemainder.current=0;setSelectedBuildingId(null);
  };
  const save=()=>{
    try{
      const blob=new Blob([encodeSave(game)],{type:'application/json'}),url=URL.createObjectURL(blob);
      const anchor=document.createElement('a');anchor.href=url;anchor.download=`IRON-FRONT-${Math.floor(game.tick)}.json`;
      document.body.append(anchor);anchor.click();anchor.remove();window.setTimeout(()=>URL.revokeObjectURL(url),1000);
      setNotice(t.saveOk);
    }catch{setNotice(t.saveError);}
  };
  const importSave=async(selectedFile:File|undefined)=>{
    if(!selectedFile)return;
    try{
      if(selectedFile.size>500000)throw new Error('size');
      const loaded=decodeSave(await selectedFile.text());
      setGame(loaded);setBiome(loaded.biome);setDifficulty(loaded.difficulty);
      setRunning(false);setMoveMode(false);setModal(null);setNotice(t.loadOk);frameRemainder.current=0;
    }catch{setNotice(t.loadError);}
    finally{if(file.current)file.current.value='';}
  };
  const scene=<FortressScene state={game} paused={!effectiveRunning} onSelect={selectUnit}
    onMoveOrder={moveUnits} onAttackBuilding={attackBuilding} onRectSelect={rectSelectIds}
    moveMode={moveMode} rallyMode={rallyMode} onSetRally={placeRally}
    onSelectBuilding={selectBuilding} selectedBuildingId={selectedBuildingId}
    onCameraMove={(x,z,dist)=>setCamView(cv=>Math.abs(cv.x-x)+Math.abs(cv.z-z)+Math.abs(cv.dist-dist)>.5?{x,z,dist}:cv)}
    jumpRef={jumpRef}/>;
  const ended=game.phase!=='playing';
  const count=(kind:BuildingKind)=>game.buildings.filter(b=>b.kind===kind).length;
  // The tapped friendly building opens its own contextual card: training and upgrades live on the map.
  const selectedBuilding=game.buildings.find(b=>b.id===selectedBuildingId)??null;
  const trainableUnits=selectedBuilding?(Object.keys(UNIT_SPECS) as UnitKind[])
    .filter(kind=>UNIT_SPECS[kind].building===selectedBuilding.kind):[];
  const fieldControls=<div className="field-controls">
    <button onClick={()=>setModal('help')}>{t.help}</button>
    <span className="performance" id="performance">3D / WEBGL</span>
  </div>;
  return <main className={`app-shell${panelOpen?'':' map-focus'}`} dir={ar?'rtl':'ltr'}>
    <header className="topbar">
      <div className="brand" dir="ltr"><div className="brand-mark">IF</div><div><strong>IRON FRONT</strong><span>TOTAL DOMINATION</span></div></div>
      <div className="resources">{(['steel','fuel','power','ammo'] as const).map(key=>
        <div key={key}><small>{t[key]}</small><b>{Math.floor(game.resources[key]).toLocaleString('en-US')}</b></div>)}</div>
      <div className="top-actions"><button onClick={()=>setLanguage(ar?'en':'ar')} aria-label="Change language">{ar?'EN':'العربية'}</button>
        <button className="save-btn" onClick={save}>{t.save}</button>
        <button className="audio-btn" aria-pressed={sound} onClick={async()=>{try{setSound(await battleAudio.toggle());}catch{setNotice(ar?'الصوت غير متاح':'Audio unavailable');}}}>{sound?'SFX ON':'SFX OFF'}</button></div>
    </header>
    <section className="battle-area" aria-label={t.mission} dir="ltr">
      <div className="map-label"><span className="live-dot"/>{t.mission}<small>{t.sector}</small></div>
      <div className="map-stage">{scene}</div>
      {/* Radar minimap: the whole field at a glance; tap it to pan the 3D camera. */}
      <RadarMinimap state={game} onJump={(x,z)=>jumpRef.current?.(x,z)}
        viewRect={{x:camView.x-camView.dist*.42,z:camView.z-camView.dist*.24,w:camView.dist*.84,h:camView.dist*.48}}/>
      <div className="map-vignette"/>
      <div className="status-stack">
        <div><small className="full-label">{t.hq}</small><small className="compact-label">{ar?'قاعدتك':'YOUR HQ'}</small><b>{Math.ceil(game.baseHp)}%<span className="health"><i style={{width:game.baseHp+'%'}}/></span></b></div>
        <div className="enemy"><small className="full-label">{t.enemyHQ}</small><small className="compact-label">{ar?'العدو':'HOSTILE'}</small><b>{Math.ceil(game.enemyHp)}%<span className="health"><i style={{width:game.enemyHp+'%'}}/></span></b></div>
      </div>
      {fieldControls}
      {!effectiveRunning&&!modal&&!ended&&<button className="pause-overlay" onClick={()=>setRunning(true)}>{t.resume}</button>}
      <div className="map-coords">{t.friendly} {friendlies.length} / {t.hostile} {enemies.length} / {t.wave} {game.wave}
        <span>{t.next} {Math.ceil(Math.max(0,game.nextWave-game.tick))}{t.seconds}</span></div>
      <div className={`unit-hint ${moveMode||rallyMode?'armed':''}`}>{moveMode?t.moveHint:rallyMode?(ar?'اضغط على الخريطة لتحديد نقطة تجمع القوات الجديدة':'TAP THE MAP TO PLACE THE RALLY FLAG'):selected.length?`${selected.length} ${t.selected}`:t.hint}</div>
      {/* The live training strip is always visible on the map: progress and time remaining. */}
      {game.training.length>0&&<div className="training-strip" dir={ar?'rtl':'ltr'} aria-label={t.queue}>
        {game.training.map((item,i)=><div key={item.id} className={i===0?'active':''}>
          <b>{unitName(item.kind)}</b><progress max={item.total} value={item.total-item.remaining}/>
          <small>{i===0?Math.ceil(item.remaining)+t.seconds:ar?'بالانتظار':'QUEUED'}</small></div>)}
      </div>}
      {selectedBuilding&&<aside className="building-card" dir={ar?'rtl':'ltr'} aria-label={buildingName(selectedBuilding.kind)}>
        <div className="bc-head">
          <div><b>{buildingName(selectedBuilding.kind)}</b>
            <small>LV {selectedBuilding.level} / {Math.ceil(selectedBuilding.hp)}/{selectedBuilding.maxHp} HP{selectedBuilding.status==='constructing'?` / ${t.constructing}`:''}</small></div>
          <button className="bc-close" aria-label={ar?'إغلاق':'CLOSE'} onClick={()=>setSelectedBuildingId(null)}>×</button>
        </div>
        {selectedBuilding.status==='constructing'
          ?<div className="bc-progress"><progress max={selectedBuilding.buildSeconds} value={selectedBuilding.buildSeconds-selectedBuilding.remaining}/>
            <small>{Math.ceil(selectedBuilding.remaining)}{t.seconds}</small></div>
          :<div className="bc-body">
            {trainableUnits.length>0&&<div className="bc-train">{trainableUnits.map(kind=>{
              const spec=UNIT_SPECS[kind],affordable=canAfford(game.resources,spec)&&game.resources.ammo>=spec.ammo;
              const blocked=game.training.length>=5||friendlies.length+game.training.length>=24;
              return <button key={kind} disabled={!affordable||blocked||ended} onClick={()=>setGame(g=>recruit(g,kind))}>
                <b>{unitName(kind)}</b><small dir="ltr">{spec.steel}S {spec.fuel}F {spec.power}P {spec.ammo}A / {spec.seconds}s</small></button>;})}
            </div>}
            <div className="bc-actions">
              {selectedBuilding.level<3&&<button disabled={ended} className="primary-action"
                onClick={()=>setGame(g=>upgradeBuilding(g,selectedBuilding.id))}>{ar?`تطوير إلى المستوى ${selectedBuilding.level+1}`:`UPGRADE TO LV ${selectedBuilding.level+1}`}</button>}
              {selectedBuilding.kind==='hq'&&<button disabled={game.baseHp>=100||game.resources.steel<120||ended}
                onClick={()=>setGame(g=>repairBase(g))}>{t.repair}<small>{t.repairCost}</small></button>}
            </div>
          </div>}
      </aside>}
    </section>
    <section className={`command-panel${panelOpen?'':' collapsed'}`} id="commands">
      <div className="panel-head">
        <div><small>{t.playing}</small><h1>{ar?'قيادة العمليات':'FORTRESS OPERATIONS'}</h1></div>
        <div className="online"><span className={effectiveRunning?'live-dot':''}/>{effectiveRunning?t.active:t.paused}<b dir="ltr">T+ {time(game.tick)}</b></div>
        {!panelOpen&&<div className="quick-bar">
          <button onClick={()=>{setRunning(v=>!v);setMoveMode(false);}}>{running?t.pause:t.resume}</button>
          <button onClick={()=>setSpeed(v=>v===1?2:v===2?4:1)} aria-label="Simulation speed">{speed}×</button>
          <button onClick={selectAll} disabled={!game.units.some(u=>u.faction==='player')}>{t.selectAll}</button>
        </div>}
        <button className="panel-toggle" aria-expanded={panelOpen} onClick={()=>setPanelOpen(v=>!v)}>
          {panelOpen?(ar?'إخفاء الأوامر ▾':'HIDE COMMANDS ▾'):(ar?'الأوامر ▴':'COMMANDS ▴')}
        </button>
      </div>
      {panelOpen&&<nav className="tabs" aria-label={ar?'لوحات القيادة':'Command panels'}>{(['command','build','army','support'] as const).map(key=>
        <button key={key} aria-pressed={tab===key} className={tab===key?'active':''} onClick={()=>setTab(key)}>{t[key]}</button>)}</nav>}
      {panelOpen&&<div className="panel-body">
        {tab==='command'&&<div className="command-content">
          <div className="command-summary"><b>{t.objective}</b><p>{effectiveRunning?(ar?'المناطق المركزية تنتج الحديد عند السيطرة عليها. موارد الصناعة محدودة؛ احمِ المنشآت وراقب الذخيرة.':'Capture central depots for steel. Industrial reserves are finite. Protect your production and watch ammunition.') : t.pausedText}</p>
            <small>{t.kills} {game.kills} / {t.losses} {game.losses} / {ar?'احتياطي الصناعة':'INDUSTRIAL RESERVE'} {game.reserve.toLocaleString('en-US')}</small>
          </div>
          <div className="action-row">
            <button className={moveMode?'primary-action':''} aria-pressed={moveMode} disabled={!selected.length||ended} onClick={()=>setMoveMode(v=>!v)}>{moveMode?t.cancel:t.move}</button>
            <button className={rallyMode?'primary-action':''} aria-pressed={rallyMode} disabled={ended} onClick={()=>{setRallyMode(v=>!v);setMoveMode(false);}}>{ar?'نقطة التجمع':'RALLY POINT'}</button>
            <button disabled={!friendlies.length||ended} onClick={selectAll}>{t.selectAll}</button>
            <button disabled={!selected.length||ended} onClick={()=>{setGame(g=>holdSelected(g));setMoveMode(false);}}>{t.hold}</button>
            <button className="attack-action" disabled={!selected.length||ended} onClick={attackHQ}>{t.attackHQ}</button>
            <button disabled={!selected.length||ended} onClick={()=>{setGame(g=>issueMove(g,-5,4));setMoveMode(false);}}>{ar?'تراجع':'RETREAT'}</button>
            <button disabled={ended} onClick={()=>{setRunning(v=>!v);setMoveMode(false);}}>{running?t.pause:t.resume}</button>
            <button onClick={()=>setSpeed(v=>v===1?2:v===2?4:1)} aria-label="Simulation speed">{speed}×</button>
          </div>
          <div className="action-row formation-row"><small>{t.formation}</small>
            {(['line','wedge','flank'] as const).map(f=>
              <button key={f} aria-pressed={formation===f} className={formation===f?'primary-action':''} onClick={()=>setFormation(f)}>{t[f]}</button>)}
          </div>
          <div className="mini-map"><RadarMinimap state={game} onJump={(x,z)=>jumpRef.current?.(x,z)} inline/><small>{ar?'الرادار التكتيكي':'TACTICAL RADAR'}</small></div>
        </div>}
        {tab==='build'&&<div className="construction-grid">{BUILDINGS.map(spec=>{
          const active=game.buildings.find(b=>b.kind===spec.kind&&b.status==='active');
          const inProgress=game.buildings.find(b=>b.kind===spec.kind&&b.status==='constructing');
          const limit=spec.kind==='wall'?10:spec.kind==='watchtower'?4:1;
          const limitReached=count(spec.kind)>=limit,affordable=canAfford(game.resources,spec.cost);
          return <article className="construction-card" key={spec.kind}>
            <div className="building-symbol">{spec.short}</div><div className="building-copy"><b>{buildingName(spec.kind)}</b>
              <small>{ar?buildingDescription[spec.kind]??'تدريب المشاة والقناصة والمهندسين':spec.description}</small>
              <span className="cost" dir="ltr">{spec.cost.steel} S / {spec.cost.fuel} F / {spec.cost.power} P / {spec.seconds}s</span>
              {inProgress&&<><progress max={inProgress.buildSeconds} value={inProgress.buildSeconds-inProgress.remaining}/><small>{Math.ceil(inProgress.remaining)}{t.seconds}</small></>}
              {active&&<small className="built-label">{t.operational} / LV {active.level} / {Math.ceil(active.hp)} HP</small>}
            </div><div className="card-buttons">
              <button disabled={limitReached||!affordable||ended} onClick={()=>setGame(g=>queueBuilding(g,spec.kind))}>{limitReached?t.limit:!affordable?t.unaffordable:t.buy}</button>
              {active&&active.level<3&&<button disabled={ended} onClick={()=>setGame(g=>upgradeBuilding(g,active.id))}>{ar?'تطوير':'UPGRADE'} {active.level+1}</button>}
            </div>
          </article>;
        })}</div>}
        {tab==='army'&&<div className="army-content">
          <p className="army-hint">{ar?'اضغط على أي مبنى في الخريطة لفتح لوحة تدريبه وتطويره.':'Tap any building on the map to open its training and upgrade card.'}</p>
          <div className="training-queue"><b>{t.queue} ({game.training.length}/5)</b>{game.training.length?game.training.map((item,i)=>
            <div key={item.id}><span>{unitName(item.kind)} #{item.id}</span><progress max={item.total} value={item.total-item.remaining}/><small>{i===0?Math.ceil(item.remaining)+t.seconds:ar?'انتظار':'QUEUED'}</small></div>):<small>{t.emptyQueue}</small>}</div>
          <div className="roster"><b>{t.friendly} ({friendlies.length}/24)</b>{!friendlies.length&&<p>{t.noUnits}</p>}
            {friendlies.map(u=><button key={u.id} aria-pressed={u.selected} className={u.selected?'selected-unit':''} onClick={()=>selectUnit(u.id,false,true)}>
              {unitName(u.kind)} #{u.id}<span>{Math.ceil(u.hp)}/{u.maxHp} HP / {u.order.toUpperCase()}</span></button>)}
          </div>
        </div>}
        {tab==='support'&&<div className="support-content">
          <div className="research-grid">{(Object.keys(RESEARCH) as ResearchKind[]).map(kind=>{
            const spec=RESEARCH[kind],done=game.technologies[kind]>0,job=game.research?.kind===kind?game.research:null;
            const ready=game.buildings.some(b=>b.kind==='research'&&b.status==='active');
            return <article className="unit-card" key={kind}><b>{ar?spec.ar:spec.en}</b>
              <span className="cost" dir="ltr">{spec.steel} S / {spec.fuel} F / {spec.power} P / {spec.seconds}s</span>
              {job&&<progress max={job.total} value={job.total-job.remaining}/>}
              <button disabled={done||!!game.research||!ready||!canAfford(game.resources,spec)||ended} onClick={()=>setGame(g=>upgrade(g,kind))}>
                {done?t.operational:job?Math.ceil(job.remaining)+t.seconds:!ready?buildingName('research'):ar?'ابدأ البحث':'RESEARCH'}</button>
            </article>;
          })}</div>
          <div className="support-actions"><button disabled={game.baseHp>=100||game.resources.steel<120||ended} onClick={()=>setGame(g=>repairBase(g))}>{t.repair}<small>{t.repairCost}</small></button>
            <button disabled={ended} onClick={()=>setGame(g=>upgradeBuilding(g,'HQ-001'))}>{ar?'تطوير المقر':'UPGRADE HQ'}</button>
            <button onClick={save}>{t.save}</button><button onClick={()=>file.current?.click()}>{t.load}</button>
            <button onClick={()=>setModal('restart')}>{t.newMission}</button>
            <button aria-pressed={sound} onClick={async()=>{try{setSound(await battleAudio.toggle());}catch{setNotice(ar?'الصوت غير متاح':'Audio unavailable');}}}>{sound?'SFX ON':'SFX OFF'}</button></div>
          <div className="event-log" aria-label={ar?'سجل العمليات':'Military event log'}>{game.events.slice(-8).reverse().map((event,i)=><div key={`${event.time}-${i}`}><time dir="ltr">{time(event.time)}</time><span>{event.text}</span></div>)}</div>
        </div>}
      </div>}
      {panelOpen&&<footer className="footer-line"><span className="log-dot"/><span>{notice||game.message}</span>
        {notice&&<button aria-label="Dismiss notification" onClick={()=>setNotice('')}>×</button>}
        <span className="footer-units">{selected.length} {t.selected} / {friendlies.length} {t.friendly}</span>
      </footer>}
    </section>
    <input ref={file} type="file" accept=".json,application/json" aria-label={t.load} hidden onChange={e=>void importSave(e.target.files?.[0])}/>
    {(modal||ended)&&<div className="modal-backdrop"><section className="mission-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
      <div className="dialog-eyebrow" dir="ltr">IRON FRONT / TOTAL DOMINATION / 0.8</div>
      <h2 id="dialog-title">{ended?(game.phase==='victory'?t.victory:t.defeat):modal==='restart'?t.restartTitle:t.briefing}</h2>
      <p>{ended?(game.phase==='victory'?t.victoryText:t.defeatText):modal==='restart'?t.restartText:t.objective}</p>
      {ended?<div className="result-stats"><div><b>{game.kills*100+Math.ceil(game.baseHp)*10-game.losses*25}</b><small>{t.score}</small></div>
        <div><b>{time(game.tick)}</b><small>{ar?'مدة المعركة':'BATTLE TIME'}</small></div><div><b>{game.kills} / {game.losses}</b><small>{t.kills} / {t.losses}</small></div></div>
      :modal!=='restart'&&<><p>{t.instructions}</p><p className="controls-copy">{t.controls}</p>
        <div className="settings-grid"><label>{ar?'ميدان المعركة':'BATTLEFIELD'}<select value={biome} onChange={e=>setBiome(e.target.value as GameState['biome'])} disabled={modal==='help'}>
          <option value="forest">{ar?'وادي الغابات':'FOREST VALLEY'}</option><option value="desert">{ar?'الحدود الصحراوية':'DESERT FRONTIER'}</option><option value="snow">{ar?'الجبهة المتجمدة':'FROZEN FRONT'}</option></select></label>
          <label>{ar?'صعوبة التخطيط المعادي':'AI DIFFICULTY'}<select value={difficulty} onChange={e=>setDifficulty(e.target.value as GameState['difficulty'])} disabled={modal==='help'}>
            <option value="easy">{ar?'سهل':'EASY'}</option><option value="normal">{ar?'عادي':'NORMAL'}</option><option value="hard">{ar?'صعب':'HARD'}</option></select></label></div>
        <small>{ar?'الخصم يدفع تكاليف البناء والإنتاج نفسها، دون موارد مجانية.':'The opponent pays the same costs, with no free resources or reinforcements.'}</small></>}
      <div className="dialog-actions">{modal==='help'&&!ended?<button className="primary-action" onClick={()=>setModal(null)}>{t.resume}</button>:
        <button id="start-btn" className="primary-action" onClick={begin}>{ended||modal==='restart'?t.newMission:t.start}</button>}
        {!ended&&modal==='restart'&&<button onClick={()=>setModal(null)}>{t.cancel}</button>}
        {modal==='briefing'&&<button onClick={()=>file.current?.click()}>{t.load}</button>}
        {ended&&<button onClick={save}>{t.save}</button>}
        <button onClick={()=>setLanguage(ar?'en':'ar')}>{ar?'English':'العربية'}</button>
      </div>
    </section></div>}
  </main>;
}
