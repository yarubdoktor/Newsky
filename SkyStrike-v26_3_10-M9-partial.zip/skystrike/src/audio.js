let ac, master, eng, eng2, engF, engG, engN, nb, muted = false, musOn = true, musG = null, musTimer = 0, nextT = 0, step = 0, intensity = 0;
export function setMute(m){ muted = m; if(master) master.gain.value = m ? 0 : .55; }
export function setMusic(on){ musOn = on; if(!on) stopMusic(); }
export function initAudio(){
  if(ac){ ac.resume(); return; }
  const C = window.AudioContext || window.webkitAudioContext; if(!C) return;
  ac = new C(); master = ac.createGain(); master.gain.value = muted ? 0 : .55; master.connect(ac.destination);
  nb = ac.createBuffer(1, ac.sampleRate*2, ac.sampleRate); const d = nb.getChannelData(0); for(let i=0;i<d.length;i++) d[i] = Math.random()*2-1;
  eng = ac.createOscillator(); eng.type = 'sawtooth'; eng.frequency.value = 60;
  engF = ac.createBiquadFilter(); engF.type = 'lowpass'; engF.frequency.value = 300;
  engG = ac.createGain(); engG.gain.value = 0; eng2 = ac.createOscillator(); eng2.type = 'sawtooth'; eng2.frequency.value = 60; eng2.connect(engF); eng2.start();
  eng.connect(engF); engF.connect(engG); engG.connect(master); eng.start();
  const n = ac.createBufferSource(); n.buffer = nb; n.loop = true; const nf = ac.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 500;
  engN = ac.createGain(); engN.gain.value = 0; n.connect(nf); nf.connect(engN); engN.connect(master); n.start();
}
export function suspendAudio(s){ if(!ac) return; s ? ac.suspend() : ac.resume(); }
export function setEngine(r, b = 0){
  if(!ac) return; const t = ac.currentTime;
  if(r <= 0){ engG.gain.setTargetAtTime(0,t,.1); engN.gain.setTargetAtTime(0,t,.1); return; }
  const f = ep.f+r*ep.fr+b*ep.fb; eng.frequency.setTargetAtTime(f,t,.15); eng2.frequency.setTargetAtTime(f,t,.15); engF.frequency.setTargetAtTime(ep.c+b*ep.cb,t,.2);
  engG.gain.setTargetAtTime((ep.g+b*.06)*.75,t,.15); engN.gain.setTargetAtTime((.04+b*.1)*ep.n,t,.2);
}
/* صوت محرك ومدفع مخصص لكل طائرة: 0=احتياطي (هدير عميق؛ لا طائرة لاعب به منذ M8) ، 1=MiG-29 (صفير حاد + محركين) ، 2=Su-57 (هدير مزدوج) */
const EP = {
  0:{t:'sawtooth',f:48,fr:26,fb:36,c:230,cb:420,n:1,   g:.10, d:4,  gp:1},
  1:{t:'sawtooth',f:72,fr:38,fb:56,c:330,cb:760,n:1.25,g:.10, d:22, gp:1.3},
  2:{t:'square',  f:56,fr:30,fb:48,c:260,cb:560,n:1.1, g:.085,d:30, gp:.85}
};
let ep = EP[0], gp = 1;
export function setEngineKind(k){ ep = EP[k] || EP[0]; gp = ep.gp; if(!ac) return; eng.type = ep.t; eng2.type = ep.t; eng2.detune.value = ep.d; }
function out(pan){
  if(pan == null || !ac.createStereoPanner) return master;
  const p = ac.createStereoPanner(); p.pan.value = pan; p.connect(master); return p;
}
function burst(dur,f0,f1,type,vol,q=1,delay=0,pan){
  const t = ac.currentTime+delay, s = ac.createBufferSource(); s.buffer = nb;
  const f = ac.createBiquadFilter(); f.type = type; f.Q.value = q; f.frequency.setValueAtTime(f0,t); f.frequency.exponentialRampToValueAtTime(f1,t+dur);
  const g = ac.createGain(); g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+dur);
  s.connect(f); f.connect(g); g.connect(out(pan)); s.start(t, Math.random()*.3, dur+.05);
}
function tone(f0,f1,dur,type,vol,delay=0,pan){
  const t = ac.currentTime+delay, o = ac.createOscillator(), g = ac.createGain(); o.type = type;
  o.frequency.setValueAtTime(f0,t); o.frequency.exponentialRampToValueAtTime(f1,t+dur);
  g.gain.setValueAtTime(vol,t); g.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(g); g.connect(out(pan)); o.start(t); o.stop(t+dur+.02);
}
// pan: -1 يسار .. 1 يمين (صوت مكاني)
export function sfx(k, v = 1, big = false, pan){
  if(!ac || muted) return;
  switch(k){
    case 'gun': burst(.07,3500*gp,900*gp,'bandpass',.22,1.2); tone(220*gp,80*gp,.06,'square',.08); break;
    case 'efire': burst(.08,2000,500,'bandpass',.12*v,1,0,pan); break;
    case 'msl': burst(.9,400,2500,'lowpass',.35); tone(120,300,.5,'sawtooth',.12); break;
    case 'emsl': burst(.7,500,2000,'lowpass',.25*v,1,0,pan); break;
    case 'boom': burst(big?1.4:.9,big?900:1400,60,'lowpass',.9*v,.7,0,pan); tone(big?90:130,28,big?1.1:.7,'sine',.8*v,0,pan); if(big) burst(.5,3000,300,'highpass',.25*v,.8,0,pan); break;
    case 'hit': burst(.18,1200,200,'lowpass',.5); tone(160,60,.15,'square',.15); break;
    case 'lock': tone(1400,1400,.07,'sine',.14); tone(1400,1400,.07,'sine',.14,.12); break;
    case 'radio': tone(1700,1700,.05,'square',.07); tone(1300,1300,.06,'square',.07,.08); break;
    case 'warn': tone(900,700,.15,'square',.08); break;
    case 'alarm': tone(1100,1100,.09,'square',.11); tone(1100,1100,.09,'square',.11,.14); break;
    case 'flare': burst(.6,7000,2500,'highpass',.2); tone(1800,900,.25,'triangle',.07); break;
    case 'wave': tone(520,520,.12,'triangle',.2); tone(660,660,.12,'triangle',.2,.13); tone(880,880,.25,'triangle',.2,.26); break;
    case 'win': for(let i=0;i<5;i++) tone(523*Math.pow(1.26,i),523*Math.pow(1.26,i),.22,'triangle',.18,i*.14); break;
  }
}

/* ---------- موسيقى توليدية (بدون ملفات): باص + أكورد + أربيجيو + طبول، تسرع وتشتد مع المعركة ---------- */
const ROOT = [45,45,41,43], ARP = [0,7,12,7,15,12,7,3], mtof = m => 440*Math.pow(2,(m-69)/12);
function mn(f,t,d,type,v,cut){
  const o = ac.createOscillator(), g = ac.createGain(), fl = ac.createBiquadFilter(); o.type = type; o.frequency.value = f; fl.type = 'lowpass'; fl.frequency.value = cut;
  g.gain.setValueAtTime(.0001,t); g.gain.exponentialRampToValueAtTime(v,t+.02); g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(fl); fl.connect(g); g.connect(musG); o.start(t); o.stop(t+d+.05);
}
function mnoise(t,d,v,hp){
  const s = ac.createBufferSource(); s.buffer = nb; const f = ac.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp;
  const g = ac.createGain(); g.gain.setValueAtTime(v,t); g.gain.exponentialRampToValueAtTime(.001,t+d); s.connect(f); f.connect(g); g.connect(musG); s.start(t,Math.random()*.5,d+.05);
}
function kick(t){
  const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(140,t); o.frequency.exponentialRampToValueAtTime(40,t+.15);
  g.gain.setValueAtTime(.7,t); g.gain.exponentialRampToValueAtTime(.001,t+.22); o.connect(g); g.connect(musG); o.start(t); o.stop(t+.25);
}
function sched(){
  if(!ac || !musG || muted || !musOn) return;
  const bpm = 92+intensity*34, st = 60/bpm/2;
  while(nextT < ac.currentTime+.4){
    const bar = (step>>4)&3, s = step&15, root = ROOT[bar];
    if(s%2 === 0) mn(mtof(root),nextT,st*1.8,'sawtooth',.5,350+intensity*500);
    if(s === 0) for(const iv of [0,7,12]) mn(mtof(root+12+iv),nextT,st*14,'sawtooth',.1,900);
    if(intensity > .25) mn(mtof(root+24+ARP[s%8]),nextT,st*.9,'triangle',.16*(.4+intensity),1800+intensity*2000);
    if(s%4 === 0 && intensity > .05) kick(nextT);
    if(intensity > .1 && s%2 === 1) mnoise(nextT,.05,.1*intensity+.03,7000);
    nextT += st; step++;
  }
}
export function startMusic(){
  if(!ac || !musOn || musTimer) return;
  musG = ac.createGain(); musG.gain.value = .2; musG.connect(master); nextT = ac.currentTime+.1; step = 0; musTimer = setInterval(sched,120);
}
export function stopMusic(){
  if(musTimer){ clearInterval(musTimer); musTimer = 0; }
  if(musG){ const g = musG; g.gain.setTargetAtTime(0,ac.currentTime,.25); setTimeout(() => { try { g.disconnect(); } catch(e){} },1500); musG = null; }
}
export function setIntensity(x){ intensity = Math.max(0,Math.min(1,x)); }
