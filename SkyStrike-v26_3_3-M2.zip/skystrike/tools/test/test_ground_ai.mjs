// بند #9 (v26.2.6): عقل الأرضيات — ai_ground.js دالة صرفة. محاكاة node: دوران تدريجي، تحذير قبل الرمي، تنوّع، تعاون، بوابات المدى.
import {groundThink,maxCrew} from '../../src/ai_ground.js';
import {GROUND_AI as A,TURRET,FLAK,SAM,AGGR} from '../../src/enemies.js';
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const seeded = s => () => (s = (s*1664525+1013904223) >>> 0)/4294967296;
const D = {turret:TURRET.gun, flak:FLAK.gun, sam:SAM.msl};
const OLD = {turret:1/1.7, flak:1/2.4, sam:1/5.75};            // معدل الرمي القديم (طلقة/رشقة/صاروخ بالثانية)
const DT = 1/60;
function ctxFor(k,w,u,pl,since,crew){
  const d = D[k], m = k === 'sam', dx = pl.x-u.x, dy = pl.y-(u.y+6), dz = pl.z-u.z;
  return {px:pl.x,py:pl.y,pz:pl.z,vx:pl.vx,vy:0,vz:pl.vz,ex:u.x,ey:u.y+6,ez:u.z,dist:Math.hypot(dx,dy,dz),alive:true,
    canFire:u.canFire !== false,rmin:d.min||0,rmax:m ? d.max : d.range,gunSp:d.speed,spread:d.spread||0,
    ag:Math.min(1,AGGR.base+w*AGGR.w),w,crew,maxCrew:maxCrew(w),since};
}
function circle(t,R,start=0,alt=400){ const sp = 150, a = start+sp/R*t;           // لاعب يدور حول الوحدة بنصف قطر R
  return {x:Math.sin(a)*R,y:alt,z:Math.cos(a)*R,vx:Math.cos(a)*sp,vz:-Math.sin(a)*sp}; }
function run(k,w,secs,seed,{start=0,R=600,canFire=true}={}){
  const r = seeded(seed), u = {kind:k,x:0,y:0,z:0,canFire}, ev = {shots:[],starts:[],pats:new Set(),maxStep:0};
  let since = 99, ly = 0, lp = 0, first = null, startT = null, minWarn = 1e9;
  for(let i = 0, t = 0; t < secs; i++, t += DT){
    const o = groundThink(u,ctxFor(k,w,u,circle(t,R,start),since,0),DT,r); since += DT;
    if(o.start){ since = 0; ev.starts.push(t); startT = t; ev.pats.add(u.gpat.id); }
    if(o.shots){ ev.shots.push(t); if(startT !== null){ minWarn = Math.min(minWarn,t-startT); startT = null; } if(first === null) first = t; }
    ev.maxStep = Math.max(ev.maxStep,Math.abs(Math.atan2(Math.sin(u.gay-ly),Math.cos(u.gay-ly)))/DT,Math.abs(u.gap-lp)/DT); ly = u.gay; lp = u.gap;
  }
  ev.first = first; ev.minWarn = minWarn; return ev;
}
console.log('ذكاء الأرضيات:');
for(const k of ['turret','flak','sam']){
  const rates = [], pats = new Set(); let maxStep = 0, minWarn = 1e9;
  for(const w of [1,4,8]) for(let s = 1; s <= 6; s++){ const e = run(k,w,180,s*97+w); rates.push(e.shots.length/180); e.pats.forEach(p => pats.add(p)); maxStep = Math.max(maxStep,e.maxStep); minWarn = Math.min(minWarn,e.minWarn); }
  const avg = rates.reduce((a,b) => a+b,0)/rates.length, ratio = avg/OLD[k];
  ok(ratio > .6 && ratio < 2,`${k}: معدل الرمي ${avg.toFixed(2)}/ث = ${ratio.toFixed(2)}× القديم (مسموح .6–2×)`);
  ok(maxStep <= A.slew[k]*1.001,`${k}: أقصى سرعة دوران ${maxStep.toFixed(2)} ≤ ${A.slew[k]} راد/ث (لا التقاط لحظي)`);
  ok(minWarn >= A.warn[k]*.75*.9,`${k}: أقل تحذير قبل الرمي ${minWarn.toFixed(2)}ث ≥ ${(A.warn[k]*.75*.9).toFixed(2)}`);
  ok(pats.size >= (k === 'sam' ? 2 : 2),`${k}: تنوّع الأنماط ${[...pats].join('/')}`);
}
const e0 = run('turret',1,60,5,{start:Math.PI});                 // اللاعب خلف البرج (180° من وضع الراحة)
ok(e0.first >= 1.5,`البرج يدور تدريجياً نحو لاعب خلفه: أول رمية بعد ${e0.first?.toFixed(2)}ث (≥1.5)`);
for(const k of ['turret','flak','sam']){
  const far = run(k,5,60,3,{R:2600,alt:400}); ok(far.shots.length === 0,`${k}: لا رمي خارج المدى`);
}
ok(run('sam',5,90,3,{canFire:false}).shots.length === 0,'SAM: لا رمي لو اللاعب أخفض من الارتفاع الأدنى');
// تعاون: 6 وحدات متقاربة، حدّ الرمي المتزامن وفاصل البدايات
for(const w of [1,8]){
  const r = seeded(11+w), us = Array.from({length:6},(_,i) => ({kind:'turret',x:Math.cos(i)*120,y:0,z:Math.sin(i)*120,canFire:true}));
  let since = 99, maxC = 0, minGap = 1e9, last = null, shots = 0;
  for(let t = 0; t < 150; t += DT){
    const pl = circle(t,500); since += DT;                      // الزمن يزيد مرة واحدة بالفريم (مثل G.t بـ ai.js)
    for(const u of us){
      let crew = 0; for(const o of us) if(o !== u && (o.gst === 'wrn' || o.gst === 'fir')) crew++;
      const o = groundThink(u,ctxFor('turret',w,u,pl,since,crew),DT,r); shots += o.shots;
      if(o.start){ if(last !== null) minGap = Math.min(minGap,t-last); last = t; since = 0; }
    }
    maxC = Math.max(maxC,us.filter(u => u.gst === 'wrn' || u.gst === 'fir').length);
  }
  ok(maxC <= maxCrew(w),`تعاون (موجة ${w}): أقصى وحدات تحذّر/ترمي معاً ${maxC} ≤ ${maxCrew(w)}`);
  ok(minGap >= A.stagger*.8-1e-9,`تعاون (موجة ${w}): أقل فاصل بين بدايات الرشقات ${minGap.toFixed(2)}ث ≥ ${(A.stagger*.8).toFixed(2)}`);
  ok(shots > 0,`تعاون (موجة ${w}): الوحدات ترمي فعلاً (${shots} طلقة)`);
}
ok(maxCrew(1) === 1 && maxCrew(8) === 4 && maxCrew(99) === A.crewMax,'حدّ الوحدات المطلِقة: 1 بالموجة 1 → 4 كحدّ أقصى');
if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
