// يحوّل استيرادات combat.js و ai.js (three/core/state/…) لنسخ وهمية خفيفة، فنختبرهم بـ node بدون متصفح.
const STUBS = new URL('./stubs.mjs', import.meta.url).href;
const STUB_COMBAT = new URL('./stub_combat.mjs', import.meta.url).href;
const SPECS = new Set(['three','./util.js','./i18n.js','./audio.js','./jets.js','./core.js','./state.js','./ui.js','./waves.js','./spawn.js']);
export async function resolve(spec, ctx, next){
  const p = ctx.parentURL || '';
  if(/\/(combat|ai)\.js$/.test(p)){
    if(spec === './combat.js' && /\/ai\.js$/.test(p)) return {url:STUB_COMBAT, shortCircuit:true};
    if(SPECS.has(spec)) return {url:STUBS, shortCircuit:true};
  }
  return next(spec, ctx);
}
