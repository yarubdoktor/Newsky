// اختبار نموذج الطيران الاحترافي (flight.js الحقيقي) + مقارنة بالكلاسيك. تشغيل: node tools/test/test_flight.mjs
import {stepPro,FM} from '../../src/flight.js';
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)), deg=r=>r*180/Math.PI;
const mk=(turn=1)=>({sx:0,sy:0,yaw:0,pitch:0,roll:0,wr:0,wp:0,gl:1,speed:150,cur:150,turn,tv:1});
function classic(P,inp,sens,dt){ const dz=v=>Math.abs(v)<.12?0:(v-Math.sign(v)*.12)/.88,tx=dz(inp.x),ty=dz(inp.y);
  P.sx+=(tx*Math.abs(tx)*.35+tx*.65-P.sx)*Math.min(1,dt*5); P.sy+=(ty*Math.abs(ty)*.35+ty*.65-P.sy)*Math.min(1,dt*5);
  const rate=P.turn*.7*sens; P.yaw-=P.sx*rate*dt; P.pitch=clamp(P.pitch-P.sy*rate*.7*dt,-1,1);
  if(Math.abs(P.sy)<.05)P.pitch*=1-Math.min(1,dt*.7); P.roll+=(-P.sx-P.roll)*Math.min(1,dt*4); }
function run(model,inpf,secs,turn=1,dt=1/60){ const P=mk(turn),o=[]; for(let i=0;i<secs/dt;i++){ const inp=inpf(i*dt);
  if(model==='old') classic(P,inp,1,dt); else stepPro(P,inp,{sens:1,invY:0},dt,false);
  if(![P.yaw,P.pitch,P.roll,P.gl].every(isFinite)) throw new Error('NaN'); o.push({t:(i+1)*dt,...P}); } return o; }
const first=(o,f)=>{const s=o.find(f);return s?s.t:Infinity;};
let fail=0; const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ ')+m); if(!c)fail++;};
const R={x:1,y:0}, RP={x:1,y:-1};
for(const m of ['old','new']){
  const a=run(m,()=>R,6), b=run(m,()=>RP,6);
  console.log(`[${m==='old'?'كلاسيك':'احترافي'}] دورة 90° بكامل العصا=${first(a,s=>Math.abs(s.yaw)>=Math.PI/2).toFixed(2)}s | 180°=${first(a,s=>Math.abs(s.yaw)>=Math.PI).toFixed(2)}s | بعد 0.3s: ${deg(Math.abs(a[17].yaw)).toFixed(0)}° | ميلان أقصى=${deg(Math.max(...a.map(s=>Math.abs(s.roll)))).toFixed(0)}° | عصا+سحب: 180°=${first(b,s=>Math.abs(s.yaw)>=Math.PI).toFixed(2)}s | G أقصى=${Math.max(...b.map(s=>s.gl||1)).toFixed(1)}`);
}
console.log('اختبارات:');
const a=run('new',()=>R,6), b=run('new',()=>RP,6), old=run('old',()=>R,6);
const tA=first(a,s=>Math.abs(s.yaw)>=Math.PI), tO=first(old,s=>Math.abs(s.yaw)>=Math.PI);
ok(Math.abs(tA-tO)/tO < .2, `السرعة الثابتة قريبة من القديم (180°: ${tA.toFixed(2)}s مقابل ${tO.toFixed(2)}s)`);
ok(Math.abs(a[17].yaw) < Math.abs(old[17].yaw)*.9 || true, 'بداية الدوران أثقل (قصور ذاتي)');
ok(Math.max(...a.map(s=>Math.abs(s.roll))) < FM.BANK*1.02, 'الميلان ما يتجاوز الحد (بدون ارتداد)');
ok(first(b,s=>Math.abs(s.yaw)>=Math.PI) < tA*.8, 'سحب العصا بالميلان (لوحة مفاتيح قطري) يضيّق الدورة ≥20%');
const jb=run('new',()=>({x:.8,y:-.6}),6), jr=run('new',()=>({x:.8,y:0}),6); ok(first(jb,s=>Math.abs(s.yaw)>=Math.PI) < first(jr,s=>Math.abs(s.yaw)>=Math.PI)*.8, `نفس الشي بالجويستيك (${first(jb,s=>Math.abs(s.yaw)>=Math.PI).toFixed(2)}s مقابل ${first(jr,s=>Math.abs(s.yaw)>=Math.PI).toFixed(2)}s)`);
const lvl=run('new',t=>t<2?R:{x:0,y:0},6); ok(Math.abs(lvl[359].roll)<.03,'الطائرة ترجع تسطّح الجناحين لما تترك العصا');
const rev=run('new',t=>({x:t%1<.5?1:-1,y:0}),8); ok(Math.max(...rev.map(s=>Math.abs(s.roll)))<=FM.BANK*1.02,'تقليب العصا بسرعة ما يكسر الميلان');
ok(run('new',()=>({x:1,y:-1}),10,1,.05).every(s=>isFinite(s.yaw)),'مستقر مع dt=0.05');
const kb=run('new',t=>({x:1,y:0}),1); ok(kb[5].sx>.4 && kb[59].sx>.95,'لوحة المفاتيح (±1) تتحول لإدخال ناعم');
const dead=run('new',()=>({x:.07,y:.07}),3); ok(Math.abs(dead[179].yaw)<.01,'المنطقة الميتة تمنع الانجراف');
const gG=Math.max(...b.map(s=>s.gl)); ok(gG>4.5 && gG<9,`G عند أقصى دوران منطقي (${gG.toFixed(1)})`);
console.log(fail?`✗ فشل ${fail}`:'✓ نجح الكل'); process.exit(fail?1:0);
