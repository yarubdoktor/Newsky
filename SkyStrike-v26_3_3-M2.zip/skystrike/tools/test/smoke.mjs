// اختبار دخان بمتصفح حقيقي (Playwright + Chromium) — بند #17 / KI-05.
// يبني اللعبة (vite build) ويقدّم dist بخادم ثابت، يفتح اللوبي، يبدأ جولة، ويتأكد من:
//   1) لا pageerror ولا console.error، ولا أي تحذير «failed» (فشل تحميل GLB/bin يرجع للبديل بصمت!).
//   2) اللوبي يظهر، والجولة تبدأ (W.run) وتجري ~6 ثوانٍ مع أعداء.
//   3) ميزانية الأداء (BUDGET أدناه) على renderer.info.
// تشغيل: node tools/test/smoke.mjs [--no-build] [--shots]   (يخرج 1 عند الفشل، 2 إن لم تتوفر البيئة)
// ⚠️ الأرقام بـ BUDGET تقديرية ولم تُعايَر بعد (أول تشغيل حقيقي يطبع القيم المقيسة: عدّلها حينها).
import {createServer} from 'node:http';
import {readFileSync, existsSync, statSync, mkdirSync} from 'node:fs';
import {execSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {dirname, resolve, extname, join} from 'node:path';
import {createRequire} from 'node:module';
import {tmpdir} from 'node:os';

const require = createRequire(import.meta.url);
let chromium; try { ({chromium} = require('playwright')); } catch { console.error('Playwright غير متوفر'); process.exit(2); }
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const dist = resolve(root, 'dist');
const args = process.argv.slice(2);

const BUDGET = {drawCalls: 600, triangles: 1500000, geometries: 800, textures: 200, enemies: 60};
const PLAY_MS = 6000;

if(!args.includes('--no-build')){
  try { execSync('npx vite build', {cwd: root, stdio: 'inherit'}); }
  catch { console.error('فشل vite build (أو vite غير مثبّت)'); process.exit(2); }
}
if(!existsSync(join(dist, 'index.html'))){ console.error('لا يوجد dist/index.html'); process.exit(2); }

const MIME = {'.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webp': 'image/webp', '.png': 'image/png',
  '.glb': 'model/gltf-binary', '.bin': 'application/octet-stream', '.webmanifest': 'application/manifest+json', '.json': 'application/json'};
const server = createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/')) p += 'index.html';
  const f = resolve(dist, '.' + p);
  if(!f.startsWith(dist) || !existsSync(f) || !statSync(f).isFile()){ res.writeHead(404); res.end(); return; }
  res.writeHead(200, {'content-type': MIME[extname(f)] || 'application/octet-stream'}); res.end(readFileSync(f));
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

const problems = [];
const browser = await chromium.launch({args: ['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
try {
  const page = await browser.newPage({viewport: {width: 1280, height: 720}});
  page.on('pageerror', e => problems.push('pageerror: ' + e.message));
  page.on('console', m => {
    const t = m.type(), x = m.text();
    if(t === 'error') problems.push('console.error: ' + x);
    else if(t === 'warning' && /failed|unavailable/i.test(x)) problems.push('console.warn: ' + x);
  });
  page.on('requestfailed', r => problems.push('requestfailed: ' + r.url()));
  page.on('response', r => { if(r.status() >= 400) problems.push(`HTTP ${r.status()}: ${r.url()}`); });
  await page.addInitScript(() => { globalThis.__SS_DEBUG = true; });
  await page.goto(url, {waitUntil: 'load'});

  await page.waitForFunction(() => document.querySelector('#menu')?.children.length > 0 && !document.querySelector('#load.on') && globalThis.__ss, null, {timeout: 60000})
    .catch(() => problems.push('اللوبي لم يظهر خلال 60 ث (أو انتهى التحميل بخطأ)'));
  if(args.includes('--shots')){ mkdirSync(join(tmpdir(), 'ss_smoke'), {recursive: true}); await page.screenshot({path: join(tmpdir(), 'ss_smoke', 'lobby.png')}); }

  await page.evaluate(() => globalThis.__ss.startGame());
  await page.waitForFunction(() => globalThis.__ss.W.run, null, {timeout: 30000}).catch(() => problems.push('الجولة لم تبدأ (W.run) خلال 30 ث'));
  await page.waitForTimeout(PLAY_MS);
  if(args.includes('--shots')) await page.screenshot({path: join(tmpdir(), 'ss_smoke', 'play.png')});

  const m = await page.evaluate(() => { const s = globalThis.__ss, i = s.renderer.info;
    return {run: s.W.run, enemies: s.enemies.length, hp: s.P.hp, drawCalls: i.render.calls, triangles: i.render.triangles, geometries: i.memory.geometries, textures: i.memory.textures}; });
  console.log('المقاسة:', JSON.stringify(m), '| الميزانية:', JSON.stringify(BUDGET));
  if(!m.run) problems.push('الجولة توقفت قبل الوقت');
  if(!(m.enemies > 0)) problems.push('لا أعداء بعد ' + PLAY_MS / 1000 + ' ث من بدء الجولة');
  for(const k of Object.keys(BUDGET)) if(m[k] > BUDGET[k]) problems.push(`تجاوز الميزانية: ${k} = ${m[k]} > ${BUDGET[k]}`);
} finally { await browser.close(); server.close(); }

if(problems.length){ console.error('✗ فشل اختبار الدخان:\n' + [...new Set(problems)].map(p => '  - ' + p).join('\n')); process.exit(1); }
console.log('✓ نجح اختبار الدخان');
