/* اختبار إصلاحات v17.1: (1) تصادم بالمسار  (3) انفجار واحد للصاروخ  (4) تصويب الأرضيات بالسرعة الفعلية
   التشغيل: npm test      (أو COMBAT_PATH=… AI_PATH=… لتجربة نسخة قديمة وإثبات أن الاختبار يكشف الخطأ) */
import {pathToFileURL} from 'node:url';
import * as S from './stubs.mjs';
import * as C from './stub_combat.mjs';
const {W,P,FW,V,Mesh,counts} = S;
const combat = await import(process.env.COMBAT_PATH ? pathToFileURL(process.env.COMBAT_PATH).href : '../../src/combat.js');
const ai = await import(process.env.AI_PATH ? pathToFileURL(process.env.AI_PATH).href : '../../src/ai.js');

let pass = 0, fail = 0;
const ok = (c,name,extra='') => { if(c){ pass++; console.log('  ✓',name); } else { fail++; console.log('  ✗',name,extra); } };
const near = (a,b,e=.01) => Math.abs(a-b) < e;
function reset(){
  W.G = {dead:false,wave:1,hit:false,combo:0,ct:0,mult:1,kj:0,kg:0,score:0,coins:0,xp:0};
  W.units.length = 0; W.projs.length = 0; W.flares.length = 0; W.shake = 0; counts.explode = 0; C.shots.length = 0;
  P.g.position.set(0,0,0); P.hp = 100; P.speed = 150; P.cur = 150;
}
const enemy = (x,y,z,r=9) => ({kind:'jet',g:{position:V(x,y,z)},r,air:true,hp:30,max:30,pts:100,fl:0});
const proj = (o) => { const m = new Mesh(); m.position.copy(o.pos); return {mesh:m,dir:o.dir||V(0,0,-1),speed:o.speed,dmg:o.dmg||5,owner:o.owner,mis:!!o.mis,bomb:false,target:null,turn:2.4,vy:0,life:o.life ?? 5}; };

console.log('1) تصادم بالمسار (الرصاصة السريعة ما تنفذ من الهدف)');
{ // رصاصة اللاعب 750 بفريم 20 FPS (dt=.05) = 37.5 وحدة؛ قطر المقاتلة 18
  reset(); const e = enemy(0,0,-500); W.units.push(e);
  W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'p',dmg:6})); combat.projectilesUpdate(.05);
  ok(e.hp < 30,'رصاصة اللاعب تصيب مقاتلة بفريم 20 FPS','(hp='+e.hp+')');
  ok(W.projs.length === 0,'الرصاصة تُزال بعد الإصابة');
  reset(); const e2 = enemy(30,0,-500); W.units.push(e2);
  W.projs.push(proj({pos:V(0,0,-480),speed:750,owner:'p',dmg:6})); combat.projectilesUpdate(.05);
  ok(e2.hp === 30,'رصاصة تمرّ بجنب الهدف (30 وحدة) ما تصيب');
  // رصاصة العدو 520 بفريم 30 FPS = 17.3 وحدة؛ قطر الإصابة 14
  reset(); P.g.position.set(0,0,-500);
  W.projs.push(proj({pos:V(0,0,-490),speed:520,owner:'e',dmg:5})); combat.projectilesUpdate(1/30);
  ok(P.hp === 95,'رصاصة العدو تصيب اللاعب بفريم 30 FPS','(hp='+P.hp+')');
  reset(); P.g.position.set(0,0,-500);
  W.projs.push(proj({pos:V(20,0,-490),speed:520,owner:'e',dmg:5})); combat.projectilesUpdate(1/30);
  ok(P.hp === 100,'رصاصة العدو تمرّ بجنب اللاعب (20 وحدة) ما تصيب');
}

console.log('3) انفجار واحد للصاروخ');
{
  reset(); W.units.push(enemy(0,0,-100));
  W.projs.push(proj({pos:V(0,0,-90),speed:480,owner:'p',mis:true,dmg:5})); combat.projectilesUpdate(1/60);
  ok(counts.explode === 1,'صاروخ اللاعب يصيب عدو = انفجار واحد','(explode='+counts.explode+')');
  reset(); P.g.position.set(0,0,-100);
  W.projs.push(proj({pos:V(0,0,-90),speed:340,owner:'e',mis:true,dmg:5})); combat.projectilesUpdate(1/60);
  ok(counts.explode === 1,'صاروخ العدو يصيب اللاعب = انفجار واحد','(explode='+counts.explode+')');
  reset();
  W.projs.push(proj({pos:V(500,500,500),speed:480,owner:'p',mis:true,life:.001})); combat.projectilesUpdate(1/60);
  ok(counts.explode === 1,'صاروخ ينتهي عمره بالفراغ = انفجار واحد','(explode='+counts.explode+')');
}

console.log('4) المدفع الأرضي و flak يتقدّمان بسرعتك الفعلية (P.cur) مو الأساسية  (v26.2.6: البرج يدور تدريجياً، فنفحص اتجاهه بعد الالتقاط)');
for(const kind of ['turret','flak']){
  reset(); P.speed = 150; P.cur = 300; P.g.position.set(0,200,0); W.G.t = 0;      // Boost: السرعة الفعلية ضعف الأساسية؛ اللاعب على ارتفاع 200 ليظهر التقدّم بزاوية الميلان
  let aimed = null; const e = {kind,g:{position:V(0,0,-600),userData:{aim:{lookAt:(x,y,z) => aimed = {x,y,z}}}},hp:50,max:50,r:9,muz:6,air:false,ground:true,cd:0,mcd:0,pts:100};
  W.units.push(e); for(let i = 0; i < 240; i++){ W.G.t += .016; ai.enemiesUpdate(.016); }
  const gs = kind === 'turret' ? 420 : 520, dist = Math.hypot(600,200-6), lead = cur => Math.atan2(194,600-cur*dist/gs);
  const pitch = aimed && Math.atan2(aimed.y-6,Math.hypot(aimed.x,aimed.z+600)), want = lead(300), old = lead(150);
  ok(pitch !== null && Math.abs(pitch-want) < .12 && Math.abs(pitch-want) < Math.abs(pitch-old),kind+': ميلان الفوهة '+(pitch&&pitch.toFixed(2))+' (المطلوب '+want.toFixed(2)+'، القديم كان '+old.toFixed(2)+')');
}

console.log('\n'+(fail ? '✗ فشل '+fail+' / ' : '✓ نجح الكل: ')+(pass+fail)+' اختبار');
process.exit(fail ? 1 : 0);
