// فحص تداخل عناصر اللوبي بمتصفح حقيقي (Playwright/Chromium) على عدة أبعاد شاشة.
// ⚠️ القالب أدناه يعكس أصناف menu.js يدوياً: عدّله إذا غيّرت هيكل اللوبي.
// يستعمل lobby.css الحقيقي + قالب مطابق لأصناف menu.js (بيانات تجريبية). غير مدرج بـ npm test لأنه يحتاج Playwright.
//   تشغيل:  node tools/test/lobby_layout.mjs            (يطبع التداخلات ويخرج 1 إذا وُجدت)
//           node tools/test/lobby_layout.mjs --shots     (يحفظ صوراً بمجلد التخزين المؤقت للمراجعة)
import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
let chromium; try { ({chromium} = require('playwright')); } catch { console.error('Playwright غير متوفر'); process.exit(2); }

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const css = readFileSync(resolve(root, 'src/lobby.css'), 'utf8').replace('url(./assets/lobby-bg.webp)', `url(file://${root}/src/assets/lobby-bg.webp)`);
const img = n => `file://${root}/src/assets/${n}`;
const html = `<!doctype html><meta charset=utf-8><style>html,body{margin:0;height:100%;background:#000;font-family:sans-serif}${css}</style>
<div id=menu data-s=lobby>
  <div class="lb-top"><div class="lb-prof"><div class="lb-pi"><b>PILOT NAME</b><span>Rank</span><i class="xpb"><b style="width:40%"></b></i><small>120 / 300 XP</small></div></div>
    <div class="lb-cur"><div class="cur"><span class="ci">🪙</span><b>1200</b><button><svg class=ic></svg></button></div><div class="cur"><span class="ci">💎</span><b>5</b><button><svg class=ic></svg></button></div></div>
    <div class="lb-ico"><button></button><button></button><button></button></div></div>
  <nav class="lb-nav">${[1,2,3,4,5].map(i => `<button class="${i===1?'on':''}"><svg class=ic></svg><span>Item ${i}</span></button>`).join('')}</nav>
  <div class="lb-right"><div class="lb-logo"><img src="${img('logo-horizontal.webp')}" alt=""></div><div class="lb-plane"><div class="pp-h"><div><b>F-35 Lightning II</b><p>Stealth multirole fighter</p></div><span class="lvb">Lv 3</span></div>
    <div class="st">${['SPD','TURN','HP'].map(k => `<span>${k}</span><i class="sb"><b style="width:60%"></b></i><em>120</em>`).join('')}</div>
    <div class="ths">${['f35','mig29','su57'].map((k,i) => `<button class="th ${i===0?'on':''}"><img src="${img('planes/'+k+'.webp')}" alt=""></button>`).join('')}</div></div></div>
  <button class="lb-event"><img src="${img('planes/f35.webp')}" alt=""><div><span class="tag">Daily</span><b>2 / 3</b><small>⏱ 5h 20m</small></div></button>
  <button class="lb-rank"><div class="rk-h"><svg class=ic></svg><b>Top pilots</b></div>${[1,2,3].map(i => `<div class="rk"><i>${i}</i><span>Player ${i}</span><small>Lv${i}</small><b>${9000-i*10}</b></div>`).join('')}</button>
  <button class="lb-chip"><svg class=ic></svg><span>Island · Survival</span></button>
  <div class="lb-bot"><button>Maps</button><button>Rank</button><button>Soon</button></div>
  <button class="lb-cta"><i></i><span>START</span><svg class=ic></svg></button>
</div>`;

const page = `${process.env.SHOT_DIR || '/tmp/lobby_shots'}/harness.html`; mkdirSync(dirname(page), {recursive:true}); writeFileSync(page, html);   // ملف حقيقي حتى تُحمَّل الصور (file://)
const SIZES = [[640,360],[740,360],[800,360],[844,390],[915,412],[960,440],[1024,600],[1180,820],[1024,768],[1280,720],[1920,1080],[2340,1080],[2560,1080]];
const SEL = {logo:'.lb-logo',top:'.lb-top',nav:'.lb-nav',plane:'.lb-plane',event:'.lb-event',rank:'.lb-rank',chip:'.lb-chip',bot:'.lb-bot',cta:'.lb-cta'};
const shots = process.argv.includes('--shots');
const browser = await chromium.launch({args:['--allow-file-access-from-files']});
let bad = 0; const out = process.env.SHOT_DIR || '/tmp/lobby_shots'; if(shots) mkdirSync(out, {recursive:true});
for(const [w,h] of SIZES){
  const pg = await browser.newPage({viewport:{width:w,height:h}}); await pg.goto('file://'+page);
  await pg.evaluate(([w,h]) => { const d = document.documentElement; d.style.setProperty('--vw', w/100+'px'); d.style.setProperty('--vh', h/100+'px'); }, [w,h]);
  await pg.waitForFunction(() => [...document.images].every(i => i.complete && i.naturalWidth > 0), null, {timeout:8000});   // الصور لازم تُحمَّل قبل القياس
  await pg.waitForTimeout(100);
  const R = await pg.evaluate(S => Object.fromEntries(Object.entries(S).map(([k,s]) => { const r = document.querySelector(s).getBoundingClientRect(); return [k,[r.left,r.top,r.right,r.bottom]]; })), SEL);
  const names = Object.keys(R), found = [];
  for(let i=0;i<names.length;i++) for(let j=i+1;j<names.length;j++){
    const a = R[names[i]], b = R[names[j]], ox = Math.min(a[2],b[2]) - Math.max(a[0],b[0]), oy = Math.min(a[3],b[3]) - Math.max(a[1],b[1]);
    if(ox > 1 && oy > 1) found.push(`${names[i]}×${names[j]} (${ox.toFixed(0)}×${oy.toFixed(0)}px)`);
  }
  const off = names.filter(n => R[n][0] < -1 || R[n][1] < -1 || R[n][2] > w+1 || R[n][3] > h+1);
  console.log(`${w}×${h}: ${found.length || off.length ? '✗' : '✓'} ${found.join(' | ')}${off.length ? ' | خارج الشاشة: '+off.join(',') : ''}`);
  bad += found.length + off.length;
  if(shots) await pg.screenshot({path:`${out}/lobby_${w}x${h}.png`});
  await pg.close();
}
await browser.close(); console.log(bad ? `✗ ${bad} مشكلة` : '✓ لا تداخل'); process.exit(bad ? 1 : 0);
