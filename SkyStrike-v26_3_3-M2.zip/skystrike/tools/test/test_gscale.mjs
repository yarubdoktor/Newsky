// بند #10 (v26.2.4): مقياس الأرضيات — gscale.js دالة صرفة. يتأكد أن الأحجام/التصادم/التعزيز منطقية ومرتبطة بأبعاد الـ GLB الفعلية.
import {readFileSync} from 'node:fs';
import {GK,GSCALE,groundScale,groundRadius,groundMuzzle,farBoost,BOOST} from '../../src/gscale.js';
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const dir = new URL('../../src/models/', import.meta.url);
function maxDim(k){ const b = readFileSync(new URL('e_'+k+'.glb',dir)), len = b.readUInt32LE(12), j = JSON.parse(b.subarray(20,20+len).toString());
  const lo = [1e9,1e9,1e9], hi = [-1e9,-1e9,-1e9];
  j.nodes.forEach(n => { if(n.mesh === undefined) return; const t = n.translation || [0,0,0];
    for(const p of j.meshes[n.mesh].primitives){ const a = j.accessors[p.attributes.POSITION]; for(let i=0;i<3;i++){ lo[i] = Math.min(lo[i],a.min[i]+t[i]); hi[i] = Math.max(hi[i],a.max[i]+t[i]); } } });
  return Math.max(...hi.map((v,i) => v-lo[i])); }
console.log('مقياس الأرضيات:');
ok(GK.length === 5 && GK.every(k => GSCALE[k]),'الأنواع الخمسة معرّفة');
for(const k of GK){
  const real = maxDim(k);
  ok(Math.abs(real-GSCALE[k].size) < .6,`${k}: الحجم المسجّل ${GSCALE[k].size} يطابق الـ GLB (${real.toFixed(1)})`);
  ok(groundScale(k) >= 1.5 && groundScale(k) <= 2.5,`${k}: المضاعف ${groundScale(k)} (1.5..2.5)`);
  const r = groundRadius(k); ok(r >= 9 && r <= 16,`${k}: نصف قطر التصادم ${r} (9..16)`);
  ok(groundMuzzle(k) > 4 && groundMuzzle(k) < real*groundScale(k),`${k}: ارتفاع الفوهة ${groundMuzzle(k)} داخل جسم الآلة`);
}
ok(farBoost(0) === 1 && farBoost(BOOST.near) === 1,'قريباً (≤500م) بلا تكبير');
ok(Math.abs(farBoost(BOOST.far)-BOOST.max) < 1e-9 && farBoost(9999) === BOOST.max,'بعيداً (≥2000م) أقصاه 1.8×');
let prev = 1, mono = true; for(let d=0;d<=2500;d+=25){ const b = farBoost(d); if(b < prev-1e-12) mono = false; prev = b; }
ok(mono,'التعزيز متصاعد بلا قفزات ولا نزول');
if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
