// بند #9 (v26.2.5): محاكاة اشتباك مقاتلة عدو ضد لاعب بـ node (ai_jet.js الحقيقي). تتأكد: لا لصق بالذيل، المواجهة تهدّد فعلاً، لا غوص بالأرض.
// اللاعب: سرعة 150 بأنماط (مستقيم/دوران/مراوغة). العدو: نفس steer بـ ai.js (حد دوران + حد سرعة). legacy = المطاردة المباشرة القديمة للمقارنة.
import {jetThink,maxAttackers} from '../../src/ai_jet.js';
import {JET,JET_AI as J} from '../../src/enemies.js';
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const clamp = (v,a,b) => Math.max(a,Math.min(b,v)), wrap = a => Math.atan2(Math.sin(a),Math.cos(a));
const mulberry = a => () => { a |= 0; a = a+0x6D2B79F5|0; let t = Math.imul(a^a>>>15,1|a); t = t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; };
const fwd = (yaw,pitch) => [-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)];

function sim(mode,wave,seed,legacy = false,T = 90){
  const r = mulberry(seed), dt = 1/30, ag = Math.min(1,.3+wave*.08);
  const P = {x:0,y:300,z:0,yaw:0,pitch:0,sp:150}, ep = {x:900,y:300,z:900};
  const e = {yaw:Math.atan2(900,900),pitch:0,ag,elite:false,sp:Math.min(JET.spMax,JET.sp+wave*JET.spw),tn:Math.min(JET.tnMax,JET.tn+wave*JET.tnw),sd:1};
  let tailRun = 0, tailMax = 0, near = 0, fireWin = 0, minY = 1e9, t = 0, wy = 0;
  while(t < T){
    if(mode === 'circle') P.yaw += .5*dt;
    else if(mode === 'weave'){ wy = clamp(wy+(r()-.5)*dt*6,-1,1); P.yaw += wy*dt; P.pitch = clamp(P.pitch+(r()-.5)*dt*1.5,-.4,.4); }
    const f = fwd(P.yaw,P.pitch); P.x += f[0]*P.sp*dt; P.y = Math.max(120,P.y+f[1]*P.sp*dt); P.z += f[2]*P.sp*dt;
    const dx = P.x-ep.x, dy = P.y-ep.y, dz = P.z-ep.z, dist = Math.hypot(dx,dy,dz) || 1;
    const c = {px:P.x,py:P.y,pz:P.z,vx:f[0]*P.sp,vy:f[1]*P.sp,vz:f[2]*P.sp,fx:f[0],fy:f[1],fz:f[2],sp:P.sp,dist,alive:true,gh:60,atk:0,maxAtk:maxAttackers(wave),dodge:JET.dodge,gunSp:JET.gun.speed};
    const o = legacy ? {ty:Math.atan2(-dx,-dz),tp:clamp(Math.asin(clamp(dy/dist,-.7,.7)),-.7,.7),spMul:1,tnMul:1,cap:1e9,fire:true} : jetThink(e,c,dt,r,ep);
    const rate = e.tn*o.tnMul, dyaw = wrap(o.ty-e.yaw);
    e.yaw += clamp(dyaw,-rate*dt,rate*dt); e.pitch += clamp(o.tp-e.pitch,-rate*dt,rate*dt);
    const sp = Math.min(e.sp*o.spMul,o.cap), ef = fwd(e.yaw,e.pitch); ep.x += ef[0]*sp*dt; ep.y += ef[1]*sp*dt; ep.z += ef[2]*sp*dt;
    minY = Math.min(minY,ep.y);
    // اللصق: العدو خلف اللاعب بزاوية > 120° ضمن tailDist ومتجه بنفس اتجاهه تقريباً
    const cosR = -(dx*f[0]+dy*f[1]+dz*f[2])/dist, stuck = dist < J.tailDist && cosR < J.tailCos && (ef[0]*f[0]+ef[1]*f[1]+ef[2]*f[2]) > .3;
    tailRun = stuck ? tailRun+dt : 0; tailMax = Math.max(tailMax,tailRun);
    if(dist < 120) near += dt;
    // نافذة الإطلاق: الرصاصة (سرعة gun.speed على اتجاه العدو) تمرّ < 20م من موقع اللاعب المتوقَّع وقت وصولها
    const tb = dist/JET.gun.speed, mx = P.x+f[0]*P.sp*tb-(ep.x+ef[0]*JET.gun.speed*tb), my = P.y+f[1]*P.sp*tb-(ep.y+ef[1]*JET.gun.speed*tb), mz = P.z+f[2]*P.sp*tb-(ep.z+ef[2]*JET.gun.speed*tb);
    if(o.fire && dist < JET.gun.range && Math.hypot(mx,my,mz) < 20 && Math.abs(wrap(o.ty-e.yaw)) < JET.gun.aim) fireWin += dt;
    t += dt;
  }
  return {tailMax,near:near/T,fire:fireWin/T,minY};
}
console.log('محاكاة مواجهة مقاتلة (90 ث × أنماط × موجات × بذور):');
let worstTail = 0, legTail = 0, worstNear = 0, maxFire = 0, worstY = 1e9, n = 0; const hiFire = [];
for(const mode of ['straight','circle','weave']) for(const wave of [1,4,8,12]) for(let seed = 1;seed <= 6;seed++){
  const sd = seed*131+wave, s = sim(mode,wave,sd); n++;
  legTail = Math.max(legTail,sim(mode,wave,sd,true).tailMax);
  worstTail = Math.max(worstTail,s.tailMax); worstNear = Math.max(worstNear,s.near); worstY = Math.min(worstY,s.minY);
  if(mode !== 'straight'){ maxFire = Math.max(maxFire,s.fire); if(wave >= 4) hiFire.push(s.fire); }   // لاعب يهرب بخط مستقيم للأبد ما يُحسب للتهديد (العدو أبطأ منه بالموجات الأولى بالتصميم)
}
const avgHi = hiFire.reduce((a,b) => a+b,0)/hiFire.length;
console.log(`  (${n} تشغيل) أطول لصق ${worstTail.toFixed(1)}ث · أعلى قرب<120م ${(worstNear*100).toFixed(1)}% · أعلى نافذة إطلاق ${(maxFire*100).toFixed(1)}% · أخفض ارتفاع ${worstY.toFixed(0)}م`);
console.log(`  للمقارنة: المطاردة القديمة لصقت ${legTail.toFixed(1)} ث متواصلة · متوسط نافذة الإطلاق من الموجة 4: ${(avgHi*100).toFixed(1)}%`);
ok(worstTail <= J.tailMax+3,`ما يلصق على الذيل (<${J.tailDist}م خلفه) أكثر من ${(J.tailMax+3).toFixed(1)} ث (يشمل زمن الانعطاف للخروج)`);
ok(worstTail < legTail*.25,'اللصق صار أقل من ربع المطاردة القديمة');
ok(worstNear < .15,'وقت القرب الشديد (<120م) أقل من 15% من المواجهة');
ok(avgHi > .015,'المقاتل يهدّد فعلاً: متوسط نافذة إطلاق > 1.5% من الموجة 4');
ok(maxFire < .30,'ما يرمي بشكل دائم (نافذة الإطلاق < 30%)');
ok(worstY > 20,'ما يغوص بالأرض (ارتفاع > 20م)');
ok(maxAttackers(1) === 1 && maxAttackers(3) === 2 && maxAttackers(6) === 3 && maxAttackers(30) === 3,'عدد المهاجمين المتزامنين يزيد بالموجات ويتوقف عند 3');
if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
