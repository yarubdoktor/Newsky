#!/usr/bin/env python3
"""يولّد كل أصول الهوية البصرية لـ Sky Strike (أيقونة، شاشة بداية، شعار). التشغيل:  python3 tools/make_brand.py
   يحتاج Pillow فقط. الخط: Poppins Bold Italic (غيّر FONT لو بدك خط ثاني)."""
import math, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = '/usr/share/fonts/truetype/google-fonts/Poppins-BoldItalic.ttf'
NAVY, DEEP, HOT, HOT2, ICE, WHITE = (11,22,38), (19,36,59), (255,122,47), (255,170,90), (159,216,255), (234,244,255)
SS = 2  # supersampling

# ---- نصف الطائرة اليمين (x,y) بوحدات محلية، الأنف للأعلى (+y)، الطول ~100
HALF = [(0,52),(3.5,36),(5,20),(8,12),(47,-20),(47,-27),(9,-19),(8,-30),(21,-45),(21,-50),(4,-44),(0,-48)]
def jet_poly(cx,cy,scale,ang_deg):
    pts = HALF + [(-x,y) for x,y in reversed(HALF[1:-1])]
    a = math.radians(ang_deg); ca, sa = math.cos(a), math.sin(a); out = []
    for x,y in pts:
        x,y = x*scale, -y*scale                      # y لتحت بالصورة
        out.append((cx + x*ca - y*sa, cy + x*sa + y*ca))
    return out
def canopy_poly(cx,cy,scale,ang_deg):
    pts = [(0,34),(2.6,26),(2.2,18),(0,15),(-2.2,18),(-2.6,26)]
    a = math.radians(ang_deg); ca, sa = math.cos(a), math.sin(a)
    return [(cx+(x*scale)*ca-(-y*scale)*sa, cy+(x*scale)*sa+(-y*scale)*ca) for x,y in pts]

def vgrad(w,h,stops):
    im = Image.new('RGB',(1,h)); px = im.load()
    for y in range(h):
        t = y/(h-1)
        for i in range(len(stops)-1):
            t0,c0 = stops[i]; t1,c1 = stops[i+1]
            if t0 <= t <= t1:
                k = (t-t0)/(t1-t0) if t1>t0 else 0; px[0,y] = tuple(int(c0[j]+(c1[j]-c0[j])*k) for j in range(3)); break
    return im.resize((w,h))
DUSK = [(0,(10,20,40)),(.45,(34,38,66)),(.72,(150,78,70)),(1,(255,128,52))]

def trail(layer, cx, cy, scale, ang_deg, length):
    """خط الاندفاع البرتقالي خلف الطائرة (شريط مدبّب + نواة بيضاء + شرارات)"""
    d = ImageDraw.Draw(layer); a = math.radians(ang_deg); ux, uy = math.sin(a), -math.cos(a)  # اتجاه الأنف
    bx, by = cx - ux*43*scale, cy - uy*43*scale                                              # ذيل الطائرة
    nx, ny = -uy, ux
    for w,col,L in [(15*scale,HOT+(255,),length),(8.5*scale,HOT2+(255,),length*.82),(3.6*scale,WHITE+(255,),length*.6)]:
        ex, ey = bx - ux*L, by - uy*L
        d.polygon([(bx+nx*w,by+ny*w),(bx-nx*w,by-ny*w),(ex,ey)], fill=col)
    for off,L,w in [(-26,.55,2.2),(27,.7,2.2),(-38,.38,1.6)]:   # خطوط سرعة جانبية
        sx, sy = bx+nx*off*scale-ux*8*scale, by+ny*off*scale-uy*8*scale
        d.line([(sx,sy),(sx-ux*length*L,sy-uy*length*L)], fill=ICE+(170,), width=max(2,int(w*scale)))

def draw_mark(size, ang=45, fill=WHITE, with_trail=True, glow=True, pad=0.0):
    """يرسم الشعار على لوحة شفافة مربعة. pad = هامش نسبي"""
    S = size*SS; im = Image.new('RGBA',(S,S),(0,0,0,0))
    scale = S*(1-2*pad)/205; cx = cy = S/2
    shift = 22*scale; sx, sy = math.sin(math.radians(ang)), -math.cos(math.radians(ang))
    jx, jy = cx + sx*shift, cy + sy*shift
    if with_trail:
        tl = Image.new('RGBA',(S,S),(0,0,0,0)); trail(tl,jx,jy,scale,ang,125*scale)
        if glow: im.alpha_composite(tl.filter(ImageFilter.GaussianBlur(10*SS)))
        im.alpha_composite(tl)
    d = ImageDraw.Draw(im)
    sh = Image.new('RGBA',(S,S),(0,0,0,0)); ImageDraw.Draw(sh).polygon(jet_poly(jx+6*scale,jy+8*scale,scale,ang),fill=(0,0,0,110))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(5*SS)))
    d.polygon(jet_poly(jx,jy,scale,ang),fill=fill+(255,))
    d.polygon(canopy_poly(jx,jy,scale,ang),fill=(21,60,98,255))
    return im.resize((size,size),Image.LANCZOS)

def font(sz): return ImageFont.truetype(FONT,sz)
def spaced(d,xy,text,f,fill,track=0,anchor='l'):
    x,y = xy; widths = [d.textlength(c,font=f) for c in text]; total = sum(widths)+track*(len(text)-1)
    if anchor == 'm': x -= total/2
    for c,w in zip(text,widths): d.text((x,y),c,font=f,fill=fill); x += w+track
    return total
def wordmark(d, cx, y, sz, track=None):
    f = font(sz); track = sz*.05 if track is None else track
    w1 = sum(d.textlength(c,font=f) for c in 'SKY')+track*2; w2 = sum(d.textlength(c,font=f) for c in 'STRIKE')+track*5
    gap = sz*.34; x = cx-(w1+gap+w2)/2
    spaced(d,(x,y),'SKY',f,WHITE+(255,),track); spaced(d,(x+w1+gap,y),'STRIKE',f,HOT+(255,),track)
    return w1+gap+w2

out = lambda *p: os.path.join(ROOT,*p)

# 1) أيقونة التطبيق (مربعة كاملة الخلفية) + طبقتا الأيقونة التكيفية لأندرويد
bg = vgrad(1024,1024,DUSK).convert('RGBA')
sun = Image.new('RGBA',(1024,1024),(0,0,0,0)); ImageDraw.Draw(sun).ellipse((-200,760,1224,1500),fill=(255,190,120,150))
bg.alpha_composite(sun.filter(ImageFilter.GaussianBlur(60)))
icon = bg.copy(); icon.alpha_composite(draw_mark(1024,pad=.08)); icon.convert('RGB').save(out('assets','icon-only.png'))
bg.convert('RGB').save(out('assets','icon-background.png'))
draw_mark(1024,pad=.20).save(out('assets','icon-foreground.png'))      # المنطقة الآمنة للأيقونة التكيفية ~66%

# 2) شاشة البداية: لاندسكيب. المحتوى كله ضمن المركز الآمن (≈1500×900 من 2732²)
W = H = 2732; sp = vgrad(W,H,[(0,(7,13,24)),(.55,(16,28,50)),(.82,(70,45,60)),(1,(190,92,46))]).convert('RGBA')
hz = Image.new('RGBA',(W,H),(0,0,0,0)); ImageDraw.Draw(hz).ellipse((W*.1,H*.74,W*.9,H*1.25),fill=(255,150,70,90)); sp.alpha_composite(hz.filter(ImageFilter.GaussianBlur(120)))
m = draw_mark(760,pad=0.0); sp.alpha_composite(m,(W//2-380,H//2-520))
d = ImageDraw.Draw(sp); wordmark(d,W//2,H//2+215,200)
tag = 'COMBAT FLIGHT'; f = font(52); spaced(d,(W//2,H//2+470),tag,f,ICE+(235,),track=26,anchor='m')
d.rectangle((W//2-90,H//2+455,W//2+90,H//2+459),fill=HOT+(255,))
sp.convert('RGB').save(out('assets','splash.png'))

# 3) شعار أفقي (شفاف) + مربع للمشاركة + أيقونات الويب
hh = 420; hl = Image.new("RGBA",(2200,hh),(0,0,0,0)); hl.alpha_composite(draw_mark(hh,pad=.03),(0,0))
dd = ImageDraw.Draw(hl); f = font(190); tw = spaced(dd,(hh+30,70),'SKY',f,WHITE+(255,),10)
spaced(dd,(hh+30+tw+60,70),'STRIKE',f,HOT+(255,),10); spaced(dd,(hh+36,285),'COMBAT FLIGHT',font(52),ICE+(235,),track=24)
hl.crop(hl.getbbox()).save(out('brand','logo-horizontal.png'))
draw_mark(1024,pad=.03).save(out('brand','logo-mark.png'))
icon.convert('RGB').resize((512,512),Image.LANCZOS).save(out('public','icon-512.png'))
icon.convert('RGB').resize((192,192),Image.LANCZOS).save(out('public','icon-192.png'))
icon.convert('RGB').resize((64,64),Image.LANCZOS).save(out('public','favicon.png'))
print('brand assets done')
