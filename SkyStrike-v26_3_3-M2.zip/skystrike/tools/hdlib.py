#!/usr/bin/env python3
"""
hdlib — مكتبة صغيرة لبناء نماذج عالية التفاصيل بالكود (numpy + PIL فقط) لنماذج الأعداء v26.3
  • مجسمات: box / cbox (حواف مشطوفة) / loft (مقاطع) / extrude (مضلع) / cyl / cone / ellipsoid
  • UV مسقط حسب اتجاه الوجه، ولون رؤوس (AO + أتربة قرب الأرض)
  • خامات PBR مولّدة (ألوان + normal + خشونة/معدنية): تمويه، ألواح وبراغي، أتربة، معدن مصقول، مطاط
  • كاتب GLB بخامات مدمجة + معاين برمجي (render_model) للتحقق بدون محرك
الاتجاهات: كل الإحداثيات بنظام اللعبة (y للأعلى). الأنف -Z للطائرات، الفوهة +Z للأرضيات.
"""
import math, json, struct, io
import numpy as np
from PIL import Image, ImageDraw

D2R = math.pi / 180
def rx(a): c, s = math.cos(a*D2R), math.sin(a*D2R); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def ry(a): c, s = math.cos(a*D2R), math.sin(a*D2R); return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def rz(a): c, s = math.cos(a*D2R), math.sin(a*D2R); return np.array([[c,-s,0],[s,c,0],[0,0,1]])
def rot(x=0, y=0, z=0): return ry(y) @ rx(x) @ rz(z)

# ============================================================ مجسمات (كل واحد يرجع (P,N) مثلثات مفلطحة n*3 x 3)
def _unit(v): return v / np.maximum(np.linalg.norm(v, axis=-1, keepdims=True), 1e-12)

def _finish(T, want):
    """T: (n,3,3) مثلثات؛ want: (n,3) الاتجاه الخارجي المتوقع → يعدّل الترتيب ويحذف المثلثات الميتة"""
    T = np.asarray(T, float); want = np.asarray(want, float)
    n = np.cross(T[:,1]-T[:,0], T[:,2]-T[:,0]); ok = np.linalg.norm(n, axis=1) > 1e-9
    T, n, want = T[ok], n[ok], want[ok]
    flip = (n*want).sum(1) < 0
    T[flip] = T[flip][:, [0,2,1]]; n[flip] *= -1
    return T, _unit(n)

def _flat(T, n): return T.reshape(-1,3), np.repeat(n, 3, axis=0)

def loft(rings, smooth=False, caps=True):
    """rings: (m,k,3) حلقات مغلقة بنفس عدد النقاط. smooth = normals ناعمة على الجانب (أسطوانات/جسم طائرة)"""
    R = np.asarray(rings, float); m, k, _ = R.shape; cen = R.mean(1)
    side, want, idx = [], [], []
    for i in range(m-1):
        for j in range(k):
            j2 = (j+1) % k
            q = (R[i,j]+R[i,j2]+R[i+1,j2]+R[i+1,j])/4 - (cen[i]+cen[i+1])/2
            side += [[R[i,j],R[i,j2],R[i+1,j2]], [R[i,j],R[i+1,j2],R[i+1,j]]]; want += [q, q]
            idx += [[(i,j),(i,j2),(i+1,j2)], [(i,j),(i+1,j2),(i+1,j)]]
    T, n = _finish(side, want)
    if smooth:
        G = np.zeros((m,k,3))
        for i in range(m):
            for j in range(k):
                dk = R[i,(j+1)%k] - R[i,(j-1)%k]; di = R[min(i+1,m-1),j] - R[max(i-1,0),j]
                nn = np.cross(dk, di); out = R[i,j] - cen[i]
                if np.linalg.norm(nn) < 1e-9: nn = out
                elif np.dot(nn, out) < 0: nn = -nn
                G[i,j] = nn / max(np.linalg.norm(nn), 1e-12)
        # أعد بناء الـ normals الناعمة لنفس المثلثات الباقية (بعد حذف الميتة) — نطابق بالموضع
        P, N = [], []
        look = {}
        for i in range(m):
            for j in range(k): look.setdefault(tuple(np.round(R[i,j], 6)), G[i,j])
        Pf = T.reshape(-1,3); Nf = np.array([look.get(tuple(np.round(p, 6)), None) if tuple(np.round(p, 6)) in look else None for p in Pf], dtype=object)
        Nn = np.array([v if v is not None else np.zeros(3) for v in Nf], float)
        # المثلثات المقلوبة الاتجاه: normals الشبكة اتجاهها خارجي أصلاً
        P, N = Pf, Nn
        zero = np.linalg.norm(N, axis=1) < 1e-9
        if zero.any(): N[zero] = np.repeat(n, 3, axis=0)[zero]
    else:
        P, N = _flat(T, n)
    parts_P, parts_N = [P], [N]
    if caps:
        for e, sgn in ((0, cen[0]-cen[1]), (m-1, cen[-1]-cen[-2])):
            if np.linalg.norm(sgn) < 1e-9: continue
            tc = [[cen[e], R[e,j], R[e,(j+1)%k]] for j in range(k)]
            Tc, nc = _finish(tc, [sgn]*k)
            if len(Tc): a, b = _flat(Tc, nc); parts_P.append(a); parts_N.append(b)
    return np.concatenate(parts_P), np.concatenate(parts_N)

def box(c, s):
    cx, cy, cz = c; hx, hy, hz = s[0]/2, s[1]/2, s[2]/2
    r0 = [[cx-hx,cy-hy,cz-hz],[cx+hx,cy-hy,cz-hz],[cx+hx,cy+hy,cz-hz],[cx-hx,cy+hy,cz-hz]]
    r1 = [[p[0],p[1],cz+hz] for p in r0]
    return loft([r0, r1])

def cbox(c, s, ch=.15):
    """صندوق بحواف مشطوفة (chamfer) — أخذ ثمانيات الزوايا العمودية + تشطيب أعلى/أسفل"""
    cx, cy, cz = c; hx, hy, hz = s[0]/2, s[1]/2, s[2]/2; ch = min(ch, hx*.9, hy*.9, hz*.9)
    def ring(y, i):
        a, b = hx-i, hz-i; k = max(ch-i, 0)
        return [[cx-a+k,y,cz-b],[cx+a-k,y,cz-b],[cx+a,y,cz-b+k],[cx+a,y,cz+b-k],[cx+a-k,y,cz+b],[cx-a+k,y,cz+b],[cx-a,y,cz+b-k],[cx-a,y,cz-b+k]]
    return loft([ring(cy-hy, ch), ring(cy-hy+ch, 0), ring(cy+hy-ch, 0), ring(cy+hy, ch)])

def ear_clip(poly):
    idx = list(range(len(poly))); out = []
    def cross(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    def inside(p, a, b, c): return cross(a,b,p) >= -1e-12 and cross(b,c,p) >= -1e-12 and cross(c,a,p) >= -1e-12
    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        for n in range(len(idx)):
            i0, i1, i2 = idx[n-1], idx[n], idx[(n+1) % len(idx)]; a, b, c = poly[i0], poly[i1], poly[i2]
            if cross(a, b, c) <= 1e-12: continue
            if any(inside(poly[j], a, b, c) for j in idx if j not in (i0, i1, i2)): continue
            out.append((i0, i1, i2)); idx.pop(n); break
        else: break
    if len(idx) == 3: out.append(tuple(idx))
    return out

def extrude(poly, w0, w1, plane='zy'):
    """مضلع (u,v) → مجسم. plane='zy' يعني u→z, v→y والسماكة على x (من w0 إلى w1)."""
    poly = [tuple(p) for p in poly]
    if sum(poly[i][0]*poly[(i+1)%len(poly)][1] - poly[(i+1)%len(poly)][0]*poly[i][1] for i in range(len(poly))) < 0: poly = poly[::-1]
    ax = {'x':0, 'y':1, 'z':2}; au, av = ax[plane[0]], ax[plane[1]]; aw = 3 - au - av
    def p3(u, v, w): p = [0,0,0]; p[au] = u; p[av] = v; p[aw] = w; return np.array(p, float)
    T, want = [], []
    for (a, b, c) in ear_clip(poly):
        for w, sgn in ((w0, -1), (w1, 1)):
            T.append([p3(*poly[a], w), p3(*poly[b], w), p3(*poly[c], w)]); e = np.zeros(3); e[aw] = sgn; want.append(e)
    for i in range(len(poly)):
        a, b = poly[i], poly[(i+1) % len(poly)]; du, dv = b[0]-a[0], b[1]-a[1]
        nrm = p3(dv, -du, 0)    # خارج (للمضلع CCW)
        T += [[p3(*a,w0), p3(*b,w0), p3(*b,w1)], [p3(*a,w0), p3(*b,w1), p3(*a,w1)]]; want += [nrm, nrm]
    return _flat(*_finish(T, want))

def _circle(n, r, r2=None):
    r2 = r if r2 is None else r2
    return np.array([[math.cos(2*math.pi*i/n)*r, math.sin(2*math.pi*i/n)*r2] for i in range(n)])

def cyl(c, r, length, axis='y', seg=14, r2=None, smooth=True, caps=True):
    """أسطوانة/مخروط: r = نصف قطر البداية، r2 = نصف قطر النهاية. المحور يمتد من -length/2 إلى +length/2 حول c"""
    r2 = r if r2 is None else r2; h = length/2
    ring = lambda rr, z: [[p[0], p[1], z] for p in _circle(seg, rr)]
    P, N = loft([ring(r, -h), ring(r2, h)], smooth=smooth, caps=caps)
    R = {'z': np.eye(3), 'y': rx(-90), 'x': ry(90)}[axis]   # z→المحور المطلوب
    return place((P, N), R, c)

def ellipsoid(c, rad, seg=12, lat=7):
    rings = []
    for i in range(lat+1):
        a = math.pi*i/lat; z = -math.cos(a)*rad[2]; s = math.sin(a)
        rings.append([[math.cos(2*math.pi*j/seg)*rad[0]*s, math.sin(2*math.pi*j/seg)*rad[1]*s, z] for j in range(seg)])
    P, N = loft(rings, smooth=True, caps=False)
    return place((P, N), np.eye(3), c)

def place(prim, R=None, t=(0,0,0), s=1.0):
    P, N = prim; R = np.eye(3) if R is None else R
    return (P*s) @ R.T + np.asarray(t, float), _unit(N @ R.T)

def cat(*prims): return np.concatenate([p[0] for p in prims]), np.concatenate([p[1] for p in prims])

# ============================================================ نموذج: مجموعات (عقدة، نوع مادة) → مثلثات
class Model:
    def __init__(self, pivots=None, ground=True): self.g = {}; self.pivots = pivots or {}; self.ground = ground
    def add(self, node, kind, prim, R=None, t=(0,0,0), s=1.0):
        P, N = place(prim, R, t, s) if (R is not None or any(t) or s != 1.0) else prim
        self.g.setdefault((node, kind), []).append((P, N)); return self
    def drop(self, node, kind): self.g.pop((node, kind), None)
    def items(self):
        for (node, kind), lst in self.g.items(): yield node, kind, np.concatenate([a for a, _ in lst]), np.concatenate([b for _, b in lst])

# ============================================================ UV + ألوان الرؤوس
def uv_planar(P, N, tile, mode='planar'):
    """إسقاط مستوٍ حسب المحور الغالب لاتجاه المثلث. tile = طول القرميد بوحدات اللعبة"""
    T = P.reshape(-1,3,3); fn = np.cross(T[:,1]-T[:,0], T[:,2]-T[:,0]); a = np.abs(fn); dom = a.argmax(1)
    UV = np.zeros((len(T),3,2))
    for d, (iu, iv) in enumerate(((2,1),(0,2),(0,1))):
        m = dom == d
        if mode == 'zstripe':      # مطاط الجنازير: u دائماً مع Z (الخطوط عرضية على اتجاه المسير)
            UV[m, :, 0] = T[m, :, 2]; UV[m, :, 1] = T[m, :, 0] + T[m, :, 1]
        else:
            UV[m, :, 0] = T[m, :, iu]; UV[m, :, 1] = T[m, :, iv]
    return (UV / tile).reshape(-1, 2).astype(np.float32)

def vcolors(P, N, ground=True, dirt=(0.46,0.40,0.32)):
    """لون رؤوس: AO تقريبي (الوجوه السفلية أغمق) + أتربة قرب الأرض (للأرضيات)"""
    y = P[:,1]; c = np.ones((len(P),3))
    ao = np.clip(1 + np.minimum(N[:,1], 0)*.5, .5, 1)               # وجوه للأسفل
    c *= ao[:,None]
    if ground:
        k = np.clip((y-0.0)/3.0, 0, 1)[:,None]                      # 0 عند الأرض → 1 فوق 3 وحدات
        c *= (0.62 + 0.38*k)
        c = c*(1-0.18*(1-k)) + np.array(dirt)*0.18*(1-k)
    return np.clip(c, 0, 1).astype(np.float32)

# ============================================================ خامات مولّدة
def _rank01(a): r = np.empty(a.size); r[np.argsort(a, axis=None)] = np.linspace(0, 1, a.size); return r.reshape(a.shape)

def blob_noise(n, cells, rng):
    F = np.fft.fft2(rng.standard_normal((n, n))); fx = np.fft.fftfreq(n)[:,None]; fy = np.fft.fftfreq(n)[None,:]
    f = np.sqrt(fx**2 + fy**2); fc = cells / n
    return _rank01(np.real(np.fft.ifft2(F*np.exp(-(f/fc)**2))))

def stretch_noise(n, cu, cv, rng):
    F = np.fft.fft2(rng.standard_normal((n, n))); fx = np.fft.fftfreq(n)[:,None]; fy = np.fft.fftfreq(n)[None,:]
    return _rank01(np.real(np.fft.ifft2(F*np.exp(-(fx/(cv/n))**2 - (fy/(cu/n))**2))))

def blur(a, px):
    n = a.shape[0]; fx = np.fft.fftfreq(n)[:,None]; fy = np.fft.fftfreq(n)[None,:]; g = np.exp(-(2*(math.pi*px)**2)*(fx**2+fy**2))
    if a.ndim == 2: return np.real(np.fft.ifft2(np.fft.fft2(a)*g))
    return np.stack([blur(a[..., i], px) for i in range(a.shape[2])], -1)

def _normal_map(h, strength):
    gx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * .5; gy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * .5
    n = np.stack([-gx*strength, gy*strength, np.ones_like(h)], -1); n /= np.linalg.norm(n, axis=-1, keepdims=True)
    return ((n*.5+.5)*255).astype(np.uint8)

def _mr(rough, metal):
    s = rough.shape; out = np.zeros(s+(3,), np.uint8); out[...,0] = 255
    out[...,1] = np.clip(rough*255, 0, 255); out[...,2] = np.clip(metal*255, 0, 255); return out

def _hex(c): return np.array([int(c[1:3],16), int(c[3:5],16), int(c[5:7],16)])/255.0

def tex_paint(n=512, palette=('#55603f','#2f3a2a','#7a6e4c','#26231f'), ratios=(.42,.28,.2,.1), seed=1, panels=4, grime=.34, rough=.66, metal=.12):
    """طلاء مموّه بألواح وبراغي وأتربة وخدوش"""
    rng = np.random.default_rng(seed); cols = [_hex(c) for c in palette]
    f = _rank01(.6*blob_noise(n, 3, rng) + .4*blob_noise(n, 6, rng)); cut = np.cumsum(ratios); cls = np.digitize(f, cut[:-1])
    alb = np.zeros((n, n, 3))
    for i, c in enumerate(cols): alb[cls == i] = c
    alb = blur(alb, 1.2) * (1 + (blob_noise(n, 60, rng)-.5)[...,None]*.10)
    h = np.zeros((n, n)); step = n // panels; yy, xx = np.mgrid[0:n, 0:n]
    tone = np.ones((n, n))
    for pi in range(panels):
        for pj in range(panels): tone[pi*step:(pi+1)*step, pj*step:(pj+1)*step] = rng.uniform(.92, 1.07)
    line = ((xx % step) < 2) | ((yy % step) < 2)
    h -= line*1.0; alb *= np.where(line, .62, 1.0)[...,None]
    img = Image.new('L', (n, n), 0); dr = ImageDraw.Draw(img); sp = step // 6
    for pi in range(panels):
        for pj in range(panels):
            x0, y0 = pj*step, pi*step
            for q in range(1, 6):
                for (rx_, ry_) in ((x0+q*sp, y0+6), (x0+q*sp, y0+step-7)): dr.ellipse([rx_-2, ry_-2, rx_+2, ry_+2], fill=255)
                for (rx_, ry_) in ((x0+6, y0+q*sp), (x0+step-7, y0+q*sp)): dr.ellipse([rx_-2, ry_-2, rx_+2, ry_+2], fill=255)
    riv = np.asarray(img, float)/255; h += blur(riv, .9)*1.4; alb *= (1 + riv*.10)[...,None]; alb *= tone[...,None]
    # أتربة + مجاري مطر عمودية
    d = blob_noise(n, 6, rng)**2; st = stretch_noise(n, 80, 3, rng)*np.clip(1 - ((yy % (n//2))/(n/2)), 0, 1)
    dirt = np.clip(d*.7 + st*.45, 0, 1)*grime; brown = _hex('#5a4a36')
    alb = alb*(1-dirt[...,None]*.7) + brown*dirt[...,None]*.35
    # خدوش فاتحة
    sc = Image.new('L', (n, n), 0); ds = ImageDraw.Draw(sc)
    for _ in range(90):
        x, y = rng.integers(0, n, 2); a = rng.uniform(0, math.pi); l = rng.uniform(8, 38)
        ds.line([x, y, x+math.cos(a)*l, y+math.sin(a)*l], fill=int(rng.uniform(60, 200)), width=1)
    scr = np.asarray(sc, float)/255; alb = alb*(1-scr[...,None]*.35) + scr[...,None]*.09; h += scr*.25
    h += (blob_noise(n, 90, rng)-.5)*.25
    r = np.clip(rough + dirt*.25 - scr*.3 + (blob_noise(n, 40, rng)-.5)*.14, .25, .95); m = np.clip(metal + scr*.5, 0, 1)
    return np.clip(alb, 0, 1), _normal_map(h, 2.2), _mr(r, m)

def tex_metal(n=256, base='#34363a', seed=2, metal=.75, rough=.38):
    """معدن داكن مصقول بخطوط فرشاة وخدوش وبراغي"""
    rng = np.random.default_rng(seed); b = _hex(base); br = stretch_noise(n, 3, 90, rng)
    alb = b[None,None,:]*(0.75 + .5*br)[...,None]*(1 + (blob_noise(n, 8, rng)-.5)[...,None]*.25)
    h = (br-.5)*.5; sc = Image.new('L', (n, n), 0); ds = ImageDraw.Draw(sc)
    for _ in range(60):
        x, y = rng.integers(0, n, 2); a = rng.uniform(-.4, .4); l = rng.uniform(10, 50)
        ds.line([x, y, x+math.cos(a)*l, y+math.sin(a)*l], fill=int(rng.uniform(80, 220)), width=1)
    scr = np.asarray(sc, float)/255; alb = alb*(1-scr[...,None]*.3) + scr[...,None]*.14; h += scr*.3
    yy, xx = np.mgrid[0:n, 0:n]; line = ((xx % (n//2)) < 2) | ((yy % (n//2)) < 2); h -= line*.8; alb *= np.where(line, .6, 1)[...,None]
    r = np.clip(rough + (blob_noise(n, 30, rng)-.5)*.25 - scr*.2, .15, .9); m = np.clip(metal + (blob_noise(n, 20, rng)-.5)*.2, .2, 1)
    return np.clip(alb, 0, 1), _normal_map(h, 1.6), _mr(r, m)

def tex_rubber(n=256, seed=3):
    """مطاط/جنزير: عوارض عرضية (على u) + وسخ. u = اتجاه المسير"""
    rng = np.random.default_rng(seed); yy, xx = np.mgrid[0:n, 0:n]; per = n//8
    bar = ((xx % per) < per*.55).astype(float); lug = ((yy % (n//2)) < n*.38).astype(float)
    h = bar*.9 + bar*lug*.5 + (blob_noise(n, 70, rng)-.5)*.3
    alb = np.ones((n, n, 3))*_hex('#1a1b1c')*(0.7 + .6*blob_noise(n, 25, rng))[...,None]
    alb *= (1 - (1-bar)*.45)[...,None]; dirt = blob_noise(n, 8, rng)**2*.35; alb = alb*(1-dirt[...,None]) + _hex('#4a4132')*dirt[...,None]*.5
    return np.clip(alb, 0, 1), _normal_map(h, 2.4), _mr(np.clip(.88 + (blob_noise(n, 30, rng)-.5)*.1, .6, 1), np.full((n, n), .05))

def tex_composite(n=512, base='#8d9096', accent='#a02828', seed=4):
    """جسم مسيّرة: ألياف/ألواح رمادية مع خطوط حمراء وعلامات"""
    rng = np.random.default_rng(seed); b = _hex(base); ac = _hex(accent); yy, xx = np.mgrid[0:n, 0:n]
    alb = np.ones((n, n, 3))*b*(0.88 + .22*blob_noise(n, 5, rng))[...,None]
    step = n//4; line = ((xx % step) < 2) | ((yy % step) < 2); h = -line*1.0
    band = ((yy > n*.42) & (yy < n*.5)) | ((yy > n*.55) & (yy < n*.58)); alb = np.where(band[...,None], ac, alb)
    alb *= np.where(line, .65, 1)[...,None]
    # شبكة ألياف
    weave = (np.sin(xx*.8)*np.sin(yy*.8) > .2)*.04; alb *= (1 - weave)[...,None]; h += weave*.4
    dirt = blob_noise(n, 7, rng)**2*.25; alb = alb*(1-dirt[...,None]*.6)
    r = np.clip(.5 + (blob_noise(n, 30, rng)-.5)*.2, .3, .8)
    return np.clip(alb, 0, 1), _normal_map(h, 1.8), _mr(r, np.full((n, n), .15))

# ============================================================ كاتب GLB
def _img_bytes(arr, fmt):
    b = io.BytesIO(); im = Image.fromarray(arr)
    if fmt == 'jpeg': im.save(b, 'JPEG', quality=88, optimize=True)
    else: im.save(b, 'PNG', optimize=True)
    return b.getvalue()

def write_glb_hd(path, nodes, mats):
    """nodes: [(name, translation|None, {kind:(P,N,UV,COL)})]
       mats : {kind: dict(tex=(alb,nrm,mr)|None, color=[r,g,b], metal, rough, emissive=[r,g,b]|None, tile, ...)}"""
    bin_ = bytearray(); bvs = []; accs = []; meshes = []; jnodes = []; images = []; textures = []; materials = []; kind_idx = {}
    def add_bv(data, target=None):
        while len(bin_) % 4: bin_.append(0)
        off = len(bin_); bin_.extend(data); bv = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
        if target: bv['target'] = target
        bvs.append(bv); return len(bvs)-1
    def add_acc(arr, typ, minmax=False):
        arr = np.ascontiguousarray(arr, np.float32); bv = add_bv(arr.tobytes(), 34962)
        a = {'bufferView': bv, 'componentType': 5126, 'count': len(arr), 'type': typ}
        if minmax: a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
        accs.append(a); return len(accs)-1
    def add_tex(arr, fmt):
        bv = add_bv(_img_bytes(arr, fmt)); images.append({'bufferView': bv, 'mimeType': 'image/jpeg' if fmt == 'jpeg' else 'image/png'})
        textures.append({'sampler': 0, 'source': len(images)-1}); return len(textures)-1
    for kind, c in mats.items():
        m = {'name': kind, 'pbrMetallicRoughness': {}}; pb = m['pbrMetallicRoughness']
        if c.get('tex') is not None:
            alb, nrm, mr = c['tex']
            pb['baseColorTexture'] = {'index': add_tex((alb*255).astype(np.uint8), 'jpeg')}; pb['baseColorFactor'] = [1, 1, 1, 1]
            pb['metallicRoughnessTexture'] = {'index': add_tex(mr, 'jpeg')}; pb['metallicFactor'] = 1.0; pb['roughnessFactor'] = 1.0
            m['normalTexture'] = {'index': add_tex(nrm, 'png'), 'scale': c.get('nscale', 1.0)}
        else:
            pb['baseColorFactor'] = list(c['color']) + [1]; pb['metallicFactor'] = c.get('metal', .2); pb['roughnessFactor'] = c.get('rough', .6)
        if c.get('emissive') is not None: m['emissiveFactor'] = list(c['emissive'])
        materials.append(m); kind_idx[kind] = len(materials)-1
    for name, tr, groups in nodes:
        prims = []
        for kind, (P, N, UV, COL) in groups.items():
            if kind not in kind_idx: continue
            at = {'POSITION': add_acc(P, 'VEC3', True), 'NORMAL': add_acc(N, 'VEC3')}
            if UV is not None: at['TEXCOORD_0'] = add_acc(UV, 'VEC2')
            if COL is not None: at['COLOR_0'] = add_acc(COL, 'VEC3')
            prims.append({'attributes': at, 'material': kind_idx[kind], 'mode': 4})
        meshes.append({'name': name + '_m', 'primitives': prims}); nd = {'name': name, 'mesh': len(meshes)-1}
        if tr is not None and any(abs(x) > 1e-9 for x in tr): nd['translation'] = [float(x) for x in tr]
        jnodes.append(nd)
    j = {'asset': {'version': '2.0', 'generator': 'skystrike hdlib.py'}, 'scene': 0, 'scenes': [{'nodes': list(range(len(jnodes)))}],
         'nodes': jnodes, 'meshes': meshes, 'materials': materials, 'accessors': accs, 'bufferViews': bvs, 'buffers': [{'byteLength': len(bin_)}]}
    if images: j['images'] = images; j['textures'] = textures; j['samplers'] = [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497}]
    js = json.dumps(j, separators=(',', ':')).encode(); js += b' '*((4-len(js) % 4) % 4)
    while len(bin_) % 4: bin_.append(0)
    total = 12 + 8 + len(js) + 8 + len(bin_)
    open(path, 'wb').write(struct.pack('<4sII', b'glTF', 2, total) + struct.pack('<II', len(js), 0x4E4F534A) + js + struct.pack('<II', len(bin_), 0x004E4942) + bytes(bin_))
    return total

# ============================================================ معاين برمجي (للتحقق فقط)
def render_model(nodes, mats, views, size=(560, 380), ss=2, light=(.45, .8, .5)):
    """nodes كما بـ write_glb_hd. views = [(yaw,pitch,title)] ؛ يرجع صورة PIL"""
    W, H = size[0]*ss, size[1]*ss; tiles = []
    allp = np.concatenate([P + (np.array(tr) if tr is not None else 0) for _, tr, g in nodes for P, _, _, _ in g.values()])
    ctr = (allp.max(0)+allp.min(0))/2; ext = np.linalg.norm(allp.max(0)-allp.min(0))
    mips = {}
    for k, c in mats.items():
        if c.get('tex') is not None:
            a = (c['tex'][0]*255).astype(np.uint8); ch = [a]
            while ch[-1].shape[0] > 8: ch.append(np.asarray(Image.fromarray(ch[-1]).resize((ch[-1].shape[0]//2,)*2, Image.BOX)))
            mips[k] = ch
    Ld = np.array(light)/np.linalg.norm(light)
    for yaw, pitch, title in views:
        Rv = rx(pitch) @ ry(yaw); img = np.zeros((H, W, 3)); img[:] = np.array([.64, .70, .78]); zb = np.full((H, W), -1e9); sc = min(W, H)*.9/ext
        for name, tr, groups in nodes:
            for kind, (P, N, UV, COL) in groups.items():
                if kind not in mats: continue
                c = mats[kind]; Pw = P + (np.array(tr) if tr is not None else 0); Pv = (Pw-ctr) @ Rv.T; Nv = N @ Rv.T
                X = Pv[:,0]*sc + W/2; Y = -Pv[:,1]*sc + H/2; Z = Pv[:,2]
                base = np.array(c.get('color', [1,1,1])); em = np.array(c.get('emissive') or [0,0,0]); has = kind in mips
                for t in range(len(P)//3):
                    i = t*3; xs, ys = X[i:i+3], Y[i:i+3]
                    x0, x1 = int(max(xs.min(), 0)), int(min(xs.max()+1, W-1)); y0, y1 = int(max(ys.min(), 0)), int(min(ys.max()+1, H-1))
                    if x1 < x0 or y1 < y0: continue
                    den = (ys[1]-ys[2])*(xs[0]-xs[2]) + (xs[2]-xs[1])*(ys[0]-ys[2])
                    if abs(den) < 1e-9: continue
                    gx, gy = np.meshgrid(np.arange(x0, x1+1)+.5, np.arange(y0, y1+1)+.5)
                    l0 = ((ys[1]-ys[2])*(gx-xs[2]) + (xs[2]-xs[1])*(gy-ys[2]))/den; l1 = ((ys[2]-ys[0])*(gx-xs[2]) + (xs[0]-xs[2])*(gy-ys[2]))/den; l2 = 1-l0-l1
                    m = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
                    if not m.any(): continue
                    z = l0*Z[i] + l1*Z[i+1] + l2*Z[i+2]; sub = zb[y0:y1+1, x0:x1+1]; m &= z > sub
                    if not m.any(): continue
                    n3 = l0[...,None]*Nv[i] + l1[...,None]*Nv[i+1] + l2[...,None]*Nv[i+2]; n3 /= np.maximum(np.linalg.norm(n3, axis=-1, keepdims=True), 1e-9)
                    dif = np.clip((n3*Ld).sum(-1), 0, 1)*.75 + .38*(0.5+0.5*n3[...,1])
                    col = np.ones(l0.shape+(3,))*base
                    if has:
                        uv = l0[...,None]*UV[i] + l1[...,None]*UV[i+1] + l2[...,None]*UV[i+2]
                        area_uv = abs(np.cross(UV[i+1]-UV[i], UV[i+2]-UV[i]))*.5; area_px = abs(den)*.5
                        tex = mips[kind]; n0 = tex[0].shape[0]; lod = int(np.clip(0.5*math.log2(max(area_uv*n0*n0/max(area_px, 1e-6), 1)), 0, len(tex)-1))
                        a = tex[lod]; nn = a.shape[0]; ui = (np.floor((uv[...,0] % 1)*nn)).astype(int) % nn; vi = (np.floor((uv[...,1] % 1)*nn)).astype(int) % nn
                        col = a[vi, ui]/255.0*base
                    if COL is not None: col = col*(l0[...,None]*COL[i] + l1[...,None]*COL[i+1] + l2[...,None]*COL[i+2])
                    out = np.clip(col*dif[...,None] + em, 0, 1)
                    reg = img[y0:y1+1, x0:x1+1]; reg[m] = out[m]; sub[m] = z[m]
        im = Image.fromarray((img*255).astype(np.uint8)).resize(size, Image.LANCZOS); ImageDraw.Draw(im).text((6, 4), title, fill=(255, 255, 255)); tiles.append(im)
    out = Image.new('RGB', (size[0]*len(tiles), size[1]))
    for i, t in enumerate(tiles): out.paste(t, (i*size[0], 0))
    return out
