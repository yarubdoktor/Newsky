#!/usr/bin/env python3
"""
تحويل خريطة عالم كبيرة (GLB بمحور Z لفوق) إلى حزمة صغيرة للعبة Sky Strike:
  - heightmap (Uint16) + ألوان التضاريس (RGB)      ← تضاريس عبر نظام القطع الحالي (LOD/culling مجاني)
  - المجسمات (قاعدة، مباني، صخور) مدموجة ومقسّمة لبلاطات (tiles) بلون الرؤوس، بدون textures
  - صناديق تصادم للمباني
  - الغابات الأصلية لا تُنسخ (اللعبة تزرع أشجارها instanced وبكثافة أعلى وأخف)

التدوير: three(X,Y,Z) = (-y, z, -x)  ← الأعلى +Y، والمدرج (كان على محور x) صار على محور Z والأنف نحو -Z.

الاستعمال:
  python3 tools/convert_world.py models_src/world.glb src/models/greenland.bin
"""
import sys, os, json, struct, re
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from optimize_glb import read_glb, accessor

TERRAIN, FOREST = '20km_Procedural_Desert_Mountains', 'Procedural_Conifer_Forests'
TILE = 2400.0
SOLID = re.compile(r'^(Aircraft_Hangar|Aircraft_Shelter|Fuel_Tank_\d|Base_Service_Building|Settlement_\d_Building|Comms_Mast|Airbase_Radar_Dish|Forward_Pad_Shelter|Forward_Pad_Radio)')

def rot(p):  # (x,y,z) -> (-y, z, -x)
    p = np.asarray(p, np.float32); return np.stack([-p[:,1], p[:,2], -p[:,0]], 1)

def pad4(b): return b + b'\0' * (-len(b) % 4)

def main(src, dst):
    j, bin_ = read_glb(src)
    nodes, meshes, mats = j['nodes'], j['meshes'], j.get('materials', [])
    byname = {n.get('name'): n for n in nodes}

    def prim_data(p):
        a = p['attributes']; pos = accessor(j, bin_, a['POSITION']).astype(np.float32)[:, :3]
        idx = accessor(j, bin_, p['indices']).reshape(-1).astype(np.int64)
        col = None
        if 'COLOR_0' in a:
            col = accessor(j, bin_, a['COLOR_0']).astype(np.float32)[:, :3]
            if j['accessors'][a['COLOR_0']]['componentType'] == 5121: col /= 255.0
        return pos, idx, col

    # ---------- التضاريس -> heightmap ----------
    pos, idx, col = prim_data(meshes[byname[TERRAIN]['mesh']]['primitives'][0])
    xs = np.unique(np.round(pos[:,0],2)); ys = np.unique(np.round(pos[:,1],2)); N = len(xs); assert N == len(ys)
    ix = np.searchsorted(xs, np.round(pos[:,0],2)); iy = np.searchsorted(ys, np.round(pos[:,1],2))
    Hm = np.zeros((N,N),np.float32); Hm[iy,ix] = pos[:,2]
    Cm = np.zeros((N,N,3),np.float32); Cm[iy,ix] = col if col is not None else .5
    half = float(xs[-1]); step = float(xs[1]-xs[0])
    Hn = Hm.T[::-1, ::-1]; Cn = Cm.transpose(1,0,2)[::-1, ::-1]        # الصف = Z ، العمود = X
    hmin, hmax = float(Hn.min()), float(Hn.max())
    h16 = np.round((Hn-hmin)/(hmax-hmin)*65535).astype('<u2')
    c8 = np.round(np.clip(Cn,0,1)*255).astype('u1')

    # ---------- المجسمات ----------
    tiles = {}; boxes = []; clear = []
    for n in nodes:
        nm = n.get('name') or ''
        if 'mesh' not in n or nm in (TERRAIN, FOREST): continue
        P, I, C = [], [], []; off = 0
        for p in meshes[n['mesh']]['primitives']:
            ps, ix_, cl = prim_data(p)
            m = mats[p['material']]['pbrMetallicRoughness']['baseColorFactor'][:3] if p.get('material') is not None else [.5,.5,.5]
            cc = np.tile(np.array(m,np.float32),(len(ps),1)) * (cl if cl is not None else 1)
            P.append(rot(ps)); C.append(cc); I.append(ix_+off); off += len(ps)
        P = np.concatenate(P); I = np.concatenate(I); C = np.concatenate(C)
        mn, mx = P.min(0), P.max(0); ctr = (mn+mx)/2
        key = (int((ctr[0]+half)//TILE), int((ctr[2]+half)//TILE))
        t = tiles.setdefault(key, {'P':[], 'C':[], 'I':[], 'n':0})
        t['P'].append(P); t['C'].append(C); t['I'].append(I+t['n']); t['n'] += len(P)
        if SOLID.match(nm): boxes.append(np.concatenate([mn,mx]))
        if re.match(r'^Settlement_\d_Building', nm): clear.append(ctr)
    # مراكز المستوطنات للتنظيف من الأشجار
    cl = {}
    for c in clear:
        k = (round(float(c[0])/900), round(float(c[2])/900)); cl.setdefault(k,[]).append(c)
    clear = [[float(np.mean([a[0] for a in v])), float(np.mean([a[2] for a in v])), 260.0] for v in cl.values()]

    # ---------- التعبئة ----------
    blob = b''; hdr = {'N':N,'half':half,'step':step,'hmin':hmin,'hmax':hmax}
    def add(b):
        nonlocal blob; o = len(blob); blob += pad4(b); return o
    hdr['oH'] = add(h16.tobytes()); hdr['oC'] = add(c8.tobytes())
    B = np.array(boxes,np.float32).reshape(-1,6); hdr['nB'] = len(B); hdr['oB'] = add(B.tobytes())
    hdr['clear'] = clear; hdr['tile'] = TILE; tl = []; tv = ti = 0
    for (a,b),t in sorted(tiles.items()):
        P = np.concatenate(t['P']).astype('<f4'); C = np.round(np.clip(np.concatenate(t['C']),0,1)*255).astype('u1')
        I = np.concatenate(t['I']); assert I.max() < 65536
        o = add(P.tobytes() + pad4(C.tobytes()) + I.astype('<u2').tobytes())
        tl.append({'o':o,'v':len(P),'i':len(I)}); tv += len(P); ti += len(I)//3
    hdr['tiles'] = tl
    js = json.dumps(hdr,separators=(',',':')).encode(); js += b' ' * (-len(js) % 4)   # مسافات (مش أصفار) حتى يقرأها JSON.parse
    # رأس: [طول json][json][blob] ، والـ blob يبدأ على حدّ 4 بايت
    open(dst,'wb').write(struct.pack('<I',len(js)) + js + blob)
    print(f'grid {N}x{N} step {step:.1f}m  H {hmin:.0f}..{hmax:.0f}m | props: {len(tiles)} tiles, {tv} verts, {ti} tris | boxes {len(B)} | clearings {len(clear)}')
    print(f'output {os.path.getsize(dst)/1024:.0f} KB')

if __name__ == '__main__':
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    main(sys.argv[1], sys.argv[2])
