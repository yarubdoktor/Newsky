#!/usr/bin/env python3
"""يُشغَّل في الـ workflow بعد `npx cap add android`: يقفل اللعبة أفقياً + ملء الشاشة + منطقة الـ notch.
   لو أي خطوة ما انطبقت يفشل البناء (بدل ما يطلع APK عمودي بصمت)."""
import re, sys, pathlib
base = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else 'android/app/src/main')

man = base/'AndroidManifest.xml'; t = man.read_text(encoding='utf-8')
if 'android:screenOrientation' in t:
    t = re.sub(r'android:screenOrientation="[^"]*"','android:screenOrientation="sensorLandscape"',t)
else:
    t, n = re.subn(r'<activity\b(?![-\w])', '<activity android:screenOrientation="sensorLandscape"', t, count=1)
    assert n == 1, 'AndroidManifest: ما لقيت <activity>'
man.write_text(t, encoding='utf-8')
assert 'sensorLandscape' in man.read_text(encoding='utf-8')

st = base/'res/values/styles.xml'; s = st.read_text(encoding='utf-8')
if 'windowFullscreen' not in s:
    s, n = re.subn(r'(<style name="AppTheme\.NoActionBar"[^>]*>)',
        r'\1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>', s, count=1)
    assert n == 1, 'styles.xml: ما لقيت AppTheme.NoActionBar'
    st.write_text(s, encoding='utf-8')
assert 'windowFullscreen' in st.read_text(encoding='utf-8')
print('android patch OK: sensorLandscape + fullscreen')
