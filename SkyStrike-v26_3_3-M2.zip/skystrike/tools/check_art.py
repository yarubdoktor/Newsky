#!/usr/bin/env python3
"""يفحص صور الواجهة (src/assets/planes|weapons|campaign) مقابل المطلوب: الموجود/الناقص، المقاس، النسبة، الحجم.
التشغيل:  python3 tools/check_art.py        (يحتاج Pillow للمقاسات: pip install pillow ؛ بدونه يفحص الوجود فقط)"""
import os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
SRC = os.path.join(ROOT, 'src')
rd = lambda f: open(os.path.join(SRC, f), encoding='utf-8').read()
planes = re.findall(r"^\s{2}(\w+):\s*\{n:'", rd('data.js'), re.M)
weapons = re.findall(r"^export const WPN = \{(.*?)\};", rd('data.js'), re.S | re.M)
weapons = re.findall(r"(\w+):\{ic:", weapons[0]) if weapons else []
camp = re.findall(r"\{id:'(c\d+)'", rd('campaign.js'))
skins = [s for s in re.findall(r"^\s{2}(\w+):sk\(", rd('data.js'), re.M) if s != 'gray']
# (مجلد، أسماء، العرض×الارتفاع المطلوب، الحد الأدنى للعرض)
SPEC = [('planes', planes, (1200, 900), 900), ('weapons', weapons, (800, 640), 600), ('campaign', camp, (1000, 1000), 800), ('modes', ['survive','assault','defend'], (800, 500), 600)]
EXT = ('.webp', '.png', '.jpg')
try: from PIL import Image
except ImportError: Image = None; print('! Pillow غير مثبّت: بفحص الوجود فقط (pip install pillow)\n')

def find(d, name):
    for e in EXT:
        p = os.path.join(SRC, 'assets', d, name + e)
        if os.path.isfile(p): return p
    return None
def check(p, want, minw):
    msg, bad = [], False
    kb = os.path.getsize(p) / 1024
    if kb > 400: msg.append(f'حجم الملف {kb:.0f}KB (الأفضل < 300KB)'); bad = True
    if Image:
        w, h = Image.open(p).size
        if abs(w / h - want[0] / want[1]) / (want[0] / want[1]) > .08: msg.append(f'النسبة {w}×{h} (المطلوب {want[0]}×{want[1]})'); bad = True
        elif w < minw: msg.append(f'صغيرة {w}×{h} (الحد الأدنى {minw} عرض)'); bad = True
        return f'{w}×{h} · {kb:.0f}KB', msg, bad
    return f'{kb:.0f}KB', msg, bad

have = miss = warn = 0
for d, names, want, minw in SPEC:
    print(f'== assets/{d}  (المطلوب {want[0]}×{want[1]})')
    for n in names:
        p = find(d, n)
        if not p: miss += 1; print(f'  ✗ {n:8} ناقصة   ← src/assets/{d}/{n}.webp'); continue
        info, msg, bad = check(p, want, minw); have += 1; warn += bad
        print(f"  {'!' if bad else '✓'} {n:8} {info}" + (('  ⚠ ' + ' · '.join(msg)) if msg else ''))
    if d == 'planes':
        extra = [f for f in sorted(os.listdir(os.path.join(SRC, 'assets', d))) if re.match(r'^(%s)_(%s)\.' % ('|'.join(planes), '|'.join(skins)), f)] if os.path.isdir(os.path.join(SRC, 'assets', d)) else []
        print('  (اختياري) صور الألوان:', ', '.join(extra) if extra else 'لا يوجد — لون غير افتراضي يرجع لمعاينة المحرك')
print(f'\nالموجود {have} · الناقص {miss} · تحذيرات {warn}')
sys.exit(1 if warn else 0)
