#!/usr/bin/env python3
"""v25: أيقونة التطبيق الجديدة «Strike Reticle» (طائرة + مصوّب برتقالي) + أصول المتجر.
   التشغيل: python3 tools/make_icons.py     (يحتاج Pillow + خط Poppins، نفس make_brand.py)
   يولّد: assets/icon-only|icon-foreground|icon-background|icon-monochrome.png ، public/icon-*.png ، favicon،
          brand/store/play-icon-512.png و feature-graphic-1024x500.png"""
import math, os, re
from PIL import Image, ImageDraw, ImageFilter
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
exec(open(os.path.join(HERE,'make_brand.py'),encoding='utf-8').read().split('# 1) أيقونة التطبيق')[0])   # يستعير دوال الرسم والألوان فقط
out = lambda *p: os.path.join(ROOT,*p)

def ring_layer(S, R, th, col):
    """حلقة مصوّب: 4 أقواس بينها فجوات + 4 علامات خارجية"""
    L = Image.new('RGBA',(S,S),(0,0,0,0)); d = ImageDraw.Draw(L); c = S/2
    box = (c-R,c-R,c+R,c+R)
    for a0 in (0,90,180,270):
        d.arc(box,a0+14,a0+76,fill=col,width=int(th))
    for a in (0,90,180,270):
        r = math.radians(a-45+45); ux, uy = math.cos(math.radians(a+45)), math.sin(math.radians(a+45))
    for a in (45,135,225,315):                       # علامات بالفجوات (عند 0/90/180/270 فعلياً)
        pass
    for a in (0,90,180,270):
        ux, uy = math.cos(math.radians(a)), math.sin(math.radians(a))
        d.line([(c+ux*(R-th*1.5),c+uy*(R-th*1.5)),(c+ux*(R+th*1.9),c+uy*(R+th*1.9))],fill=col,width=int(th*.85))
    return L

def compose(size, content, bg=True, mono=False):
    """content = نسبة قطر الحلقة من حجم اللوحة. الأيقونة التكيفية: 0.60 (ضمن المنطقة الآمنة)، الكاملة: 0.80"""
    S = size*SS; im = Image.new('RGBA',(S,S),(0,0,0,0))
    R = S*content/2; th = S*content*.052
    # توهج برتقالي خلف الحلقة
    if not mono:
        gl = Image.new('RGBA',(S,S),(0,0,0,0)); ImageDraw.Draw(gl).ellipse((S/2-R,S/2-R,S/2+R,S/2+R),fill=HOT+(70,)); im.alpha_composite(gl.filter(ImageFilter.GaussianBlur(S*.03)))
    # قرص داكن داخل الحلقة لإبراز الطائرة
    if not mono:
        dk = Image.new('RGBA',(S,S),(0,0,0,0)); ImageDraw.Draw(dk).ellipse((S/2-R*.93,S/2-R*.93,S/2+R*.93,S/2+R*.93),fill=(8,16,30,150)); im.alpha_composite(dk)
    im.alpha_composite(ring_layer(S,R,th,HOT+(255,)))
    # الطائرة + الاندفاع (تتجاوز الحلقة من الذيل = إحساس بالسرعة)
    m = draw_mark(int(size*content*1.25),pad=.02,ang=45).resize((int(S*content*1.25),)*2,Image.LANCZOS) if False else draw_mark(int(size*content*1.22),pad=.0,ang=45)
    mm = m.resize((int(S*content*1.22),)*2,Image.LANCZOS); im.alpha_composite(mm,(int(S/2-mm.width/2),int(S/2-mm.height/2)))
    return im.resize((size,size),Image.LANCZOS)

def dusk_bg(size=1024):
    bg = vgrad(size,size,DUSK).convert('RGBA')
    sun = Image.new('RGBA',(size,size),(0,0,0,0)); ImageDraw.Draw(sun).ellipse((-200,size*.74,size*1.2,size*1.45),fill=(255,190,120,150))
    bg.alpha_composite(sun.filter(ImageFilter.GaussianBlur(size*.06))); return bg

if __name__ == '__main__':
    bg = dusk_bg(); icon = bg.copy(); icon.alpha_composite(compose(1024,.68))
    icon.convert('RGB').save(out('assets','icon-only.png')); bg.convert('RGB').save(out('assets','icon-background.png'))
    compose(1024,.58).save(out('assets','icon-foreground.png'))
    # أحادية اللون (Android 13 themed icon): شكل أبيض على شفاف
    fg = compose(1024,.58,mono=True); a = fg.split()[3].point(lambda v: 255 if v>40 else 0); Image.merge('RGBA',(a.point(lambda v:255),a.point(lambda v:255),a.point(lambda v:255),a)).save(out('assets','icon-monochrome.png'))
    for n,s in (('icon-512',512),('icon-192',192)): icon.convert('RGB').resize((s,s),Image.LANCZOS).save(out('public',n+'.png'))
    icon.convert('RGB').resize((64,64),Image.LANCZOS).save(out('public','favicon.png'))
    os.makedirs(out('brand','store'),exist_ok=True)
    icon.convert('RGB').resize((512,512),Image.LANCZOS).save(out('brand','store','play-icon-512.png'))
    # Feature graphic 1024x500
    W,H = 1024,500; fgm = vgrad(W,H,[(0,(7,13,24)),(.55,(18,30,54)),(.85,(110,60,60)),(1,(230,112,50))]).convert('RGBA')
    hz = Image.new('RGBA',(W,H),(0,0,0,0)); ImageDraw.Draw(hz).ellipse((W*.05,H*.78,W*.95,H*1.5),fill=(255,150,70,110)); fgm.alpha_composite(hz.filter(ImageFilter.GaussianBlur(40)))
    ic = compose(400,.74); fgm.alpha_composite(ic,(W-430,50))
    d = ImageDraw.Draw(fgm); f = font(84); tw = spaced(d,(60,150),'SKY',f,WHITE+(255,),5); spaced(d,(60+tw+28,150),'STRIKE',f,HOT+(255,),5)
    spaced(d,(66,278),'COMBAT FLIGHT',font(30),ICE+(235,),track=14); d.rectangle((66,262,226,266),fill=HOT+(255,))
    fgm.convert('RGB').save(out('brand','store','feature-graphic-1024x500.png'))

    # شعار جديد (شفاف) + أفقي + شاشة البداية بالمصوّب
    mark = compose(1024,.86); mark.save(out('brand','logo-mark.png')); mark.resize((256,256),Image.LANCZOS).save(out('src','assets','logo-mark.png'))
    hh = 420; hl = Image.new("RGBA",(2200,hh),(0,0,0,0)); hl.alpha_composite(compose(hh,.92),(0,0)); dd = ImageDraw.Draw(hl); f = font(190)
    tw = spaced(dd,(hh+30,70),'SKY',f,WHITE+(255,),10); spaced(dd,(hh+30+tw+60,70),'STRIKE',f,HOT+(255,),10); spaced(dd,(hh+36,285),'COMBAT FLIGHT',font(52),ICE+(235,),track=24)
    hl = hl.crop(hl.getbbox()); hl.save(out('brand','logo-horizontal.png')); hl.save(out('src','assets','logo-horizontal.webp'),quality=90,method=6)
    W = H = 2732; sp = vgrad(W,H,[(0,(7,13,24)),(.55,(16,28,50)),(.82,(70,45,60)),(1,(190,92,46))]).convert('RGBA')
    hz = Image.new('RGBA',(W,H),(0,0,0,0)); ImageDraw.Draw(hz).ellipse((W*.1,H*.74,W*.9,H*1.25),fill=(255,150,70,90)); sp.alpha_composite(hz.filter(ImageFilter.GaussianBlur(120)))
    sp.alpha_composite(compose(820,.86),(W//2-410,H//2-560)); d = ImageDraw.Draw(sp); wordmark(d,W//2,H//2+215,200)
    spaced(d,(W//2,H//2+470),'COMBAT FLIGHT',font(52),ICE+(235,),track=26,anchor='m'); d.rectangle((W//2-90,H//2+455,W//2+90,H//2+459),fill=HOT+(255,))
    sp.convert('RGB').save(out('assets','splash.png'))
    print('icons done')
