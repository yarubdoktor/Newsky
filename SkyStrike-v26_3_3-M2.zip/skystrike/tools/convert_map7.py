#!/usr/bin/env python3
"""
تحويل الخريطة السابعة (Map 7: القاعدتان + الأساطيل، 24×24 كم) إلى حزمة صغيرة للعبة.

المصادر (الملفات المنفصلة اللي بالمشروع):
  models_src/map7_terrain.glb  ← التضاريس (شبكة 129×129 بخطوة 187.5م + ألوان رؤوس)  [= terrain.glb]
  models_src/map7_world.glb    ← كل المجسمات: القواعد A/B + السفن + المستوطنات + الجسر + الفنار + المنصة + التوربينات
                                 [= world_full.glb = airbase.glb + ships.glb + props.glb]
  (world_complete.glb نسخة أقدم وأقل تفاصيل، وworld.glb فيه فقط العلامات Point/Spawn/Carrier — لا حاجة لهم بالتحويل)

التدوير: three(X,Y,Z) = (-y, z, -x) ← الأعلى +Y. المدارج (كانت على محور x) صارت على محور Z:
  القاعدة A (البداية) عند Z=+4500 والأنف نحو -Z ، القاعدة B عند Z=-4500 ، الجزيرة المركزية عند (0,0).

تعديلات مقصودة على المصدر (لأنها كانت تعطي مظهراً/تصادماً غلط داخل اللعبة):
  0. الساحل بالمصدر درجات سلّم (شبكة 187.5م) ← تنعيم خفيف لخلايا الساحل فقط (الهضبة والتلال ما تتأثر).
  1. الشاطئ كان بارتفاع 0.0 بالضبط = نفس مستوى سطح الماء ← وميض (z-fighting) على حلقة بعرض ~300م حول كل جزيرة.
     نرفع الشاطئ +2.2م (يتلاشى فوق 6م وتحت -30م، فالمدارج والهضاب ما تتأثر).
  2. المجسمات الأرضية كلها مرسومة على z=0 بينما الأرض 0..65م (المستوطنات) أو 24م (القاعدة) ← تُلصق بالأرض فعلياً
     (ترتفع/تنخفض لسطح التضاريس + قاعدة تمتد تحتها). المدارج/الممرات/السفن/الجسر/المنصة تبقى ثابتة.
  3. مجسمات السفن بدون لاحقة (Ship_Carrier_A ...) صندوق تصادم بحجم السفينة كلها وارتفاعه يغطّي سطح الحاملة،
     فلو رُسم لأخفى سطح الحاملة والمدرج المائل ← يُستعمل للتصادم فقط ولا يُرسم.
  4. سفينتا الشحن (Cargo_Ship) كانتا على اليابسة قرب الميناء ← تُزاحان جنوباً لأقرب ماء مفتوح. الفنار كان بالبحر ← يُزاح لأقرب شاطئ.
     مبنى مستوطنة غاطس بالماء يُحذف.

الاستعمال:
  python3 tools/convert_map7.py models_src/map7_terrain.glb models_src/map7_world.glb src/models/map7.bin
"""
import sys, os, json, struct, re
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from optimize_glb import read_glb, accessor

TERRAIN = 'World_Terrain'
TILE = 3000.0
HALF = 12000.0
LIFT = 2.2
SKIP = re.compile(r'^(World_Terrain|Spawn_.*|Point_.*|Carrier_[AB])$')             # علامات منطقية + مسطح الأرض الفارغ
SHIP = re.compile(r'^(Ship_(?:Carrier|Destroyer|Frigate|Tanker)_[AB](?:_\d+)?)(?:_(hull|deck|island|angled|mast))?$')
CARGO = re.compile(r'^(Cargo_Ship_\d+)$')
SOLID = re.compile(r'^(Aircraft_Hangar|Aircraft_Shelter|Fuel_Tank_|Base_Service_Building|Settlement_\d_Building|Comms_Mast|Airbase_Radar_Dish|Wind_Turbine_\d+_Tower|Lighthouse|Oil_Platform|Pylon_|Harbor_Crane|Bridge_Deck|Bridge_Pier|Cargo_Ship_\d+$)')
FIXED = re.compile(r'^(Runway|Taxiway|Apron|Ship_|Cargo_Ship_|Oil_Platform|Bridge_Deck)')   # لا تُلصق: مسطّحة أصلاً أو على الماء
FOLLOW = [   # أجزاء تتبع عنصراً رئيسياً (anchor) كي ما ينفصل عنه
    (re.compile(r'^(Airbase_Radar_Dish_\d+_[AB])$'), lambda m: m[1] + '_base'),
    (re.compile(r'^Wind_Turbine_(\d+)_Hub$'),        lambda m: f'Wind_Turbine_{m[1]}_Tower'),
]
ISLANDS = [(-4500, 0), (4500, 0), (0, 0), (0, 3500), (0, -3500)]                    # مراكز الجزر بإحداثيات المصدر

def rot(p):  # (x,y,z) -> (-y, z, -x)
    p = np.asarray(p, np.float32); return np.stack([-p[:, 1], p[:, 2], -p[:, 0]], 1)
def pad4(b): return b + b'\0' * (-len(b) % 4)
sm = lambda t: t * t * (3 - 2 * t)

def main(tsrc, wsrc, dst):
    # ---------- التضاريس ----------
    tj, tb = read_glb(tsrc)
    p = tj['meshes'][[n for n in tj['nodes'] if n.get('name') == TERRAIN][0]['mesh']]['primitives'][0]
    P = accessor(tj, tb, p['attributes']['POSITION']).astype(np.float64)
    N = int(round(len(P) ** .5)); assert N * N == len(P), 'شبكة التضاريس يجب أن تكون مربعة'
    step = 2 * HALF / (N - 1)
    ix = np.rint((P[:, 0] + HALF) / step).astype(int); iy = np.rint((P[:, 1] + HALF) / step).astype(int)
    Zs = np.zeros((N, N)); Zs[iy, ix] = P[:, 2]                                       # الصف = y ، العمود = x (إحداثيات المصدر)
    # 1) رفع الشاطئ فوق الماء
    Zs = Zs + LIFT * (1 - sm(np.clip(Zs / 6.0, 0, 1))) * sm(np.clip((Zs + 30.0) / 30.0, 0, 1))
    # 2) تنعيم الساحل: الشبكة 187.5م فالشاطئ يطلع درجات سلّم (مثمّن). نعمل blur 3×3 مرتين على خلايا الساحل فقط (بجوارها يابسة وبحر معاً)
    def blur(Z):
        Pd = np.pad(Z, 1, mode='edge'); k = np.array([1., 2., 1.])
        R = sum(k[a] * Pd[a:a + N, :] for a in range(3)) / 4.0                    # على الصفوف
        Pd = np.pad(R, ((0, 0), (1, 1)), mode='edge'); return sum(k[a] * Pd[:, a:a + N] for a in range(3)) / 4.0
    for _ in range(2):
        Pd = np.pad(Zs, 1, mode='edge'); mx = np.max([Pd[a:a + N, b:b + N] for a in range(3) for b in range(3)], 0); mn = np.min([Pd[a:a + N, b:b + N] for a in range(3) for b in range(3)], 0)
        coast = (mx > -5) & (mn < -40); coast = coast & (Zs < 20)                  # ما نلمس الهضبة (24م) ولا التلال
        Zs = np.where(coast, blur(Zs), Zs)
    Hn = Zs.T[::-1, ::-1].copy()                                                      # الصف = Z ، العمود = X (نفس قاعدة Greenland)
    hmin, hmax = float(Hn.min()), float(Hn.max())
    h16 = np.round((Hn - hmin) / (hmax - hmin) * 65535).astype('<u2')

    def cr(p0, p1, p2, p3, t): return p1 + .5 * t * (p2 - p0 + t * (2 * p0 - 5 * p1 + 4 * p2 - p3 + t * (3 * (p1 - p2) + p3 - p0)))
    def ground(x, y):                                                                  # نفس استيفاء arch/map7_height.js (bicubic + قصّ التجاوز)
        u = min(max((x + HALF) / step, 0), N - 1.0001); v = min(max((y + HALF) / step, 0), N - 1.0001)
        i, k = int(u), int(v); fu, fv = u - i, v - k; c = lambda a: min(max(a, 0), N - 1)
        row = lambda dk: (lambda r: cr(Zs[r, c(i - 1)], Zs[r, i], Zs[r, c(i + 1)], Zs[r, c(i + 2)], fu))(c(k + dk))
        val = cr(row(-1), row(0), row(1), row(2), fv)
        core = [Zs[k, i], Zs[k, c(i + 1)], Zs[c(k + 1), i], Zs[c(k + 1), c(i + 1)]]
        return float(min(max(val, min(core)), max(core)))
    def foot(mn, mx, n=5):
        return [ground(x, y) for x in np.linspace(mn[0], mx[0], n) for y in np.linspace(mn[1], mx[1], n)]

    # ---------- المجسمات ----------
    j, bin_ = read_glb(wsrc)
    nodes, meshes, mats = j['nodes'], j['meshes'], j.get('materials', [])
    objs = {}
    for n in nodes:
        nm = n.get('name') or ''
        if 'mesh' not in n or SKIP.match(nm): continue
        assert not any(k in n for k in ('matrix', 'translation', 'rotation', 'scale')), f'{nm}: العقدة فيها تحويل؛ المحوّل يفترض هندسة جاهزة بالعالم'
        Ps, Is, Cs = [], [], []; off = 0
        for pr in meshes[n['mesh']]['primitives']:
            a = pr['attributes']; ps = accessor(j, bin_, a['POSITION']).astype(np.float32)[:, :3]
            ix_ = accessor(j, bin_, pr['indices']).reshape(-1).astype(np.int64)
            cl = accessor(j, bin_, a['COLOR_0']).astype(np.float32)[:, :3] if 'COLOR_0' in a else None
            if cl is not None and j['accessors'][a['COLOR_0']]['componentType'] == 5121: cl /= 255.0
            m = mats[pr['material']]['pbrMetallicRoughness']['baseColorFactor'][:3] if pr.get('material') is not None else [1, 1, 1]
            Ps.append(ps); Cs.append(np.tile(np.array(m, np.float32), (len(ps), 1)) * (cl if cl is not None else 1)); Is.append(ix_ + off); off += len(ps)
        objs[nm] = {'P': np.concatenate(Ps), 'I': np.concatenate(Is), 'C': np.concatenate(Cs)}
    stats = {'snapped': 0, 'fixed': 0, 'dropped': [], 'moved': [], 'hitonly': 0}

    # ---------- السفن: يجب أن تقف على الماء ----------
    groups = {}
    for nm in objs:
        m = SHIP.match(nm) or CARGO.match(nm)
        if m: groups.setdefault(m[1], []).append(nm)
    def gbox(k, dy=0.0, dx=0.0):
        P = np.concatenate([objs[nm]['P'] for nm in groups[k]]); mn, mx = P.min(0), P.max(0)
        return mn[0] - 40 + dx, mn[1] - 40 + dy, mx[0] + 40 + dx, mx[1] + 40 + dy
    def is_water(b): return max(foot((b[0], b[1]), (b[2], b[3]), 9)) < -1.0
    def overlap(a, b): return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]
    for k in sorted(groups):
        if is_water(gbox(k)): continue
        others = [gbox(o) for o in groups if o != k]
        for dy in range(-100, -3200, -100):
            b = gbox(k, dy)
            if is_water(b) and not any(overlap(b, o) for o in others):
                for nm in groups[k]: objs[nm]['P'] = objs[nm]['P'] + np.array([0, dy, 0], np.float32)
                stats['moved'].append((k, dy)); break
        else: raise SystemExit(f'لم أجد ماءً للسفينة {k}')

    # ---------- الفنار: لأقرب شاطئ ----------
    for nm in [n for n in objs if n.startswith('Lighthouse')]:
        P = objs[nm]['P']; mn, mx = P.min(0), P.max(0)
        if min(foot(mn, mx, 3)) >= 1.5: continue
        c = np.array([(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2]); ic = np.array(min(ISLANDS, key=lambda q: np.hypot(q[0] - c[0], q[1] - c[1])), float)
        d = (ic - c) / np.hypot(*(ic - c))
        for t in range(0, 3000, 25):
            q = c + d * t; g = min(foot((q[0] - 8, q[1] - 8), (q[0] + 8, q[1] + 8), 3))
            if g >= 1.5 and g <= 8:
                objs[nm]['P'] = P + np.array([q[0] - c[0], q[1] - c[1], 0], np.float32); stats['moved'].append((nm, f'{t}م نحو الجزيرة')); break
        else: raise SystemExit('لم أجد شاطئاً للفنار')

    # ---------- لصق الأشياء الأرضية بالتضاريس ----------
    anchor_of = {}
    for nm in objs:
        for rx, fn in FOLLOW:
            m = rx.match(nm)
            if m: anchor_of[nm] = fn(m); break
    off_of = {}
    for nm, o in objs.items():
        if nm in anchor_of or FIXED.match(nm): continue
        P = o['P']; mn, mx = P.min(0), P.max(0); g = foot(mn, mx, 5); gmax, gmin = max(g), min(g)
        if nm.startswith('Settlement_') and gmax < 1.0: stats['dropped'].append(nm); continue    # مبنى غاطس بالبحر
        base = max(gmax, 0.0)
        off_of[nm] = (base - float(mn[2]), min(gmin, base) - 3.0)          # (إزاحة رأسية، قاع القاعدة)
        stats['snapped'] += 1
    for nm in list(anchor_of):
        a = anchor_of[nm]
        if a in off_of: off_of[nm] = (off_of[a][0], None)
    for nm in stats['dropped']: objs.pop(nm, None)

    tiles = {}; boxes = []; clear = []
    for nm, o in sorted(objs.items()):
        P = o['P'].copy()
        if nm in off_of:
            dz, floor = off_of[nm]; zmin = float(P[:, 2].min()); low = P[:, 2] < zmin + 0.01
            P[:, 2] += dz
            if floor is not None: P[low, 2] = min(floor, P[low, 2].min())     # قاعدة تمتد تحت الأرض لسدّ الفجوات على المنحدرات
        else: stats['fixed'] += 1
        R = rot(P); I = o['I']; C = o['C']
        mn, mx = R.min(0), R.max(0); ctr = (mn + mx) / 2
        sm_ = SHIP.match(nm)
        hit_only = bool(sm_ and sm_[2] is None)                              # صندوق السفينة الكامل: تصادم فقط
        if not hit_only:
            key = (int((ctr[0] + HALF) // TILE), int((ctr[2] + HALF) // TILE))
            t = tiles.setdefault(key, {'P': [], 'C': [], 'I': [], 'n': 0})
            t['P'].append(R); t['C'].append(C); t['I'].append(I + t['n']); t['n'] += len(R)
        else: stats['hitonly'] += 1
        if SOLID.match(nm) or (sm_ and (hit_only or sm_[2] in ('island', 'mast'))): boxes.append(np.concatenate([mn, mx]))
        if re.match(r'^Settlement_\d_Building', nm): clear.append(ctr)
    cl = {}
    for c in clear: cl.setdefault((round(float(c[0]) / 900), round(float(c[2]) / 900)), []).append(c)
    clear = [[float(np.mean([a[0] for a in v])), float(np.mean([a[2] for a in v])), 260.0] for v in cl.values()]

    # ---------- التعبئة (نفس تنسيق Greenland بدون مصفوفة ألوان) ----------
    blob = b''; hdr = {'N': N, 'half': HALF, 'step': step, 'hmin': hmin, 'hmax': hmax}
    def add(b):
        nonlocal blob; o = len(blob); blob += pad4(b); return o
    hdr['oH'] = add(h16.tobytes())
    B = np.array(boxes, np.float32).reshape(-1, 6); hdr['nB'] = len(B); hdr['oB'] = add(B.tobytes())
    hdr['clear'] = clear; hdr['tile'] = TILE; tl = []; tv = ti = 0
    for (a, b), t in sorted(tiles.items()):
        Pp = np.concatenate(t['P']).astype('<f4'); Cc = np.round(np.clip(np.concatenate(t['C']), 0, 1) * 255).astype('u1')
        Ii = np.concatenate(t['I']); assert Ii.max() < 65536, 'بلاطة تتجاوز 65535 رأس'
        o = add(Pp.tobytes() + pad4(Cc.tobytes()) + Ii.astype('<u2').tobytes())
        tl.append({'o': o, 'v': len(Pp), 'i': len(Ii)}); tv += len(Pp); ti += len(Ii) // 3
    hdr['tiles'] = tl
    js = json.dumps(hdr, separators=(',', ':')).encode(); js += b' ' * (-len(js) % 4)
    open(dst, 'wb').write(struct.pack('<I', len(js)) + js + blob)
    print(f'grid {N}x{N} step {step:.1f}m  H {hmin:.1f}..{hmax:.1f}m | props: {len(tiles)} tiles, {tv} verts, {ti} tris | boxes {len(B)} | clearings {len(clear)}')
    print(f'snapped {stats["snapped"]} · fixed {stats["fixed"]} · hitbox-only {stats["hitonly"]} · dropped(in sea) {stats["dropped"]}')
    print(f'moved: {stats["moved"]}')
    print(f'output {os.path.getsize(dst)/1024:.0f} KB')

if __name__ == '__main__':
    if len(sys.argv) < 4: print(__doc__); sys.exit(1)
    main(*sys.argv[1:4])
