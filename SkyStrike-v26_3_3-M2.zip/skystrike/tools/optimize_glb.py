#!/usr/bin/env python3
"""
أداة تحضير نماذج GLB للعبة Sky Strike (بدون أي مكتبة غير numpy).
تعمل: تدوير النموذج لاتجاه اللعبة (الأنف نحو -Z والأعلى +Y) + ضبط الطول + دمج القطع حسب المادة
(draw calls أقل بكثير) + حذف أجزاء (عجلات/براغي) + حساب normals ناعمة + تحريك الأصل لمركز الطائرة.

مثال (نفس اللي استُخدم للـ F-35):
  python3 tools/optimize_glb.py models_src/F35_Stealth_Fighter_Premium.glb src/models/f35.glb \
      --forward +x --up +z --length 14 --drop "landing gear,wheel hub,gear brace,fastener"

--forward/--up: اتجاه الأنف والأعلى داخل النموذج الأصلي (+x -x +y -y +z -z).
إذا طلع النموذج بالعبة مقلوب/ماشي بالعكس جرّب قيم مختلفة.
"""
import sys, json, struct, argparse, math
import numpy as np

AX = {'x':0,'y':1,'z':2}
def axis(s):
    v = np.zeros(3); v[AX[s[1]]] = 1.0 if s[0] == '+' else -1.0; return v

def read_glb(path):
    b = open(path,'rb').read(); assert b[:4] == b'glTF', 'مش ملف GLB'
    off = 12; js = None; bin_ = b''
    while off < len(b):
        l, t = struct.unpack('<II', b[off:off+8]); d = b[off+8:off+8+l]; off += 8+l
        if t == 0x4E4F534A: js = json.loads(d)
        elif t == 0x004E4942: bin_ = d
    if not js.get('materials'):   # نماذج بدون مواد (ألوان رؤوس فقط): نضيف مادة رمادية معدنية
        js['materials'] = [{'name':'Fighter grey','pbrMetallicRoughness':{'baseColorFactor':[.57,.6,.635,1],'metallicFactor':.55,'roughnessFactor':.45}}]
    return js, bin_

CT = {5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC = {'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def accessor(j, bin_, i):
    a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
    dt = CT[a['componentType']]; n = NC[a['type']]; off = bv.get('byteOffset',0)+a.get('byteOffset',0)
    stride = bv.get('byteStride')
    if stride and stride != np.dtype(dt).itemsize*n:
        raw = np.frombuffer(bin_, dtype=np.uint8, count=stride*a['count'], offset=off).reshape(a['count'],stride)
        return raw[:, :np.dtype(dt).itemsize*n].copy().view(dt).reshape(a['count'],n)
    return np.frombuffer(bin_, dtype=dt, count=a['count']*n, offset=off).reshape(a['count'],n)

def node_matrix(n):
    if 'matrix' in n: return np.array(n['matrix'],dtype=float).reshape(4,4).T
    m = np.eye(4); t = n.get('translation',[0,0,0]); q = n.get('rotation',[0,0,0,1]); s = n.get('scale',[1,1,1])
    x,y,z,w = q
    R = np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
    m[:3,:3] = R*np.array(s); m[:3,3] = t; return m

def collect(j, bin_, drops):
    """يرجع {material_index: [مثلثات (N,3,3)]} بإحداثيات عالمية"""
    out = {}; dropped = 0
    def walk(ni, parent):
        nonlocal dropped
        n = j['nodes'][ni]; M = parent @ node_matrix(n)
        if 'mesh' in n:
            name = n.get('name','').lower()
            if any(d and d in name for d in drops): dropped += 1
            else:
                for pr in j['meshes'][n['mesh']]['primitives']:
                    if pr.get('mode',4) != 4: continue
                    P = accessor(j,bin_,pr['attributes']['POSITION']).astype(float)
                    P = (np.c_[P,np.ones(len(P))] @ M.T)[:,:3]
                    idx = accessor(j,bin_,pr['indices']).reshape(-1) if 'indices' in pr else np.arange(len(P))
                    out.setdefault(pr.get('material',0),[]).append(P[idx].reshape(-1,3,3))
        for c in n.get('children',[]): walk(c,M)
    for r in j['scenes'][j.get('scene',0)]['nodes']: walk(r,np.eye(4))
    return {k:np.concatenate(v) for k,v in out.items()}, dropped

def smooth_normals(tris, angle=38.0):
    """normals ناعمة داخل زاوية معينة، وحادة عند الحواف"""
    e1 = tris[:,1]-tris[:,0]; e2 = tris[:,2]-tris[:,0]; fn = np.cross(e1,e2)
    area = np.linalg.norm(fn,axis=1); fnu = fn/np.maximum(area[:,None],1e-12)
    cosT = math.cos(math.radians(angle)); N = len(tris); normals = np.zeros((N,3,3))
    buckets = {}
    for f in range(N):
        for k in range(3): buckets.setdefault(tuple(np.round(tris[f,k],4)),[]).append(f)
    for f in range(N):
        for k in range(3):
            acc = np.zeros(3)
            for g in buckets[tuple(np.round(tris[f,k],4))]:
                if np.dot(fnu[f],fnu[g]) >= cosT: acc += fn[g]
            l = np.linalg.norm(acc); normals[f,k] = acc/l if l > 1e-12 else fnu[f]
    return normals

def write_glb(path, groups, materials, names):
    bin_ = bytearray(); bvs = []; accs = []; meshes = []; nodes = []
    for gi,(mi,tris,nrm) in enumerate(groups):
        P = tris.reshape(-1,3).astype(np.float32); Nn = nrm.reshape(-1,3).astype(np.float32)
        for arr,key in ((P,'POSITION'),(Nn,'NORMAL')):
            off = len(bin_); bin_ += arr.tobytes(); bvs.append({'buffer':0,'byteOffset':off,'byteLength':arr.nbytes,'target':34962})
            a = {'bufferView':len(bvs)-1,'componentType':5126,'count':len(arr),'type':'VEC3'}
            if key == 'POSITION': a['min'] = P.min(0).tolist(); a['max'] = P.max(0).tolist()
            accs.append(a)
        meshes.append({'name':names[gi],'primitives':[{'attributes':{'POSITION':len(accs)-2,'NORMAL':len(accs)-1},'material':mi,'mode':4}]})
        nodes.append({'name':names[gi],'mesh':gi})
    j = {'asset':{'version':'2.0','generator':'skystrike optimize_glb.py'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],
         'nodes':nodes,'meshes':meshes,'materials':materials,'accessors':accs,'bufferViews':bvs,'buffers':[{'byteLength':len(bin_)}]}
    js = json.dumps(j,separators=(',',':')).encode(); js += b' '*((4-len(js)%4)%4); bin_ += b'\0'*((4-len(bin_)%4)%4)
    total = 12+8+len(js)+8+len(bin_)
    open(path,'wb').write(struct.pack('<4sII',b'glTF',2,total)+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(bin_),0x004E4942)+bytes(bin_))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('inp'); ap.add_argument('out')
    ap.add_argument('--forward',default='+x'); ap.add_argument('--up',default='+z'); ap.add_argument('--length',type=float,default=14.0)
    ap.add_argument('--drop',default='landing gear,wheel hub,gear brace,fastener'); ap.add_argument('--angle',type=float,default=38.0)
    a = ap.parse_args(); j, bin_ = read_glb(a.inp)
    drops = [d.strip().lower() for d in a.drop.split(',')]
    mats, dropped = collect(j,bin_,drops)
    f, u = axis(a.forward), axis(a.up); r = np.cross(f,u)             # right = forward × up
    R = np.array([r,u,-f])                                            # model -> three (أنف -Z، أعلى +Y، يمين +X)
    allv = np.concatenate([m.reshape(-1,3) for m in mats.values()]) @ R.T
    length = allv[:,2].max()-allv[:,2].min(); s = a.length/length
    shift = np.array([(allv[:,0].max()+allv[:,0].min())/2, 0.0, (allv[:,2].max()+allv[:,2].min())/2])
    groups = []; names = []; tri_total = 0
    for mi, tris in sorted(mats.items()):
        T = ((tris.reshape(-1,3) @ R.T)-shift)*s; T = T.reshape(-1,3,3)
        groups.append((mi,T,smooth_normals(T,a.angle))); names.append((j['materials'][mi].get('name') or f'mat{mi}').replace(' ','_')); tri_total += len(T)
    write_glb(a.out,groups,j['materials'],names)
    allv2 = np.concatenate([g[1].reshape(-1,3) for g in groups])
    print(f'حُذفت {dropped} قطعة | {len(groups)} مادة (draw calls) | {tri_total} مثلث | scale={s:.3f}')
    print('الأبعاد (x عرض, y ارتفاع, z طول):', np.round(allv2.max(0)-allv2.min(0),2).tolist())
    print('z min (الأنف) / max (الذيل):', round(allv2[:,2].min(),2), round(allv2[:,2].max(),2), '| y max (الزعنفة):', round(allv2[:,1].max(),2))
if __name__ == '__main__': main()
