#!/usr/bin/env python3
"""
توليد نماذج مركبات الأرض الإجرائية (v26.3.2، بند M2 تمهيد): دبابة · ناقلة جند مدرعة · شاحنة رتل.
لا تحتاج أي ملف مصدر: المجسمات تُبنى بالكود (صناديق/أسطوانات/موشورات محدبة) وتُكتب GLB بنفس صيغة prep_enemy.py:
  body = الجسم الثابت (مدموج بحسب المادة)      aim = البرج (دبابة/مدرعة): اللعبة تدوّره بـ lookAt (الفوهة على +Z)
  قاعدة الجسم عند y=0 ومركزه عند x=0,z=0. الألوان رمادية-زيتونية فاتحة ليمزجها mkEM(tint) بلون الجهة.
الاستعمال (من جذر المشروع):   python3 tools/make_vehicles.py      ← يكتب src/models/e_tank.glb e_apc.glb e_truck.glb
"""
import os, sys, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prep_enemy import write_glb, OUT

def _tris(faces, centroid):
    """faces: قوائم نقاط محدبة ← مثلثات موجّهة للخارج (تُقاس بالنسبة لمركز المجسم) + normals مسطحة"""
    P = []; N = []
    for f in faces:
        f = [np.array(p, float) for p in f]; c = sum(f) / len(f)
        for i in range(1, len(f) - 1):
            a, b, d = f[0], f[i], f[i + 1]; n = np.cross(b - a, d - a); ln = np.linalg.norm(n)
            if ln < 1e-12: continue
            n /= ln
            if np.dot(n, c - centroid) < 0: b, d, n = d, b, -n
            P += [a, b, d]; N += [n, n, n]
    return np.array(P), np.array(N)

class Mesh:
    """مجمّع مجسمات حسب المادة. كل add يضيف مجسماً محدباً"""
    def __init__(self): self.by = {}
    def _put(self, mat, faces, pts):
        P, N = _tris(faces, np.mean(np.array(pts, float), axis=0)); self.by.setdefault(mat, []).append((P, N))
    def hexa(self, mat, c):
        """c = 8 ركن: 0-3 قاعدة سفلية (دوراناً) · 4-7 العلوية المقابلة"""
        f = [[c[0], c[1], c[2], c[3]], [c[4], c[5], c[6], c[7]]] + [[c[i], c[(i + 1) % 4], c[4 + (i + 1) % 4], c[4 + i]] for i in range(4)]
        self._put(mat, f, c)
    def box(self, mat, cx, cy, cz, sx, sy, sz): self.frustum(mat, cx, cy - sy / 2, cz, sx, sz, sx, sz, sy)   # cy = مركز الارتفاع
    def frustum(self, mat, cx, cy, cz, bx, bz, tx, tz, h, tzs=0.0):
        """قاعدة bx×bz عند الأسفل (y=cy) وقمة tx×tz بارتفاع h؛ tzs = إزاحة القمة على z"""
        c = []
        for (sx, sz, y, o) in ((bx, bz, cy, 0), (tx, tz, cy + h, tzs)):
            c += [(cx - sx / 2, y, cz - sz / 2 + o), (cx + sx / 2, y, cz - sz / 2 + o), (cx + sx / 2, y, cz + sz / 2 + o), (cx - sx / 2, y, cz + sz / 2 + o)]
        self.hexa(mat, c)
    def prism(self, mat, poly_yz, x0, x1):
        """موشور محدب: مضلع بمستوى (y,z) يُسحب من x0 إلى x1"""
        A = [(x0, y, z) for y, z in poly_yz]; B = [(x1, y, z) for y, z in poly_yz]; n = len(A)
        f = [A, B] + [[A[i], A[(i + 1) % n], B[(i + 1) % n], B[i]] for i in range(n)]
        self._put(mat, f, A + B)
    def cyl(self, mat, ctr, axis, r, length, seg=12, r2=None):
        ax = np.array(axis, float); ax /= np.linalg.norm(ax); ctr = np.array(ctr, float)
        u = np.cross(ax, [0, 1, 0] if abs(ax[1]) < .9 else [1, 0, 0]); u /= np.linalg.norm(u); v = np.cross(ax, u)
        r2 = r if r2 is None else r2; a = ctr - ax * length / 2; b = ctr + ax * length / 2
        ra = [a + (u * math.cos(2 * math.pi * i / seg) + v * math.sin(2 * math.pi * i / seg)) * r for i in range(seg)]
        rb = [b + (u * math.cos(2 * math.pi * i / seg) + v * math.sin(2 * math.pi * i / seg)) * r2 for i in range(seg)]
        f = [ra, rb] + [[ra[i], ra[(i + 1) % seg], rb[(i + 1) % seg], rb[i]] for i in range(seg)]
        self._put(mat, f, ra + rb)
    def groups(self, shift=(0, 0, 0)):
        sh = np.array(shift, float)
        return [(mi, np.concatenate([p for p, _ in v]) - sh, np.concatenate([n for _, n in v])) for mi, v in sorted(self.by.items())]

def mat(rgb, rough=.8): return {'pbrMetallicRoughness': {'baseColorFactor': [*rgb, 1.0], 'metallicFactor': .05, 'roughnessFactor': rough}}
PAINT, DARK, TRACK, GLASS, TARP = 0, 1, 2, 3, 4
MATS = [mat((.46, .49, .38)), mat((.17, .18, .17)), mat((.10, .10, .10), .95), mat((.20, .28, .33), .4), mat((.40, .42, .32), .95)]

def wheels_side(m, x, zs, r, w, mat_=DARK, cy=None):
    for z in zs: m.cyl(mat_, (x, r if cy is None else cy, z), (1, 0, 0), r, w, 12)

def tank():
    b = Mesh()
    for s in (-1, 1):                                              # الجنزير: موشور بمقدمة مائلة + عجلات طريق + عجلة قيادة
        b.prism(TRACK, [(0.05, -3.5), (1.15, -3.5), (1.15, 3.0), (0.65, 3.75), (0.05, 3.55)], s * 1.55 - .36, s * 1.55 + .36)
        wheels_side(b, s * 1.55 + s * .30, [-2.8 + i * 1.15 for i in range(6)], .46, .26, DARK, .6)
        b.cyl(DARK, (s * 1.55 + s * .30, .9, 3.0), (1, 0, 0), .34, .3, 10); b.cyl(DARK, (s * 1.55 + s * .30, .9, -3.3), (1, 0, 0), .34, .3, 10)
        b.box(PAINT, s * 1.55, 1.28, -.2, .86, .14, 7.0)                # رفرف الجنزير
    b.prism(PAINT, [(0.55, -3.45), (1.85, -3.45), (1.85, 1.9), (1.3, 3.55), (0.65, 3.35)], -1.28, 1.28)   # الهيكل + الدرع الأمامي المائل
    b.box(DARK, 0, 1.7, -3.55, 2.2, .5, .25); b.box(DARK, 1.0, 1.35, -3.5, .35, .35, .3); b.box(DARK, -1.0, 1.35, -3.5, .35, .35, .3)   # شبك المحرك
    b.box(PAINT, 0, 1.9, 2.4, 1.2, .12, 1.0)                                # فتحة السائق
    t = Mesh(); L = lambda *a: a
    t.frustum(PAINT, 0, 0, 0, 3.0, 3.9, 2.3, 3.1, .95, .1)                   # جسم البرج (الأصل عند حلقة البرج)
    t.frustum(PAINT, 0, 0.02, 1.65, 1.5, .55, 1.3, .35, .9, .0)             # درع المدفع
    t.cyl(DARK, (0, .55, 2.5), (0, 0, 1), .15, 4.8, 10); t.cyl(DARK, (0, .55, 4.9), (0, 0, 1), .2, .55, 10)   # ماسورة + كابح الفوهة
    t.cyl(DARK, (0, 1.1, -.2), (0, 1, 0), .38, .22, 10); t.box(DARK, .75, 1.05, .6, .35, .28, .5)           # فتحة القائد + مستشعر
    t.cyl(DARK, (-.8, 1.0, .1), (0, 0, 1), .06, 1.0, 6)                       # رشاش
    t.box(PAINT, 0, .45, -2.15, 2.0, .7, .55)                                # صندوق خلفي بالبرج
    return b.groups(), t.groups((0, 0, 0)), (0, 1.8, -.2)

def apc():
    b = Mesh()
    zs = [-2.7, -0.9, 0.95, 2.75]
    for s in (-1, 1): wheels_side(b, s * 1.5, zs, .62, .5, TRACK)
    b.box(DARK, 0, .85, 0, 2.3, .4, 7.6)                                     # الشاسيه
    b.prism(PAINT, [(0.9, -3.9), (2.45, -3.9), (2.45, 1.0), (1.7, 3.2), (1.0, 3.9)], -1.5, 1.5)   # الهيكل بمقدمة مائلة
    b.frustum(GLASS, 0, 1.75, 2.35, 1.8, .35, 1.6, .15, .45, .05)            # زجاج السائق
    b.box(DARK, 0, 2.5, -1.2, .9, .12, .9); b.box(DARK, 1.1, 2.55, -2.6, .5, .4, .9)
    t = Mesh()
    t.frustum(PAINT, 0, 0, 0, 1.6, 1.8, 1.3, 1.4, .6, .1); t.cyl(DARK, (0, .35, 1.7), (0, 0, 1), .08, 2.2, 8); t.box(DARK, .5, .35, .3, .3, .25, .5)
    return b.groups(), t.groups(), (0, 2.5, 0.4)

def truck():
    b = Mesh()
    for z in (-2.6, -0.9, 2.5):
        for s in (-1, 1): b.cyl(TRACK, (s * 1.25, .6, z), (1, 0, 0), .62, .42, 12)
    b.box(DARK, 0, .75, -.2, 1.6, .35, 8.0)                                   # شاسيه
    b.box(PAINT, 0, 1.05, 3.0, 2.3, 1.55, 1.9); b.frustum(GLASS, 0, 1.95, 3.45, 2.1, .9, 2.0, .7, .55, .2)   # كابينة + زجاج
    b.box(DARK, 0, 1.0, 4.05, 2.1, .45, .25)                                   # المصد الأمامي
    b.box(PAINT, 0, 1.15, -1.6, 2.5, .22, 5.3)                                 # أرضية الحمولة
    b.prism(TARP, [(1.3, -4.2), (2.5, -4.2), (3.0, -3.5), (3.25, -1.6), (3.0, 0.3), (2.5, 0.9), (1.3, 0.9)], -1.2, 1.2)   # غطاء الحمولة (قوس)
    b.box(DARK, -1.35, .65, 1.1, .3, .55, 1.2)                                 # خزان
    return b.groups(), None, None

def write(name, parts):
    (body, aim, pivot) = parts
    lo = min(P[:, 1].min() for _, P, _n in body)                   # نُنزل/نرفع الكل حتى تلامس أدنى نقطة (العجلات/الجنزير) y=0 بالضبط
    if abs(lo) > 1e-9:
        body = [(mi, P - np.array([0, lo, 0]), N) for mi, P, N in body]
        if pivot: pivot = (pivot[0], pivot[1] - lo, pivot[2])
    nodes = [('body', None, [(mi, P, N) for mi, P, N in body])]
    if aim: nodes.append(('aim', pivot, [(mi, P, N) for mi, P, N in aim]))
    p = os.path.join(OUT, name + '.glb'); write_glb(p, nodes, MATS); print(name, os.path.getsize(p) // 1024, 'KB')

def main():
    os.makedirs(OUT, exist_ok=True)
    write('e_tank', tank()); write('e_apc', apc()); write('e_truck', truck())

if __name__ == '__main__': main()
