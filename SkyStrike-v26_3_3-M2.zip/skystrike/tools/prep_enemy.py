#!/usr/bin/env python3
"""
تحضير نماذج الأعداء (v26.2) — يحوّل أي GLB لنموذج جاهز للعبة:
  • يدوّره لاتجاه اللعبة ويضبط الحجم ويركّزه ويضعه على الأرض (للأرضيات)
  • يدمج القطع الثابتة بحسب المادة (draw calls أقل بكثير)
  • يُبقي القطع المتحركة (البرج/المراوح) كعُقد منفصلة بأسماء ثابتة تقرأها اللعبة:
        aim    = برج الأرضيات (اللعبة تدوّره بـ lookAt نحو اللاعب؛ فوهة المدفع لازم تكون +Z)
        rotor  = المروحة الرئيسية (تدور حول Y)      rotor2 = مروحة الذيل (تدور حول X)
  • يخفّف المعدنية (ما في environment map بالمشهد فالمعدن العالي يطلع أسود)

الاستعمال (من جذر المشروع):
    python3 tools/prep_enemy.py                 # يحضّر كل النماذج المعرّفة بـ PRESETS
    python3 tools/prep_enemy.py e_tank          # نموذج واحد
المصادر بـ models_src/enemies/ والنتائج بـ src/models/e_*.glb

لإضافة نموذج جديد: أضف سطراً لـ PRESETS.
  fwd/up : اتجاه الأنف (للطائرات) أو اتجاه فوهة المدفع (للأرضيات) والأعلى، داخل النموذج الأصلي
  mode   : 'nose'  = الأنف يصير -Z (طائرات)   |  'barrel' = الفوهة تصير +Z (أرضيات، لأن aim.lookAt يوجّه +Z)
  scale  : معامل التكبير (غيّره حتى يناسب حجم الجسم بالمعركة)
  air    : True = يتركّز رأسياً بالمنتصف | False = أسفل الجسم عند y=0 (ينزل على الأرض)
  fix    : عقد أسطواناتها مرسومة حول المحور Y بدل Z (فوهات/صواريخ بالنماذج الأصلية واقفة عمودياً): كل قطعة متصلة
           تُدوَّر 90° حول X عند مركزها الخاص فتنام باتجاه Z. نفس صيغة nodes (اسم | 'بادئة*')
  parts  : اسم → {nodes:[...], pivot:..., rotY:..}
       nodes: اسم عقدة | 'بادئة*' | 'أ..ب' (مجال عقد بالترتيب) — القطعة تشمل أبناءها
       pivot: 'node:الاسم' (موضع العقدة) | 'bbox:الاسم' (مركز صندوقها)
"""
import os, sys, json, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from optimize_glb import read_glb, accessor, node_matrix, axis
import struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'models_src', 'enemies')
OUT = os.path.join(ROOT, 'src', 'models')

PRESETS = {
    # مسيّرة انتحارية: الأنف (الحساس) بـ -Z أصلاً، المروحة الدافعة بالخلف
    'e_drone': dict(src='UAV_Lightweight_Mobile.glb', fwd='-z', up='+y', mode='nose', scale=2.0, air=True),
    # هيلوكبتر: الأنف +Z بالأصل (الذيل -Z). مروحة الذيل مرسومة بمستوى XY (غلط)، نلفّها 90° لتصير جانبية
    'e_heli': dict(src='helicopter_aaa.glb', fwd='+z', up='+y', mode='nose', scale=2.0, air=True, fix=['Rocket_*'], parts={
        'rotor':  dict(nodes=['RotorMain'], pivot='node:RotorMain'),
        'rotor2': dict(nodes=['RotorTail'], pivot='node:RotorTail', rotY=90)}),
    # مدافع/دبابة أرضية: الفوهة +Z أصلاً
    'e_aa_twin': dict(src='AA_Twin_Rotary_AAA.glb', fwd='+z', up='+y', mode='barrel', scale=2.2, air=False, parts={
        'aim': dict(nodes=['Turret_Yaw'], pivot='node:Turret_Yaw')}),
    'e_aa_tank': dict(src='tank_aaa.glb', fwd='+z', up='+y', mode='barrel', scale=2.0, air=False, fix=['Gun','MG'], parts={
        'aim': dict(nodes=['Turret'], pivot='node:Turret')}),
    'e_gepard': dict(src='anti_air_gepard_aaa.glb', fwd='+z', up='+y', mode='barrel', scale=2.4, air=False, fix=['Gun_Left','Gun_Right'], parts={
        'aim': dict(nodes=['Turret'], pivot='node:Turret')}),
    # Flak Heavy: عقد مسطحة؛ البرج = من Turret_Rotating إلى Turret_Hatch_Handle_4. الفوهات +Z
    'e_flak': dict(src='SkyStrike_AA_Flak_Heavy_v1.glb', fwd='+z', up='+y', mode='barrel', scale=1.5, air=False,
                   fix=['Gun_Barrel_*','Barrel_Muzzle_*','Barrel_Cluster_*','Rotary_Cannon_*','Turret_Ring','Turret_Bearing_Detail'], parts={
        'aim': dict(nodes=['Turret_Rotating..Turret_Hatch_Handle_4'], pivot='bbox:Turret_Ring')}),
    # منصة الصواريخ: الأعلى +Z، الصواريخ تشير لـ +X
    'e_sam': dict(src='sam_platform_aaa.glb', fwd='+x', up='+z', mode='barrel', scale=1.8, air=False, parts={
        'aim': dict(nodes=['Turret_Yaw'], pivot='node:Turret_Yaw')}),
}

def lay_down(P, N, idx):
    """كل مجموعة رؤوس متصلة (بالموضع) تُدوَّر 90° حول X عند مركزها: أسطوانة محورها Y تصير محورها Z"""
    keys = {}; par = []
    def f(x):
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    vid = np.empty(len(P), int)
    for i, p in enumerate(P):
        k = tuple(np.round(p, 4)); vid[i] = keys.setdefault(k, len(keys))
    par = list(range(len(keys)))
    for t in idx.reshape(-1, 3):
        for k in (1, 2): par[f(vid[t[k]])] = f(vid[t[0]])
    comp = np.array([f(v) for v in vid]); P2 = P.copy(); N2 = None if N is None else N.copy()
    for c in np.unique(comp):
        m = comp == c; ctr = (P[m].max(0) + P[m].min(0)) / 2; d = P[m] - ctr
        P2[m] = ctr + np.c_[d[:, 0], -d[:, 2], d[:, 1]]
        if N is not None: N2[m] = np.c_[N[m][:, 0], -N[m][:, 2], N[m][:, 1]]
    return P2, N2

def collect(j, b, fix=()):
    prims, NM = [], {}
    def walk(i, par, chain):
        n = j['nodes'][i]; M = par @ node_matrix(n); ch = chain + [i]; NM[i] = M
        if 'mesh' in n:
            for pr in j['meshes'][n['mesh']]['primitives']:
                if pr.get('mode', 4) != 4: continue
                P = accessor(j, b, pr['attributes']['POSITION']).astype(float)
                Nn = accessor(j, b, pr['attributes']['NORMAL']).astype(float) if 'NORMAL' in pr['attributes'] else None
                idx = accessor(j, b, pr['indices']).reshape(-1) if 'indices' in pr else np.arange(len(P))
                if any(match(j, sp, [i]) for sp in fix): P, Nn = lay_down(P, Nn, idx)
                Pw = (np.c_[P, np.ones(len(P))] @ M.T)[:, :3]
                Nw = None
                if Nn is not None:
                    Nw = Nn @ np.linalg.inv(M[:3, :3]); Nw /= np.maximum(np.linalg.norm(Nw, axis=1, keepdims=True), 1e-12)
                prims.append(dict(chain=ch, mat=pr.get('material', 0), P=Pw[idx].reshape(-1, 3, 3),
                                  N=None if Nw is None else Nw[idx].reshape(-1, 3, 3)))
        for c in n.get('children', []): walk(c, M, ch)
    for r in j['scenes'][j.get('scene', 0)]['nodes']: walk(r, np.eye(4), [])
    return prims, NM

def match(j, spec, chain):
    names = [j['nodes'][i].get('name', '') for i in chain]
    if '..' in spec:
        a, z = spec.split('..'); ia = next(i for i, n in enumerate(j['nodes']) if n.get('name') == a)
        iz = next(i for i, n in enumerate(j['nodes']) if n.get('name') == z)
        return any(ia <= i <= iz for i in chain)
    if spec.endswith('*'): return any(n.startswith(spec[:-1]) for n in names)
    return spec in names

def node_index(j, name): return next(i for i, n in enumerate(j['nodes']) if n.get('name') == name)

def write_glb(path, nodes_out, materials):
    """nodes_out: [(اسم, translation, [(mat, P(n,3), N(n,3))])]"""
    bin_ = bytearray(); bvs = []; accs = []; meshes = []; nodes = []
    for name, tr, prims in nodes_out:
        pj = []
        for mi, P, N in prims:
            P = P.astype(np.float32); N = N.astype(np.float32); ids = []
            for arr, key in ((P, 'POSITION'), (N, 'NORMAL')):
                off = len(bin_); bin_ += arr.tobytes()
                bvs.append({'buffer': 0, 'byteOffset': off, 'byteLength': arr.nbytes, 'target': 34962})
                a = {'bufferView': len(bvs) - 1, 'componentType': 5126, 'count': len(arr), 'type': 'VEC3'}
                if key == 'POSITION': a['min'] = P.min(0).tolist(); a['max'] = P.max(0).tolist()
                accs.append(a); ids.append(len(accs) - 1)
            pj.append({'attributes': {'POSITION': ids[0], 'NORMAL': ids[1]}, 'material': mi, 'mode': 4})
        meshes.append({'name': name + '_m', 'primitives': pj})
        nd = {'name': name, 'mesh': len(meshes) - 1}
        if tr is not None and any(abs(x) > 1e-9 for x in tr): nd['translation'] = [float(x) for x in tr]
        nodes.append(nd)
    j = {'asset': {'version': '2.0', 'generator': 'skystrike prep_enemy.py'}, 'scene': 0, 'scenes': [{'nodes': list(range(len(nodes)))}],
         'nodes': nodes, 'meshes': meshes, 'materials': materials, 'accessors': accs, 'bufferViews': bvs, 'buffers': [{'byteLength': len(bin_)}]}
    js = json.dumps(j, separators=(',', ':')).encode(); js += b' ' * ((4 - len(js) % 4) % 4); bin_ += b'\0' * ((4 - len(bin_) % 4) % 4)
    total = 12 + 8 + len(js) + 8 + len(bin_)
    open(path, 'wb').write(struct.pack('<4sII', b'glTF', 2, total) + struct.pack('<II', len(js), 0x4E4F534A) + js + struct.pack('<II', len(bin_), 0x004E4942) + bytes(bin_))

def fix_materials(mats):
    out = []
    for m in mats:
        m = json.loads(json.dumps(m)); pbr = m.setdefault('pbrMetallicRoughness', {})
        bc = pbr.get('baseColorFactor', [.7, .7, .7, 1]); pbr['baseColorFactor'] = [bc[0], bc[1], bc[2], 1.0]   # بدون شفافية (ترتيب الرسم)
        pbr['metallicFactor'] = min(pbr.get('metallicFactor', 0), .3); pbr['roughnessFactor'] = max(pbr.get('roughnessFactor', .6), .55)
        m.pop('alphaMode', None); out.append(m)
    return out

def prep(key):
    c = PRESETS[key]; j, b = read_glb(os.path.join(SRC, c['src'])); prims, NM = collect(j, b, c.get('fix', []))
    f, u = axis(c['fwd']), axis(c['up']); r = np.cross(f, u)
    R = np.array([r, u, -f]) if c['mode'] == 'nose' else np.array([-r, u, f])   # nose: أنف→-Z ؛ barrel: فوهة→+Z
    s = c['scale']; parts = c.get('parts', {})
    for p in prims:
        p['part'] = next((pn for pn, pc in parts.items() if any(match(j, sp, p['chain']) for sp in pc['nodes'])), None)
    body = [p for p in prims if p['part'] is None]
    bpts = np.concatenate([p['P'].reshape(-1, 3) for p in body]) @ R.T * s
    shift = np.array([(bpts[:, 0].max() + bpts[:, 0].min()) / 2, ((bpts[:, 1].max() + bpts[:, 1].min()) / 2) if c['air'] else bpts[:, 1].min(),
                      (bpts[:, 2].max() + bpts[:, 2].min()) / 2])
    T = lambda P: (P.reshape(-1, 3) @ R.T) * s - shift
    TN = lambda N, P_n: (N.reshape(-1, 3) @ R.T)
    def flat_normals(P):
        Pt = P.reshape(-1, 3, 3); fn = np.cross(Pt[:, 1] - Pt[:, 0], Pt[:, 2] - Pt[:, 0]); fn /= np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-12)
        return np.repeat(fn, 3, axis=0)
    def group(ps, pivot=None, rotY=0):
        by = {}
        for p in ps:
            Pn = T(p['P']); Nn = TN(p['N'], None) if p['N'] is not None else flat_normals(Pn)
            if pivot is not None:
                Pn = Pn - pivot
                if rotY:
                    a = math.radians(rotY); Ry = np.array([[math.cos(a), 0, math.sin(a)], [0, 1, 0], [-math.sin(a), 0, math.cos(a)]])
                    Pn = Pn @ Ry.T; Nn = Nn @ Ry.T
            by.setdefault(p['mat'], []).append((Pn, Nn))
        return [(mi, np.concatenate([a for a, _ in v]), np.concatenate([n for _, n in v])) for mi, v in sorted(by.items())]
    nodes_out = [('body', None, group(body))]
    for pn, pc in parts.items():
        kind, name = pc['pivot'].split(':')
        if kind == 'node': pm = NM[node_index(j, name)][:3, 3]
        else:
            pp = np.concatenate([p['P'].reshape(-1, 3) for p in prims if any(j['nodes'][i].get('name') == name for i in p['chain'])]); pm = (pp.max(0) + pp.min(0)) / 2
        pivot = T(pm[None, :])[0]
        nodes_out.append((pn, pivot, group([p for p in prims if p['part'] == pn], pivot, pc.get('rotY', 0))))
    os.makedirs(OUT, exist_ok=True); path = os.path.join(OUT, key + '.glb')
    write_glb(path, nodes_out, fix_materials(j['materials']))
    allp = np.concatenate([T(p['P']) for p in prims]); tris = sum(len(p['P']) for p in prims)
    print(f"{key}: {tris} مثلث | {len(nodes_out)} عقدة | {os.path.getsize(path)//1024}KB | الأبعاد x={np.ptp(allp[:,0]):.1f} y={np.ptp(allp[:,1]):.1f} z={np.ptp(allp[:,2]):.1f}"
          f" | y:[{allp[:,1].min():.1f},{allp[:,1].max():.1f}] z:[{allp[:,2].min():.1f},{allp[:,2].max():.1f}]"
          + ''.join(f" | {n[0]} pivot={np.round(n[1],2).tolist()}" for n in nodes_out[1:]))

if __name__ == '__main__':
    for k in (sys.argv[1:] or PRESETS): prep(k)
