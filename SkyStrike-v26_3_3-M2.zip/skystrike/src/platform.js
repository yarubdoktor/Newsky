/* منصّة الجوال: تمرير القوائم يدوياً بالوضع المدوّر + محاولة ملء الشاشة وقفل الأفقي. استيراده يكفي (ما يصدّر شي). */
import {$,FL} from './util.js';
import {isMobile} from './core.js';

/* ================= الاتجاه الأفقي =================
   أندرويد: القفل الأساسي من AndroidManifest (يُضاف تلقائياً بـ tools/android_patch.py في الـ workflow).
   المتصفح: نحاول القفل بعد أول لمسة (يحتاج ملء الشاشة)، وإذا فشل تظهر شاشة «دوّر جوالك» (#rot بـ index.html)
   وتتوقف اللعبة تلقائياً إذا صار الجوال عمودياً أثناء اللعب. */
/* تمرير القوائم يدوياً عندما تكون الواجهة مدوّرة (FL): حركة الإصبع على الشاشة = محور مقلوب داخل الواجهة */
{ const mn = $('#menu'); let ds = null, moved = false;
  mn.addEventListener('pointerdown',e => { moved = false; const sb = FL.on && e.target.closest('.sh-b'); ds = sb ? {sb,x:e.clientX,y:e.clientY,st:sb.scrollTop,id:e.pointerId} : null; });
  mn.addEventListener('pointermove',e => { if(!ds || e.pointerId !== ds.id) return; const sx = e.clientX-ds.x, sy = e.clientY-ds.y; if(!moved && Math.hypot(sx,sy) < 10) return; moved = true; ds.sb.scrollTop = ds.st+sx; });
  const end = () => { ds = null; }; mn.addEventListener('pointerup',end); mn.addEventListener('pointercancel',end);
  mn.addEventListener('click',e => { if(moved){ e.stopPropagation(); e.preventDefault(); moved = false; } },true); }
let lockTried = false;
addEventListener('pointerdown',async () => {
  if(lockTried || !isMobile) return; lockTried = true;
  try{
    if(!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen({navigationUI:'hide'});
    if(screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
  }catch(e){ /* المتصفح ما سمح: شاشة «دوّر جوالك» تغطي الحالة */ }
},{once:false,passive:true});
