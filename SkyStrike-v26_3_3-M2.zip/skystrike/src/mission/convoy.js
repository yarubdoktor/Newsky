/* أرتال: تعريف الرتل بالمهمة = كيان واحد {kind:'convoy', units:['tank','apc',…], gap, speed, pos, route[]}
   ينقسم لمركبات.
   دوال صرفة. معرّفات الأعضاء: id+1 ، id+2 … (يُشار لها بأهداف المهمة والأحداث). */
export const entityIds = d => (d.kind === 'convoy' ? d.units.map((_, i) => d.id+(i+1)) : [d.id]);

/* مواضع أعضاء الرتل: الأول عند start والباقي خلفه على الخط المعاكس لاتجاه الحركة نحو toward */
export function convoySlots(start, toward, n, gap){
  const dx = toward.x-start.x, dz = toward.z-start.z, l = Math.hypot(dx, dz) || 1, ux = dx/l, uz = dz/l;
  return Array.from({length:n}, (_, i) => ({x:start.x-ux*gap*i, z:start.z-uz*gap*i}));
}
export const convoyYaw = (a, b) => Math.atan2(-(b.x-a.x), -(b.z-a.z));
