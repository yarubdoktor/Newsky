/* أنواع الأهداف (دالة صرفة، بلا DOM/three). كل نوع: init(def) ← حالة، on(o, ev) ← 'done' | 'failed' | null.
   حالياً (M0): destroy فقط. باقي الأنواع (suppress/escort/intercept/defend/rtb) تُضاف بالبند M3 بإضافة مدخل هنا.
   حالة الهدف: {id,type,textKey,optional,status:'active'|'done'|'failed', ...حقول النوع} */
const TYPES = {
  destroy:{
    init:d => ({targets:d.targets.slice(), left:d.targets.slice()}),
    on(o, ev){
      if(ev.type !== 'entityDead') return null;
      const i = o.left.indexOf(ev.id); if(i < 0) return null;
      o.left.splice(i, 1);
      return o.left.length ? null : 'done';
    },
    progress:o => ({done:o.targets.length-o.left.length, total:o.targets.length})
  }
};

export const objectiveTypes = () => Object.keys(TYPES);
export const hasType = type => Object.prototype.hasOwnProperty.call(TYPES, type);

export function makeObjective(d){
  if(!hasType(d.type)) throw new Error('objectives: unknown type '+d.type);
  const base = {id:d.id, type:d.type, textKey:d.text, optional:!!d.optional, status:'active'};
  return Object.assign(base, TYPES[d.type].init(d));
}
/* يمرّر حدثاً لهدف نشط؛ يرجع الحالة الجديدة إن تغيّرت وإلا null */
export function feed(o, ev){
  if(o.status !== 'active') return null;
  const r = TYPES[o.type].on(o, ev); if(r) o.status = r; return r;
}
export const progressOf = o => TYPES[o.type].progress(o);
