/* نص متتبّع الأهداف (دالة صرفة). tr = دالة الترجمة t. يرجع أسطراً HTML-آمنة (نصوص ثابتة فقط). */
import {progressOf} from './objectives.js';

export function objectiveLines(rt, tr){
  return rt.objectives.map(o => {
    const p = progressOf(o), mark = o.status === 'done' ? '✔' : o.status === 'failed' ? '✖' : '◆';
    return mark+' '+tr(o.textKey)+(o.optional ? ' ('+tr('ms_opt')+')' : '')+(p.total > 1 ? ' '+p.done+'/'+p.total : '');
  });
}
export const headLine = (rt, tr) => tr(rt.def.title)+' · '+objectiveLines(rt, tr).join(' · ');
