/* الجهات وجدول العداء. دالة صرفة بلا استيراد. الأسماء والعلامات هنا (والنصوص بـ mission_text.js)
   حتى يسهل تحويلها لأسماء عامة عند الحاجة (سياسات المتجر). */
export const SIDES = {PLAYER:'player', ALLY:'ally', ENEMY:'enemy'};

/* HOSTILE[a][b] = هل الجهة a معادية للجهة b؟ (متماثل) */
export const HOSTILE = {
  player:{player:false, ally:false, enemy:true},
  ally:{player:false, ally:false, enemy:true},
  enemy:{player:true, ally:true, enemy:false}
};

/* nameKey: مفتاح الاسم بـ i18n · color: لون الرادار/العلامات */
export const FACTION = {
  player:{nameKey:'f_player', color:'#5fd8ff'},
  ally:{nameKey:'f_ally', color:'#5fe3a1'},
  enemy:{nameKey:'f_enemy', color:'#ff3b3b'}
};

/* نيران صديقة: قذيفة اللاعب التي تصيب وحدة حليفة تضرّ بنسبة dmgMul وتخصم score عند قتلها (كل G.ff عدّاد للتقييم) */
export const FRIENDLY_FIRE = {dmgMul:.3, killPenalty:300, warnEvery:3};
/* وحدة بلا جهة (كود/اختبارات قديمة) تُعامل كعدو */
export const sideOf = u => (u && u.side) || 'enemy';
/* مضاعف ضرر قذيفة جهتها ps على هدف جهته ts: 1 معادٍ · dmgMul نيران صديقة (قذائف اللاعب على الحلفاء فقط) · 0 لا يتأذى */
export const hitMul = (ps, ts) => (isHostile(ps, ts) ? 1 : ps === 'player' && ts === 'ally' ? FRIENDLY_FIRE.dmgMul : 0);
export const isSide = s => Object.prototype.hasOwnProperty.call(HOSTILE, s);
export const isHostile = (a, b) => !!(HOSTILE[a] && HOSTILE[a][b]);
export const colorOf = s => (FACTION[s] || FACTION.enemy).color;
