/* نصوص المهمات والجهات (عربي، إنجليزي). تُدمج بـ i18n.js. أسماء الجهات هنا فقط (f_*) ليسهل تعديلها. */
export const MISSION_TEXT = {
  f_player:['الطيار','Pilot'], f_ally:['الجيش السوري','Syrian Army'], f_enemy:['الجيش الإسرائيلي','Israeli Army'],
  ffWarn:['⚠ نيران صديقة','⚠ Friendly fire'], ffKill:['أسقطت وحدة صديقة (−نقاط)','Friendly unit lost (−score)'],
  m1t:['عملية الرتل','Operation Convoy'],
  m1i:['أمر من وزارة الدفاع: رتل مدرع صديق يتقدم نحو الجبهة. دمّر كمين القوة المعادية على الطريق قبل أن يبلغه الرتل.',
       'MoD order: a friendly armored convoy is advancing to the front. Destroy the hostile ambush on its route before it arrives.'],
  m1d:['رتل مدرع صديق (دبابة + ناقلة + شاحنتان) يمر بكمين: دبابتان معاديتان ومدفع وبطارية SAM. افتح الطريق للرتل.',
       'A friendly armored convoy (tank, APC, two trucks) runs into an ambush: two hostile tanks, a gun and a SAM. Clear its way.'],
  m1o1:['دمّر كمين العدو على طريق الرتل','Destroy the hostile ambush on the convoy route'],
  ms_opt:['ثانوي','optional'], ms_title:['المهمات','Missions'], ms_play:['انطلق','Launch'],
  ms_win:['✅ نجحت المهمة','✅ Mission accomplished'], ms_fail:['❌ فشلت المهمة','❌ Mission failed'],
  m0t:['عملية أول ضوء','Operation First Light'],
  m0d:['أمر من وزارة الدفاع: دمّر مستودع الذخيرة المعادي خلف خط التماس. دفاعات أرضية خفيفة وبطارية SAM.',
       'MoD order: destroy the hostile ammunition depot behind the line. Light ground defenses and one SAM battery.'],
  m0i:['وزارة الدفاع ← الطيار: دمّر مستودع الذخيرة','MoD to Pilot: destroy the ammunition depot'],
  m0o1:['دمّر مستودع الذخيرة','Destroy the ammunition depot']
};
