/* منطق الوحدات الأرضية المتحركة (أرتال ودبابات): دوال صرفة بلا three/DOM تُختبر بـ node.
   الجسم b = {x,z,yaw,v,route:[{x,z}],wp,state} حالته: 'drive' يتبع المسار · 'arrived' وصل · 'hold' ثابت.
   driveStep يحرّك الجسم نحو النقطة التالية مع: حد دوران، إبطاء بالمنعطفات، حفظ مسافة عن الرائد،
   التفاف حول العوائق (env.ok(x,z) = هل الموضع صالح للمركبة؟ ماء/جبل/مبنى = لا) وكشف العالق.
   باقي الملف: تصويب بتقدير حركة الهدف · ميلان الهيكل على التضاريس · سقف الوحدات النشطة (أداء). */
import {headingDir} from './entity_pos.js';

export const DRIVE = {
  arrive:30,                       // م: الوصول لنقطة المسار
  probe:16,                        // م: مسافة الاستكشاف أمام المركبة للتأكد أن الطريق صالح
  offsets:[.5, -.5, 1, -1, 1.6, -1.6],   // راد: زوايا الالتفاف المجرَّبة بالترتيب عند انسداد الطريق
  detourT:1.2,                     // ث: نثبت الالتفاف هذا الزمن قبل إعادة الفحص (يمنع الاهتزاز)
  stuckT:5,                        // ث: بعد هذا الانسداد المتواصل تُعلَّم المركبة «عالقة»
  turnSlow:.6, acc:7,              // الإبطاء بالمنعطف (0..1) · التسارع م/ث²
  gapMin:18, gapFull:60            // م: خلف الرائد نتوقف عند gapMin ونسير بكامل السرعة عند gapFull
};

const TAU = Math.PI*2, clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const wrap = a => { a %= TAU; return a > Math.PI ? a-TAU : a < -Math.PI ? a+TAU : a; };

export function makeBody(x, z, yaw, route){
  return {x, z, yaw, v:0, route:route || [], wp:0, state:route && route.length ? 'drive' : 'hold',
    off:0, offT:0, stuckT:0, stuck:false};
}

/* خطوة قيادة. D = {sp, turn} · env = {ok(x,z), leadDist (م أو null), speedMul (افتراضي 1)}
   يرجع {moved, arrived} (arrived مرة واحدة عند وصول آخر نقطة) */
export function driveStep(b, D, dt, env){
  const out = {moved:false, arrived:false};
  if(b.state !== 'drive'){ b.v = 0; return out; }
  let wp = b.route[b.wp], dx = wp.x-b.x, dz = wp.z-b.z, d = Math.hypot(dx, dz);
  while(d < DRIVE.arrive){
    if(++b.wp >= b.route.length){ b.state = 'arrived'; b.v = 0; out.arrived = true; return out; }
    wp = b.route[b.wp]; dx = wp.x-b.x; dz = wp.z-b.z; d = Math.hypot(dx, dz);
  }
  const want = Math.atan2(-dx, -dz), free = yaw => { const h = headingDir(yaw);
    return env.ok(b.x+h.x*DRIVE.probe, b.z+h.z*DRIVE.probe); };
  b.offT -= dt; let aim = want+b.off;
  if(b.offT <= 0){                          // أعد اختيار الاتجاه: مباشر إن كان صالحاً وإلا أول التفاف صالح
    b.off = 0; aim = want;
    if(!free(want)){
      const o = DRIVE.offsets.find(k => free(want+k));
      if(o === undefined){ aim = null; } else { b.off = o; aim = want+o; b.offT = DRIVE.detourT; }
    }
  }
  if(aim === null){                         // كل الاتجاهات مسدودة: قف وادُر بالمكان لعل اتجاهاً يفتح
    b.v = 0; b.yaw = wrap(b.yaw+D.turn*dt); b.stuckT += dt; if(b.stuckT > DRIVE.stuckT) b.stuck = true;
    return out;
  }
  const dy = wrap(aim-b.yaw); b.yaw = wrap(b.yaw+clamp(dy, -D.turn*dt, D.turn*dt));
  let tv = D.sp*(env.speedMul ?? 1)*(1-DRIVE.turnSlow*Math.min(1, Math.abs(dy)/1.2));
  if(env.leadDist != null) tv *= clamp((env.leadDist-DRIVE.gapMin)/(DRIVE.gapFull-DRIVE.gapMin), 0, 1);
  b.v += clamp(tv-b.v, -DRIVE.acc*2*dt, DRIVE.acc*dt);
  const h = headingDir(b.yaw), nx = b.x+h.x*b.v*dt, nz = b.z+h.z*b.v*dt;
  if(env.ok(nx, nz)){ b.x = nx; b.z = nz; out.moved = true; b.stuckT = 0; b.stuck = false; }
  else { b.v = 0; b.offT = 0; b.stuckT += dt; if(b.stuckT > DRIVE.stuckT) b.stuck = true; }
  return out;
}

/* تصويب مع تقدير حركة الهدف: from/to/vel كائنات {x,y,z}؛ out يستقبل الاتجاه الواحدي + زمن الوصول t */
export function leadAim(from, to, vel, speed, out){
  let tx = to.x, ty = to.y, tz = to.z, T = 0;
  for(let i = 0; i < 3; i++){
    T = Math.hypot(tx-from.x, ty-from.y, tz-from.z)/speed;
    tx = to.x+vel.x*T; ty = to.y+vel.y*T; tz = to.z+vel.z*T;
  }
  const dx = tx-from.x, dy = ty-from.y, dz = tz-from.z, l = Math.hypot(dx, dy, dz) || 1;
  out.x = dx/l; out.y = dy/l; out.z = dz/l; out.t = T; return out;
}

/* ميلان الهيكل من أربع ارتفاعات: أمام/خلف/يمين/يسار (طول وعرض قاعدة العينات). أمام أعلى ← pitch موجب */
export function tiltOf(hF, hB, hR, hL, len, wid){
  return {pitch:clamp(Math.atan2(hF-hB, len), -.5, .5), roll:clamp(Math.atan2(hR-hL, wid), -.5, .5)};
}

/* سقف الأداء: الأقرب للاعب (cap وحدة) نشطة بكامل الذكاء، والبقية u.lite = true (حركة مبسّطة فقط).
   u.pin = دائماً نشطة (أهداف رئيسية/زعماء). يرجع عدد الوحدات المبسّطة */
const _s = [];
export function markActive(units, p, cap){
  if(units.length <= cap){ for(const u of units) u.lite = false; return 0; }
  _s.length = 0;
  for(const u of units){ const q = u.g.position;
    u._d = u.pin ? -1 : (q.x-p.x)**2+(q.y-p.y)**2+(q.z-p.z)**2; _s.push(u); }
  _s.sort((a, b) => a._d-b._d);
  for(let i = 0; i < _s.length; i++) _s[i].lite = i >= cap;
  return _s.length-cap;
}
