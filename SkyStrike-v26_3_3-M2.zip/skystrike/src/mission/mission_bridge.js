/* جسر المهمة بالمحرك: يبدأ المهمة (إنشاء الكيانات + آلة الحالات) ويحدّثها كل فريم ويحوّل مخرجاتها لحالة اللعبة.
   المنطق نفسه بـ mission_runtime.js (صرف)؛ هنا فقط الربط بالمحرك (HUD، صوت، نهاية). */
import {createRuntime, pushEvent, stepRuntime} from './mission_runtime.js';
import {spawnEntities} from './entities.js';
import {W} from '../state.js';
import {world} from '../core.js';
import {banner} from '../ui.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';

export function beginMission(def){
  const G = W.G; G.ms = createRuntime(def);
  G.wave = def.difficulty;                 // مؤقت: أرقام الذكاء القديمة ما زالت تقرأ G.wave (تُزال مع M1/M4)
  spawnEntities(def, world.cfg.spawn || {x:0, z:0, yaw:0});
  banner(t(def.intro));
}
function onOutput(o){
  const G = W.G;
  if(o.type === 'objective' && o.status === 'done'){ sfx('lock'); return; }
  if(o.type !== 'end') return;
  if(o.result === 'won'){ G.win = true; G.wait = 2.8; banner(t('ms_win')); sfx('win'); }
  else {                                   // الفشل بسبب الموت يُنهى بمساره الحالي (G.deadT)
    banner(t('ms_fail')); if(!G.dead){ G.win = false; G.wait = 2.5; sfx('alarm'); }
  }
}
export function missionUpdate(dt){
  const G = W.G, ms = G.ms; if(!ms) return;
  if(G.dead && !ms.deadSent){ ms.deadSent = true; pushEvent(ms, {type:'playerDead'}); }
  for(const o of stepRuntime(ms, dt)) onOutput(o);
}
