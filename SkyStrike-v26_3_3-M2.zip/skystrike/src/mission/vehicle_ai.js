/* سلوك المركبات الأرضية (دبابة/ناقلة/شاحنة) كل فريم: قيادة على المسار + تتبّع التضاريس
   + اشتباك مبسّط (برج يلاحق الهدف ويرمي).
   لا يستورد three/state/core (ليُختبر بـ node): كل ما يلزم يأتي بكائن X من ai.js:
     X = {world, units: W.units, V (منشئ المتجهات), fire(e, shot), event(id) (وصول), w: رقم الصعوبة}
   الرمي عبر X.fire فيحمل جهة المركبة تلقائياً. أرقام التوازن بـ enemies.js › VEH. */
import {VEH} from '../enemies.js';
import {driveStep, leadAim, tiltOf, wrap} from './friendly_ai.js';
import {headingDir} from './entity_pos.js';

let _w = null;
/* هل الموضع صالح لعجلات/جنازير؟ فوق الماء بهامش، منحدر معتدل، خارج المباني (نفس شروط landPos) */
export function driveOk(world, x, z){
  const h = world.H(x, z);
  if(world.hasWater() && h < world.cfg.water.level+3) return false;
  if(Math.hypot(world.H(x+8, z)-h, world.H(x, z+8)-h) > 6.5) return false;
  return !(world.cfg.hit && world.cfg.hit(x, h+3, z));
}
const okFn = (x, z) => driveOk(_w, x, z);
const env = {ok:okFn, leadDist:null, speedMul:1}, DD = {sp:0, turn:0}, L = {x:0, y:0, z:0, t:0};
const MZ = {x:0, y:0, z:0};

function advance(e, dt, X, speedMul){
  const D = VEH[e.kind], b = e.drv, f = e.follow; _w = X.world;
  env.leadDist = f && X.units.includes(f) ? Math.hypot(f.g.position.x-b.x, f.g.position.z-b.z) : null;
  env.speedMul = speedMul; DD.sp = e.spd; DD.turn = D.turn;
  const o = driveStep(b, DD, dt, env);
  if(o.arrived && e.mid) X.event(e.mid);
  const p = e.g.position; p.x = b.x; p.z = b.z; p.y = X.world.ground(b.x, b.z);
}

/* وحدة بعيدة (خارج سقف الأداء): حركة فقط، بلا تصويب ولا رمي ولا ميلان */
export function vehicleLite(e, dt, X){
  advance(e, dt, X, 1); e.g.rotation.set(0, e.drv.yaw, 0);
}

export function vehicleThink(e, dt, c, X){
  const D = VEH[e.kind], gun = D.gun, b = e.drv, g = e.g, p = g.position, T = e.tgt;
  const inRange = !!(gun && c && T && c.dist <= gun.range && (!T.air || c.dist <= gun.air));
  advance(e, dt, X, inRange ? D.engage : 1);
  const len = D.size*D.scale*.4, hd = headingDir(b.yaw), W = X.world;           // ميلان الهيكل (4 عينات)
  const hF = W.ground(p.x+hd.x*len, p.z+hd.z*len), hB = W.ground(p.x-hd.x*len, p.z-hd.z*len);
  const hR = W.ground(p.x-hd.z*len, p.z+hd.x*len), hL = W.ground(p.x+hd.z*len, p.z-hd.x*len);
  const t = tiltOf(hF, hB, hR, hL, len*2, len*2), k = Math.min(1, dt*6);
  e.pitch += (t.pitch-e.pitch)*k; e.roll += (t.roll-e.roll)*k; g.rotation.set(e.pitch, b.yaw, e.roll);
  e.yaw = b.yaw;
  const aim = g.userData.aim; if(!gun || !aim) return;
  const rate = gun.turn*dt;
  if(!inRange){                                         // بلا هدف ضمن المدى: البرج يعود لاتجاه الهيكل
    aim.rotation.y += Math.max(-rate, Math.min(rate, -aim.rotation.y)); aim.rotation.x *= 1-k; return;
  }
  const bs = e.boost || 1;
  MZ.x = p.x; MZ.y = p.y+D.muz*bs; MZ.z = p.z;
  leadAim(MZ, T.g.position, c.tv, gun.speed, L);
  const wy = wrap(Math.atan2(-L.x, -L.z)-b.yaw), dy = wrap(wy-aim.rotation.y);
  aim.rotation.y = wrap(aim.rotation.y+Math.max(-rate, Math.min(rate, dy)));
  const el = Math.max(-.12, Math.min(.6, Math.atan2(L.y, Math.hypot(L.x, L.z))));
  aim.rotation.x += Math.max(-rate, Math.min(rate, -el-aim.rotation.x));
  if(Math.abs(wrap(wy-aim.rotation.y)) > .08 || e.cd > 0) return;
  e.cd = gun.cd*(.9+Math.random()*.3);
  const ah = headingDir(b.yaw+aim.rotation.y), sp = gun.spread;
  MZ.x += ah.x*D.barrel*bs; MZ.z += ah.z*D.barrel*bs;
  L.x += (Math.random()*2-1)*sp; L.y += (Math.random()*2-1)*sp; L.z += (Math.random()*2-1)*sp;
  const l = Math.hypot(L.x, L.y, L.z) || 1; L.x /= l; L.y /= l; L.z /= l;
  X.fire(e, {pos:X.V(MZ.x, MZ.y, MZ.z), dir:X.V(L.x, L.y, L.z), speed:gun.speed,
    dmg:gun.dmg+(e.side === 'enemy' ? X.w*gun.dmgw : 0)});
}
