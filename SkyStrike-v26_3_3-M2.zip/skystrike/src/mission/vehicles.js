/* مركبات الأرض المتحركة: النموذج (GLB مصبوغ بلون الجهة) + إنشاء الوحدة.
   السلوك بـ vehicle_ai.js والخوارزميات بـ friendly_ai.js.
   النموذج يواجه +Z (فوهة البرج)، فنلفّه π داخل حاوية تواجه -Z كباقي الوحدات. عقدة 'aim' = البرج. */
import * as THREE from 'three';
import {rnd} from '../util.js';
import {scene, world} from '../core.js';
import {W} from '../state.js';
import {hasEM, mkEM} from '../emodels.js';
import {VEH, HP_SCALE} from '../enemies.js';
import {HIT_K} from '../gscale.js';
import {makeBody} from './friendly_ai.js';

const TINT = {ally:0x3f8f55, enemy:0x8a5a3a, player:0x4a8fc8};         // لون الجهة (يمزج مع ألوان النموذج)
const SH_GEO = new THREE.CircleGeometry(1, 20).rotateX(-Math.PI/2);
const SH_MAT = new THREE.MeshBasicMaterial({color:0x000000, transparent:true, opacity:.38, depthWrite:false});

function fallback(D){            // لو فشل تحميل GLB: صندوقان بسيطان (جسم + برج 'aim')
  const m = new THREE.Group(), mat = new THREE.MeshStandardMaterial({color:0x6a6e58, roughness:.8});
  const body = new THREE.Mesh(new THREE.BoxGeometry(D.size*.4, D.size*.2, D.size*.85), mat);
  body.position.y = D.size*.12;
  const aim = new THREE.Group(); aim.name = 'aim'; aim.position.y = D.size*.3;
  const gun = new THREE.Mesh(new THREE.BoxGeometry(.4, .4, D.size*.5), mat); gun.position.z = D.size*.25; aim.add(gun);
  m.add(body); if(D.gun) m.add(aim); return m;
}
export function mkVehicle(kind, side){
  const D = VEH[kind], g = new THREE.Group(); g.rotation.order = 'YXZ';
  const m = hasEM(kind) ? mkEM(kind, TINT[side] ?? TINT.enemy, .4) : fallback(D);
  m.rotation.y = Math.PI; m.scale.setScalar(D.scale); g.add(m);
  const sh = new THREE.Mesh(SH_GEO, SH_MAT);
  sh.scale.set(D.size*D.scale*.32, 1, D.size*D.scale*.55); sh.position.y = .25; g.add(sh);
  const aim = m.getObjectByName('aim'); if(aim) aim.rotation.order = 'YXZ';
  g.userData.aim = aim || null; g.userData.gk = kind;        // gk: يفعّل «تعزيز المسافة» بـ ai.js مثل الأرضيات
  return g;
}

/* o = {yaw, route:[{x,z}], speed, follow (وحدة تسير أمامه)} — يرجع الوحدة (تُضاف لـ W.units) */
export function addVehicle(kind, x, z, w, side, o = {}){
  const D = VEH[kind], g = mkVehicle(kind, side), yaw = o.yaw || 0;
  const hp = D.hp*(side === 'enemy' ? 1+w*HP_SCALE : 1), r = +(D.size*D.scale*HIT_K).toFixed(2);
  g.position.set(x, world.ground(x, z), z); g.rotation.y = yaw; scene.add(g);
  const e = {kind, g, hp, max:hp, r, r0:r, boost:1, muz:D.muz, pts:D.pts, cd:rnd(1, 2), mcd:0, ground:true, air:false,
    side, vehicle:true, sense:D.sense, unarmed:!D.gun, fl:0, pitch:0, roll:0, yaw, spd:o.speed || D.sp,
    drv:makeBody(x, z, yaw, o.route), follow:o.follow || null};
  // دبابة تجاه طائرة: بمدى قصير فقط
  e.accept = D.gun ? (c, d2) => !c.air || d2 <= D.gun.air*D.gun.air : () => false;
  W.units.push(e); return e;
}
