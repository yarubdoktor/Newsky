/* تعريفات المهمات كبيانات. الحقول:
   id · map · title/intro (مفاتيح i18n بـ mission_text.js) · difficulty (يحل مكان رقم الموجة: يضبط صحة/عدوانية الأعداء)
   entities[]: {id, kind, side, pos, obj?, tt?, alt?, route?[]}  kind: 'depot'|'turret'|'sam'|'flak'|'tank'|'apc'|
               'truck'|'jet'|'ace'|'heli'|'drone'|'bomber'|'convoy'  (route = نقاط مسار للمركبات)
               convoy: {units:[مركبات], gap?, speed?, route[]} ← معرّفات الأعضاء id+1..
   objectives[]: {id, type, text, targets[], optional?} · fail[] · triggers[] (M3) · comms[] (M3)
   لإضافة مهمة: أضف كائناً هنا + نصوصها بـ mission_text.js. */
import {entityIds} from './convoy.js';
import {VEHICLE_KINDS} from './entity_pos.js';

export const MISSIONS = [
  { id:'m0', map:'desert', title:'m0t', intro:'m0i', difficulty:2,
    entities:[
      {id:'depot', kind:'depot', side:'enemy', pos:{d:1700, a:0, r:420}, obj:true},
      {id:'aa1', kind:'turret', tt:0, side:'enemy', pos:{near:'depot', r:150}},
      {id:'aa2', kind:'turret', tt:1, side:'enemy', pos:{near:'depot', r:170}},
      {id:'sam1', kind:'sam', side:'enemy', pos:{near:'depot', r:200}}
    ],
    objectives:[{id:'o1', type:'destroy', text:'m0o1', targets:['depot']}],
    fail:[{type:'playerDead'}], triggers:[], comms:[] },
  { id:'m1', map:'desert', title:'m1t', intro:'m1i', difficulty:2,
    entities:[
      {id:'cv', kind:'convoy', side:'ally', units:['tank', 'apc', 'truck', 'truck'], gap:34, speed:11,
       pos:{d:260, a:.5, r:80}, route:[{d:900, a:.25, r:150}, {d:1700, a:.05, r:200}, {d:2400, a:-.1, r:200}]},
      {id:'et1', kind:'tank', side:'enemy', pos:{d:1900, a:.05, r:150}},
      {id:'et2', kind:'tank', side:'enemy', pos:{near:'et1', r:130}},
      {id:'aa1', kind:'turret', tt:0, side:'enemy', pos:{near:'et1', r:220}},
      {id:'sam1', kind:'sam', side:'enemy', pos:{near:'et2', r:240}}
    ],
    objectives:[{id:'o1', type:'destroy', text:'m1o1', targets:['et1', 'et2', 'aa1', 'sam1']}],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}], triggers:[], comms:[] }
];

export const missionById = id => MISSIONS.find(m => m.id === id) || null;

/* فحص سلامة تعريف المهمة (يستعمله الاختبار): يرجع قائمة أخطاء (فارغة = سليم) */
export function validateMission(m, kinds, objTypes){
  const err = [], ids = new Set();
  for(const e of m.entities){
    for(const id of entityIds(e)){ if(ids.has(id)) err.push('duplicate entity '+id); ids.add(id); }
    if(!kinds.includes(e.kind)) err.push('bad kind '+e.kind);
    if(e.kind === 'convoy' && !(e.units && e.units.length && e.units.every(k => VEHICLE_KINDS.includes(k))))
      err.push('convoy needs units of vehicle kinds: '+e.id);
    if((e.kind === 'convoy' || e.route) && !(Array.isArray(e.route) && e.route.length))
      err.push('route needs points: '+e.id);
    if(!e.pos) err.push('no pos '+e.id);
    else if(e.pos.near !== undefined &&
            !m.entities.slice(0, m.entities.indexOf(e)).some(p => entityIds(p).includes(e.pos.near)))
      err.push('near must reference an earlier entity: '+e.id);
  }
  if(!m.objectives.length) err.push('no objectives');
  for(const o of m.objectives){
    if(!objTypes.includes(o.type)) err.push('bad objective type '+o.type);
    for(const id of o.targets || []) if(!ids.has(id)) err.push('objective target missing: '+id);
  }
  return err;
}
