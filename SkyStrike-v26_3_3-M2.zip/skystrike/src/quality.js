export const CH = 600; // حجم قطعة التضاريس بالمتر
export const PRESETS = {
  lite: {pr:.75,  view:3, seg:10, trees:25,  treeRing:1, clouds:12, fx:90,  bloom:0, city:0},
  low:  {pr:1,    view:3, seg:14, trees:50,  treeRing:1, clouds:22, fx:140, bloom:0, city:0},
  med:  {pr:1.25, view:4, seg:22, trees:90,  treeRing:2, clouds:40, fx:260, bloom:0, city:1},
  high: {pr:1.75, view:5, seg:32, trees:150, treeRing:3, clouds:70, fx:420, bloom:1, city:1}
};
export const Q = {name:'med', ...PRESETS.med};
export function setQuality(n){ if(!PRESETS[n]) n = 'med'; Object.assign(Q, PRESETS[n]); Q.name = n; }
