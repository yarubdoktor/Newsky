export const $ = s => document.querySelector(s);
export const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
export const wrap = a => Math.atan2(Math.sin(a),Math.cos(a));
export const rnd = (a,b) => a + Math.random()*(b-a);
export const smooth = t => t*t*(3-2*t);
export function mulberry(a){
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a>>>15, 1|a);
    t = t + Math.imul(t ^ t>>>7, 61|t) ^ t; return ((t ^ t>>>14) >>> 0) / 4294967296; };
}
export function hash2(x,y,s=0){
  let h = (Math.imul(x|0,374761393) + Math.imul(y|0,668265263) + Math.imul(s|0,982451653))|0;
  h = Math.imul(h ^ (h>>>13), 1274126177); return ((h ^ (h>>>16))>>>0) / 4294967296;
}
export const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* ---------- أفقي مُدار (Forced Landscape) ----------
   إذا كان الجوال عمودياً (قفل التدوير شغّال، أو المتصفح ما قدر يقفل الاتجاه) ندوّر واجهة اللعبة 90° بالـCSS
   بدل ما نحجب الشاشة. على الجوال الأفقي الحقيقي ما يتغيّر شي (FL.on = false). */
export const FL = {on:false};
export const VW = () => FL.on ? innerHeight : innerWidth;
export const VH = () => FL.on ? innerWidth : innerHeight;
let hintDone = false;
export function applyFL(){
  const on = innerHeight > innerWidth && matchMedia('(pointer:coarse)').matches, d = document.documentElement, w = on ? innerHeight : innerWidth, h = on ? innerWidth : innerHeight;
  FL.on = on; d.classList.toggle('fl',on);
  d.style.setProperty('--vw',w/100+'px'); d.style.setProperty('--vh',h/100+'px'); d.style.setProperty('--W',w+'px'); d.style.setProperty('--H',h+'px');
  const r = document.getElementById('rot');
  if(r){ if(on && !hintDone){ hintDone = true; r.classList.add('show'); setTimeout(() => r.classList.remove('show'),6000); } if(!on) r.classList.remove('show'); }
}
applyFL(); addEventListener('resize',applyFL); addEventListener('orientationchange',applyFL);
