import * as THREE from 'three';
import {GL,parseGL,lin8} from './gl_height.js';
export {GL,makeH,colorAt,noTree,hit} from './gl_height.js';

const BIN = new URL('./models/greenland.bin',import.meta.url).href;
// تحميل الحزمة (620KB). إذا فشل، تختفي الخريطة من القائمة واللعبة تكمل عادي
export async function loadGreenland(){
  try { const r = await fetch(BIN); if(!r.ok) throw new Error(r.status); parseGL(await r.arrayBuffer()); return true; }
  catch(e){ console.warn('greenland.bin failed',e); return false; }
}
// القاعدة الجوية والمباني والصخور: مجسمات مدموجة بلون الرؤوس، مقسّمة لبلاطات (culling) — بدون textures
export function buildProps(){
  const g = new THREE.Group(); if(!GL.ok) return g;
  const mat = new THREE.MeshLambertMaterial({vertexColors:true,flatShading:true});
  for(const t of GL.hdr.tiles){
    const o = GL.base+t.o, pos = new Float32Array(GL.buf,o,t.v*3), c8 = new Uint8Array(GL.buf,o+t.v*12,t.v*3);
    const idx = new Uint16Array(GL.buf,o+t.v*12+((t.v*3+3)&~3),t.i), col = new Float32Array(t.v*3);
    for(let i=0;i<col.length;i++) col[i] = lin8[c8[i]];
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.BufferAttribute(pos,3)); geo.setAttribute('color',new THREE.BufferAttribute(col,3));
    geo.setIndex(new THREE.BufferAttribute(idx,1)); geo.computeBoundingSphere();
    g.add(new THREE.Mesh(geo,mat));
  }
  g.userData.mat = mat; return g;
}
