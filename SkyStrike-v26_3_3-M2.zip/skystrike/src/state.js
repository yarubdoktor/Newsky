/* الحالة المشتركة للّعبة.
   قاعدة مهمة: ES modules ما تسمح بإعادة إسناد متغير مستورد، فكل شي يتغيّر يعيش داخل الكائن W
   (اقرأه دائماً W.G / W.units بدل ما تخزّنه بمتغير طويل العمر). المصفوفات تُفرَّغ بالمكان (length = 0) ما تُستبدل. */
import * as THREE from 'three';
import {softTex} from './fx.js';
import {scene,V} from './core.js';

export const W = {
  run:false, paused:false, starting:false,          // حالة الجلسة
  G:{},                                             // حالة المهمة الحالية (تُستبدل بـ startGame)
  units:[], projs:[], flares:[],               // units = كل الوحدات من كل الجهات (side). لا تستعمل W.enemies (أُعيدت تسميتها)
  shake:0,                                          // اهتزاز الكاميرا
  candE:null, lockE:null, lockDist:0, lockT:0,      // القفل: المرشح، المقفول، المسافة، زمن القفل
  tut:null                                          // الجولة التعليمية (null = غير فعالة)
};

// اللاعب. P.g تُستبدل لما تتغير الطائرة (startGame)، فاقرأ P.g دائماً من P.
export const P = {g:new THREE.Group(),yaw:0,pitch:0,roll:0,wr:0,wp:0,gl:1,speed:150,hp:100,maxhp:100,turn:1.1,gcd:0,msl:0,mul:0,bmb:0,flr:0,sx:0,sy:0,en:1,cur:150,bk:0};
P.side = 'player'; P.g.rotation.order = 'YXZ'; P.g.visible = false; scene.add(P.g);
export const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1,1).rotateX(-Math.PI/2),
  new THREE.MeshBasicMaterial({map:softTex,color:0x000000,transparent:true,opacity:.4,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
shadow.visible = false; scene.add(shadow);
export const FW = V(0,0,-1);                         // اتجاه أمام اللاعب (يحدّثه playerUpdate كل فريم ويقرأه الذكاء الاصطناعي للتصويب)
