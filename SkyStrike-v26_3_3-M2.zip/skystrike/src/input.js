/* الإدخال: لوحة المفاتيح + الجويستيك + الأزرار + الميلان. الكائن inp هو الواجهة الوحيدة اللي يقرأها اللعب. */
import {$,clamp,FL} from './util.js';
import {S} from './save.js';
import {W} from './state.js';

export const inp = {x:0,y:0,fire:false,msl:false,msP:false,boost:false,mul:false,mulP:false,bmb:false,bmbP:false,flr:false,flrP:false};
const keys = {};
let pauseCb = () => {};
export const bindPause = fn => { pauseCb = fn; };     // game.js يربط Esc/P بالإيقاف المؤقت

addEventListener('keydown',e => { keys[e.code] = 1;
  if(e.code === 'Space') inp.fire = true; if(e.code === 'KeyM') inp.msl = true; if(e.code === 'ShiftLeft') inp.boost = true;
  if(e.code === 'KeyN') inp.mul = true; if(e.code === 'KeyB') inp.bmb = true; if(e.code === 'KeyF') inp.flr = true;
  if((e.code === 'Escape' || e.code === 'KeyP') && W.run) pauseCb(); });
addEventListener('keyup',e => { keys[e.code] = 0;
  if(e.code === 'Space') inp.fire = false; if(e.code === 'KeyM') inp.msl = false; if(e.code === 'ShiftLeft') inp.boost = false;
  if(e.code === 'KeyN') inp.mul = false; if(e.code === 'KeyB') inp.bmb = false; if(e.code === 'KeyF') inp.flr = false; });

/* ---------- الجويستيك ---------- */
let joyId = null; const joy = $('#joy'), knob = joy.firstElementChild;
const jset = e => { const r = joy.getBoundingClientRect(); let sx = e.clientX-r.left-r.width/2, sy = e.clientY-r.top-r.height/2; if(FL.on){ const q = sx; sx = sy; sy = -q; }   // الواجهة مدوّرة 90°
  const dx = sx/55, dy = sy/55, m = Math.hypot(dx,dy) || 1, k = m > 1 ? 1/m : 1;
  inp.x = dx*k; inp.y = dy*k; knob.style.transform = `translate(${inp.x*35}px,${inp.y*35}px)`; };
joy.addEventListener('pointerdown',e => { joyId = e.pointerId; joy.setPointerCapture(e.pointerId); jset(e); });
joy.addEventListener('pointermove',e => { if(e.pointerId === joyId) jset(e); });
const jend = e => { if(e.pointerId === joyId){ joyId = null; inp.x = inp.y = 0; knob.style.transform = ''; } };
joy.addEventListener('pointerup',jend); joy.addEventListener('pointercancel',jend);

/* ---------- أزرار الإمساك ---------- */
const hold = (b,k) => { b.addEventListener('pointerdown',() => inp[k] = true); for(const ev of ['pointerup','pointercancel','pointerleave']) b.addEventListener(ev,() => inp[k] = false); };
hold($('#bf'),'fire'); hold($('#bm'),'msl'); hold($('#bb'),'boost'); hold($('#bw'),'mul'); hold($('#bo'),'bmb'); hold($('#bl'),'flr');

/* تصفير كل الإدخال: يمنع «الأزرار العالقة» (مفتاح/إصبع ضايع لما النافذة تفقد التركيز أو اللعبة توقف أو تنتهي) */
export function resetInput(){
  for(const k in keys) keys[k] = 0;
  inp.x = inp.y = 0; inp.fire = inp.msl = inp.boost = inp.mul = inp.bmb = inp.flr = false; inp.msP = inp.mulP = inp.bmbP = inp.flrP = false;
  joyId = null; knob.style.transform = '';
}
addEventListener('blur',resetInput);
addEventListener('contextmenu',e => e.preventDefault());   // يمنع قائمة الضغط المطوّل أثناء اللعب

/* ---------- الميلان (تجريبي): "عكس الميلان" بالإعدادات لو الاتجاه معكوس ---------- */
let tilt0 = null;
export const resetTilt = () => { tilt0 = null; };
addEventListener('deviceorientation',e => {
  if(!S.tilt || !W.run || W.paused || W.G.dead || joyId !== null || e.beta == null) return;
  const ang = FL.on ? 90 : ((screen.orientation && screen.orientation.angle) || 0); let st, pi;
  if(ang === 90){ st = e.beta; pi = -e.gamma; } else if(ang === 270){ st = -e.beta; pi = e.gamma; } else { st = e.gamma; pi = e.beta; }
  if(S.tiltInv){ st = -st; pi = -pi; }
  if(!tilt0) tilt0 = {st,pi}; inp.x = clamp((st-tilt0.st)/22,-1,1); inp.y = clamp((pi-tilt0.pi)/22,-1,1);
});

/* يُستدعى كل فريم: محاور لوحة المفاتيح (الجويستيك والميلان لهم الأولوية) */
export function pollKeys(){
  if(keys.ArrowLeft || keys.KeyA) inp.x = -1; else if(keys.ArrowRight || keys.KeyD) inp.x = 1; else if(joyId === null && !S.tilt) inp.x = 0;
  if(keys.ArrowUp || keys.KeyW) inp.y = -1; else if(keys.ArrowDown || keys.KeyS) inp.y = 1; else if(joyId === null && !S.tilt) inp.y = 0;
}
