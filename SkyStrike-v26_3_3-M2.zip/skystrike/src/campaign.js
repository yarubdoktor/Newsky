/* ---------- الحملة (v16) ----------
   كل مهمة: خريطة + نمط + هدف (goal = عدد الموجات/المراحل) + مكافأة أول إكمال فقط.
   النصوص (العنوان c1t / الوصف c1d ...) بـ i18n.js. المهمة تنفتح بعد إكمال اللي قبلها (S.cp = عدد المهام المكتملة).
   لإضافة مهمة: أضف سطراً هنا + نصَّيها بـ i18n.js. */
export const CAMPAIGN = [
  {id:'c1', map:'island',    mode:'survive', goal:3,  c:400,  g:0,  xp:100},
  {id:'c2', map:'desert',    mode:'assault', goal:3,  c:600,  g:5,  xp:150},
  {id:'c3', map:'night',     mode:'defend',  goal:4,  c:800,  g:5,  xp:200},
  {id:'c4', map:'arctic',    mode:'survive', goal:5,  c:1000, g:10, xp:300},   // تنتهي بمواجهة الصقر الأحمر
  {id:'c5', map:'canyon',    mode:'assault', goal:3,  c:1200, g:10, xp:350},
  {id:'c6', map:'greenland', mode:'survive', goal:10, c:2500, g:25, xp:800},   // زعيمان: الصقر الأحمر ثم القلعة الطائرة
  {id:'c7', map:'map7',      mode:'assault', goal:5,  c:3000, g:30, xp:900}   // خريطة 24×24 كم: قاعدتان وأساطيل
];
