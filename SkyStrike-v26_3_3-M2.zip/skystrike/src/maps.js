import {clamp,smooth} from './util.js';
import {makeH,colorAt as glColor,noTree as glNoTree,hit as glHit,buildProps} from './greenland.js';
import {makeH as m7H,colorAt as m7Color,noTree as m7NoTree,hit as m7Hit,buildProps as m7Props} from './map7.js';

export function mkNoise(seed){
  const p = new Uint8Array(512), a = Array.from({length:256},(_,i)=>i); let s = (seed|0) || 1;
  for(let i=255;i>0;i--){ s = (Math.imul(s,1664525)+1013904223)>>>0; const j = s%(i+1); [a[i],a[j]] = [a[j],a[i]]; }
  for(let i=0;i<512;i++) p[i] = a[i&255];
  const fade = t => t*t*t*(t*(t*6-15)+10), lerp = (a,b,t) => a+(b-a)*t;
  const grad = (h,x,y) => { switch(h&7){case 0:return x+y;case 1:return -x+y;case 2:return x-y;case 3:return -x-y;case 4:return x;case 5:return -x;case 6:return y;default:return -y;} };
  return (x,y) => {
    const fx = Math.floor(x), fy = Math.floor(y), X = fx&255, Y = fy&255; x -= fx; y -= fy;
    const u = fade(x), v = fade(y), A = p[X]+Y, B = p[X+1]+Y;
    return lerp(lerp(grad(p[A],x,y),grad(p[B],x-1,y),u), lerp(grad(p[A+1],x,y-1),grad(p[B+1],x-1,y-1),u), v);
  };
}
const fbm = (n,x,y,o) => { let a = 1, f = 1, s = 0, m = 0;
  for(let i=0;i<o;i++){ s += n(x*f+i*17.3,y*f-i*9.1)*a; m += a; a *= .5; f *= 2; } return s/m; };

// كل خريطة: تضاريس (h) + سماء + ضباب + إضاءة + ألوان + أشجار + مدن + طقس
export const MAPS = {
  island:{ seed:11, exp:1.15,
    water:{level:0,color:0x1b78b0,op:.88,spec:0xffd6a8},
    sky:{top:0x2a5fb0,hor:0xf0b98c,stars:0}, fog:0xefb98f, fogFar:3600,
    sun:{dir:[-.7,.45,-.55],col:0xffd1a0,i:3.6}, hemi:[0xbcd6ff,0x6b5a45,2.3], cloud:0xffffff,
    pal:[[.5,0x1d5f7a],[4,0xe0c88a],[40,0x4c8a3c],[110,0x6f6a5c],[1e9,0xf2f5f8]], rock:0x7a7466, rockNy:.72, rockMin:8,
    tree:{type:'cone',col:0x2f6f33,hmin:5,hmax:70,p:.95,sc:[.8,1.7]}, city:{p:.08,night:false},
    h:n => (x,z) => { const a = fbm(n,x*.0007,z*.0007,4), d = fbm(n,x*.004+9,z*.004+9,3);
      return a>0 ? Math.pow(a*1.6,1.4)*190 + d*a*40 + 2 : a*110 - 2 + d*3; } },
  desert:{ seed:23, exp:1.1,
    water:null, sky:{top:0x3b78c4,hor:0xf2cf9a,stars:0}, fog:0xedc89a, fogFar:3200,
    sun:{dir:[.5,.7,.3],col:0xfff0d0,i:4}, hemi:[0xe6d2b0,0x8a6a40,2.4], cloud:0xfff4e0,
    pal:[[30,0xc9a063],[70,0xdbb577],[110,0xe6c488],[1e9,0xb98a58]], rock:0x8a6a48, rockNy:.78, rockMin:20,
    tree:{type:'cactus',col:0x4f7a3a,hmin:30,hmax:90,p:.12,sc:[.8,1.6]}, city:{p:.06,night:false},
    h:n => (x,z) => { const b = fbm(n,x*.0012,z*.0012,4)*60, dune = Math.abs(n(x*.004+z*.0015,z*.005))*22,
        m = fbm(n,x*.0006+40,z*.0006-40,3), mesa = smooth(clamp((m-.12)*5,0,1))*90; return 45+b+dune+mesa; } },
  // القطب (v13): أُعيد تصميمها بالكامل. القديمة كانت 65% منها انحدار فوق 45° وقممها قريبة من سقف الطيران.
  // الجديدة: سهول جليدية + مضايق مائية + سلاسل جبلية معزولة (أقصى ارتفاع ~230م) وسقف طيران 800م. البداية دائماً على يابسة.
  arctic:{ seed:37, exp:1.0,
    water:{level:0,color:0x2f6f96,op:.92,spec:0xffffff},
    sky:{top:0x3f78bd,hor:0xcfe0ee,stars:0}, fog:0xc4d7e6, fogFar:3600,
    sun:{dir:[-.45,.28,.6],col:0xffe9cf,i:2.9}, hemi:[0xbfd6f2,0x6f7f92,2.0], cloud:0xeef4fb,
    pal:[[.8,0x7fb3cf],[5,0xbfd6e2],[70,0xe4edf4],[150,0xb4c3d0],[1e9,0xf2f6fa]], rock:0x4d5560, rockNy:.80, rockMin:25,
    tree:{type:'cone',col:0x1f4a38,hmin:6,hmax:60,p:.18,sc:[.9,1.6]}, city:null, weather:'snow',
    ceil:800, cloudY:[420,700], spawn:{x:0,z:0,alt:140,pitch:0,yaw:0},
    h:n => (x,z) => {
      const b = fbm(n,x*.00045,z*.00045,3), o = smooth(clamp(1-Math.hypot(x,z)/1200,0,1));      // o: يابسة حول نقطة البداية
      const land = Math.max(smooth(clamp((b+.34)*2.4,0,1)),o);                                    // 0 مضيق/بحر → 1 يابسة
      const mk = smooth(clamp((fbm(n,x*.00035+30,z*.00035-12,2)-.02)*3.2,0,1));                   // أين تقع السلاسل الجبلية
      const r = 1-Math.abs(fbm(n,x*.0009+7,z*.0009-3,3)), m = Math.pow(r,3.5)*mk*land*(1-o);       // شكل القمم
      const roll = fbm(n,x*.0018+11,z*.0018-5,2);                                                 // تموجات جليدية ناعمة
      return -24 + land*(30+(b+.2)*26+roll*12) + m*215 + n(x*.008,z*.008)*1.6*land; } },
  canyon:{ seed:51, exp:1.1,
    water:null, sky:{top:0x2f6fb5,hor:0xf4c590,stars:0}, fog:0xf0c08c, fogFar:3400,
    sun:{dir:[.6,.5,-.5],col:0xffd9a8,i:3.8}, hemi:[0xf0d6b8,0x7a4a2a,2.2], cloud:0xfff0e0,
    pal:[[60,0xb5653a],[120,0xc97b45],[200,0xd9955a],[1e9,0xe7b27a]], rock:0x8d4f30, rockNy:.8, rockMin:0, band:true,
    tree:{type:'ball',col:0x6b7a3a,hmin:5,hmax:140,p:.15,sc:[.7,1.3]}, city:null,
    h:n => (x,z) => { const t = fbm(n,x*.0008,z*.0008,4)*.5+.5, k = clamp(t,0,.999)*6, f = Math.floor(k), fr = k-f;
      return ((f+smooth(clamp((fr-.55)*2.2,0,1)))/6)*330 + fbm(n,x*.012,z*.012,2)*5; } },
  night:{ seed:67, exp:.95,
    water:{level:0,color:0x061a30,op:.9,spec:0x9fb8ff},
    sky:{top:0x050c20,hor:0x1a2b4d,stars:1.1}, fog:0x0f1c36, fogFar:3600,
    sun:{dir:[.5,.6,-.4],col:0x9bb4ff,i:1.7}, hemi:[0x4a62a0,0x141c2a,1.7], cloud:0x3c4c78,
    pal:[[.5,0x0b2236],[7,0x3a3a30],[60,0x1f3a2a],[1e9,0x40403f]], rock:0x303338, rockNy:.72, rockMin:20,
    tree:{type:'cone',col:0x16301f,hmin:8,hmax:80,p:.7,sc:[.8,1.5]}, city:{p:.4,night:true},
    h:n => (x,z) => { const a = fbm(n,x*.0006,z*.0006,4), d = fbm(n,x*.006,z*.006,3)*6;
      return a>-.04 ? 6+(a+.04)*230+d : (a+.04)*90 - 1 + d*.3; } },
  // خريطة جاهزة 20×20 كم (heightmap من GLB). التفاصيل في greenland.js و tools/convert_world.py
  greenland:{ seed:73, exp:1.05,
    water:null, sky:{top:0x2c6cb8,hor:0xd3e3f0,stars:0}, fog:0xc9dae8, fogFar:4200,
    sun:{dir:[-.6,.4,-.5],col:0xffe6c4,i:3.8}, hemi:[0xbcd8ff,0x5d6b52,2.3], cloud:0xffffff,
    pal:[[60,0x558f47],[300,0x3f7a3a],[500,0x6f7d6f],[1e9,0xe8eeee]], rock:0x7a7a74, rockNy:.66, rockMin:90,
    tree:{type:'cone',col:0x2b5e36,hmin:50,hmax:420,p:.9,sc:[.9,2]}, city:null,
    cloudY:[650,1050], ceil:1400, limit:9300, spawn:{x:400,z:1500,alt:90,pitch:.08,yaw:.26},
    colorFn:glColor, noTree:glNoTree, hit:glHit, buildProps,
    h:n => makeH(n) },
  // الخريطة 7 (v24): القاعدتان + الأساطيل 24×24 كم. بحر مفتوح + جزيرتا قواعد جوية (A و B بمدارج مقابلة) + جزيرة مركزية جبلية + جزيرتان صغيرتان + حاملتا طائرات وأساطيل.
  // التفاصيل: map7_height.js و tools/convert_map7.py (المصدر الأصلي بـ models_src/map7_*.glb)
  map7:{ seed:79, exp:1.08,
    water:{level:0,color:0x1d6f8f,op:.9,spec:0xffffff},
    sky:{top:0x2b64b0,hor:0xbcd9ec,stars:0}, fog:0xb8d4e6, fogFar:4400,
    sun:{dir:[-.5,.62,-.45],col:0xfff1dc,i:3.7}, hemi:[0xbfd9ff,0x5b6a55,2.3], cloud:0xffffff,
    pal:[[2,0x1d6f8f],[9,0xe0c88a],[35,0x4c8a3c],[95,0x2f6f33],[1e9,0x6f6a5c]], rock:0x6f6a5c, rockNy:.86, rockMin:30,
    tree:{type:'cone',col:0x2f6f33,hmin:36,hmax:110,p:.8,sc:[.9,1.8]}, city:null,
    cloudY:[800,1300], ceil:1500, limit:10800, spawn:{x:0,z:5300,alt:90,pitch:.05,yaw:0},
    colorFn:m7Color, noTree:m7NoTree, hit:m7Hit, buildProps:m7Props,
    h:n => m7H(n) }
};
export const MAP_IDS = Object.keys(MAPS);
export function buildMap(id){
  const cfg = MAPS[id] || MAPS.island, n = mkNoise(cfg.seed), H = cfg.h(n), lvl = cfg.water ? cfg.water.level : -1e9;
  return {cfg, H, ground:(x,z) => Math.max(H(x,z),lvl)};
}
