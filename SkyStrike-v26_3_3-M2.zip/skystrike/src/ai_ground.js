/* عقل الأرضيات (v26.2.6، بند #9 — الجزء الأرضي). دالة صرفة بدون three/DOM: تنختبر بمحاكاة node (test_ground_ai.mjs).
   بدل «البرج يلتقط اللاعب لحظة الإطلاق + رشقة بزمن ثابت»: التقاط (acq) ← تتبّع تدريجي بسرعة دوران محدودة (trk)
   ← تحذير (wrn) مع تثبيت الهدف بآخر لحظاته ← رشقة بنمط مختار (fir) ← تبريد. الطلقات تخرج باتجاه الفوهة الفعلي.
   تعاون: حدّ لعدد الوحدات المطلِقة معاً + فاصل بين بدايات الرشقات (الباقي يتتبّع ويأتي دوره).
   اتجاه الفوهة +Z (عكس المقاتلات -Z): yaw = atan2(dx,dz). ai.js ينفّذ التدوير والرمي فقط. */
import {GROUND_AI as A} from './enemies.js';
const clamp = (v,a,b) => Math.max(a,Math.min(b,v)), wrap = a => Math.atan2(Math.sin(a),Math.cos(a));
const rng = (r,x) => Array.isArray(x) ? x[0]+r()*(x[1]-x[0]) : x;
const cnt = (r,x) => Array.isArray(x) ? x[0]+Math.floor(r()*(x[1]-x[0]+1)) : x;
const out = {dx:0,dy:0,dz:1,moved:false,shots:0,warn:false,start:false,spread:0};
export const maxCrew = w => clamp(1+Math.floor(w/A.crewEvery),1,A.crewMax);

function choose(list,w,r){
  let tot = 0; for(const p of list) if((p.minW||0) <= w) tot += p.w;
  let x = r()*tot; for(const p of list){ if((p.minW||0) > w) continue; x -= p.w; if(x <= 0) return p; }
  return list[0];
}
function aimAt(e,c,dt,r,slewMul){        // يحدّث الزاوية المطلوبة (نقطة تقدّم + خطأ إدراك) ثم يدوّر الفوهة بسرعة محدودة
  const k = e.kind, p = e.gpat;
  if(!e.gfr){
    e.get -= dt;
    if(e.get <= 0){ e.get = .3+r()*.4;
      const s = A.err[k]*(p ? p.errMul||1 : 1)*(1.4-c.ag)*clamp(c.dist/500,.5,1.6);
      e.ge[0] = (r()*2-1)*s; e.ge[1] = (r()*2-1)*s; e.ge[2] = (r()*2-1)*s; }
    const t = c.dist/c.gunSp*(1+(p ? p.lead||0 : 0));
    const dx = c.px+c.vx*t+e.ge[0]-c.ex, dy = c.py+c.vy*t+e.ge[1]-c.ey, dz = c.pz+c.vz*t+e.ge[2]-c.ez;
    e.gty = Math.atan2(dx,dz); e.gtp = clamp(Math.atan2(dy,Math.hypot(dx,dz)||1e-6),-.2,1.4);
  }
  const s = A.slew[k]*slewMul*dt, dyw = wrap(e.gty-e.gay), dpt = e.gtp-e.gap;
  if(Math.abs(dyw) > 1e-4 || Math.abs(dpt) > 1e-4) out.moved = true;
  e.gay = wrap(e.gay+clamp(dyw,-s,s)); e.gap += clamp(dpt,-s,s);
  return Math.hypot(wrap(e.gty-e.gay)*Math.cos(e.gap),e.gtp-e.gap);     // الخطأ المتبقي (راد)
}
function done(e,cd){ e.gst = 'trk'; e.gcd = cd; e.gpat = null; e.gfr = false; e.tele = 0; }
function dir(e){ const cp = Math.cos(e.gap); out.dx = Math.sin(e.gay)*cp; out.dy = Math.sin(e.gap); out.dz = Math.cos(e.gay)*cp; return out; }

/* e = الوحدة (تُخزَّن حالتها بحقول g*). c = {px,py,pz,vx,vy,vz (اللاعب)، ex,ey,ez (الفوهة)، dist، alive، canFire،
   rmin،rmax، gunSp، spread (للفلاك)، ag (عدوانية)، w (موجة)، crew (وحدات تحذّر/ترمي الآن)، maxCrew، since (ث منذ آخر بداية)}.
   out = {dx,dy,dz (اتجاه الفوهة)، moved، shots (0/1 هذا الفريم)، spread (راد)، warn/start (بدأ تحذير الآن)}. */
export function groundThink(e,c,dt,r){
  out.moved = false; out.shots = 0; out.warn = false; out.start = false; out.spread = 0;
  if(e.gst === undefined){ e.gst = 'idle'; e.gt = 0; e.gay = 0; e.gap = 0; e.gcd = .5+r()*1.5; e.gn = 0; e.gi = 0;
    e.ge = [0,0,0]; e.get = 0; e.gty = 0; e.gtp = 0; e.gfr = false; e.gpat = null; e.tele = 0; }
  e.gcd -= dt; const k = e.kind;
  if(!c.alive || c.dist > c.rmax*A.sense){ if(e.gst !== 'idle'){ e.gst = 'idle'; e.gpat = null; e.gfr = false; e.tele = 0; } return dir(e); }
  if(e.gst === 'idle'){ e.gst = 'acq'; e.gt = rng(r,A.acq)*(1.3-c.ag*.5); }
  const inR = c.dist <= c.rmax && c.dist >= c.rmin && c.canFire; let err;
  if(e.gst === 'acq'){ aimAt(e,c,dt,r,1); e.gt -= dt; if(e.gt <= 0) e.gst = 'trk'; }
  else if(e.gst === 'trk'){
    err = aimAt(e,c,dt,r,1);
    if(e.gcd <= 0 && inR && err < A.tol[k] && c.crew < c.maxCrew && c.since > A.stagger*(1.2-c.ag*.4)){
      e.gpat = choose(A.patterns[k],c.w,r); e.gst = 'wrn'; e.tele = 1; out.warn = out.start = true;
      e.gt = A.warn[k]*(e.gpat.warnMul||1)*(1.35-c.ag*.6); }
  } else if(e.gst === 'wrn'){
    e.gfr = e.gt < A.commit; aimAt(e,c,dt,r,1); e.gt -= dt;
    if(!inR) done(e,.6);
    else if(e.gt <= 0){ e.gst = 'fir'; e.gfr = false; e.tele = 0; e.gn = cnt(r,e.gpat.n); e.gi = 0; }
  } else {                                     // fir
    aimAt(e,c,dt,r,.5); e.gi -= dt;
    if(!inR) done(e,.8);
    else if(e.gi <= 0){ out.shots = 1; out.spread = c.spread*(e.gpat.spreadMul||1)/Math.max(c.dist,250);
      e.gn--; e.gi = e.gpat.gap; if(e.gn <= 0) done(e,rng(r,e.gpat.cd)*(1.25-c.ag*.35)); }
  }
  return dir(e);
}
