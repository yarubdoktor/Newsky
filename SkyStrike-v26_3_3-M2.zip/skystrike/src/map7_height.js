// الخريطة 7 (القاعدتان + الأساطيل، 24×24 كم): قراءة الحزمة + عيّنات الارتفاع/اللون/التصادم (بدون three، قابلة للاختبار بـ node).
// الإحداثيات = إحداثيات اللعبة: الأعلى +Y، المدارج على محور Z. قاعدة A عند Z=+4500 (البداية، الأنف نحو -Z) وقاعدة B عند Z=-4500. المركز (0,0) جزيرة مركزية.
// الشبكة 129×129 بخطوة 187.5م فقط، فنستعمل bicubic مع قصّ التجاوز (ما يطلع شاطئ منتفخ/قاع متموّج) ونضيف تفاصيل ناعمة على القمم فقط.
// بدون مصفوفة ألوان: لون التضاريس يُحسب من الارتفاع (colorAt) فتبقى الحزمة صغيرة. يُنتج بـ tools/convert_map7.py
export const M7 = {ok:false, N:0, half:0, step:0, H:null, boxes:null, nB:0, hdr:null, buf:null, base:0};
const clamp = (v,a,b) => v < a ? a : v > b ? b : v, sm = t => t*t*(3-2*t);
const LIN = new Float32Array(256); for(let i=0;i<256;i++){ const c = i/255; LIN[i] = c <= .04045 ? c/12.92 : Math.pow((c+.055)/1.055,2.4); }
export const lin8 = LIN;
const rgb = (r,g,b) => [LIN[r],LIN[g],LIN[b]];
// ألوان التضاريس الأصلية بملف الخريطة: رمل (223,199,137) وعشب (75,137,59) وقاع (28,110,142)
const PAL = {deep:rgb(28,110,142), shallow:rgb(52,150,168), sand:rgb(223,199,137), grass:rgb(75,137,59), forest:rgb(52,110,48), rock:rgb(111,106,92)};

// قاعدتان: مستطيل (نصف عرض BX على X، نصف طول BZ على Z) يمنع زرع الأشجار. الهضبة 24م والتلال تبدأ بعد ~400م من المحور
const BASES = [[0,4500],[0,-4500]], BX = 480, BZ = 1500;

export function parseM7(ab){
  const jl = new DataView(ab).getUint32(0,true), h = JSON.parse(new TextDecoder().decode(new Uint8Array(ab,4,jl))), b = 4+jl, n = h.N*h.N;
  const u16 = new Uint16Array(ab,b+h.oH,n), H = new Float32Array(n), k = (h.hmax-h.hmin)/65535;
  for(let i=0;i<n;i++) H[i] = h.hmin + u16[i]*k;
  Object.assign(M7,{ok:true,N:h.N,half:h.half,step:h.step,H,hdr:h,buf:ab,base:b,nB:h.nB,boxes:new Float32Array(ab,b+h.oB,h.nB*6)});
  return M7;
}

const cr = (p0,p1,p2,p3,t) => p1 + .5*t*(p2-p0 + t*(2*p0-5*p1+4*p2-p3 + t*(3*(p1-p2)+p3-p0)));
function baseH(x,z){
  const N = M7.N, H = M7.H, inv = 1/M7.step, u = clamp((x+M7.half)*inv,0,N-1.0001), v = clamp((z+M7.half)*inv,0,N-1.0001);
  const i = u|0, j = v|0, fu = u-i, fv = v-j, c = a => a < 0 ? 0 : a > N-1 ? N-1 : a, i0 = c(i-1), i1 = i, i2 = c(i+1), i3 = c(i+2);
  const row = k => { const b = c(j+k)*N; return cr(H[b+i0],H[b+i1],H[b+i2],H[b+i3],fu); };
  const r = cr(row(-1),row(0),row(1),row(2),fv);
  const j1 = c(j+1)*N, j0 = j*N, a = H[j0+i1], b = H[j0+i2], d = H[j1+i1], e = H[j1+i2];      // قصّ بين أصغر/أكبر قيمة بالخلية (يمنع التجاوز عند الشاطئ)
  const lo = Math.min(a,b,d,e), hi = Math.max(a,b,d,e);
  return r < lo ? lo : r > hi ? hi : r;
}
// الارتفاع النهائي: الشبكة (bicubic) + تفاصيل ناعمة فوق 70م فقط (المدارج والشواطئ والمستوطنات تحت 70م فتبقى مستوية كما حُسبت بالمحوّل)
export function makeH(n){
  return (x,z) => {
    if(!M7.ok) return 0;
    const b = baseH(x,z), a = sm(clamp((b-70)/90,0,1));
    return a > .01 ? b + (n(x*.011,z*.011)*3.2 + n(x*.037+5,z*.037-3)*1.1)*a*(.8+clamp(b/500,0,1)*1.6) : b;
  };
}
const mix = (o,a,b,t) => { o[0] = a[0]+(b[0]-a[0])*t; o[1] = a[1]+(b[1]-a[1])*t; o[2] = a[2]+(b[2]-a[2])*t; };
const _t = [0,0,0];
// لون التضاريس (خطي) من الارتفاع: قاع ← رمل (الشاطئ والهضبة 24م) ← عشب فوق 27م ← غابة أغمق بالقمم. الصخر على المنحدرات من cfg.rockNy بـ world.js
export function colorAt(x,z,out){
  const h = baseH(x,z), c = _t;
  if(h < 2){ mix(c,PAL.shallow,PAL.deep,sm(clamp(-h/45,0,1))); mix(c,c,PAL.sand,sm(clamp((h+1)/3,0,1))); }
  else { c[0] = PAL.sand[0]; c[1] = PAL.sand[1]; c[2] = PAL.sand[2]; }
  mix(c,c,PAL.grass,sm(clamp((h-27)/12,0,1)));
  mix(c,c,PAL.forest,sm(clamp((h-85)/45,0,1)));
  out.r = c[0]; out.g = c[1]; out.b = c[2]; return out;
}
// ممنوع زرع أشجار: على القاعدتين وحول المستوطنات
export function noTree(x,z){
  if(!M7.ok) return false;
  for(const b of BASES) if(Math.abs(x-b[0]) < BX && Math.abs(z-b[1]) < BZ) return true;
  for(const c of M7.hdr.clear){ const ax = x-c[0], az = z-c[1]; if(ax*ax+az*az < c[2]*c[2]) return true; }
  return false;
}
// تصادم الطائرة مع المباني والسفن والأبراج والجسر (صناديق AABB)
export function hit(x,y,z){
  if(!M7.ok) return false;
  const B = M7.boxes, m = 3;
  for(let i=0,n=M7.nB*6;i<n;i+=6){
    if(x > B[i]-m && x < B[i+3]+m && z > B[i+2]-m && z < B[i+5]+m && y < B[i+4]+m && y > B[i+1]-60) return true;
  }
  return false;
}
