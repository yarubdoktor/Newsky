/* مقياس الأرضيات (v26.2.4، بند #10) — دالة صرفة بدون three/DOM، تنختبر بـ node.
   الفكرة: كل نوع أرضي له (1) مضاعف حجم فوق حجم نموذج GLB الأصلي ليحس اللاعب بآلة ضخمة حقيقية من الكاميرا القريبة،
   (2) نصف قطر تصادم محسوب من حجم النموذج الفعلي (مش رقم ثابت)، (3) ارتفاع فوهة النار، (4) «تعزيز مسافة»:
   من بعيد/من فوق يكبر الهدف قليلاً كي يبقى مقروءاً (ويكبر تصادمه معه: اللي تشوفه هو اللي تصيبه).
   أبعاد النماذج الأصلية (الأكبر بُعداً، من الـ GLB): aa_twin 13.1 · aa_tank 18.3 · gepard 16.8 · flak 13.9 · sam 15.4 */
export const GK = ['aa_twin','aa_tank','gepard','sam','flak'];          // نفس ترتيب mkGround(t)
export const GSCALE = {
  aa_twin:{size:13.1, mul:1.8, muz:9},
  aa_tank:{size:18.3, mul:1.9, muz:9},
  gepard: {size:16.8, mul:1.9, muz:11},
  sam:    {size:15.4, mul:1.9, muz:14},
  flak:   {size:13.9, mul:2.0, muz:12}
};
export const HIT_K = .42;                                                  // نصف قطر التصادم = HIT_K × أكبر بُعد بعد التكبير
export const BOOST = {near:500, far:2000, max:1.8};                         // تعزيز المسافة: 1× حتى 500م ثم يزيد بنعومة حتى 1.8× عند 2000م

export const groundScale = k => GSCALE[k].mul;
export const groundRadius = k => +(GSCALE[k].size*GSCALE[k].mul*HIT_K).toFixed(2);
export const groundMuzzle = k => GSCALE[k].muz;
export function farBoost(dist){
  const t = Math.min(1,Math.max(0,(dist-BOOST.near)/(BOOST.far-BOOST.near)));
  return 1+(BOOST.max-1)*t*t*(3-2*t);                                      // smoothstep
}
