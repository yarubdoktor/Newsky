/* فحص التصادم بالمسار (Swept): بدون أي استيراد (قابل للاختبار بـ node).
   الفحص بنقطة واحدة كل فريم يخلّي الرصاصة السريعة "تنفذ" من الهدف لما ينزل الـ FPS
   (رصاصة اللاعب 750 وحدة/ث = 37 وحدة بفريم 20 FPS، وقطر المقاتلة 18). هنا نقيس أقرب مسافة
   بين المركز (cx,cy,cz) والقطعة المستقيمة من الموضع القديم (ax..) للجديد (bx..) ونرجّع مربعها. */
export function segDist2(ax,ay,az,bx,by,bz,cx,cy,cz){
  const dx = bx-ax, dy = by-ay, dz = bz-az, l2 = dx*dx+dy*dy+dz*dz;
  let t = l2 > 1e-9 ? ((cx-ax)*dx+(cy-ay)*dy+(cz-az)*dz)/l2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  const px = ax+dx*t-cx, py = ay+dy*t-cy, pz = az+dz*t-cz;
  return px*px+py*py+pz*pz;
}
