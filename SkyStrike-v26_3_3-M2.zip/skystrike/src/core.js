/* المحرك المشترك: الرندر، المشهد، الكاميرا، العالم، الجسيمات، الجودة. يُنشأ مرة وحدة ويستوردونه الباقي. */
import * as THREE from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import {$,clamp,VW,VH} from './util.js';
import {S} from './save.js';
import {Q,setQuality} from './quality.js';
import {createWorld} from './world.js';
import {createFX} from './fx.js';

export const V = (x=0,y=0,z=0) => new THREE.Vector3(x,y,z);
export const isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || matchMedia('(pointer:coarse)').matches;

export const renderer = new THREE.WebGLRenderer({antialias:!isMobile,powerPreference:'high-performance'});
renderer.toneMapping = THREE.ACESFilmicToneMapping;
document.body.prepend(renderer.domElement);
export const scene = new THREE.Scene();
export const cam = new THREE.PerspectiveCamera(65,1,1,9000);
export const world = createWorld(scene,renderer,cam);
export const fx = createFX(scene);
export const ind = $('#ind'), ix = ind.getContext('2d');   // كانفس أسهم الأعداء خارج الشاشة (يرسمه hud.js)
let composer = null, bloom = null, autoName = null;
export const setAutoQuality = n => { autoName = n; };         // الجودة التلقائية لما ينزل الـFPS (game.js)

function ensureComposer(){
  if(!Q.bloom) return;
  try{
    const w = VW(), h = VH();
    if(!composer){
      const rt = new THREE.WebGLRenderTarget(w,h,{type:THREE.HalfFloatType,samples:isMobile?0:4});
      composer = new EffectComposer(renderer,rt);
      composer.addPass(new RenderPass(scene,cam));
      bloom = new UnrealBloomPass(new THREE.Vector2(w/2,h/2),.55,.65,.92); composer.addPass(bloom);
      composer.addPass(new OutputPass());
    }
  }catch(err){ console.warn('bloom unavailable',err); composer = null; Q.bloom = 0; }
}
export function resize(){
  const w = VW(), h = VH(); renderer.setSize(w,h); cam.aspect = w/h; cam.updateProjectionMatrix();
  if(composer){ composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(w,h); }
  fx.setScale(h*renderer.getPixelRatio(),cam.fov); ind.width = w; ind.height = h;
}
addEventListener('resize',resize);
export function applyQuality(){
  const nm = S.q === 'auto' ? (autoName || (isMobile ? 'med' : 'high')) : S.q;
  setQuality(nm); renderer.setPixelRatio(Math.min(devicePixelRatio||1,Q.pr)); fx.setCap(Q.fx);
  world.applyQuality(); ensureComposer(); resize();
}
export const renderFrame = () => { if(Q.bloom && composer) composer.render(); else renderer.render(scene,cam); };

/* مساعدات صغيرة مشتركة */
export const dirOfTo = (g,o) => o.set(0,0,-1).applyEuler(g.rotation);     // اتجاه الأمام لمجسم
export const vib = ms => { if(S.vib && navigator.vibrate){ try{ navigator.vibrate(ms); }catch(e){} } };
export const panOf = p => { const e = cam.matrixWorld.elements, dx = p.x-cam.position.x, dy = p.y-cam.position.y, dz = p.z-cam.position.z, L = Math.hypot(dx,dy,dz) || 1;
  return clamp((dx*e[0]+dy*e[1]+dz*e[2])/L,-1,1); };                       // موضع الصوت يمين/يسار
