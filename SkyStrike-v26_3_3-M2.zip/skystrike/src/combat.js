/* القتال: الطلقات والصواريخ والقنابل، الانفجارات، الضرر، القتل، المشاعل. */
import * as THREE from 'three';
import {$,clamp,rnd} from './util.js';
import {t} from './i18n.js';
import {sfx,setEngine} from './audio.js';
import {mkMsl,mkBomb,BULLET_GEO,BULLET_P,BULLET_E} from './jets.js';
import {scene,world,fx,V,vib,panOf} from './core.js';
import {W,P,shadow} from './state.js';
import {banner} from './ui.js';
import {checkClear} from './waves.js';
import {pushEvent} from './mission/mission_runtime.js';
import {segDist2} from './collide.js';
import {isHostile,hitMul,sideOf,FRIENDLY_FIRE} from './mission/factions.js';

const _a = V(), _b = V(), _o = V();       // _o = موضع الطلقة قبل الحركة (للتصادم بالمسار)

export function boom(pos,r=12){
  const d = pos.distanceTo(P.g.position);
  if(r < 12){ fx.glow(pos.x,pos.y,pos.z,0xffe9a0,r*1.4,r*3.5,.18); return; }
  const big = r >= 22; sfx('boom',clamp(1-d/1500,.15,1),big,panOf(pos));
  fx.explode(pos,r); W.shake = Math.max(W.shake,clamp(1-d/700,0,1)*(big?1.6:1)); if(big && d < 500) vib(40);
}
/* o.side: جهة صاحب الطلقة ('player'|'ally'|'enemy'). بدونها تُشتق من owner ('p' لاعب، غيره عدو) كما قبل v26.3.2 */
export const projSide = o => o.side || (o.owner === 'p' ? 'player' : 'enemy');
export function shoot(o){
  const side = projSide(o), foe = side === 'enemy'; let mesh;
  if(o.bomb) mesh = mkBomb(); else if(o.mis) mesh = mkMsl(foe);
  else { mesh = new THREE.Mesh(BULLET_GEO,foe ? BULLET_E : BULLET_P); mesh.scale.set(1,1,7); }
  mesh.position.copy(o.pos); scene.add(mesh);
  if(side !== 'player') sfx(o.mis?'emsl':'efire',clamp(1-o.pos.distanceTo(P.g.position)/900,0,1),false,panOf(o.pos));
  W.projs.push({mesh,dir:o.dir.clone().normalize(),speed:o.speed,dmg:o.dmg,owner:o.owner,side,mis:!!o.mis,bomb:!!o.bomb,
    target:o.target||null,turn:o.turn||2.4,vy:0,life:o.life||(o.bomb?14:o.mis?7:2.2)});
}

/* ---------- اللاعب: ضرر / موت / خسارة القاعدة ---------- */
export function die(){ const G = W.G; if(G.dead) return; G.dead = true; G.deadT = 1.8; boom(P.g.position,30); P.g.visible = false; shadow.visible = false; setEngine(0); vib(200); }
export function baseLost(){ const G = W.G; if(G.dead) return; G.dead = true; G.deadT = 2; banner(t('baseLost')); boom(_a.set(G.obj.x,world.ground(G.obj.x,G.obj.z)+10,G.obj.z),30); sfx('alarm'); }
export function hurt(d){
  const G = W.G; if(G.dead || W.tut) return; G.hit = true; P.hp -= d; sfx('hit'); W.shake = Math.max(W.shake,.6); vib(30);
  const f = $('#fl'); f.style.opacity = .35; setTimeout(() => f.style.opacity = 0,120); if(P.hp <= 0) die();
}

/* ---------- الأعداء: إزالة / قتل ---------- */
export function removeEnemy(e){ scene.remove(e.g); const i = W.units.indexOf(e); if(i >= 0) W.units.splice(i,1); if(W.lockE === e) W.lockE = null; if(W.candE === e){ W.candE = null; W.lockT = 0; } }
/* by = جهة القاتل. مكافآت اللاعب (نقاط/كومبو/عملات) فقط لو قتل معادياً؛ قتل حليف بنيرانه = عقوبة (FRIENDLY_FIRE) */
export function kill(e,by = 'player'){
  const G = W.G;
  boom(e.g.position,e.air ? (e.kind === 'boss' ? 40 : e.kind === 'bomber' ? 26 : 22) : 16); removeEnemy(e);
  if(by === 'player' && isHostile(by,sideOf(e))){
    if(e.air) G.kj++; else G.kg++;
    G.combo++; G.ct = 4; G.mult = Math.min(5,1+Math.floor(G.combo/3));
    G.score += Math.round(e.pts*G.mult); G.coins += Math.round(e.pts/8); G.xp += Math.round(e.pts/5);
    if(e.kind === 'boss'){ G.coins += 150; banner(t('bossDown')); sfx('win'); }
  } else if(by === 'player' && sideOf(e) === 'ally'){
    G.ff = (G.ff||0)+1; G.combo = 0; G.mult = 1; G.score = Math.max(0,G.score-FRIENDLY_FIRE.killPenalty);
    banner(t('ffKill')); sfx('alarm');
  }
  if(G.ms && e.mid) pushEvent(G.ms,{type:'entityDead',id:e.mid,by});   // المهمة الجديدة: الحدث يقرأه mission_bridge
  checkClear();
}
/* إصابة وحدة بطلقة جهتها ps: يرجع true لو تأثّرت. نيران صديقة من اللاعب = ضرر مخفّض + تحذير مُخفَّف التكرار */
function hitUnit(e,dmg,ps){
  const k = hitMul(ps,sideOf(e)); if(!k) return false;
  const G = W.G; e.hp -= dmg*k;
  if(k < 1 && (G.t||0)-(G.ffT ?? -9) > FRIENDLY_FIRE.warnEvery){ G.ffT = G.t||0; banner(t('ffWarn')); }
  if(e.hp <= 0) kill(e,ps);
  return true;
}
/* تنظيف كل الكيانات (بداية/نهاية مهمة). المصفوفات تُفرَّغ بالمكان لأن باقي الملفات تقرأها من W */
export function clearEntities(){
  const G = W.G;
  for(const e of W.units) scene.remove(e.g); for(const p of W.projs) scene.remove(p.mesh);
  W.units.length = 0; W.projs.length = 0; W.flares.length = 0; W.lockE = null; W.candE = null; W.lockT = 0;
  if(G.beacon){ scene.remove(G.beacon); G.beacon = null; }
}

/* ---------- تحديث الطلقات والمشاعل ---------- */
export function projectilesUpdate(dt){
  const pos = P.g.position, G = W.G, units = W.units, projs = W.projs, flares = W.flares;
  for(let pi=projs.length-1;pi>=0;pi--){
    const p = projs[pi], mp = p.mesh.position, ps = projSide(p), tg = p.target;
    if(p.mis){
      if(tg && tg !== P && tg.fl > 0 && G.wave >= 4 && tg.g.position.distanceToSquared(mp) < 280*280
        && Math.random() < dt*Math.min(2,(G.wave-3)*.4)){           // الهدف يطلق مشعلاً فيضيع الصاروخ
        const tp = tg.g.position; tg.fl--; p.target = null;
        sfx('flare',clamp(1-tp.distanceTo(pos)/900,0,1),false,panOf(tp));
        for(let k=0;k<3;k++) fx.glow(tp.x+rnd(-6,6),tp.y+rnd(-6,2),tp.z+rnd(-6,6),0xffb060,5,2,.5,0,0,0,.95); }
      if(p.target && p.target !== P){          // صاروخ موجّه نحو وحدة (لاعب أو حليف أو عدو)
        if(units.includes(p.target)){
          _a.copy(p.target.g.position).sub(mp).normalize(); p.dir.lerp(_a,Math.min(1,dt*p.turn)).normalize(); } }
      else if(ps === 'enemy' || p.target === P){    // صاروخ عدو (أو موجّه للاعب): يتتبع اللاعب أو أقرب مشعل
        let tp = pos, bs = 360*360;
        for(const f of flares){ const d2 = f.p.distanceToSquared(mp); if(d2 < bs){ bs = d2; tp = f.p; } }
        const turn = dt*p.turn*(tp === pos ? P.ms : 1);                     // التخفّي: أضعف تتبعاً للاعب
        _a.copy(tp).sub(mp).normalize(); p.dir.lerp(_a,Math.min(1,turn)).normalize(); }
      fx.glow(mp.x-p.dir.x*2.5,mp.y-p.dir.y*2.5,mp.z-p.dir.z*2.5,0xffa040,2.4,.6,.14,0,0,0,.95);
      if(Math.random() < .7) fx.smk(mp.x-p.dir.x*2,mp.y-p.dir.y*2,mp.z-p.dir.z*2,0xcfcfcf,1.4,6,1,0,2,0,.45);
    }
    _o.copy(mp); mp.addScaledVector(p.dir,p.speed*dt);
    if(p.bomb){ p.vy -= 75*dt; mp.y += p.vy*dt; _b.copy(mp).addScaledVector(p.dir,p.speed); _b.y += p.vy; p.mesh.lookAt(_b); }
    else { _b.copy(mp).add(p.dir); p.mesh.lookAt(_b); }
    p.life -= dt;
    let dead = p.life <= 0 || mp.y < world.ground(mp.x,mp.z), boomed = false;   // boomed: انفجرت عند الإصابة
    if(!dead){
      for(const e of units){                    // تتأثر حسب hitMul (معادٍ كامل · حليف: نيران صديقة من اللاعب فقط)
        if(!hitMul(ps,sideOf(e))) continue;
        const ep = e.g.position, hr = e.r+(e.air?0:2);
        if(segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,ep.x,ep.y,ep.z) < hr*hr){
          dead = true; boomed = true; boom(mp,p.mis?16:3); hitUnit(e,p.dmg,ps); break; } }
      if(!dead && isHostile(ps,'player') && !G.dead && segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,pos.x,pos.y,pos.z) < 49){
        hurt(p.dmg); dead = true; boomed = true; boom(mp,p.mis?12:4); }
      if(!dead && p.mis && ps === 'enemy'){
        for(const f of flares){ if(f.p.distanceToSquared(mp) < 100){ dead = true; break; } } }
      if(!dead && ps !== 'enemy' && !p.mis && !p.bomb){          // رصاص اللاعب/الحلفاء يسقط صواريخ المعادي
        for(const q of projs){ if(q.mis && isHostile(ps,projSide(q)) && segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,
          q.mesh.position.x,q.mesh.position.y,q.mesh.position.z) < 20){ q.life = 0; dead = true; break; } } }
    }
    if(dead){
      if(p.mis && !boomed) boom(mp,12);
      if(p.bomb){ boom(mp,26); for(const e of units.slice()){ const dd = e.g.position.distanceTo(mp);
        if(dd < 36) hitUnit(e,p.dmg*(1-dd/48),ps); } }
      scene.remove(p.mesh); projs.splice(pi,1);
    }
  }
}
export function flaresUpdate(dt){
  const flares = W.flares;
  for(let i=flares.length-1;i>=0;i--){
    const f = flares[i]; f.life -= dt; if(f.life <= 0){ flares.splice(i,1); continue; }
    f.v.y -= 9*dt; f.p.addScaledVector(f.v,dt); f.v.multiplyScalar(1-dt*.5);
    fx.glow(f.p.x,f.p.y,f.p.z,0xffb060,5,2,.35,0,0,0,.95); if(Math.random() < .5) fx.smk(f.p.x,f.p.y,f.p.z,0xdddddd,2,7,1.2,0,1,0,.4);
  }
}
