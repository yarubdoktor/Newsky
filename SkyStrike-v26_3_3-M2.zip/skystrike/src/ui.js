/* عناصر الواجهة المشتركة (HUD) + لافتة الرسائل. لا تستورد شي سوى util حتى ما تتكوّن دورات استيراد. */
import {$} from './util.js';

export const el = {hp:$('#hp'),sc:$('#sc'),st:$('#st'),cmb:$('#cmb'),lk:$('#lk'),lkb:$('#lkb'),warn:$('#warn'),bossw:$('#bossw'),bossb:$('#bossb'),basew:$('#basew'),baseb:$('#baseb'),fps:$('#fps'),bn:$('#bn'),ld:$('#ld')};

export function banner(txt){ el.bn.textContent = txt; el.bn.style.opacity = 1; clearTimeout(banner.h); banner.h = setTimeout(() => el.bn.style.opacity = 0,1800); }
