/* عقل مقاتلة العدو (v26.2.5، بند #9). دالة صرفة بدون three/DOM: تنختبر بمحاكاة node (tools/test/test_jet_ai.mjs).
   jetThink يحدّث حالة العدو e (e.bst...) ويرجع out = {ty,tp,spMul,tnMul,cap,fire} — ai.js ينفّذ التوجيه والحركة والرمي.
   بدل المطاردة المباشرة الملتصقة: هجوم بزاوية متقدمة (lead) → مرور → تمدد وانفصال → صعود والتفاف أو عودة بزاوية،
   مع زمن رد فعل بشري وخطأ تقدير، وسقف لسرعة العدو قرب اللاعب، وحدّ لعدد المهاجمين المتزامنين (الباقي يلتف جانباً). */
import {JET_AI as J} from './enemies.js';
const clamp = (v,a,b) => Math.max(a,Math.min(b,v)), wrap = a => Math.atan2(Math.sin(a),Math.cos(a));
const out = {ty:0,tp:0,spMul:1,tnMul:1,cap:1e9,fire:false};
const rng = (r,[a,b]) => a+r()*(b-a);

function aim(ex,ey,ez,tx,ty,tz){            // اتجاه (yaw,pitch) من العدو نحو نقطة. الأمام = -Z (نفس اصطلاح steer)
  const dx = tx-ex, dy = ty-ey, dz = tz-ez, h = Math.hypot(dx,dz) || 1e-6;
  out.ty = Math.atan2(-dx,-dz); out.tp = clamp(Math.atan2(dy,h),-.7,.7);
}
function enter(e,st,r){
  e.bst = st;
  if(st === 'atk'){ e.bt = rng(r,J.atkT); e.brk = J.breakDist+r()*J.breakR; }      // brk = مسافة انفصاله بعد المرور (تختلف بكل هجمة)
  else if(st === 'ext'){ e.bt = rng(r,J.extT); e.sd = r() < .5 ? -1 : 1; }
  else if(st === 'clm'){ e.bt = J.climbT; }
  else if(st === 'evd'){ /* e.bt تحدده الدالة */ }
}
export const maxAttackers = w => clamp(1+Math.floor(w/3),J.maxAtk[0],J.maxAtk[2]);

/* ep = موقع العدو {x,y,z}. c = {px,py,pz (اللاعب), vx,vy,vz (سرعته), fx,fy,fz (أمامه), sp (سرعته), dist, alive, gh (حد أدنى للارتفاع), atk (عدد المهاجمين الآخرين), maxAtk, dodge (JET/ACE.dodge), gunSp} */
export function jetThink(e,c,dt,r,ep){
  if(!e.pp){ e.pp = {x:c.px,y:c.py,z:c.pz}; e.pv = {x:c.vx,y:c.vy,z:c.vz}; e.pt = 0; e.pa = 0; e.tailT = 0; e.off = 0; e.offT = 0; e.en = 0; e.cool = 0; e.jk = 0;
    enter(e,c.atk < c.maxAtk ? 'atk' : 'flk',r); }
  const dist = c.dist, dg = c.dodge;
  // --- إدراك بشري: يأخذ عيّنة لموقع/سرعة اللاعب كل «زمن رد فعل» (+خطأ)، وبينها يستقرئ من آخر عيّنة ---
  e.pt -= dt; e.pa += dt; e.bt -= dt; e.jk -= dt; e.en = Math.max(0,e.en-dt); e.offT = Math.max(0,e.offT-dt);
  if(e.pt <= 0){
    e.pt = (dist > J.sense ? J.farReact : J.react[0]+(1-e.ag)*(J.react[1]-J.react[0]))+r()*.1; e.pa = 0;
    const er = J.err*(1-e.ag*.6); e.pp.x = c.px+(r()-.5)*2*er; e.pp.y = c.py+(r()-.5)*2*er*.5; e.pp.z = c.pz+(r()-.5)*2*er;
    e.pv.x = c.vx; e.pv.y = c.vy; e.pv.z = c.vz;
  }
  const lead = e.pa+dist/(c.gunSp || 520)*(.5+.5*e.ag);
  const tx = e.pp.x+e.pv.x*lead, ty = e.pp.y+e.pv.y*lead, tz = e.pp.z+e.pv.z*lead;
  // --- كشف اللصق على ذيل اللاعب ---
  const vx = ep.x-c.px, vy = ep.y-c.py, vz = ep.z-c.pz, cosR = (vx*c.fx+vy*c.fy+vz*c.fz)/(dist || 1);
  const behind = c.alive && dist < J.tailDist && cosR < J.tailCos;
  e.tailT = behind ? e.tailT+dt : Math.max(0,e.tailT-dt*2);

  out.spMul = 1; out.tnMul = 1; out.cap = 1e9; out.fire = false;
  switch(e.bst){
    case 'atk': {
      aim(ep.x,ep.y,ep.z,tx,ty,tz);
      if(e.offT > 0) out.ty += e.off*(e.offT/J.offT);                         // عودة بزاوية جانبية تتلاشى (ما يجي من الذيل مباشرة)
      if(e.en > 0) out.spMul = 1.1;                                           // طاقة الغوص بعد الصعود
      if(dist < J.capDist) out.cap = Math.max(J.capMin,c.sp*(e.elite ? J.capAce : J.capRatio));
      const aimed = c.alive && (c.fx*(ep.x-c.px)+c.fy*(ep.y-c.py)+c.fz*(ep.z-c.pz))/(dist || 1) > dg.aim;
      if(aimed && e.jk <= 0 && dist < dg.range && r() < dt*e.ag*dg.rate){ enter(e,'evd',r); e.bt = dg.dur+r()*dg.durR; e.sd = r() < .5 ? -1 : 1; e.jk = dg.cd; }
      else if(dist < e.brk){ enter(e,'ext',r); }                              // مرّ بجانب اللاعب: ينفصل
      else if(e.bt <= 0 || e.tailT > J.tailMax){ enter(e,'ext',r); }
      else out.fire = c.alive;
      break; }
    case 'evd':
      out.ty = e.yaw+e.sd*dg.turn; out.tp = .25; out.tnMul = 1.2;
      if(e.bt <= 0) enter(e,'atk',r);
      break;
    case 'ext': {                                                             // تمدد: ينعطف جانباً عن مسار اللاعب، أسرع قليلاً، ينفصل عن الذيل
      // عمودياً على اتجاه اللاعب: يخرج من جيب الذيل (الابتعاد بنفس اتجاهه كان يبقيه على ذيله)
      out.ty = Math.atan2(-c.fx,-c.fz)+e.sd*1.4; out.tp = .1; out.spMul = 1.15; out.tnMul = 1.4;
      if(behind && e.xt > J.vertAfter){ out.tp = .9; out.spMul = .9; out.tnMul = 1.8; }   // ما زال بجيب الذيل بعد ثانية: كسر عمودي (صعود حاد يخسر سرعة فيقع خلف اللاعب)
      e.xt += dt;
      if(e.bt <= 0 || dist > J.extDist){
        if(r() < J.climbP && dist < J.climbDist){ enter(e,'clm',r); }
        else { e.off = e.sd*J.offAngle; e.offT = J.offT; enter(e,c.atk < c.maxAtk ? 'atk' : 'flk',r); }
      }
      break; }
    case 'clm':                                                               // صعود حاد والتفاف نحو اللاعب (تبادل سرعة بارتفاع)
      aim(ep.x,ep.y,ep.z,tx,ty,tz); out.tp = 1; out.spMul = .85; out.tnMul = 1.1;
      if(e.bt <= 0){ e.en = J.enT; enter(e,c.atk < c.maxAtk ? 'atk' : 'flk',r); }
      break;
    case 'flk': {                                                             // التفاف جانبي حول اللاعب بانتظار دوره بالهجوم
      const a = Math.atan2(ep.x-c.px,ep.z-c.pz)+e.sd*1.2;
      aim(ep.x,ep.y,ep.z,c.px+Math.sin(a)*J.flankDist,c.py+J.flankAlt,c.pz+Math.cos(a)*J.flankDist);
      if(c.atk < c.maxAtk && e.cool <= 0) enter(e,'atk',r);
      break; }
  }
  if(ep.y < c.gh){ out.tp = Math.max(out.tp,.6); out.spMul = Math.min(out.spMul,1); }      // لا يهبط تحت حد الأرض
  return out;
}
