/* نموذج الطيران الاحترافي (S.fm = 1) — دالة صرفة بدون DOM/three حتى تنختبر بـ node مباشرة (tools/test/test_flight.mjs).
   الفكرة (مثل Ace Combat لكن بوزن حقيقي):
   • عصا اليمين/اليسار = «زاوية ميلان» مطلوبة، والطائرة توصلها بنابض مخمّد (ما يرتد، يعطي وزن).
   • الدوران الأفقي ينتج من الميلان نفسه (sin الميلان) + شوية دفّة مباشرة عشان ما يتأخر التصويب الدقيق.
   • عصا أمام/خلف = معدل صعود/نزول بقصور ذاتي (يتأخر شوي ويكمل شوي)، وبالميلان يتحوّل جزء منه لدوران أفقي = «شدّ» الدورة.
   • الطاقة (بـplayer.js): الصعود يبطّئ والغطس يسرّع. القدرة على الدوران تقل بالسرعة العالية (الـBoost) إلا Su-57 (توجيه الدفع tv).
   • G: يُحسب من معدل الدوران الكلي (للـHUD والاهتزاز وخطوط البخار). */
const clamp = (v,a,b) => Math.min(b,Math.max(a,v));
export const FM = {
  DZ:.1,                 // منطقة ميتة شعاعية
  BANK:1.22,             // أقصى ميلان (~70°)
  RW:8, RZ:1, RMAX:2.4,  // نابض الميلان: تردد، تخميد (1 = بدون ارتداد)، أقصى سرعة لفّ (rad/s)
  TB:.62,                // دوران من الميلان (rad/s عند ميلان 90° × turn)
  TD:.18,                // دفّة مباشرة
  UP:.72, DN:.5,         // أقصى معدل سحب/دفع للأنف (rad/s)
  PLAG:7,                // سرعة استجابة معدل النبرة (أقل = أثقل)
  SAG:.06,               // نزول الأنف تلقائياً بالميلان لو ما سحبت (يخلّي السحب له معنى)
  CPL:.9,                // قوة تحويل السحب لدوران أفقي بالميلان
  GMAX:6                 // G عند أقصى دوران
};
export function stepPro(P,inp,opt,dt,boosting){
  const m = Math.min(1,Math.hypot(inp.x,inp.y)), k = m < FM.DZ ? 0 : (m-FM.DZ)/(1-FM.DZ), gn = m ? k*(.7+.3*k)/m : 0, a = 1-Math.exp(-dt*12);   // m مقصوصة عند 1: الجويستيك ما يتأثر، والقطر بلوحة المفاتيح يحتفظ بقوته الكاملة
  P.sx += (inp.x*gn-P.sx)*a; P.sy += (inp.y*gn-P.sy)*a;
  const sp = P.cur/P.speed, auth = clamp(Math.pow(sp,-.6),.75,1.2)*(boosting ? P.tv : 1)*opt.sens*P.turn;
  // الميلان: نابض مخمّد
  P.wr += ((-P.sx*FM.BANK-P.roll)*FM.RW*FM.RW-2*FM.RZ*FM.RW*P.wr)*dt; P.wr = clamp(P.wr,-FM.RMAX,FM.RMAX); P.roll += P.wr*dt;
  // النبرة: معدل بقصور ذاتي
  const u = opt.invY ? P.sy : -P.sy;
  P.wp += (u*(u > 0 ? FM.UP : FM.DN)*auth-P.wp)*(1-Math.exp(-dt*FM.PLAG));
  const sr = Math.sin(P.roll), cr = Math.cos(P.roll);
  P.pitch = clamp(P.pitch+(P.wp*(.5+.5*Math.abs(cr))-(P.pitch > -.6 ? FM.SAG*sr*sr : 0))*dt,-1.2,1.2);
  if(Math.abs(P.sy) < .05) P.pitch *= 1-Math.min(1,dt*.35);
  // الدوران الأفقي
  const wy = (sr*FM.TB-P.sx*FM.TD)*auth+(P.wp > 0 ? P.wp*sr*FM.CPL : 0);
  P.yaw += wy*dt;
  // G
  P.gl += (1+clamp(Math.hypot(wy,P.wp)/.95,0,1.3)*FM.GMAX-P.gl)*(1-Math.exp(-dt*6));
  return wy;
}
