import * as THREE from 'three';
import {rnd} from './util.js';

export const softTex = (() => {
  const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), gr = x.createRadialGradient(32,32,0,32,32,32);
  gr.addColorStop(0,'rgba(255,255,255,1)'); gr.addColorStop(.4,'rgba(255,255,255,.55)'); gr.addColorStop(1,'rgba(255,255,255,0)');
  x.fillStyle = gr; x.fillRect(0,0,64,64); return new THREE.CanvasTexture(c);
})();

// نظام جسيمات GPU: كل الدخان/الانفجارات/الشرر بـ draw call واحد (Points) بدل Sprite لكل جسيم
const VS = `attribute vec4 aCol;attribute float aSize;uniform float uScale;varying vec4 vc;
void main(){vc=aCol;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=min(aSize*uScale/max(-mv.z,1.),420.);gl_Position=projectionMatrix*mv;}`;
const FS = `varying vec4 vc;
void main(){float r=length(gl_PointCoord-.5)*2.;float a=1.-smoothstep(0.,1.,r);a*=a;gl_FragColor=vec4(vc.rgb,vc.a*a);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;
const _c = new THREE.Color();

class Pool {
  constructor(scene,n,additive){
    this.n = n; this.cap = n; this.i = 0; this.act = 0;
    this.pos = new Float32Array(n*3); this.col = new Float32Array(n*4); this.size = new Float32Array(n);
    this.vel = new Float32Array(n*3); this.age = new Float32Array(n); this.life = new Float32Array(n);
    this.s0 = new Float32Array(n); this.s1 = new Float32Array(n); this.o = new Float32Array(n); this.gr = new Float32Array(n); this.rgb = new Float32Array(n*3);
    const g = this.g = new THREE.BufferGeometry();
    this.aPos = new THREE.BufferAttribute(this.pos,3).setUsage(THREE.DynamicDrawUsage);
    this.aCol = new THREE.BufferAttribute(this.col,4).setUsage(THREE.DynamicDrawUsage);
    this.aSize = new THREE.BufferAttribute(this.size,1).setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position',this.aPos); g.setAttribute('aCol',this.aCol); g.setAttribute('aSize',this.aSize);
    this.u = {value:800};
    this.mat = new THREE.ShaderMaterial({uniforms:{uScale:this.u},vertexShader:VS,fragmentShader:FS,transparent:true,depthWrite:false,
      blending:additive?THREE.AdditiveBlending:THREE.NormalBlending});
    this.pts = new THREE.Points(g,this.mat); this.pts.frustumCulled = false; this.pts.renderOrder = 5; scene.add(this.pts);
  }
  spawn(x,y,z,hex,s0,s1,life,vx,vy,vz,o,gr){
    const j = this.i; this.i = (j+1)%this.cap; if(this.life[j] <= 0) this.act++;
    this.pos[j*3] = x; this.pos[j*3+1] = y; this.pos[j*3+2] = z;
    this.vel[j*3] = vx; this.vel[j*3+1] = vy; this.vel[j*3+2] = vz;
    _c.setHex(hex); this.rgb[j*3] = _c.r; this.rgb[j*3+1] = _c.g; this.rgb[j*3+2] = _c.b;
    this.age[j] = 0; this.life[j] = life; this.s0[j] = s0; this.s1[j] = s1; this.o[j] = o; this.gr[j] = gr;
    this.size[j] = s0; this.col[j*4] = _c.r; this.col[j*4+1] = _c.g; this.col[j*4+2] = _c.b; this.col[j*4+3] = o;
  }
  update(dt){
    if(!this.act) return;
    for(let j=0;j<this.n;j++){
      if(this.life[j] <= 0) continue;
      const a = this.age[j] += dt, k = a/this.life[j];
      if(k >= 1){ this.life[j] = 0; this.size[j] = 0; this.col[j*4+3] = 0; this.act--; continue; }
      this.vel[j*3+1] -= this.gr[j]*dt;
      this.pos[j*3] += this.vel[j*3]*dt; this.pos[j*3+1] += this.vel[j*3+1]*dt; this.pos[j*3+2] += this.vel[j*3+2]*dt;
      const e = 1-(1-k)*(1-k); this.size[j] = this.s0[j]+(this.s1[j]-this.s0[j])*e;
      this.col[j*4+3] = this.o[j]*Math.pow(1-k,1.5);
    }
    this.aPos.needsUpdate = this.aCol.needsUpdate = this.aSize.needsUpdate = true;
  }
}

export function createFX(scene){
  const add = new Pool(scene,420,true), smoke = new Pool(scene,300,false);
  const dGeo = new THREE.BoxGeometry(1,.6,1.4), dMat = new THREE.MeshStandardMaterial({color:0x2a2a2a,roughness:.9});
  const deb = []; for(let i=0;i<28;i++){ const m = new THREE.Mesh(dGeo,dMat); m.visible = false; scene.add(m); deb.push({m,t:0,life:0,vx:0,vy:0,vz:0,sx:0,sy:0,sz:0}); }
  let di = 0;
  const F = {
    setCap(c){ add.cap = Math.min(add.n,c); smoke.cap = Math.max(40,Math.min(smoke.n,Math.round(c*.7))); add.i %= add.cap; smoke.i %= smoke.cap; },
    setScale(px,fov){ const s = px/(2*Math.tan(fov*Math.PI/360)); add.u.value = s; smoke.u.value = s; },
    glow(x,y,z,col,s0,s1,life,vx=0,vy=0,vz=0,o=.9,g=0){ add.spawn(x,y,z,col,s0,s1,life,vx,vy,vz,o,g); },
    smk(x,y,z,col,s0,s1,life,vx=0,vy=0,vz=0,o=.7,g=0){ smoke.spawn(x,y,z,col,s0,s1,life,vx,vy,vz,o,g); },
    debris(p,n,sp){
      for(let i=0;i<n;i++){ const d = deb[di]; di = (di+1)%deb.length; d.m.visible = true; d.m.position.copy(p); d.t = 0; d.life = 1.4;
        d.vx = rnd(-1,1)*sp; d.vy = rnd(.3,1)*sp; d.vz = rnd(-1,1)*sp; d.sx = rnd(-6,6); d.sy = rnd(-6,6); d.sz = rnd(-6,6); d.m.scale.setScalar(1); }
    },
    explode(p,r){
      const big = r >= 22, x = p.x, y = p.y, z = p.z;
      F.glow(x,y,z,0xfff1b0,r*2,r*5,.35);
      for(let i=0;i<(big?6:4);i++) F.glow(x+rnd(-1,1)*r*.4,y+rnd(-1,1)*r*.4,z+rnd(-1,1)*r*.4,i%2?0xff7a1a:0xffb347,r*1.2,r*(3+Math.random()*2),rnd(.5,.9),rnd(-1,1)*r*.6,rnd(0,1)*r*.6,rnd(-1,1)*r*.6);
      for(let i=0;i<6;i++) F.smk(x,y,z,0x2b2b2b,r*1.4,r*4.5,rnd(1.6,2.6),rnd(-1,1)*r*.4,r*rnd(.5,1.2),rnd(-1,1)*r*.4,.7);
      for(let i=0;i<14;i++){ const s = rnd(40,120); F.glow(x,y,z,0xffd070,1.6,.4,rnd(.5,1.1),rnd(-1,1)*s,rnd(-.2,1)*s,rnd(-1,1)*s,1,90); }
      F.debris(p,big?6:3,rnd(30,70));
    },
    update(dt){
      add.update(dt); smoke.update(dt);
      for(const d of deb){ if(!d.m.visible) continue; d.t += dt; if(d.t >= d.life){ d.m.visible = false; continue; }
        d.vy -= 60*dt; d.m.position.x += d.vx*dt; d.m.position.y += d.vy*dt; d.m.position.z += d.vz*dt;
        d.m.rotation.x += d.sx*dt; d.m.rotation.y += d.sy*dt; d.m.rotation.z += d.sz*dt; d.m.scale.setScalar(1-.4*d.t/d.life); }
    },
    clear(){ for(const P of [add,smoke]){ P.life.fill(0); P.size.fill(0); P.col.fill(0); P.act = 0; P.aSize.needsUpdate = P.aCol.needsUpdate = true; } for(const d of deb) d.m.visible = false; }
  };
  return F;
}
