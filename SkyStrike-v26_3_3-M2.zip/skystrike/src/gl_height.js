// خريطة Greenland: قراءة الحزمة + عيّنات الارتفاع/اللون/التصادم (بدون three، فيمكن اختبارها بـ node)
// الإحداثيات = إحداثيات اللعبة: الأعلى +Y، المدرج على محور Z (الأنف نحو -Z)، مركز المدرج (0,0).
export const GL = {ok:false, N:0, half:0, step:0, H:null, C:null, boxes:null, nB:0, hdr:null, buf:null, base:0};
const clamp = (v,a,b) => v < a ? a : v > b ? b : v, sm = t => t*t*(3-2*t);
const LIN = new Float32Array(256); for(let i=0;i<256;i++){ const c = i/255; LIN[i] = c <= .04045 ? c/12.92 : Math.pow((c+.055)/1.055,2.4); }
export const lin8 = LIN;

// منصة القاعدة: أرض مستوية حول المدرج (الأصلية كانت 110–115م والمدرج فوقها بـ 116–118م)
const PL = {level:116, cx:-300, hx:600, hz:1900, blend:380};
const EDGE_FADE = 2500, EDGE_LEVEL = 35;   // خارج حدود الخريطة الأرض تنزل تدريجياً بدل جدار

export function parseGL(ab){
  const jl = new DataView(ab).getUint32(0,true), h = JSON.parse(new TextDecoder().decode(new Uint8Array(ab,4,jl))), b = 4+jl, n = h.N*h.N;
  const u16 = new Uint16Array(ab,b+h.oH,n), c8 = new Uint8Array(ab,b+h.oC,n*3), H = new Float32Array(n), C = new Float32Array(n*3), k = (h.hmax-h.hmin)/65535;
  for(let i=0;i<n;i++) H[i] = h.hmin + u16[i]*k;
  for(let i=0;i<n*3;i++) C[i] = LIN[c8[i]];            // ألوان المصدر sRGB ← خطية
  Object.assign(GL,{ok:true,N:h.N,half:h.half,step:h.step,H,C,hdr:h,buf:ab,base:b,nB:h.nB,boxes:new Float32Array(ab,b+h.oB,h.nB*6)});
  return GL;
}

const cr = (p0,p1,p2,p3,t) => p1 + .5*t*(p2-p0 + t*(2*p0-5*p1+4*p2-p3 + t*(3*(p1-p2)+p3-p0)));
function baseH(x,z){
  const N = GL.N, H = GL.H, inv = 1/GL.step, u = clamp((x+GL.half)*inv,0,N-1.0001), v = clamp((z+GL.half)*inv,0,N-1.0001);
  const i = u|0, j = v|0, fu = u-i, fv = v-j, c = a => a < 0 ? 0 : a > N-1 ? N-1 : a, i0 = c(i-1), i1 = i, i2 = c(i+1), i3 = c(i+2);
  const row = k => { const b = c(j+k)*N; return cr(H[b+i0],H[b+i1],H[b+i2],H[b+i3],fu); };
  const r = cr(row(-1),row(0),row(1),row(2),fv);
  const d = Math.max(Math.abs(x)-GL.half,Math.abs(z)-GL.half,0);
  if(d <= 0) return r;
  const f = sm(clamp(d/EDGE_FADE,0,1)); return r*(1-f) + EDGE_LEVEL*f;
}
// دالة الارتفاع النهائية: heightmap (bicubic) + تفاصيل ناعمة + منصة القاعدة المستوية
export function makeH(n){
  return (x,z) => {
    if(!GL.ok) return 0;
    const b = baseH(x,z);
    const dx = Math.max(Math.abs(x-PL.cx)-PL.hx,0), dz = Math.max(Math.abs(z)-PL.hz,0), w = 1-sm(clamp(Math.hypot(dx,dz)/PL.blend,0,1));
    const amp = (.8 + clamp(b/500,0,1)*1.6)*(1-w);
    const d = amp > .01 ? (n(x*.011,z*.011)*3.2 + n(x*.037+5,z*.037-3)*1.1)*amp : 0;
    return b + (PL.level-b)*w + d;
  };
}
// لون التضاريس من لون الرؤوس الأصلي (bilinear) — يكتب في out.r/g/b (خطي)
export function colorAt(x,z,out){
  const N = GL.N, C = GL.C, inv = 1/GL.step, u = clamp((x+GL.half)*inv,0,N-1.0001), v = clamp((z+GL.half)*inv,0,N-1.0001);
  const i = u|0, j = v|0, fu = u-i, fv = v-j, a = (j*N+i)*3, b = a+3, c = a+N*3, d = c+3;
  out.r = (C[a]*(1-fu)+C[b]*fu)*(1-fv) + (C[c]*(1-fu)+C[d]*fu)*fv;
  out.g = (C[a+1]*(1-fu)+C[b+1]*fu)*(1-fv) + (C[c+1]*(1-fu)+C[d+1]*fu)*fv;
  out.b = (C[a+2]*(1-fu)+C[b+2]*fu)*(1-fv) + (C[c+2]*(1-fu)+C[d+2]*fu)*fv;
  return out;
}
// ممنوع زرع أشجار: على القاعدة وحول المستوطنات
export function noTree(x,z){
  if(!GL.ok) return false;
  const dx = Math.max(Math.abs(x-PL.cx)-PL.hx,0), dz = Math.max(Math.abs(z)-PL.hz,0);
  if(dx*dx+dz*dz < 14400) return true;
  for(const c of GL.hdr.clear){ const ax = x-c[0], az = z-c[1]; if(ax*ax+az*az < c[2]*c[2]) return true; }
  return false;
}
// تصادم الطائرة مع المباني (صناديق AABB)
export function hit(x,y,z){
  if(!GL.ok) return false;
  const B = GL.boxes, m = 3;
  for(let i=0,n=GL.nB*6;i<n;i+=6){
    if(x > B[i]-m && x < B[i+3]+m && z > B[i+2]-m && z < B[i+5]+m && y < B[i+4]+m && y > B[i+1]-60) return true;
  }
  return false;
}
