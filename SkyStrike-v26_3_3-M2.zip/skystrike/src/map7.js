import * as THREE from 'three';
import {M7,parseM7,lin8} from './map7_height.js';
export {M7,makeH,colorAt,noTree,hit} from './map7_height.js';

const BIN = new URL('./models/map7.bin',import.meta.url).href;
// تحميل الحزمة (~80KB). إذا فشل، تختفي الخريطة من القائمة واللعبة تكمل عادي
export async function loadMap7(){
  try { const r = await fetch(BIN); if(!r.ok) throw new Error(r.status); parseM7(await r.arrayBuffer()); return true; }
  catch(e){ console.warn('map7.bin failed',e); return false; }
}
// القواعد الجوية والسفن والمباني والتوربينات والجسر: مجسمات مدموجة بلون الرؤوس، مقسّمة لبلاطات — بدون textures
export function buildProps(){
  const g = new THREE.Group(); if(!M7.ok) return g;
  const mat = new THREE.MeshLambertMaterial({vertexColors:true,flatShading:true});
  for(const t of M7.hdr.tiles){
    const o = M7.base+t.o, pos = new Float32Array(M7.buf,o,t.v*3), c8 = new Uint8Array(M7.buf,o+t.v*12,t.v*3);
    const idx = new Uint16Array(M7.buf,o+t.v*12+((t.v*3+3)&~3),t.i), col = new Float32Array(t.v*3);
    for(let i=0;i<col.length;i++) col[i] = lin8[c8[i]];
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.BufferAttribute(pos,3)); geo.setAttribute('color',new THREE.BufferAttribute(col,3));
    geo.setIndex(new THREE.BufferAttribute(idx,1)); geo.computeBoundingSphere();
    g.add(new THREE.Mesh(geo,mat));
  }
  g.userData.mat = mat; return g;
}
