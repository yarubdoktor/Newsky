/* الجولة التعليمية للاعب الجديد (أول مهمة): 5 خطوات. النصوص tut1..tut5 بـ i18n.js. */
import {$} from './util.js';
import {S,save} from './save.js';
import {t} from './i18n.js';
import {sfx} from './audio.js';
import {W,P} from './state.js';
import {inp} from './input.js';
import {banner} from './ui.js';

const TSTEPS = [
  {k:'tut1',hl:'#joy',need:1.5,tick:() => Math.hypot(inp.x,inp.y) > .4},
  {k:'tut2',hl:'#bf',need:.8,tick:() => inp.fire},
  {k:'tut3',hl:'#bm',need:0,tick:() => P.msl < W.tut.m0},
  {k:'tut4',hl:'#bb',need:1.2,tick:() => inp.boost && P.en < .98},
  {k:'tut5',hl:'#bl',need:0,tick:() => P.flr < W.tut.f0}
];
const clearHl = () => { for(const b of document.querySelectorAll('.hl')) b.classList.remove('hl'); };
export function tutBegin(){ if(S.tut){ W.tut = null; return; } W.tut = {i:-1,a:0,t:0,m0:0,f0:0}; $('#tutx').textContent = t('tutSkip'); tutNext(); }
function tutNext(){
  const tut = W.tut; if(!tut) return; tut.i++; tut.a = 0; tut.t = 0; tut.m0 = P.msl; tut.f0 = P.flr; clearHl();
  if(tut.i >= TSTEPS.length){ S.tut = 1; save(); banner(t('tutDone')); sfx('win'); tutEnd(); return; }
  const s = TSTEPS[tut.i]; $('#tut').style.display = 'block'; $('#tutn').textContent = (tut.i+1)+' / '+TSTEPS.length; $('#tutt').textContent = t(s.k);
  const b = $(s.hl); if(b) b.classList.add('hl'); if(tut.i) sfx('lock');
}
export function tutEnd(){ W.tut = null; $('#tut').style.display = 'none'; clearHl(); }
export function tutUpdate(dt){
  const tut = W.tut, s = TSTEPS[tut.i]; tut.t += dt; if(s.tick()) tut.a += dt;
  if((tut.a > 0 && tut.a >= s.need) || tut.t > 30) tutNext();
}
$('#tutx').addEventListener('click',() => { if(W.tut){ S.tut = 1; save(); tutEnd(); } });
