/* نماذج الأعداء (GLB) — v26.2
   مُحضَّرة بـ tools/prep_enemy.py. بكل نموذج عقد بأسماء ثابتة تقرأها اللعبة:
     body   = الجسم الثابت (مدموج بحسب المادة)
     aim    = برج الأرضيات: ai.js يدوّره بـ lookAt (فوهة المدفع على +Z)
     rotor  = مروحة الهيلوكبتر الرئيسية (تدور حول Y)   rotor2 = مروحة الذيل (تدور حول X)
   أي نموذج يفشل تحميله يرجع صاحبه للمجسم البرمجي القديم تلقائياً (hasEM = false).
   مهم: كل رابط new URL هنا نص ثابت (literal) ليلتقطه Vite وينسخ الملف للبناء؛ ما تجمعه بـ '+'. */
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const URLS = {
  drone:  new URL('./models/e_drone.glb',import.meta.url).href,
  heli:   new URL('./models/e_heli.glb',import.meta.url).href,
  aa_twin:new URL('./models/e_aa_twin.glb',import.meta.url).href,
  aa_tank:new URL('./models/e_aa_tank.glb',import.meta.url).href,
  gepard: new URL('./models/e_gepard.glb',import.meta.url).href,
  flak:   new URL('./models/e_flak.glb',import.meta.url).href,
  sam:    new URL('./models/e_sam.glb',import.meta.url).href,
  tank:   new URL('./models/e_tank.glb',import.meta.url).href,      // v26.3.2: مركبات الأرتال (tools/make_vehicles.py)
  apc:    new URL('./models/e_apc.glb',import.meta.url).href,
  truck:  new URL('./models/e_truck.glb',import.meta.url).href
};
const T = {};                       // القوالب المحمّلة
const TV = {};                      // قوالب مصبوغة (مواد مخزّنة لكل لون => مشتركة بين الأعداء)

const load = k => new Promise(res => {
  try {
    new GLTFLoader().load(URLS[k], gltf => {
      gltf.scene.traverse(o => { if(o.isMesh && o.material) o.material.envMapIntensity = 1.3; });
      T[k] = gltf.scene; res(true);
    }, undefined, err => { console.warn('enemy model '+k+' failed, using built-in model',err); res(false); });
  } catch(err){ console.warn(err); res(false); }
});
export const loadEnemyModels = () => Promise.all(Object.keys(URLS).map(load));
export const hasEM = k => !!T[k];

// نسخة جديدة من النموذج (الشبكات والمواد مشتركة => خفيف). tint = لون اختياري يمزج مع ألوان النموذج
export function mkEM(k,tint,mix=.55){
  if(tint === undefined) return T[k].clone(true);
  const key = k+'_'+tint;
  if(!TV[key]){
    const r = T[k].clone(true), tc = new THREE.Color(tint), cm = {};
    r.traverse(o => { if(o.isMesh){ const u = o.material.uuid; if(!cm[u]){ const m = o.material.clone(); m.color.lerp(tc,mix); cm[u] = m; } o.material = cm[u]; } });
    TV[key] = r;
  }
  return TV[key].clone(true);
}
