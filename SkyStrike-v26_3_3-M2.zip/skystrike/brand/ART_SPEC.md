# Sky Strike — مواصفات صور الواجهة (13 صورة مطلوبة)

الصور **اختيارية**: ضع الملف بالمجلد وبالاسم الصحيح وتظهر تلقائياً بعد `npm run build`. أي صورة ناقصة تبقى مكانها بالتصميم القديم، فتقدر تضيفهم تدريجياً.
فحص جاهز: `python3 tools/check_art.py` (يقول لك الناقص، وأي صورة نسبتها/حجمها غلط).

## قواعد عامة (لكل الصور)
- **الصيغة:** WebP (جودة 80–85). يقبل PNG/JPG أيضاً لكن WebP أخف على الجوال. الحجم المستهدف **أقل من 300KB** للصورة.
- **بدون أي نص أو شعار أو علامة مائية داخل الصورة** (النصوص تُرسم من اللعبة وتتغيّر مع اللغة).
- **الأسلوب** (من `BRAND.md`): غروب دافئ، سماء زرقاء ليلية تلتقي بأفق برتقالي، تباين عالٍ، إضاءة حافة (rim light) برتقالية على الجسم. نفس أجواء خلفية اللوبي.
- **المنطقة الآمنة:** اللعبة تعرض الصورة بـ `cover` (تقص الأطراف حسب حجم البطاقة). فضع الموضوع الرئيسي **بمنتصف الصورة** داخل المنطقة الآمنة المذكورة، وخلّي الأطراف خلفية فقط.
- الخلفية لازم تكون **معتمة وداكنة** (مو شفافة): البطاقات تعرضها مباشرة.
- **حقوق:** لا تستعمل صور من الإنترنت بدون ترخيص (خصوصاً لو بدك تنشر على Google Play). ولّدها بأداة ذكاء اصطناعي تسمح بالاستعمال التجاري، أو ارسمها/اشترِ ترخيصها.

## 1) الطائرات — `src/assets/planes/`  ·  1200×900 (4:3)
تظهر بـ 3 أماكن: **بطاقة الهنجر** (مقص قليلاً من الجانبين)، **المصغّرات بلوحة اللوبي** (مقص من فوق وتحت)، **بطاقة المهام اليومية**. لذلك: الطائرة بمنتصف الصورة وتشغل **حوالي 70% من العرض و45% من الارتفاع فقط**.

| الملف | المحتوى |
|---|---|
| `f35.webp` | F-35 Lightning II (رمادي شبحي) |
| `mig29.webp` | MiG-29 Fulcrum (ذيلان، تمويه رمادي-أخضر) |
| `su57.webp` | Su-57 Felon (رمادي داكن، محركان) |

- **اختياري — صورة لكل لون:** `f35_crimson.webp` … الصيغة `<الطائرة>_<اللون>`. الألوان: `desert` `forest` `arctic` `night` `crimson` `gold`. لو ما وجدت صورة اللون المختار، تستعمل اللعبة معاينة المحرك الملوّنة (فيبان اللون الصحيح). صورة الافتراضي `f35.webp` تُستعمل فقط لما يكون اللون افتراضياً.

## 2) الأسلحة — `src/assets/weapons/`  ·  800×640 (5:4)
تظهر على يمين/يسار بطاقة السلاح (حوالي 20×16 وحدة)، والمقص بسيط. السلاح بالمنتصف ويشغل ~65% من العرض.

| الملف | السلاح |
|---|---|
| `gun.webp` | رشاش 20mm (مدفع دوّار، لقطة قريبة مع رصاص/وميض) |
| `msl.webp` | صاروخ موجّه (جو-جو، مع لهب العادم) |
| `multi.webp` | صواريخ متعددة (3 صواريخ تنطلق بدفعة واحدة) |
| `bomb.webp` | قنابل أرضية (قنبلة تسقط/مجموعة قنابل) |

## 3) مهام الحملة — `src/assets/campaign/`  ·  1000×1000 (1:1)
تظهر كمربّع/مستطيل عمودي قليلاً بجانب نص المهمة (حوالي 20 وحدة عرض × 17–25 ارتفاع). الموضوع بالمنتصف داخل **70% من العرض والارتفاع**.

| الملف | المهمة | المشهد |
|---|---|---|
| `c1.webp` | 1. أول طلعة | جزر استوائية، مقاتلات العدو فوق البحر وقت الغروب |
| `c2.webp` | 2. ضربة الفجر | صحراء، مستودع وقود ودفاعات أرضية عند الفجر |
| `c3.webp` | 3. حارس الليل | قاعدة/مدينة ليلاً، كشّافات، قاذفات تقترب |
| `c4.webp` | 4. عاصفة القطب | قطب متجمد، عاصفة ثلج، ظل مقاتلة حمراء (الزعيم «الصقر الأحمر») |
| `c5.webp` | 5. وادي النار | وادٍ أحمر ناري، دفاعات مضادة للطيران ومقاتلات نخبة |
| `c6.webp` | 6. عملية غريلاند | جبال جليدية، قلعة طائرة ضخمة + الصقر الأحمر (أقوى مهمة، أكثر درامية) |

## أمثلة أوامر توليد (بالإنجليزي أفضل لمعظم الأدوات)
أضف لكل واحد بالنهاية: `no text, no logo, no watermark, dark background, high contrast, centered subject, game UI card art, 4:3` (غيّر النسبة حسب القسم).
- **f35:** `cinematic three-quarter front view of an F-35 stealth fighter banking in flight, warm orange sunset rim light, deep navy sky fading to orange horizon, afterburner glow`
- **mig29:** `MiG-29 Fulcrum fighter jet twin tails, grey-green camouflage, banking, dramatic sunset rim light, navy to orange sky`
- **su57:** `Su-57 stealth fighter dark grey, twin engines, banking in flight, orange sunset rim light, navy sky`
- **gun:** `close-up of a 20mm rotary cannon firing with muzzle flash and tracer rounds, dark background, orange sparks, cinematic`
- **msl:** `air-to-air guided missile just launched, bright orange exhaust trail and white smoke, dark navy background`
- **multi:** `three air-to-air missiles launching simultaneously in a fan pattern with orange exhaust trails, dark background`
- **bomb:** `aerial bomb falling through the air, sunset rim light, smoke and sparks, dark navy background`
- **c1…c6:** `<المشهد من الجدول> , cinematic game mission art, warm sunset lighting, high contrast, aerial combat, square composition`

## التجهيز السريع (تحويل لـ WebP بالمقاس الصحيح)
```
pip install pillow
python3 - <<'PY'
from PIL import Image
im = Image.open('f35_original.png').convert('RGB')
im.thumbnail((1200,900)); im.save('src/assets/planes/f35.webp','WEBP',quality=82,method=6)
PY
python3 tools/check_art.py
```
