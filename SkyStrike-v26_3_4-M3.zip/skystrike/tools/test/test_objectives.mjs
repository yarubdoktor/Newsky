/* بند M3: أنواع الأهداف (destroy/suppress/escort/intercept/defend/rtb + after + optional) · المحفّزات · اللاسلكي ·
   البوصلة وسطور المتتبّع · الفاحص · مهمات m1/m2 بالحلّال. كلها دوال صرفة تعمل بـ node بلا متصفح. */
import {makeObjective,feed,tickObjective,progressOf,pointsOf,trackedIds,objectiveTypes,AFTER_TYPES} from '../../src/mission/objectives.js';
import {createRuntime,pushEvent,stepRuntime} from '../../src/mission/mission_runtime.js';
import {resolveRuntime} from '../../src/mission/mission_resolve.js';
import {createComms,queueComm,stepComms,COMM_GAP} from '../../src/mission/comms.js';
import {stepTriggers,createTriggers} from '../../src/mission/triggers.js';
import {validateMission,MISSIONS,missionById} from '../../src/mission/mission_defs.js';
import {KINDS,anchorOf} from '../../src/mission/entity_pos.js';
import {objectiveLines,compassLine,arrowOf,fmtTime,fmtDist,nearestPoint} from '../../src/mission/mission_hud.js';
import {MISSION_TEXT} from '../../src/mission/mission_text.js';
import {solveMission} from './solver.mjs';
let fail = 0; const ok = (c,m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const mk = o => ({id:'x', title:'x', entities:[], objectives:[], fail:[{type:'playerDead'}], triggers:[], comms:[], ...o});
const dead = id => ({type:'entityDead', id}), arr = id => ({type:'entityArrived', id});
const TYPES = objectiveTypes();

console.log('سجل الأنواع:');
ok(['destroy','suppress','escort','intercept','defend','rtb'].every(k => TYPES.includes(k)),'الأنواع الستة مسجّلة');

console.log('قمع (suppress):');
let o = makeObjective({id:'s', type:'suppress', text:'t', targets:['a','b','c'], need:2});
ok(feed(o,dead('a')) === null && progressOf(o).done === 1 && progressOf(o).total === 2,'1 من 2 المطلوبة');
ok(feed(o,dead('c')) === 'done' && o.status === 'done','يكفي need من الأهداف ← done');
o = makeObjective({id:'s', type:'suppress', text:'t', targets:['a','b']});
ok(o.need === 2,'بلا need = كل الأهداف');

console.log('إسناد (escort):');
const esc = () => makeObjective({id:'e', type:'escort', text:'t', units:['u1','u2','u3','u4'], need:3});
o = esc();
ok(feed(o,arr('zzz')) === null && feed(o,arr('u1')) === null && feed(o,arr('u1')) === null && progressOf(o).done === 1,'وصول وحدة مرة واحدة فقط');
ok(feed(o,dead('u4')) === null && o.status === 'active','خسارة واحدة والباقي كافٍ');
ok(feed(o,arr('u2')) === null && feed(o,arr('u3')) === 'done','وصول 3 ← done');
o = esc(); feed(o,dead('u1'));
ok(feed(o,dead('u2')) === 'failed' && o.status === 'failed','خسارة 2 من 4 وneed=3 ← failed (لا يمكن الإتمام)');
o = esc(); feed(o,arr('u1')); feed(o,arr('u2')); feed(o,dead('u1'));
ok(o.status === 'active' && progressOf(o).done === 2,'وحدة وصلت ثم دُمّرت تبقى محسوبة وصولاً');
feed(o,dead('u3')); ok(o.status === 'active','u4 ما زالت قادرة على الوصول');
ok(feed(o,dead('u4')) === 'failed','لو ماتت u4 أيضاً (2 وصلتا، need=3) ← failed');

console.log('اعتراض (intercept):');
o = makeObjective({id:'i', type:'intercept', text:'t', targets:['b1','b2'], limit:100});
ok(tickObjective(o,60) === null && progressOf(o).left === 40,'العدّاد التنازلي يعمل (40 ث متبقية)');
feed(o,dead('b1')); ok(feed(o,dead('b2')) === 'done','إسقاط المجموعة قبل الحد ← done');
o = makeObjective({id:'i', type:'intercept', text:'t', targets:['b1'], limit:100});
ok(tickObjective(o,100) === 'failed','انتهاء الحد ← failed');
o = makeObjective({id:'i', type:'intercept', text:'t', targets:['b1','b2']});
ok(feed(o,arr('b2')) === 'failed','وصول عدو لوجهته ← failed');
o = makeObjective({id:'i', type:'intercept', text:'t', targets:['b1']});
ok(tickObjective(o,9999) === null,'بلا limit لا يفشل بالزمن');

console.log('حماية (defend):');
o = makeObjective({id:'d', type:'defend', text:'t', sites:['base'], t:120});
ok(tickObjective(o,100) === null && Math.round(progressOf(o).left) === 20,'20 ث متبقية');
ok(tickObjective(o,25) === 'done','انتهاء المدة والموقع حي ← done');
o = makeObjective({id:'d', type:'defend', text:'t', sites:['base'], t:120}); tickObjective(o,30);
ok(feed(o,dead('base')) === 'failed','موت الموقع ← failed');
o = makeObjective({id:'d', type:'defend', text:'t', sites:['a','b'], t:60, need:1});
ok(feed(o,dead('a')) === null && feed(o,dead('b')) === 'failed','need=1 من موقعين');

console.log('عودة (rtb):');
o = makeObjective({id:'r', type:'rtb', text:'t', pos:{x:0,z:0}, r:500, alt:200}); o.x = 1000; o.z = 0;
ok(tickObjective(o,1,{px:0,pz:0,agl:50}) === null,'خارج الدائرة: لا');
ok(tickObjective(o,1,{px:700,pz:0,agl:500}) === null,'داخل الدائرة لكن مرتفع: لا');
ok(tickObjective(o,1,null) === null,'بلا لقطة عالم: لا يفشل ولا ينجح');
ok(tickObjective(o,1,{px:700,pz:0,agl:100}) === 'done','داخل الدائرة ومنخفض ← done');
o = makeObjective({id:'r', type:'rtb', text:'t', pos:{x:0,z:0}}); ok(pointsOf(o,{}).length === 0,'نقطة غير محلولة: لا علامات');

console.log('after (فتح لاحق):');
let rt = createRuntime(mk({entities:[], objectives:[
  {id:'o1', type:'destroy', text:'t', targets:['a']},
  {id:'o2', type:'rtb', text:'t', pos:{x:500,z:0}, r:100, alt:300, after:['o1']}]}));
resolveRuntime(rt,{x:0,z:0,yaw:0},{});
ok(rt.objectives[1].status === 'locked' && rt.objectives[1].x === 500,'rtb مقفل وموضعه محلول');
let out = stepRuntime(rt,1,{px:500,pz:0,agl:10,units:{}});
ok(rt.objectives[1].status === 'locked','لا يكتمل وهو مقفل ولو كان اللاعب فوقه');
pushEvent(rt,dead('a')); out = stepRuntime(rt,1,{px:500,pz:0,agl:10,units:{}});
ok(out.some(x => x.id === 'o2' && x.status === 'active') && rt.status === 'running','نجاح o1 يفتح o2 (والمهمة لم تنتهِ)');
out = stepRuntime(rt,1,{px:500,pz:0,agl:10,units:{}}); ok(rt.status === 'won' && out.some(x => x.type === 'end'),'o2 يكتمل ← نجاح المهمة');
ok(AFTER_TYPES.includes('rtb') && !AFTER_TYPES.includes('destroy'),'after مسموح فقط للأنواع غير المعتمدة على تاريخ الأحداث');

console.log('هدف رئيسي فاشل ← فشل المهمة / ثانوي لا:');
rt = createRuntime(mk({objectives:[{id:'e', type:'escort', text:'t', units:['u1'], need:1}]}));
pushEvent(rt,dead('u1')); stepRuntime(rt,1); ok(rt.status === 'lost' && rt.reason === 'objective','فشل الإسناد ← lost (objective)');
rt = createRuntime(mk({objectives:[{id:'a', type:'destroy', text:'t', targets:['a']},
  {id:'e', type:'escort', text:'t', units:['u1'], need:1, optional:true}]}));
pushEvent(rt,dead('u1')); pushEvent(rt,dead('a')); stepRuntime(rt,1);
ok(rt.status === 'won','فشل هدف ثانوي لا يُفشل المهمة');

console.log('المحفّزات:');
const base = (when, d = [{comm:'c'}]) => mk({objectives:[{id:'o', type:'destroy', text:'t', targets:['zz']}],
  triggers:[{id:'t', when, do:d}], comms:[{id:'c', from:'cmd', text:'x'}]});
rt = createRuntime(base({t:5})); resolveRuntime(rt,{x:0,z:0,yaw:0},{});
ok(!stepRuntime(rt,4).some(x => x.type === 'trigger'),'محفّز زمني: لم يحن');
out = stepRuntime(rt,1.5); ok(out.some(x => x.type === 'trigger' && x.id === 't') && out.some(x => x.type === 'comm'),'محفّز زمني: يطلق + رسالة');
ok(!stepRuntime(rt,10).some(x => x.type === 'trigger'),'يُطلق مرة واحدة فقط');
rt = createRuntime(base({dead:'k'}, [{spawn:[{id:'n', kind:'jet', side:'enemy', pos:{d:100}}]}]));
pushEvent(rt,dead('k')); out = stepRuntime(rt,.1);
ok(out.some(x => x.type === 'spawn' && x.list[0].id === 'n'),'محفّز موت كيان ← تعزيزات');
rt = createRuntime(base({arrived:'v'})); pushEvent(rt,arr('v')); ok(stepRuntime(rt,.1).some(x => x.type === 'trigger'),'محفّز وصول مركبة');
rt = createRuntime(mk({objectives:[{id:'o1', type:'destroy', text:'t', targets:['a']},{id:'o2', type:'destroy', text:'t', targets:['b']}],
  triggers:[{id:'t', when:{done:'o1'}, do:[{comm:'c'}]}], comms:[{id:'c', from:'cmd', text:'x'}]}));
pushEvent(rt,dead('a')); ok(stepRuntime(rt,.1).some(x => x.type === 'trigger'),'محفّز نجاح هدف');
rt = createRuntime(base({zone:{pos:{x:1000,z:0}, r:300}})); resolveRuntime(rt,{x:0,z:0,yaw:0},{});
ok(!stepRuntime(rt,1,{px:0,pz:0,agl:1,units:{}}).some(x => x.type === 'trigger'),'محفّز منطقة: اللاعب بعيد');
ok(stepRuntime(rt,1,{px:800,pz:0,agl:1,units:{}}).some(x => x.type === 'trigger'),'محفّز منطقة: دخل 200م من المركز');
rt = createRuntime(base({zone:{pos:{x:1000,z:0}, r:300}}));
ok(!stepRuntime(rt,1,{px:1000,pz:0,agl:1,units:{}}).some(x => x.type === 'trigger'),'منطقة غير محلولة لا تُطلق خطأً');
rt = createRuntime(base({dead:'k'})); out = stepRuntime(rt,1); pushEvent(rt,dead('k'));
ok(stepRuntime(rt,.1).some(x => x.type === 'trigger'),'حدث يصل بعد فريمات يُطلق');
ok(createTriggers([{id:'a',when:{t:1},do:[]}])[0].fired === false && typeof stepTriggers === 'function','تهيئة المحفّزات');

console.log('اللاسلكي:');
let cs = createComms([{id:'a', from:'cmd', text:'x', at:1}, {id:'b', from:'gnd', text:'y', at:1.2}, {id:'m', from:'ally', text:'z'}]);
ok(stepComms(cs,.5,.5) === null,'قبل الوقت: لا شيء');
let m1 = stepComms(cs,1,.5); ok(m1 && m1.id === 'a' && m1.from === 'cmd','أول رسالة بوقتها');
ok(stepComms(cs,1.5,.5) === null,'الثانية تنتظر فاصل التبريد');
let got = null, tt = 1.5; while(!got && tt < 20){ tt += .1; got = stepComms(cs,tt,.1); }
ok(got && got.id === 'b' && tt-1 >= COMM_GAP-.2,'الثانية بعد ≥ '+COMM_GAP+' ث من الأولى');
queueComm(cs,'m'); queueComm(cs,'m'); queueComm(cs,'nope'); ok(cs.q.length === 1,'لا تكرار ولا رسالة مجهولة');
ok(createComms([{id:'q', from:'cmd', text:'x'}]).timed.length === 0,'رسالة بلا at لا تُجدول');

console.log('المتتبّع والبوصلة:');
const tr = k => MISSION_TEXT[k] ? MISSION_TEXT[k][0] : k;
rt = createRuntime(mk({objectives:[
  {id:'d', type:'defend', text:'m2o1', sites:['base'], t:150},
  {id:'e', type:'escort', text:'m1o3', units:['u1','u2','u3'], need:2},
  {id:'r', type:'rtb', text:'m1o4', pos:{x:0,z:0}, after:['e']}]}));
let ln = objectiveLines(rt,tr);
ok(ln[0].endsWith('2:30') && ln[1].endsWith('0/2') && ln[2].startsWith('◇'),'عدّاد زمن الحماية 2:30 · إسناد 0/2 · المقفل ◇');
pushEvent(rt,dead('u1')); stepRuntime(rt,1); ln = objectiveLines(rt,tr);
ok(ln[1].includes(MISSION_TEXT.ms_lost[0]+' 1'),'الإسناد يعرض الخسائر');
ok(arrowOf(0) === '↑' && arrowOf(Math.PI/2) === '→' && arrowOf(Math.PI) === '↓' && arrowOf(-Math.PI/2) === '←' && arrowOf(-.1) === '↑','أسهم البوصلة');
ok(fmtTime(150) === '2:30' && fmtTime(59.2) === '1:00' && fmtDist(420) === '420 m' && fmtDist(1530) === '1.5 km','تنسيق الزمن والمسافة');
rt = createRuntime(mk({objectives:[{id:'o', type:'destroy', text:'t', targets:['a','b']}]}));
const snap = {px:0,pz:0,py:0,agl:0,units:{a:{x:0,z:-1000}, b:{x:300,z:-200}}};
ok(Math.round(nearestPoint(rt,snap).dist) === 361,'أقرب هدف حيّ (b)');
ok(compassLine(rt,snap,0).startsWith('↗') && compassLine(rt,snap,Math.PI).startsWith('↙'),'اتجاه السهم يتبع اتجاه الطائرة (yaw=0 → ↗، yaw=π → ↙)');
ok(compassLine(rt,null,0) === '' && compassLine(createRuntime(mk({objectives:[{id:'o',type:'destroy',text:'t',targets:['q']}]})),snap,0) === '','بلا هدف مرئي: لا سطر');
ok(trackedIds(rt.objectives).join() === 'a,b','معرّفات التعليم (e.obj) للأهداف النشطة');

console.log('الفاحص + المهمات:');
const V = m => validateMission(m,KINDS,TYPES);
const ent = {id:'a', kind:'tank', side:'enemy', pos:{d:100}};
const O = x => mk({entities:[ent], objectives:[{id:'o', text:'t', ...x}]});
ok(V(O({type:'destroy', targets:['a']})).length === 0,'مهمة بسيطة سليمة');
ok(V(O({type:'escort', units:['a'], need:2})).some(e => e.includes('need')),'يرفض need أكبر من العدد');
ok(V(O({type:'defend', sites:['a'], t:0})).length > 0,'يرفض defend بلا مدة');
ok(V(O({type:'rtb'})).length > 0 && V(O({type:'rtb', pos:{d:0}})).length === 0,'rtb يتطلب pos');
ok(V(O({type:'destroy', targets:['a'], after:['o']})).length > 0,'after غير مسموح لـ destroy');
ok(V(O({type:'rtb', pos:{d:0}, after:['nope']})).length > 0,'after لهدف مجهول');
ok(V(mk({entities:[ent], objectives:[{id:'o', type:'destroy', text:'t', targets:['a']}],
  triggers:[{id:'t', when:{t:1}, do:[{comm:'zz'}]}]})).length > 0,'محفّز برسالة غير معرّفة');
ok(V(mk({entities:[ent], objectives:[{id:'o', type:'destroy', text:'t', targets:['n']}],
  triggers:[{id:'t', when:{t:1}, do:[{spawn:[{id:'n', kind:'jet', side:'enemy', pos:{d:5}}]}]}]})).length === 0,'هدف يشير لكيان تعزيز (محفّز) مقبول');
ok(V(mk({entities:[ent], objectives:[{id:'o', type:'destroy', text:'t', targets:['a']}],
  triggers:[{id:'t', when:{}, do:[{comm:'c'}]}]})).length > 0,'محفّز بلا شرط');
ok(V(mk({entities:[ent], objectives:[{id:'o', type:'destroy', text:'t', targets:['a']}],
  comms:[{id:'c', from:'zzz', text:'x'}]})).length > 0,'رسالة بمرسِل مجهول');
for(const id of ['m1','m2']){
  const m = missionById(id), types = new Set(m.objectives.map(x => x.type));
  ok(m && V(m).length === 0,id+': تعريف سليم');
  const r = solveMission(m); ok(r.status === 'won',id+': الحلّال ينجح');
  ok(r.outs.some(x => x.type === 'comm') && r.outs.some(x => x.type === 'trigger'),id+': رسائل ومحفّزات تعمل بالتسلسل');
  console.log('    أنواع '+id+': '+[...types].join(' '));
}
const all = new Set(MISSIONS.flatMap(m => m.objectives.map(x => x.type)));
ok(TYPES.every(k => all.has(k)),'كل أنواع الأهداف مستعملة بمهمة حقيقية واحدة على الأقل');
// ضياع الهدف الرئيسي بمهمة حقيقية
let r1 = createRuntime(missionById('m1')); resolveRuntime(r1,{x:0,z:0,yaw:0},Object.fromEntries(['cv1','cv2','cv3','cv4','et1','et2','aa1','aa2','sam1'].map(i => [i,{x:0,z:0}])));
pushEvent(r1,dead('cv4')); stepRuntime(r1,1);
ok(r1.status === 'running','m1: خسارة وحدة من 4 (need=3): ما زال ممكناً');
pushEvent(r1,dead('cv3')); stepRuntime(r1,1); ok(r1.status === 'lost' && r1.reason === 'objective','m1: خسارة ثانية ← فشل المهمة (الرتل)');
ok(anchorOf({d:100,at:'start'},{x:0,z:0,yaw:0,start:{x:50,z:50,yaw:0}},{}).z === -50,'at:start يقيس من نقطة بداية المهمة');
console.log(fail ? '✗ فشل '+fail : '✓ نجح الكل'); process.exit(fail ? 1 : 0);
