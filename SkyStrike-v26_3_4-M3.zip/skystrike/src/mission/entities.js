/* إنشاء الكيانات الموضوعة مسبقاً بالمهمة (بدل الظهور العشوائي حول اللاعب). يستعمل addAir/addGround من spawn.js
   و addVehicle من vehicles.js، ويضيف: side (الجهة) · mid (معرّف المهمة) · obj (هدف رئيسي: علامة بالرادار/الشاشة).
   المركبات: route[] نقاط مسار (بنفس صيغ pos) ← تتحرك وتُرسل حدث entityArrived عند آخر نقطة.
   الرتل {kind:'convoy', units, gap, speed, pos, route} ينقسم لمركبات ids = id+1..
   تسير متتابعة (كل واحدة تتبع التي أمامها). */
import {addAir, addGround, landPos} from '../spawn.js';
import {addVehicle} from './vehicles.js';
import {world, V} from '../core.js';
import {VEH} from '../enemies.js';
import {anchorOf, GROUND_KINDS, VEHICLE_KINDS} from './entity_pos.js';
import {convoySlots, convoyYaw} from './convoy.js';

/* أقرب أرض صالحة حول المركز؛ يوسّع البحث تدريجياً، وآخر حل: أي نقطة (حتى لا تختفي مهمة بلا هدف) */
function findLand(a){
  for(const m of [1, 2, 4, 8]){ const c = landPos(a.x, a.z, a.rad*m, 120); if(c) return c; }
  return {x:a.x, z:a.z, h:world.ground(a.x, a.z)};
}
const routeOf = (d, spawn, placed) => (d.route || []).map(p => findLand(anchorOf(p, spawn, placed)));

function spawnConvoy(d, spawn, placed, w, out){
  const route = routeOf(d, spawn, placed), c0 = findLand(anchorOf(d.pos, spawn, placed));
  const toward = route[0] || {x:c0.x, z:c0.z-1}, yaw = convoyYaw(c0, toward);
  const slots = convoySlots(c0, toward, d.units.length, d.gap ?? 34);
  const speed = d.speed ?? Math.min(...d.units.map(k => VEH[k].sp));      // الرتل بسرعة أبطأ أعضائه
  let prev = null;
  d.units.forEach((kind, i) => {
    const sl = slots[i], id = d.id+(i+1);                  // الخانة بالضبط إن كانت صالحة (مسافات منتظمة)
    const s = i ? (landPos(sl.x, sl.z, .01, 1) || findLand({x:sl.x, z:sl.z, rad:25})) : c0;
    const e = addVehicle(kind, s.x, s.z, w, d.side, {yaw, route, speed, follow:prev});
    e.mid = id; e.obj = false; placed[id] = {x:s.x, z:s.z}; out.push(e); prev = e;
  });
  placed[d.id] = {x:c0.x, z:c0.z};
}

/* ينشئ قائمة كيانات (بداية المهمة أو تعزيزات محفّز). placed تتراكم لتعمل {near:id} مع ما سبق */
export function spawnList(list, w, spawn, placed = {}){
  const out = [];
  list.forEach((d, i) => {
    if(d.kind === 'convoy'){ spawnConvoy(d, spawn, placed, w, out); return; }
    const a = anchorOf(d.pos, spawn, placed); let e;
    if(GROUND_KINDS.includes(d.kind)){
      const c = findLand(a); placed[d.id] = c; e = addGround(d.kind, c.x, c.z, c.h, w, d.tt ?? i, d.side);
    } else if(VEHICLE_KINDS.includes(d.kind)){
      const c = findLand(a); placed[d.id] = c;
      e = addVehicle(d.kind, c.x, c.z, w, d.side, {yaw:d.yaw || 0, route:routeOf(d, spawn, placed), speed:d.speed});
    } else {
      placed[d.id] = {x:a.x, z:a.z};
      e = addAir(d.kind, V(a.x, Math.max(world.ground(a.x, a.z)+90, d.alt ?? 180), a.z), w, d.side);
    }
    e.mid = d.id; e.obj = e.fixObj = !!d.obj; out.push(e);
  });
  out.placed = placed; return out;
}
export const spawnEntities = (def, spawn) => spawnList(def.entities, def.difficulty, spawn);
