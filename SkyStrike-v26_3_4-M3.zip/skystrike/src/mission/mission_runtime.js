/* آلة حالات المهمة (دالة صرفة، بلا DOM/three/state): تستقبل أحداثاً + لقطة العالم وتنتج حالة الأهداف
   والمحفّزات والرسائل والنهاية.
   الاستعمال:  rt = createRuntime(def) ؛ pushEvent(rt,{type:'entityDead',id}) ؛ out = stepRuntime(rt, dt, snap?).
   الأحداث: entityDead{id,by} · entityArrived{id} · playerDead. snap (اختيارية) =
   {px,pz,py,agl,units:{id:{x,z,hp,max}}}.
   def.fail: {type:'playerDead'} | {type:'timeout',t}. فشل أي هدف رئيسي ← فشل المهمة (reason:'objective').
   المخرجات (out): {type:'objective',id,status} · {type:'trigger',id} · {type:'spawn',list} · {type:'comm',…}
                   · {type:'end',result:'won'|'lost',reason}. تحل مكان waves.js. أنواع الأهداف: obj_types.js · محفّزات:
                   triggers.js
   · رسائل: comms.js. الفوز يتطلب كل الأهداف الرئيسية done؛ والفشل يغلّب النجاح بنفس اللحظة. */
import {makeObjective, feed, tickObjective} from './objectives.js';
import {createTriggers, stepTriggers} from './triggers.js';
import {createComms, queueComm, stepComms} from './comms.js';

export function createRuntime(def){
  return {def, id:def.id, t:0, status:'running', reason:null, q:[], objectives:def.objectives.map(makeObjective),
    trigs:createTriggers(def.triggers), comms:createComms(def.comms),
    seen:{dead:new Set(), arrived:new Set(), done:new Set()}};
}
export const pushEvent = (rt, ev) => { if(rt.status === 'running') rt.q.push(ev); };

function failRule(rt, evs){
  for(const f of rt.def.fail || []){
    if(f.type === 'playerDead' && evs.some(e => e.type === 'playerDead')) return 'playerDead';
    if(f.type === 'timeout' && rt.t >= f.t) return 'timeout';
  }
  return null;
}
/* أهداف after تُفتح حين تنجح متطلباتها */
function unlock(rt, out){
  for(const o of rt.objectives){
    if(o.status !== 'locked') continue;
    if(o.after.every(id => rt.seen.done.has(id))){
      o.status = 'active';
      out.push({type:'objective', id:o.id, status:'active'});
    }
  }
}
function objDone(rt, o, r, out){
  out.push({type:'objective', id:o.id, status:r});
  if(r === 'done') rt.seen.done.add(o.id);
}

export function stepRuntime(rt, dt, snap){
  const out = []; if(rt.status !== 'running') return out;
  rt.t += dt; const evs = rt.q.splice(0, rt.q.length);
  for(const ev of evs){
    if(ev.type === 'entityDead') rt.seen.dead.add(ev.id);
    else if(ev.type === 'entityArrived') rt.seen.arrived.add(ev.id);
    for(const o of rt.objectives){ const r = feed(o, ev); if(r) objDone(rt, o, r, out); }
  }
  for(const o of rt.objectives){ const r = tickObjective(o, dt, snap); if(r) objDone(rt, o, r, out); }
  unlock(rt, out);
  for(const a of stepTriggers(rt.trigs, rt, snap)){ if(a.type === 'comm') queueComm(rt.comms, a.id); else out.push(a); }
  const c = stepComms(rt.comms, rt.t, dt); if(c) out.push(c);
  const objFailed = rt.objectives.some(o => !o.optional && o.status === 'failed');
  const reason = failRule(rt, evs) || (objFailed ? 'objective' : null);
  if(reason){ rt.status = 'lost'; rt.reason = reason; out.push({type:'end', result:'lost', reason}); return out; }
  const req = rt.objectives.filter(o => !o.optional);
  if(req.length && req.every(o => o.status === 'done')){
    rt.status = 'won'; out.push({type:'end', result:'won', reason:'objectives'});
  }
  return out;
}
