/* عرض رسائل اللاسلكي على الـHUD (محرك/DOM): حتى 3 رسائل بالتزامن، كل رسالة تختفي بعد hold ثانية. النص من i18n (t). */
import {$} from '../util.js';
import {t} from '../i18n.js';

const MAX = 3;
let box = null;
const host = () => box || (box = $('#comm'));

export function showComm(from, textKey, hold = 6){
  const h = host(); if(!h) return;
  const d = document.createElement('div'), b = document.createElement('b');
  b.textContent = t('c_'+from); d.appendChild(b); d.appendChild(document.createTextNode(t(textKey)));
  h.appendChild(d); while(h.children.length > MAX) h.removeChild(h.firstChild);
  setTimeout(() => { d.style.opacity = 0; setTimeout(() => d.remove(), 600); }, hold*1000);
}
export function clearComms(){ const h = host(); if(h) h.textContent = ''; }
