/* جسر المهمة بالمحرك: يبدأ المهمة (إنشاء الكيانات + آلة الحالات) ويحدّثها كل فريم ويحوّل مخرجاتها لحالة اللعبة.
   المنطق نفسه بـ mission_runtime.js (صرف)؛ هنا فقط الربط بالمحرك (HUD، صوت، تعزيزات، لاسلكي، نهاية). */
import {createRuntime, pushEvent, stepRuntime} from './mission_runtime.js';
import {resolveRuntime} from './mission_resolve.js';
import {spawnEntities, spawnList} from './entities.js';
import {makeSnap, updateMarks} from './mission_snap.js';
import {showComm, clearComms} from './comms_ui.js';
import {W, P} from '../state.js';
import {world} from '../core.js';
import {banner} from '../ui.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';

const ST = {placed:null, start:null, markT:0};

export function beginMission(def){
  const G = W.G; G.ms = createRuntime(def);
  G.wave = def.difficulty;                 // مؤقت: أرقام الذكاء القديمة ما زالت تقرأ G.wave (تُزال مع M4)
  const spawn = world.cfg.spawn || {x:0, z:0, yaw:0};
  ST.start = {x:spawn.x, z:spawn.z, yaw:spawn.yaw || 0}; ST.markT = 0;
  ST.placed = spawnEntities(def, spawn).placed;
  resolveRuntime(G.ms, ST.start, ST.placed);
  clearComms(); banner(t(def.intro));
}
/* تعزيزات محفّز: d/a تُقاس من موضع اللاعب الآن (ما لم يكن at:'start') */
function reinforce(list){
  const p = P.g.position, frame = {x:p.x, z:p.z, yaw:P.yaw, start:ST.start};
  spawnList(list, W.G.ms.def.difficulty, frame, ST.placed);
}
function onOutput(o){
  const G = W.G;
  if(o.type === 'objective'){
    if(o.status === 'done' || o.status === 'active') sfx('lock');
    if(o.status === 'failed') sfx('alarm');
    return;
  }
  if(o.type === 'spawn'){ reinforce(o.list); return; }
  if(o.type === 'comm'){ showComm(o.from, o.text, o.hold); sfx('radio'); return; }
  if(o.type !== 'end') return;
  if(o.result === 'won'){ G.win = true; G.wait = 2.8; banner(t('ms_win')); sfx('win'); }
  else {                                   // الفشل بسبب الموت يُنهى بمساره الحالي (G.deadT)
    banner(t('ms_fail')); if(!G.dead){ G.win = false; G.wait = 2.5; sfx('alarm'); }
  }
}
export function missionUpdate(dt){
  const G = W.G, ms = G.ms; if(!ms) return;
  if(G.dead && !ms.deadSent){ ms.deadSent = true; pushEvent(ms, {type:'playerDead'}); }
  const snap = makeSnap(); G.snap = snap;
  for(const o of stepRuntime(ms, dt, snap)) onOutput(o);
  ST.markT -= dt; if(ST.markT <= 0){ ST.markT = .25; updateMarks(ms, snap); }
}
