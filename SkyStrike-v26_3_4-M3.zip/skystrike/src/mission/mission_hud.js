/* نص متتبّع الأهداف + البوصلة (دوال صرفة). tr = دالة الترجمة t. يرجع أسطراً HTML-آمنة (نصوص ثابتة وأرقام فقط). */
import {progressOf, pointsOf} from './objectives.js';

const ARROWS = ['↑', '↗', '→', '↘', '↓', '↙', '←', '↖'];
export const fmtTime = s => { const n = Math.ceil(s); return ((n/60)|0)+':'+String(n%60).padStart(2, '0'); };
export const fmtDist = m => m < 1000 ? Math.round(m/10)*10+' m' : (m/1000).toFixed(1)+' km';
/* rel = الزاوية عن الأمام (راد، + = يمين) ← سهم من 8 اتجاهات */
export const arrowOf = rel => ARROWS[(((Math.round(rel/(Math.PI/4)))%8)+8)%8];

export function objectiveLines(rt, tr){
  return rt.objectives.map(o => {
    const p = progressOf(o);
    const mark = o.status === 'done' ? '✔' : o.status === 'failed' ? '✖' : o.status === 'locked' ? '◇' : '◆';
    let tail = '';
    if(o.status === 'active'){
      if(p.left !== undefined && p.left !== null) tail = ' '+fmtTime(p.left);
      else if(p.total > 1) tail = ' '+p.done+'/'+p.total;
      if(p.lost) tail += ' ('+tr('ms_lost')+' '+p.lost+')';
    }
    return mark+' '+tr(o.textKey)+(o.optional ? ' ('+tr('ms_opt')+')' : '')+tail;
  });
}
export const headLine = (rt, tr) => tr(rt.def.title)+' · '+objectiveLines(rt, tr).join(' · ');

/* أقرب نقطة لأول هدف رئيسي نشط (ثم الثانوي) ← {x,z,dist}. snap: لقطة العالم (px,pz) */
export function nearestPoint(rt, snap){
  if(!snap) return null;
  const objs = [...rt.objectives.filter(o => !o.optional), ...rt.objectives.filter(o => o.optional)];
  for(const o of objs){
    let best = null;
    for(const p of pointsOf(o, snap)){
      const d = Math.hypot(p.x-snap.px, p.z-snap.pz);
      if(!best || d < best.dist) best = {x:p.x, z:p.z, dist:d};
    }
    if(best) return best;
  }
  return null;
}
/* سطر البوصلة: سهم نحو الهدف بالنسبة لاتجاه الطائرة + المسافة. yaw = اتجاه اللاعب (أمام = (-sin, -cos)) */
export function compassLine(rt, snap, yaw){
  const n = nearestPoint(rt, snap); if(!n) return '';
  const dx = n.x-snap.px, dz = n.z-snap.pz, sn = Math.sin(yaw), cs = Math.cos(yaw);
  const rel = Math.atan2(dx*cs-dz*sn, -(dx*sn+dz*cs));
  return arrowOf(rel)+' '+fmtDist(n.dist);
}
