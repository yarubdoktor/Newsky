import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {loadEnemyModels,hasEM,mkEM} from './emodels.js';
import {GK,groundScale} from './gscale.js';
// كل الـ geometry والـ materials مشتركة ومخزّنة (cache) => ما في تسريب ذاكرة ولا إنشاء كل مرة
const GC = {}, MC = {};
const geo = (k,f) => GC[k] || (GC[k] = f());
const mkm = (k,f) => MC[k] || (MC[k] = f());
const stdm = (c,m=.5,r=.45) => mkm(`s${c}_${m}_${r}`, () => new THREE.MeshStandardMaterial({color:c,metalness:m,roughness:r}));
const basic = (c,o=1,add=false) => mkm(`b${c}_${o}_${add}`, () => new THREE.MeshBasicMaterial({color:c,transparent:o<1||add,opacity:o,
  blending:add?THREE.AdditiveBlending:THREE.NormalBlending,depthWrite:!(o<1||add)}));
function planform(pts,th){
  const sh = new THREE.Shape(); pts.forEach((q,i) => i ? sh.lineTo(q[0],q[1]) : sh.moveTo(q[0],q[1]));
  const g = new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false}); g.rotateX(Math.PI/2); return g;
}
function holder(){
  const g = new THREE.Group();
  g.add_ = (ge,ma,x=0,y=0,z=0,rx=0,ry=0,rz=0) => { const o = new THREE.Mesh(ge,ma); o.position.set(x,y,z); o.rotation.set(rx,ry,rz); g.add(o); return o; };
  return g;
}
const FUS = () => geo('fus', () => new THREE.LatheGeometry([[0,-6.8],[.5,-6.8],[.95,-5.4],[1.25,-2.5],[1.35,.5],[1.2,3.5],[.9,5.2],[.45,6.5],[0,7.6]].map(a => new THREE.Vector2(a[0],a[1])),20).rotateX(-Math.PI/2));
const WP = [[[1,-1.2],[4.8,1.8],[4.8,2.8],[1,3.6]],[[1,-3.2],[5.4,1.2],[5.4,2.4],[1,3.4]],[[1,-3.5],[5.6,1.8],[5.6,2.8],[1,3.8]]];

function flames(g,xs,z,player,sc=1,noz=true,y=0,col=0){
  const fl = [];
  for(const x of xs){
    if(noz) g.add_(geo('noz',() => new THREE.CylinderGeometry(.62,.5,1.2,10).rotateX(Math.PI/2)),stdm(0x1b2027,.3,.6),x,0,z-.5);
    const f = new THREE.Group(); f.position.set(x,y,z);
    const o = new THREE.Mesh(geo('fo',() => new THREE.ConeGeometry(.55,4.5,10)),basic(col||(player?0xff8a2f:0xff5a2a),.7,true)); o.rotation.x = Math.PI/2; o.position.z = 2.25;
    const n = new THREE.Mesh(geo('fn',() => new THREE.ConeGeometry(.28,2.6,8)),basic(0xfff0c0,.9,true)); n.rotation.x = Math.PI/2; n.position.z = 1.3;
    f.add(o,n); f.scale.setScalar(sc); g.add(f); fl.push(f);
  }
  return fl;
}


/* ---------- نماذج GLB (اختيارية): إذا فشل التحميل تستعمل اللعبة المجسم البرمجي القديم ---------- */
const PM = {};   // نماذج اللاعب حسب kind: 0=F-35 ، 1=MiG-29 ، 2=Su-57
// اللهب لكل نموذج: x مواضع المحركات، z مكان الفوهة، sc الحجم، y الارتفاع
// fc لون لهب العادم ، wt موضع طرف الجناح (لخطوط البخار Contrails)
const PFL = {0:{xs:[0],z:6.7,sc:.9,y:.07,fc:0xff8a2f,wt:{x:6.3,y:.09,z:1.7}},
  1:{xs:[-.7,.7],z:7.2,sc:.7,y:-1.15,fc:0xffb347,wt:{x:5.4,y:-1.04,z:5.5}},
  2:{xs:[-.7,.7],z:7.45,sc:.75,y:-1.15,fc:0x7fc4ff,wt:{x:6.15,y:-1.14,z:5.5}}};
export const WT = {0:PFL[0].wt,1:PFL[1].wt,2:PFL[2].wt};
// نسخ ملونة من نموذج اللاعب (Skins): مواد مخزّنة لكل (طائرة، لون)
const SKV = {};
function skinModel(kind,tint){
  const k = kind+'_'+tint;
  if(!SKV[k]){
    const tc = new THREE.Color(tint), r = PM[kind].clone(true), cm = {};
    r.traverse(o => { if(o.isMesh){ const u = o.material.uuid; if(!cm[u]){ const m = o.material.clone(); if(!m.transparent && !/canopy|glass/i.test(m.name||'')) m.color.lerp(tc,.7); cm[u] = m; } o.material = cm[u]; } });
    SKV[k] = r;
  }
  return SKV[k].clone(true);
}
function loadGLB(url,tune){
  return new Promise(res => {
    try {
      new GLTFLoader().load(url, gltf => {
        gltf.scene.traverse(o => { if(o.isMesh && o.material){ o.material.envMapIntensity = 1.3; if(o.material.transparent) o.material.depthWrite = false; } });
        tune(gltf.scene); res(true);
      }, undefined, err => { console.warn(url+' failed, using built-in model',err); res(false); });
    } catch(err){ console.warn(err); res(false); }
  });
}
// روابط new URL لازم تكون نصوصاً ثابتة (literal) حتى ينسخ Vite ملفات GLB للبناء (الدمج بـ '+' ما بينلقط)
export const loadModels = () => Promise.all([loadGLB(new URL('./models/f35.glb',import.meta.url).href,r => PM[0] = r),
  loadGLB(new URL('./models/mig29.glb',import.meta.url).href,r => PM[1] = r),loadGLB(new URL('./models/su57.glb',import.meta.url).href,r => PM[2] = r),
  loadEnemyModels()]);
export function mkJet(kind,color,player,tint){
  if(player && PM[kind]){             // طائرة اللاعب = النموذج الحقيقي (F-35 / MiG-29 / Su-57)
    const f = PFL[kind], m = holder(); m.add(tint ? skinModel(kind,tint) : PM[kind].clone(true)); m.userData.fl = flames(m,f.xs,f.z,true,f.sc,false,f.y,f.fc); return m;
  }
  // v26.2.2 (بند #1): مقاتلات العدو = المجسم البرمجي الخاص بها (أدناه) وليس نموذج F-35؛ فتختلف عن طائرات اللاعب (GLB)
  const g = holder(), m = stdm(player && tint ? tint : color,.55,.4), d = stdm(0x1b2027,.3,.6),
    gl = mkm('glass',() => new THREE.MeshStandardMaterial({color:0x0b1824,emissive:0x1d4a78,emissiveIntensity:.7,metalness:.95,roughness:.1}));
  g.add_(FUS(),m);
  const W = geo('w'+kind,() => planform(WP[kind],.16)), T = geo('tail',() => planform([[.9,3.8],[3,5.6],[3,6.4],[.9,6.4]],.1));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    g.add_(geo('fin'+kind,() => new THREE.BoxGeometry(.14,2.3+kind*.3,1.9)),m,s*(1.15+kind*.15),1.4,4.7,0,0,-s*(kind===1?0:.4-kind*.03));
    g.add_(geo('intake',() => new THREE.BoxGeometry(.8,.8,2.6)),d,s,-.45,-1.6);
    g.add_(geo('nav',() => new THREE.SphereGeometry(.14,6,4)),basic(s<0?0xff2222:0x22ff66),s*[4.8,5.4,5.6][kind],0,2.2);
    if(kind===2) g.add_(geo('canard',() => new THREE.BoxGeometry(2.2,.08,1.1)),m,s*1.9,.1,-3.4,0,s*.3,0);
    if(player) g.add_(geo('pyl',() => new THREE.CylinderGeometry(.16,.16,2.6,6).rotateX(Math.PI/2)),stdm(0xdde3ea,.3,.5),s*2.6,-.35,1.4);
  }
  g.add_(geo('can',() => new THREE.SphereGeometry(.85,12,10)),gl,0,.8,-2.6).scale.set(.75,.7,2.1);
  g.add_(geo('pitot',() => new THREE.CylinderGeometry(.04,.04,1.4,4).rotateX(Math.PI/2)),d,0,0,-8.2);
  g.userData.fl = flames(g,kind===0?[0]:[-.85,.85],6.7,player);
  return g;
}
export function mkBomber(){
  const g = holder(), m = stdm(0x59616b,.5,.5), d = stdm(0x252a30,.4,.6);
  g.add_(geo('bf',() => new THREE.CylinderGeometry(2.4,2.4,26,12).rotateX(Math.PI/2)),m);
  g.add_(geo('bn',() => new THREE.ConeGeometry(2.4,7,12).rotateX(-Math.PI/2)),m,0,0,-16.5);
  g.add_(geo('bt',() => new THREE.ConeGeometry(2.4,9,12).rotateX(Math.PI/2)),m,0,0,17.5);
  g.add_(geo('bcan',() => new THREE.SphereGeometry(1.5,10,8)),stdm(0x0b1824,.9,.1),0,1.8,-10).scale.set(.9,.7,1.6);
  const W = geo('bw',() => planform([[2,-2],[18,5],[18,8],[2,9]],.5)), T = geo('bwt',() => planform([[1.5,12],[7,16],[7,18],[1.5,18.5]],.25));
  for(const s of [-1,1]){
    g.add_(W,m).scale.x = s; g.add_(T,m).scale.x = s;
    for(const x of [6,11]) g.add_(geo('bnac',() => new THREE.CylinderGeometry(1,1.1,5,8).rotateX(Math.PI/2)),d,s*x,-.9,3.5-(x>8?2:0));
  }
  g.add_(geo('bfin',() => new THREE.BoxGeometry(.4,7,4)),m,0,4.5,16);
  g.userData.fl = flames(g,[-11,-6,6,11],6.5,false,.8).map(f => { f.position.y = -.9; return f; });
  g.scale.setScalar(1.15);
  return g;
}
export function mkHeli(){
  if(hasEM('heli')){                  // نموذج GLB: rotor = الرئيسية (تدور حول Y) ، rotor2 = الذيل (حول X)
    const g = mkEM('heli'); g.userData.rotor = g.getObjectByName('rotor') || new THREE.Group(); g.userData.rotor2 = g.getObjectByName('rotor2'); g.userData.fl = []; return g;
  }
  const g = holder(), m = stdm(0x3d4a3a,.4,.55), d = stdm(0x1a1f1a,.3,.6);
  g.add_(geo('hb',() => new THREE.SphereGeometry(2.2,12,9)),m).scale.set(1,1,1.8);
  g.add_(geo('hc',() => new THREE.SphereGeometry(1.5,10,8)),stdm(0x0b1824,.9,.1),0,.5,-2.8).scale.set(.9,.8,1.1);
  g.add_(geo('ht',() => new THREE.CylinderGeometry(.35,.6,9,6).rotateX(Math.PI/2)),m,0,.4,7);
  g.add_(geo('hf',() => new THREE.BoxGeometry(.2,2.2,1.4)),m,0,1.4,10.6);
  for(const s of [-1,1]){ g.add_(geo('hs',() => new THREE.BoxGeometry(.2,.2,5)),d,s*1.7,-2.3,0);
    g.add_(geo('hw',() => new THREE.BoxGeometry(2.4,.2,.8)),m,s*2.4,-.4,-.4); }
  const rotor = new THREE.Group(); rotor.position.y = 2.6;
  rotor.add(new THREE.Mesh(geo('hr',() => new THREE.BoxGeometry(16,.08,.7)),basic(0x222222,.55)));
  const r2 = new THREE.Mesh(geo('hr',() => new THREE.BoxGeometry(16,.08,.7)),basic(0x222222,.55)); r2.rotation.y = Math.PI/2; rotor.add(r2);
  g.add(rotor); g.userData.rotor = rotor; g.userData.fl = [];
  return g;
}
export function mkDrone(){          // مسيّرة انتحارية صغيرة بعين حمراء
  if(hasEM('drone')){                 // نموذج GLB مصبوغ بالأحمر (المروحة الدافعة بالخلف +Z)
    const g = holder(); g.add(mkEM('drone',0x8a2e2e,.5)); g.userData.fl = flames(g,[0],4.2,false,.35,false,0,0xff3a3a); return g;
  }
  const g = holder(), m = stdm(0x3a2226,.5,.4);
  g.add_(geo('dr_b',() => new THREE.SphereGeometry(1,10,8)),m).scale.set(.8,.5,2.2);
  const W = geo('dr_w',() => planform([[.6,-.6],[4,1.2],[4,2],[.6,2.2]],.1));
  for(const s of [-1,1]) g.add_(W,m).scale.x = s;
  g.add_(geo('dr_e',() => new THREE.SphereGeometry(.45,8,6)),basic(0xff2a2a),0,.3,-1.9);
  g.userData.fl = flames(g,[0],2.4,false,.35,false,0,0xff3a3a);
  return g;
}
// أنواع الأرضيات: 0 مدفع مزدوج ، 1 دبابة مضادة ، 2 جيبارد ، 3 صواريخ SAM ، 4 فلاك ثقيل (flak). كلها GLB (فوهتها +Z) والبرج 'aim' يدور نحو اللاعب
const GK_SHADOW = [9,12,11,11,10];   // نصف قطر الظل لكل نوع (بعد التكبير)
export function mkGround(t){
  if(hasEM(GK[t])){
    const m = mkEM(GK[t]); m.rotation.y = Math.random()*Math.PI*2;           // اتجاه عشوائي للهيكل (البرج يتجه بـ lookAt بالعالم)
    const g = holder(); g.add(m); m.scale.setScalar(groundScale(GK[t]));     // v26.2.4: مقياس واقعي/مضخّم (gscale.js). g = الحاوية اللي تكبّرها اللعبة بالمسافة
    g.add_(geo('gshadow',() => new THREE.CircleGeometry(1,24).rotateX(-Math.PI/2)),basic(0x000000,.38),0,.25,0).scale.setScalar(GK_SHADOW[t]);   // ظل دائري يثبّت الآلة بالأرض ويعطي عمقاً
    g.userData.aim = m.getObjectByName('aim') || m; g.userData.gk = GK[t]; return g;
  }
  if(t === 4) t = 2;                                                       // المجسم البرمجي القديم للـ flak
  const g = holder(), a = stdm(0x56604a,.1,.8), b = stdm(0x2c3128,.1,.7), tur = new THREE.Group();
  const box = (w,h,d,mt,x,y,z,par) => { const o = new THREE.Mesh(geo(`bx${w}_${h}_${d}`,() => new THREE.BoxGeometry(w,h,d)),mt); o.position.set(x,y,z); (par||g).add(o); return o; };
  if(t===0){ const bs = new THREE.Mesh(geo('gbs',() => new THREE.CylinderGeometry(5,7,4,8)),a); bs.position.y = 2; g.add(bs); tur.position.y = 5; box(3.5,2.4,4,b,0,0,0,tur); box(.5,.5,8,b,-.9,.3,5,tur); box(.5,.5,8,b,.9,.3,5,tur); }
  else if(t===1){ box(7,2,11,a,0,1.6,0); box(1.6,2,11.4,b,-3.8,1,0); box(1.6,2,11.4,b,3.8,1,0); tur.position.y = 3.6; box(4.4,1.8,5,a,0,0,0,tur); box(.6,.6,7,b,0,.2,5.5,tur); }
  else if(t===2){ box(6,2,6,b,0,1,0); tur.position.y = 2.6; for(const x of [-1.6,0,1.6]) for(const y of [0,1.6]) box(.9,.9,7,a,x,y,2,tur); }
  else { box(8,2,8,b,0,1,0); box(5,.6,5,a,0,2.3,0); tur.position.y = 3.2; box(3,1.6,3,a,0,0,0,tur);
    for(const x of [-1.2,1.2]){ box(.9,.9,6.5,a,x,1.1,-1.8,tur).rotation.x = .5; const tip = box(.7,.7,1,stdm(0xc23b2e,.2,.5),x,2.2,-4.4,tur); tip.rotation.x = .5; } }
  g.add(tur); g.userData.aim = tur; return g;
}
export function mkDepot(){
  const g = holder(), a = stdm(0x5b6458,.2,.7), b = stdm(0x2c3128,.2,.7);
  g.add_(geo('db',() => new THREE.BoxGeometry(34,1.2,30)),b,0,.6,0);
  for(const p of [[-9,0],[9,0],[0,-10]]) g.add_(geo('dt',() => new THREE.CylinderGeometry(5,5,7,14)),a,p[0],4.7,p[1]);
  g.add_(geo('dtw',() => new THREE.CylinderGeometry(2,3,20,8)),a,0,11,8);
  g.add_(geo('dtop',() => new THREE.SphereGeometry(2.4,10,8)),basic(0xff3322),0,22.5,8);
  g.userData.aim = new THREE.Group(); g.add(g.userData.aim); return g;
}
export const BULLET_GEO = new THREE.SphereGeometry(.35,6,4);
export const BULLET_P = basic(0xffe27a), BULLET_E = basic(0xff4040);
export function mkMsl(enemy){
  const g = new THREE.Group(), w = stdm(enemy?0x3a3a3a:0xe8edf2,.2,.4), r = stdm(enemy?0xff5522:0xc23b2e,.2,.5);
  g.add(new THREE.Mesh(geo('mbody',() => new THREE.CylinderGeometry(.28,.28,3.4,8).rotateX(Math.PI/2)),w),
        new THREE.Mesh(geo('mnose',() => new THREE.ConeGeometry(.28,1.1,8).rotateX(Math.PI/2).translate(0,0,2.2)),r));
  const f = new THREE.Mesh(geo('mfin',() => new THREE.BoxGeometry(.08,1.3,.8).translate(0,0,-1.3)),r); g.add(f);
  const f2 = f.clone(); f2.rotation.z = Math.PI/2; g.add(f2); return g;
}
export function mkBomb(){
  const g = new THREE.Group(), m = stdm(0x3b4a2c,.2,.6);
  g.add(new THREE.Mesh(geo('bobody',() => new THREE.CylinderGeometry(.5,.5,2.2,8).rotateX(Math.PI/2)),m),
        new THREE.Mesh(geo('bonose',() => new THREE.ConeGeometry(.5,.9,8).rotateX(Math.PI/2).translate(0,0,1.5)),m));
  return g;
}
