/* تعريفات المهمات كبيانات. الحقول:
   id · map · title/intro (مفاتيح i18n بـ mission_text.js) · difficulty (يحل مكان رقم الموجة: يضبط صحة/عدوانية الأعداء)
   entities[]: {id, kind, side, pos, obj?, tt?, alt?, route?[]}  kind: 'depot'|'turret'|'sam'|'flak'|'tank'|'apc'|
               'truck'|'jet'|'ace'|'heli'|'drone'|'bomber'|'convoy'  (route = نقاط مسار للمركبات)
               convoy: {units:[مركبات], gap?, speed?, route[]} ← معرّفات الأعضاء id+1..
   objectives[]: {id, type, text, optional?, after?[]} + حسب النوع (obj_types.js):
       destroy/suppress/intercept: targets[] (+ need? · limit?) · escort: units[] (+ need) · defend: sites[], t
       · rtb: pos, r?, alt?
   triggers[]: {id, when, do[]} (triggers.js) · comms[]: {id, from, text, at?, hold?} (comms.js) · fail[]:
   playerDead | timeout
   reward: {c, g, xp} مكافأة أول نجاح (الإعادة ربعها) · par: الزمن المرجعي بالثانية (نجمة ثانية إن لا أهداف ثانوية)
   لإضافة مهمة: أضف كائناً هنا + نصوصها بـ mission_text.js (title, intro, <id>d، الأهداف، الرسائل). */
import {validateMission} from './mission_check.js';
export {validateMission};

export const MISSIONS = [
  { id:'m0', map:'desert', title:'m0t', intro:'m0i', difficulty:2,
    reward:{c:300, g:0, xp:100}, par:150,
    entities:[
      {id:'depot', kind:'depot', side:'enemy', pos:{d:1700, a:0, r:420}, obj:true},
      {id:'aa1', kind:'turret', tt:0, side:'enemy', pos:{near:'depot', r:150}},
      {id:'aa2', kind:'turret', tt:1, side:'enemy', pos:{near:'depot', r:170}},
      {id:'sam1', kind:'sam', side:'enemy', pos:{near:'depot', r:200}}
    ],
    objectives:[{id:'o1', type:'destroy', text:'m0o1', targets:['depot']}],
    fail:[{type:'playerDead'}], triggers:[], comms:[] },

  { id:'m1', map:'desert', title:'m1t', intro:'m1i', difficulty:2,
    reward:{c:700, g:5, xp:250}, par:600,
    entities:[
      {id:'cv', kind:'convoy', side:'ally', units:['tank', 'apc', 'truck', 'truck'], gap:34, speed:11,
       pos:{d:260, a:.5, r:80}, route:[{d:900, a:.25, r:150}, {d:1700, a:.05, r:200}, {d:2400, a:-.1, r:200}]},
      {id:'et1', kind:'tank', side:'enemy', pos:{d:1900, a:.05, r:150}},
      {id:'et2', kind:'tank', side:'enemy', pos:{near:'et1', r:130}},
      {id:'aa1', kind:'turret', tt:0, side:'enemy', pos:{near:'et1', r:220}},
      {id:'aa2', kind:'turret', tt:1, side:'enemy', pos:{near:'et2', r:200}},
      {id:'sam1', kind:'sam', side:'enemy', pos:{near:'et2', r:240}}
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m1o1', targets:['et1', 'et2']},
      {id:'o2', type:'suppress', text:'m1o2', targets:['aa1', 'aa2', 'sam1'], need:2},
      {id:'o3', type:'escort', text:'m1o3', units:['cv1', 'cv2', 'cv3', 'cv4'], need:3},
      {id:'o4', type:'rtb', text:'m1o4', pos:{d:0, a:0}, r:600, alt:260, after:['o1', 'o2', 'o3']},
      {id:'o5', type:'destroy', text:'m1o5', targets:['rh1'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:{near:'et1'}, r:1500}}, do:[{comm:'c2'}]},
      {id:'t2', when:{dead:'et1'},
       do:[{spawn:[{id:'rh1', kind:'heli', side:'enemy', pos:{d:1100, a:.6}}]}, {comm:'c3'}]},
      {id:'t3', when:{arrived:'cv1'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m1c1', at:2},
      {id:'c2', from:'gnd', text:'m1c2'},
      {id:'c3', from:'cmd', text:'m1c3'},
      {id:'c4', from:'ally', text:'m1c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:1200}] },

  { id:'m2', map:'desert', title:'m2t', intro:'m2i', difficulty:2,
    reward:{c:900, g:8, xp:300}, par:330,
    entities:[
      {id:'base', kind:'depot', side:'ally', pos:{d:600, a:0, r:300}},
      {id:'g1', kind:'turret', tt:0, side:'ally', pos:{near:'base', r:160}},
      {id:'g2', kind:'turret', tt:1, side:'ally', pos:{near:'base', r:180}},
      {id:'s1', kind:'sam', side:'ally', pos:{near:'base', r:200}}
    ],
    objectives:[
      {id:'o1', type:'defend', text:'m2o1', sites:['base'], t:150},
      {id:'o2', type:'intercept', text:'m2o2', targets:['b1', 'b2'], limit:260},
      {id:'o3', type:'destroy', text:'m2o3', targets:['j1', 'j2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{t:20}, do:[{spawn:[
        {id:'b1', kind:'bomber', side:'enemy', pos:{d:2800, a:.1, at:'start'}},
        {id:'b2', kind:'bomber', side:'enemy', pos:{d:2900, a:-.1, at:'start'}}]}, {comm:'c2'}]},
      {id:'t2', when:{t:80}, do:[{spawn:[
        {id:'j1', kind:'jet', side:'enemy', pos:{d:2600, a:.3, at:'start'}},
        {id:'j2', kind:'jet', side:'enemy', pos:{d:2700, a:-.3, at:'start'}}]}, {comm:'c3'}]},
      {id:'t3', when:{done:'o2'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m2c1', at:2},
      {id:'c2', from:'gnd', text:'m2c2'},
      {id:'c3', from:'gnd', text:'m2c3'},
      {id:'c4', from:'cmd', text:'m2c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}] }
];

export const missionById = id => MISSIONS.find(m => m.id === id) || null;
