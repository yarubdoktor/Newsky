/* فحص سلامة تعريف المهمة (يستعمله الاختبار): يرجع قائمة أخطاء (فارغة = سليم). دالة صرفة. */
import {entityIds} from './convoy.js';
import {VEHICLE_KINDS} from './entity_pos.js';
import {AFTER_TYPES} from './objectives.js';
import {whenKey} from './triggers.js';
import {FROMS} from './comms.js';

const POS_OK = p => !!p && (p.near !== undefined || p.d !== undefined || (p.x !== undefined && p.z !== undefined));

function checkEntities(list, kinds, ids, err, earlier){
  for(const e of list){
    for(const id of entityIds(e)){ if(ids.has(id)) err.push('duplicate entity '+id); ids.add(id); }
    if(!kinds.includes(e.kind)) err.push('bad kind '+e.kind);
    if(e.kind === 'convoy' && !(e.units && e.units.length && e.units.every(k => VEHICLE_KINDS.includes(k))))
      err.push('convoy needs units of vehicle kinds: '+e.id);
    if((e.kind === 'convoy' || e.route) && !(Array.isArray(e.route) && e.route.length))
      err.push('route needs points: '+e.id);
    if(!POS_OK(e.pos)) err.push('no/bad pos '+e.id);
    else if(e.pos.near !== undefined && !earlier.some(p => entityIds(p).includes(e.pos.near)))
      err.push('near must reference an earlier entity: '+e.id);
    earlier.push(e);
  }
}
function needIds(o, key, ids, err){
  if(!Array.isArray(o[key]) || !o[key].length) err.push(o.id+': '+key+' required');
  for(const id of o[key] || []) if(!ids.has(id)) err.push('objective '+o.id+' references missing entity: '+id);
}
function checkObjective(o, objTypes, ids, objIds, err){
  if(!objTypes.includes(o.type)){ err.push('bad objective type '+o.type); return; }
  if(['destroy', 'suppress', 'intercept'].includes(o.type)) needIds(o, 'targets', ids, err);
  if(o.type === 'escort') needIds(o, 'units', ids, err);
  if(o.type === 'defend'){ needIds(o, 'sites', ids, err); if(!(o.t > 0)) err.push(o.id+': defend needs t > 0'); }
  if(o.type === 'rtb' && !POS_OK(o.pos)) err.push(o.id+': rtb needs pos');
  const n = (o.targets || o.units || o.sites || []).length;
  if(o.need !== undefined && !(o.need >= 1 && o.need <= n)) err.push(o.id+': need out of range');
  if(o.limit !== undefined && !(o.limit > 0)) err.push(o.id+': limit must be > 0');
  for(const a of o.after || []){
    if(!AFTER_TYPES.includes(o.type)) err.push(o.id+': after not allowed for '+o.type);
    if(!objIds.has(a) || a === o.id) err.push(o.id+': after references unknown objective '+a);
  }
}
function checkTriggers(m, kinds, ids, objIds, err){
  const trIds = new Set(), commIds = new Set((m.comms || []).map(c => c.id));
  for(const tr of m.triggers || []){
    if(trIds.has(tr.id)) err.push('duplicate trigger '+tr.id); trIds.add(tr.id);
    const k = whenKey(tr.when);
    if(!k) err.push('trigger '+tr.id+': bad when');
    if(k === 't' && !(tr.when.t >= 0)) err.push('trigger '+tr.id+': bad t');
    if(k === 'zone' && !(POS_OK(tr.when.zone.pos) && tr.when.zone.r > 0)) err.push('trigger '+tr.id+': bad zone');
    if(k === 'done' && !objIds.has(tr.when.done)) err.push('trigger '+tr.id+': unknown objective');
    if((k === 'dead' || k === 'arrived') && !ids.has(tr.when[k])) err.push('trigger '+tr.id+': unknown entity');
    if(!(tr.do && tr.do.length)) err.push('trigger '+tr.id+': no actions');
    for(const a of tr.do || []){
      if(a.comm !== undefined && !commIds.has(a.comm)) err.push('trigger '+tr.id+': unknown comm '+a.comm);
      if(a.spawn) checkEntities(a.spawn, kinds, ids, err, m.entities.slice());
      if(a.comm === undefined && !a.spawn) err.push('trigger '+tr.id+': unknown action');
    }
  }
}
export function validateMission(m, kinds, objTypes){
  const err = [], ids = new Set(), objIds = new Set(m.objectives.map(o => o.id));
  checkEntities(m.entities, kinds, ids, err, []);
  if(!m.objectives.length) err.push('no objectives');
  if(objIds.size !== m.objectives.length) err.push('duplicate objective id');
  checkTriggers(m, kinds, ids, objIds, err);
  for(const o of m.objectives) checkObjective(o, objTypes, ids, objIds, err);
  const cids = new Set();
  for(const c of m.comms || []){
    if(cids.has(c.id)) err.push('duplicate comm '+c.id); cids.add(c.id);
    if(!FROMS.includes(c.from) || !c.text) err.push('comm '+c.id+': needs from/text');
  }
  for(const k of ['c', 'g', 'xp']){
    if(m.reward !== undefined && !(m.reward[k] >= 0)) err.push('reward.'+k+' must be >= 0');
  }
  if(m.par !== undefined && !(m.par > 0)) err.push('par must be > 0');
  return err;
}
