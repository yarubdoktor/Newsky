let LANG = 'ar';
export const getLang = () => LANG;
export function setLang(l){ LANG = l === 'en' ? 'en' : 'ar'; if(typeof document !== 'undefined'){ document.documentElement.lang = LANG; document.documentElement.dir = LANG === 'ar' ? 'rtl' : 'ltr'; } }
const D = {
  tSet:['⚙️ الإعدادات','⚙️ Settings'],
  
  r1:['مجنّد','Cadet'], r2:['فضي 🥈','Silver 🥈'], r3:['ذهبي 🥇','Gold 🥇'], r4:['بلاتيني 💎','Platinum 💎'], r5:['أسطورة 👑','Legend 👑'],
  lvl:['مستوى','Level'], max:['MAX','MAX'],
  d_f35:['متوازنة وصلبة، أقوى درع وأكثر قنابل إنذار','Balanced and tough: best armor, most flares'], d_mig29:['سريعة ورشيقة لكن درعها ضعيف، للاعب الجريء','Fast and nimble but fragile, for bold pilots'], d_su57:['الأرشق والأقوى، تفوّق بالدوران والسرعة','Most agile and powerful, top turn and speed'],
  use:['استخدام','Select'], usedNow:['✅ الطائرة المستخدمة حالياً','✅ Currently selected'], tapUse:['اضغط «استخدام» لتطير بها','Tap “Select” to fly it'],
  unlockHow:['🔓 كيف تفتحها: اشترِ بـ {p} 🪙، واكسب العملات من المعارك والمهام','🔓 Unlock: buy for {p} 🪙, earn coins from battles and missions'],
  buy:['شراء','Buy'], upg:['تطوير','Upgrade'], locked:['🔒 مقفل','🔒 Locked'],
  w_gun:['رشاش 20mm','20mm Cannon'], w_msl:['صاروخ موجّه','Guided Missile'], w_multi:['صواريخ متعددة','Multi-Missiles'], w_bomb:['قنابل أرضية','Ground Bombs'],
  wd_gun:['ضرر {d} لكل طلقة · نار متواصلة (زر FIRE)','{d} dmg per round · continuous fire (FIRE)'],
  wd_msl:['ضرر {d} · {n} صواريخ · يلاحق الهدف (زر MSL)','{d} dmg · {n} missiles · homing (MSL)'],
  wd_multi:['3 صواريخ بدفعة وحدة لـ3 أهداف · ضرر {d} لكل صاروخ · {n} دفعات (زر MUL)','3 missiles per salvo at 3 targets · {d} dmg each · {n} salvos (MUL)'],
  wd_bomb:['انفجار واسع للأهداف الأرضية · ضرر {d} · {n} قنابل (زر BMB)','Wide blast vs ground targets · {d} dmg · {n} bombs (BMB)'],
  
  sgGfx:['الرسوميات','Graphics'], sgSnd:['الصوت والاهتزاز','Sound & haptics'], sgCtl:['التحكم','Controls'], sgGame:['اللعبة','Game'],
  
  
  
  
  
  
  map_island:['🏝️ جزر استوائية','🏝️ Tropical Isles'], map_desert:['🏜️ الصحراء','🏜️ Desert'], map_arctic:['❄️ القطب المتجمد','❄️ Arctic'], map_canyon:['🏞️ الوادي الأحمر','🏞️ Red Canyon'], map_night:['🌃 مدينة ليلية','🌃 Night City'], map_greenland:['🏔️ جبال غرينلاند','🏔️ Greenland Alps'], map_map7:['⚓ القاعدتان والأساطيل','⚓ Twin Bases'],
  
  claim:['استلام','Claim'], done:['تم ✅','Done ✅'], 
  
  
  sQual:['جودة الرسومات','Graphics quality'], qAuto:['تلقائي','Auto'], qLow:['منخفضة','Low'], qMed:['متوسطة','Medium'], qHigh:['عالية (Bloom)','High (Bloom)'],
  sFps:['عدّاد FPS','FPS counter'], sSnd:['الصوت','Sound'], sMus:['الموسيقى','Music'], sVib:['الاهتزاز','Vibration'],
  sTilt:['التحكم بالميلان (تجريبي)','Tilt control (experimental)'], sTiltInv:['عكس الميلان','Invert tilt'], sAssist:['مساعد تفادي الأرض','Terrain-avoid assist'],
  sSens:['الحساسية','Sensitivity'], sLang:['اللغة','Language'], on:['تشغيل','On'], off:['إيقاف','Off'],
  
  
  
  
  
  outMap:['⚠ ارجع لساحة المعركة','⚠ RETURN TO THE BATTLEFIELD'], pullUp:['⬆ ارفع الطائرة','⬆ PULL UP'], missile:['🚨 صاروخ قادم — FLR!','🚨 MISSILE — FLARES!'],
  lock:['🔒 LOCK','🔒 LOCK'], loading:['جارِ تحميل العالم…','Loading world…'], paused:['متوقف مؤقتاً','PAUSED'], resume:['متابعة','Resume'], quit:['إنهاء المهمة','End mission'],
  autoLow:['⚡ خفّضنا الجودة تلقائياً لسلاسة أعلى','⚡ Quality lowered automatically for smoother play'], combo:['كومبو','COMBO'],
  nLobby:['الرئيسية','Lobby'], nPlanes:['الطائرات','Aircraft'], nWeapons:['الأسلحة','Weapons'], nSettings:['الإعدادات','Settings'], 
  
  soon:['🔜 قريباً','🔜 Coming soon'], close:['إغلاق','Close'],
  
  hangarT:['الهنجر','Hangar'], weaponsT:['الأسلحة والترقيات','Weapons & upgrades'],
  xp:['XP','XP'],
  profileT:['الملف الشخصي','Profile'], pName:['اسم الطيار','Pilot name'], pCoins:['العملات','Coins'], pPlanes:['الطائرات المملوكة','Aircraft owned'], pSaved:['✅ تم حفظ الاسم','✅ Name saved'],
  ab_f35:['تخفّي: صواريخ العدو أضعف تتبعاً + أكثر قنابل إنذار','Stealth: enemy missiles track worse · most flares'],
  ab_mig29:['محرك قوي: سرعة Boost أعلى وشحنه يرجع أسرع','Overboost: higher boost speed and faster recharge'],
  ab_su57:['توجيه الدفع: دوران أحدّ أثناء الـ Boost واستهلاك أقل','Thrust vectoring: sharper turns while boosting, lower drain'],
  skinsT:['الألوان','Skins'], skOn:['✅ مستخدم','✅ Equipped'], skBought:['🎨 تم شراء اللون','🎨 Skin unlocked'],
  sk_gray:['رمادي (أصلي)','Stock grey'], sk_desert:['صحراوي','Desert'], sk_forest:['غابات','Forest'], sk_arctic:['قطبي','Arctic'], sk_night:['ليلي','Night'], sk_crimson:['قرمزي','Crimson'], sk_gold:['ذهبي','Gold'],
  loginT:['🎁 مكافأة الدخول اليومي','🎁 Daily login reward'], loginS:['اليوم {d} من 7 · +{c}🪙{g}','Day {d} of 7 · +{c}🪙{g}'],
  claimedL:['+{r}🪙 مكافأة الدخول اليومي','+{r}🪙 daily login reward'],
  
  locking:['… جارٍ القفل','… LOCKING'], sInvY:['عكس محور الطيران (Y)','Invert pitch (Y)'], sTut:['إعادة التعليمات بالمهمة القادمة','Replay tutorial next mission'],
  tut1:['حرّك الجويستيك لتوجيه الطائرة (PC: الأسهم/WASD)','Move the joystick to steer (PC: arrows/WASD)'],
  tut2:['اضغط مطوّلاً على FIRE لإطلاق الرشاش (PC: Space)','Hold FIRE to shoot the cannon (PC: Space)'],
  tut3:['وجّه الأنف نحو عدو حتى يكتمل القفل 🔒 ثم اضغط MSL (PC: M)','Point at an enemy until it locks 🔒 then press MSL (PC: M)'],
  tut4:['اضغط BOOST مطوّلاً للسرعة، يستهلك الشحن ويرجع تلقائياً (PC: Shift)','Hold BOOST for speed: it drains, then recharges (PC: Shift)'],
  tut5:['صاروخ قادم؟ اضغط FLR لقنابل الإنذار وتشتيته (PC: F)','Incoming missile? Press FLR to drop decoy flares (PC: F)'],
  tutDone:['جاهز يا بطل! دمّر الأعداء 🎯','Ready, pilot! Destroy the enemies 🎯'], tutSkip:['تخطي','Skip'],
  /* ---- v16: كاميرا + زعماء بمراحل + حملة + مكافآت المستويات ---- */
  sCam:['زاوية الكاميرا','Camera view'], sFm:['نمط الطيران','Flight model'], fm0:['كلاسيك','Classic'], fm1:['احترافي','Pro'], cam0:['قريبة','Close'], cam1:['متوسطة','Mid'], cam2:['بعيدة','Far'],
  
  
  
  
  
  
  
  
  
  
  
  lvUp:['ارتقيت للمستوى {l}!','Level up! Lv {l}'], lvRwT:['مكافآت المستويات القادمة','Upcoming level rewards'],
  pAvg:['متوسط العملات / مهمة','Avg coins / run'], pRuns:['عدد المهام','Missions played'], qLite:['خفيفة جداً','Ultra-low'],
};
import {MISSION_TEXT} from './mission/mission_text.js';
import {UI_TEXT} from './mission/ui_text.js';
Object.assign(D,MISSION_TEXT,UI_TEXT);                         // نصوص المهمات والجهات (ملف مستقل: قاعدة R4)
export const t = (k,o) => { const e = D[k]; let s = e ? e[LANG === 'en' ? 1 : 0] : k; if(o) for(const x in o) s = s.replace('{'+x+'}',o[x]); return s; };
