# تقرير قرار الأصول (SkyStrike v26.3.8)

> لم يُحذف أي ملف. هذا تقرير توصية فقط، والقرار النهائي لك. كل الأصول الأصلية محفوظة بلا تغيير ويحرسها `tools/test/test_assets_kept.mjs` (بصمة sha256).

## النماذج والحزم المبنية (تدخل التطبيق)

| الملف | الحجم | الدور / الاستعمال | التوصية |
|---|---|---|---|
| `src/models/f35.glb` | 266 KB | طائرة اللاعب (F-35، الافتراضية) — أساسي بالحظيرة | احتفظ |
| `src/models/mig29.glb` | 431 KB | طائرة اللاعب (MiG-29) — أساسي بالحظيرة | احتفظ |
| `src/models/su57.glb` | 373 KB | طائرة اللاعب (Su-57) — أساسي بالحظيرة | احتفظ |
| `src/models/e_aa_twin.glb` | 212 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m0، m1، m2، m3، m4، m5، m6، m7، m8، m10، m11 | احتفظ |
| `src/models/e_aa_tank.glb` | 133 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m0، m1، m2، m3، m4، m5، m6، m7، m9، m10، m11 | احتفظ |
| `src/models/e_gepard.glb` | 41 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m5، m6، m9، m11 | احتفظ |
| `src/models/e_sam.glb` | 141 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m0، m1، m2، m3، m4، m5، m6، m7، m8، m9، m10، m11 | احتفظ |
| `src/models/e_flak.glb` | 499 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m3، m9، m10 | احتفظ |
| `src/models/e_heli.glb` | 50 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m1، m3، m6، m7، m8 | احتفظ |
| `src/models/e_drone.glb` | 22 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m4 | احتفظ |
| `src/models/e_tank.glb` | 71 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m1، m8، m11 | احتفظ |
| `src/models/e_apc.glb` | 36 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m1، m8، m11 | احتفظ |
| `src/models/e_truck.glb` | 28 KB | وحدة عدو/حليف أرضية أو جوية — مهمات: m1، m8 | احتفظ |
| `src/models/greenland.bin` | 619 KB | خريطة غرينلاند (حزمة مبنية) — غير مستعملة بالحملة؛ تدخل حزمة التطبيق (~0.6MB) | قرارك |
| `src/models/map7.bin` | 82 KB | خريطة 7 «القاعدتان والأساطيل» (حزمة مبنية) — غير مستعملة بالحملة؛ تدخل حزمة التطبيق (~0.08MB) | قرارك |

## مصادر النماذج (للتوليد فقط، لا تدخل التطبيق)

| الملف | الحجم | الدور | التوصية |
|---|---|---|---|
| `models_src/F35_Stealth_Fighter_Premium.glb` | 125 KB | مصدر f35.glb (tools/optimize_glb.py) — لإعادة التوليد | احتفظ |
| `models_src/MIG29.glb` | 121 KB | مصدر mig29.glb — لإعادة التوليد | احتفظ |
| `models_src/SU57.glb` | 105 KB | مصدر su57.glb — لإعادة التوليد | احتفظ |
| `models_src/F35_Stealth_Fighter.glb` | 43 KB | نسخة F-35 أبسط، لا تشير إليها أي أداة ولا كود — مكرّر وظيفياً مع Premium | قرارك (يمكن حذفه بلا أثر) |
| `models_src/retired/enemy_f35_simplified.glb` | 132 KB | مقاتلة عدو قديمة مبسّطة (أُحيلت للتقاعد؛ العدو الآن مجسّم برمجي) — مجلد retired | قرارك (يمكن حذفه بلا أثر) |
| `models_src/enemies/AA_Twin_Rotary_AAA.glb` | 93 KB | مصدر e_aa_twin — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/tank_aaa.glb` | 104 KB | مصدر e_aa_tank — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/anti_air_gepard_aaa.glb` | 33 KB | مصدر e_gepard — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/sam_platform_aaa.glb` | 51 KB | مصدر e_sam — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/SkyStrike_AA_Flak_Heavy_v1.glb` | 87 KB | مصدر e_flak — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/helicopter_aaa.glb` | 49 KB | مصدر e_heli — tools/prep_enemy.py | احتفظ |
| `models_src/enemies/UAV_Lightweight_Mobile.glb` | 17 KB | مصدر e_drone — tools/prep_enemy.py | احتفظ |
| `models_src/Greenland_World_20km.glb` | 5549 KB | مصدر greenland.bin (أكبر ملف بالمستودع) — tools/convert_world.py | قرارك |
| `models_src/map7_terrain.glb` | 775 KB | مصدر map7.bin (تضاريس) — tools/convert_map7.py | قرارك |
| `models_src/map7_world.glb` | 225 KB | مصدر map7.bin (مجسّمات) — tools/convert_map7.py | قرارك |

## الخرائط

| الخريطة | الوصف | مهمات الحملة التي تستعملها | التوصية |
|---|---|---|---|
| `front` | مسرح جديد (M5) مستوحى من الخرائط القديمة | m0، m1، m2، m3، m4، m5، m11 | احتفظ |
| `highlands` | مسرح جديد (M5) مستوحى من الخرائط القديمة | m6، m7، m8 | احتفظ |
| `gulf` | مسرح جديد (M5) مستوحى من الخرائط القديمة | m10 | احتفظ |
| `front_night` | مسرح جديد (M5) مستوحى من الخرائط القديمة | m9 | احتفظ |
| `island` | خريطة قديمة إجرائية (الاحتياطي الافتراضي بالكود) | — | احتفظ (احتياطي) |
| `desert` | خريطة قديمة (كانت لـ m0–m2 قبل نقلها إلى front) | — | قرارك |
| `arctic` | خريطة قديمة | — | قرارك |
| `canyon` | خريطة قديمة | — | قرارك |
| `night` | خريطة قديمة (ليلية) | — | قرارك |
| `greenland` | خريطة GLB (greenland.bin) | — | قرارك |
| `map7` | خريطة GLB (map7.bin) | — | قرارك |
