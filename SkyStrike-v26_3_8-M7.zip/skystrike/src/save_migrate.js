/* ترحيل الحفظ (دالة صرفة، تعمل على كائن الحفظ بالمكان). مفتاح التخزين يبقى skystrike_v2 (قاعدة R9).
   mv = نسخة بنية المهمات: undefined = حفظ ما قبل المهمات (موجات/أنماط/حملة قديمة) ← 1.
   لا يُفقد شيء ذو قيمة: العملات/الجواهر/XP/الطائرات/الأسلحة/الألوان/الإعدادات/أعلى النتائج كلها تبقى.
   ما يُزال: حالة المهام اليومية/الأسبوعية (تتجدد أصلاً) ونمط اللعب القديم. تقدّم الحملة القديمة يُحفظ بـ cpOld
   ويبدأ S.cp من الصفر لأنه صار يعني «عدد المهمات المنجزة بالترتيب». */
import {normalizeMs} from './mission/progress.js';
export const MV = 1;
export function migrate(s){
  if(!s || typeof s !== 'object') return s;
  if(s.mv === undefined){
    s.cpOld = s.cp | 0; s.cp = 0;
    delete s.mode; delete s.mis; delete s.wk;
  }
  s.ms = normalizeMs(s.ms);
  s.cp = Math.max(0, s.cp | 0);
  s.mv = MV;
  return s;
}
