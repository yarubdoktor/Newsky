/* الواجهة أثناء اللعب: HUD النصي، مربع القفل، مؤشر التصويب (Lead)، أسهم خارج الشاشة، الرادار. */
import {$,clamp,VW,VH} from './util.js';
import {S} from './save.js';
import {t} from './i18n.js';
import {sfx,setIntensity} from './audio.js';
import {cam,ind,ix,V} from './core.js';
import {W,P} from './state.js';
import {el} from './ui.js';
import {objectiveLines,compassLine} from './mission/mission_hud.js';
import {isHostile,sideOf,colorOf} from './mission/factions.js';

/* صاروخ معادٍ موجّه نحوي (وليس نحو حليف): هو الذي يُنذر اللاعب */
const atMe = p => p.owner === 'e' && p.mis && (!p.target || p.target === P);

const _a = V(), _b = V(), _c = V();

export function hudUpdate(dt){
  const G = W.G, candE = W.candE, lockE = W.lockE, enemies = W.units, projs = W.projs;
  if(candE && !G.dead){ _a.copy(candE.g.position).project(cam);
    if(_a.z < 1){ const c = lockE ? '#ff4d5e' : '#ffd24d'; el.lkb.style.display = 'block'; el.lkb.style.left = ((_a.x*.5+.5)*VW())+'px'; el.lkb.style.top = ((-_a.y*.5+.5)*VH())+'px';
      el.lkb.style.borderColor = c; el.lkb.style.color = c; el.lkb.style.borderStyle = lockE ? 'solid' : 'dashed'; el.lkb.textContent = (W.lockDist|0)+'m'; }
    else el.lkb.style.display = 'none'; } else el.lkb.style.display = 'none';
  leadUpdate(); indUpdate();
  G.hudT -= dt; if(G.hudT > 0) return; G.hudT = .09;
  const pos = P.g.position;
  el.hp.style.width = Math.max(0,P.hp/P.maxhp*100)+'%'; el.sc.textContent = G.score;
  el.cmb.textContent = G.mult > 1 ? `${t('combo')} ×${G.mult}` : '';
  const cmp = G.ms && G.snap ? compassLine(G.ms,G.snap,P.yaw) : '';
  const head = objectiveLines(G.ms,t).join('<br>')+(cmp ? '<br>'+cmp : '');
  el.st.innerHTML = `${head}<br>MSL ${P.msl}${S.multi?` · MUL ${P.mul}`:''}${S.bomb?` · BMB ${P.bmb}`:''} · FLR ${P.flr}<br>ALT ${pos.y|0} m · ${P.cur*3.2|0} km/h${S.fm ? ` · ${P.gl.toFixed(1)}G` : ''}<br>BOOST ${P.en*100|0}%`;
  let warn = '', mis = false;
  for(const p of projs) if(atMe(p) && p.mesh.position.distanceToSquared(pos) < 1000*1000){ mis = true; break; }
  if(mis && !G.dead){ warn = t('missile'); if(G.t-(G.alT ?? -9) > 1){ sfx('alarm'); G.alT = G.t; } } else if(G.pull && !G.dead) warn = t('pullUp');
  el.warn.textContent = warn; el.warn.style.opacity = warn ? 1 : 0;
  setIntensity(clamp(enemies.length/8+(P.hp < P.maxhp*.3?.2:0),0,1));
  if(el.fps.style.display !== 'none') el.fps.style.display = S.fps ? 'block' : 'none';
  radar();
}

/* ---------- مؤشر التصويب (Lead) ---------- */
function leadUpdate(){
  const ld = el.ld, candE = W.candE, lockDist = W.lockDist;
  if(W.G.dead || !candE || !candE.vel || lockDist > 1000){ ld.style.display = 'none'; return; }
  const ep = candE.g.position, pp = P.g.position; let tt = lockDist/750;
  for(let k=0;k<2;k++){ _c.copy(ep).addScaledVector(candE.vel,tt); tt = _c.distanceTo(pp)/750; }
  _c.copy(ep).addScaledVector(candE.vel,tt).project(cam);
  if(_c.z >= 1){ ld.style.display = 'none'; return; }
  ld.style.display = 'block'; ld.style.left = ((_c.x*.5+.5)*VW())+'px'; ld.style.top = ((-_c.y*.5+.5)*VH())+'px';
}

/* ---------- أسهم الأعداء خارج الشاشة + تنبيه الصواريخ القادمة ---------- */
function indUpdate(){
  const G = W.G;
  const Wd = ind.width, H = ind.height; ix.clearRect(0,0,Wd,H); if(G.dead) return;
  const cx0 = Wd/2, cy0 = H/2, rx = Wd/2-34, ry = H/2-34, inv = cam.matrixWorldInverse, pp = P.g.position, pulse = .55+.45*Math.sin(G.t*14);
  const mark = (p,col,sz,alpha,ring) => {
    _a.copy(p).applyMatrix4(inv); const n = _b.copy(p).project(cam);
    if(_a.z < 0 && Math.abs(n.x) < .94 && Math.abs(n.y) < .9){
      if(ring){ ix.globalAlpha = alpha; ix.strokeStyle = col; ix.lineWidth = 2.5; ix.beginPath(); ix.arc((n.x*.5+.5)*Wd,(-n.y*.5+.5)*H,sz,0,6.283); ix.stroke(); }
      return; }
    let dx = _a.x, dy = -_a.y; const m = Math.hypot(dx,dy); if(m < 1e-3){ dx = 0; dy = 1; } else { dx /= m; dy /= m; }
    const k = 1/Math.max(Math.abs(dx)/rx,Math.abs(dy)/ry);
    ix.save(); ix.translate(cx0+dx*k,cy0+dy*k); ix.rotate(Math.atan2(dy,dx)); ix.globalAlpha = alpha; ix.fillStyle = col; ix.strokeStyle = '#000a'; ix.lineWidth = 1.5;
    ix.beginPath(); ix.moveTo(sz,0); ix.lineTo(-sz*.7,sz*.75); ix.lineTo(-sz*.35,0); ix.lineTo(-sz*.7,-sz*.75); ix.closePath(); ix.fill(); ix.stroke(); ix.restore();
  };
  for(const e of W.units){ if(!e.air || !isHostile('player',sideOf(e))) continue; const d = e.g.position.distanceTo(pp);
    mark(e.g.position,'#ff3b3b',9+clamp(1-d/1800,0,1)*8,.85,false); }
  for(const e of W.units) if(e.obj) mark(e.g.position,'#5fd8ff',12,.95,true);          // هدف المهمة الرئيسي (أرضي أو جوي)
  for(const p of W.projs){ if(!atMe(p)) continue; if(p.mesh.position.distanceToSquared(pp) > 1300*1300) continue;
    mark(p.mesh.position,'#ffd24d',14,pulse,true); }
  ix.globalAlpha = 1;
}

/* ---------- الرادار ---------- */
const rc = $('#radar'), cx = rc.getContext('2d');
function radar(){
  const G = W.G;
  const Wd = 240, c = 120, R = 1300, k = (c-8)/R; cx.clearRect(0,0,Wd,Wd); cx.save();
  cx.beginPath(); cx.arc(c,c,c-2,0,6.283); cx.fillStyle = 'rgba(8,24,18,.62)'; cx.fill(); cx.strokeStyle = 'rgba(95,227,161,.75)'; cx.lineWidth = 3; cx.stroke(); cx.clip();
  cx.strokeStyle = 'rgba(95,227,161,.25)'; cx.lineWidth = 1.5;
  for(const r of [40,80]){ cx.beginPath(); cx.arc(c,c,r,0,6.283); cx.stroke(); }
  cx.beginPath(); cx.moveTo(c,0); cx.lineTo(c,Wd); cx.moveTo(0,c); cx.lineTo(Wd,c); cx.stroke();
  const a = G.t*2.5; cx.strokeStyle = 'rgba(95,227,161,.5)'; cx.beginPath(); cx.moveTo(c,c); cx.lineTo(c+Math.cos(a)*c,c+Math.sin(a)*c); cx.stroke();
  const p = P.g.position, sn = Math.sin(P.yaw), cs = Math.cos(P.yaw);
  const plot = (wx,wz) => { const dx = wx-p.x, dz = wz-p.z; let X = dx*cs-dz*sn, F = -(dx*sn+dz*cs); const m = Math.hypot(X,F), edge = m > R; if(edge){ X *= R/m; F *= R/m; } return [c+X*k,c-F*k,edge]; };
  if(G.mark){ const [x,y,edge] = plot(G.mark.x,G.mark.z), r = Math.min(G.mark.r*k,c-10); cx.globalAlpha = edge ? .6 : 1; cx.strokeStyle = '#5fd8ff'; cx.lineWidth = 2;
    cx.setLineDash([5,4]); cx.beginPath(); cx.arc(x,y,edge ? 7 : Math.max(r,7),0,6.283); cx.stroke(); cx.setLineDash([]); }
  for(const e of W.units){
    const [x,y,edge] = plot(e.g.position.x,e.g.position.z); cx.globalAlpha = edge ? .55 : 1;
    const ally = sideOf(e) !== 'enemy';           // حليف: لون جهته · عدو: ألوان الأنواع القديمة
    cx.fillStyle = e.obj ? '#5fd8ff' : ally ? colorOf(sideOf(e)) : e.air ? '#ff3b3b' : '#ff9a2f';
    if(e.air){ cx.beginPath(); cx.arc(x,y,6,0,6.283); cx.fill(); } else cx.fillRect(x-5,y-5,10,10);
  }
  cx.globalAlpha = 1; cx.fillStyle = '#9fd8ff'; cx.beginPath(); cx.moveTo(c,c-10); cx.lineTo(c-7,c+8); cx.lineTo(c+7,c+8); cx.closePath(); cx.fill(); cx.restore();
}
