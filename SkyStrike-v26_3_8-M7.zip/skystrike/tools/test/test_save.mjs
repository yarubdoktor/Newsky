/* بند M4 (قاعدة R9): ترحيل الحفظ القديم (موجات/أنماط/حملة) إلى بنية المهمات بلا فقد ما له قيمة. دالة صرفة. */
import {migrate, MV} from '../../src/save_migrate.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ')+m); if(!c) fail++; };
const legacy = () => ({v:2, coins:1234, xp:560, gems:7, sel:'mig29', pl:{f35:3, mig29:2}, gun:2, msl:3, multi:1, bomb:0,
  name:'Ali', scores:[{n:'Ali', s:900, l:3}], sk:{f35:'gold'}, sko:{f35:['gold']}, lg:{last:'2026-01-01', st:2},
  wk:{k:'x', l:[{k:'kj', n:3, p:1, c:0, r:100, g:0}]}, mis:{d:'2026-01-01', l:[]},
  st:{n:12, c:900}, cp:7, mode:'defend',
  map:'desert', q:'high', lang:'ar', sens:1.2});

console.log('ترحيل حفظ قديم:');
let s = migrate(legacy());
ok(s.coins === 1234 && s.xp === 560 && s.gems === 7, 'العملات/XP/جواهر محفوظة');
ok(s.sel === 'mig29' && s.name === 'Ali', 'الطائرة المختارة والاسم محفوظان');
ok(s.pl.f35 === 3 && s.pl.mig29 === 2 && s.gun === 2 && s.msl === 3 && s.multi === 1, 'الطائرات والأسلحة محفوظة');
ok(s.sk.f35 === 'gold' && s.sko.f35[0] === 'gold', 'الألوان محفوظة');
ok(s.lg.st === 2 && s.st.n === 12, 'تسجيل الدخول والإحصاءات محفوظة');
ok(s.map === 'desert' && s.q === 'high' && s.lang === 'ar' && s.sens === 1.2, 'الإعدادات والخريطة محفوظة');
ok(s.scores.length === 1 && s.scores[0].s === 900, 'أعلى النتائج القديمة تبقى مخزّنة');
ok(s.cpOld === 7 && s.cp === 0, 'تقدّم الحملة القديم: يُحفظ بـ cpOld ويبدأ cp من 0');
ok(!('mode' in s) && !('mis' in s) && !('wk' in s), 'حقول النمط والمهام اليومية والأسبوعية تُزال');
ok(JSON.stringify(s.ms) === '{}' && s.mv === MV, 'ms فارغ ونسخة البنية');

console.log('سلامة الترحيل:');
const again = JSON.stringify(migrate(JSON.parse(JSON.stringify(s))));
ok(again === JSON.stringify(s), 'الترحيل مكرّر لا يغيّر شيئاً (idempotent)');
s = migrate({coins:5, mv:1, cp:2, ms:{m0:{stars:3, best:2000, bt:120, n:4, done:true}}});
ok(s.cp === 2 && s.ms.m0.stars === 3 && s.ms.m0.done && !('cpOld' in s), 'حفظ حديث لا يُمسّ');
s = migrate({coins:5, mv:1, ms:{m0:{stars:99, best:-1, bt:'x', n:'y', done:1}, bad:7, nul:null}});
ok(s.ms.m0.stars === 3 && s.ms.m0.best === 0 && s.ms.m0.bt === 0 && s.ms.m0.n === 0 && s.ms.m0.done === true &&
  !('bad' in s.ms) && !('nul' in s.ms), 'إدخالات ms التالفة تُنظّف');
s = migrate({coins:1, ms:'garbage'});
ok(typeof s.ms === 'object' && Object.keys(s.ms).length === 0 && s.cp === 0, 'ms نصي تالف ← كائن فارغ');
s = migrate({coins:1, cp:-3, mv:1});
ok(s.cp === 0, 'cp سالب ← 0');
ok(migrate(null) === null && migrate(undefined) === undefined, 'null/undefined لا ترمي خطأ');
s = migrate({coins:'x'});
ok(s.mv === MV, 'حفظ بقيمة غريبة يمرّ بلا خطأ');

console.log('مفتاح التخزين (قاعدة R9):');
import {readFileSync} from 'node:fs';
const src = readFileSync(new URL('../../src/save.js', import.meta.url), 'utf8');
ok(src.includes("'skystrike_v2'") && src.includes("'skystrike_v1'"), 'المفتاحان skystrike_v2 و v1 كما هما');
ok(/migrate\(s\)/.test(src) && src.indexOf('migrate(s)') < src.indexOf('Object.assign') + 60, 'load() يرحّل قبل الدمج');

if(fail){ console.log('✗ فشل '+fail); process.exit(1); } console.log('✓ نجح الكل');
