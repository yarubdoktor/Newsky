let LANG = 'ar';
export const getLang = () => LANG;
export function setLang(l){ LANG = l === 'en' ? 'en' : 'ar'; if(typeof document !== 'undefined'){ document.documentElement.lang = LANG; document.documentElement.dir = LANG === 'ar' ? 'rtl' : 'ltr'; } }
const D = {
  tSet:['⚙️ الإعدادات','⚙️ Settings'],
  
  r1:['مجنّد','Cadet'], r2:['فضي 🥈','Silver 🥈'], r3:['ذهبي 🥇','Gold 🥇'], r4:['بلاتيني 💎','Platinum 💎'], r5:['أسطورة 👑','Legend 👑'],
  lvl:['مستوى','Level'], max:['MAX','MAX'],
  d_mig29:['طائرتك الأساسية المجانية: سريعة ورشيقة لكن درعها ضعيف','Your free starter: fast and nimble but fragile'], d_su57:['الأرشق والأقوى، تفوّق بالدوران والسرعة','Most agile and powerful, top turn and speed'],
  use:['استخدام','Select'], usedNow:['✅ الطائرة المستخدمة حالياً','✅ Currently selected'], tapUse:['اضغط «استخدام» لتطير بها','Tap “Select” to fly it'],
  unlockHow:['🔓 كيف تفتحها: اشترِ بـ {p} 🪙، واكسب العملات من المعارك والمهام','🔓 Unlock: buy for {p} 🪙, earn coins from battles and missions'],
  buy:['شراء','Buy'], upg:['تطوير','Upgrade'], locked:['🔒 مقفل','🔒 Locked'],
  w_gun:['مدفع GSh-30','GSh-30 Cannon'], w_msl:['R-73 جو-جو','R-73 AAM'], w_bvr:['R-77 بعيد المدى','R-77 BVR'],
  w_multi:['دفعة R-77 متعددة','R-77 Multi-Salvo'], w_bomb:['قنابل FAB-500','FAB-500 Bombs'],
  w_agm:['Kh-29 جو-أرض','Kh-29 AGM'], w_arm:['Kh-31 مضاد رادار','Kh-31 ARM'],
  wd_gun:['ضرر {d}/طلقة · نار متواصلة (FIRE)','{d} dmg/round · continuous (FIRE)'],
  wd_msl:['صاروخ حراري قصير · ضرر {d} · {n} صواريخ (MSL)','IR dogfight missile · {d} dmg · {n} (MSL)'],
  wd_bvr:['رادار متوسط المدى · ضرر {d} · {n} صواريخ · قفل أبعد','BVR radar missile · {d} dmg · {n} · longer lock'],
  wd_multi:['3 صواريخ بدفعة لـ3 أهداف · ضرر {d} · {n} دفعات (MUL)','3-missile salvo · {d} dmg · {n} salvos (MUL)'],
  wd_bomb:['انفجار أرضي واسع · ضرر {d} · {n} قنابل (BMB)','Wide ground blast · {d} dmg · {n} (BMB)'],
  wd_agm:['موجّه جو-أرض · ضرر {d} · {n} · يفضّل الأهداف الأرضية','Guided AGM · {d} dmg · {n} · prefers ground'],
  wd_arm:['مضاد إشعاع · ضرر {d} · {n} · فعّال ضد SAM/رادار','Anti-radiation · {d} dmg · {n} · strong vs SAM/radar'],
  
  sgGfx:['الرسوميات','Graphics'], sgSnd:['الصوت والاهتزاز','Sound & haptics'], sgCtl:['التحكم','Controls'], sgGame:['اللعبة','Game'],
  
  
  
  
  
  
  map_front:['⚔️ الجبهة الغربية','⚔️ Western Front'], map_highlands:['⛰️ المرتفعات','⛰️ The Highlands'], map_gulf:['⚓ الخليج','⚓ The Gulf'],
  map_front_night:['🌙 الجبهة ليلاً','🌙 Front by Night'],
  map_island:['🏝️ جزر استوائية','🏝️ Tropical Isles'], map_desert:['🏜️ الصحراء','🏜️ Desert'], map_arctic:['❄️ القطب المتجمد','❄️ Arctic'], map_canyon:['🏞️ الوادي الأحمر','🏞️ Red Canyon'], map_night:['🌃 مدينة ليلية','🌃 Night City'], map_greenland:['🏔️ جبال غرينلاند','🏔️ Greenland Alps'], map_map7:['⚓ القاعدتان والأساطيل','⚓ Twin Bases'],
  
  claim:['استلام','Claim'], done:['تم ✅','Done ✅'], 
  
  
  sQual:['جودة الرسومات','Graphics quality'], qAuto:['تلقائي','Auto'], qLow:['منخفضة','Low'], qMed:['متوسطة','Medium'], qHigh:['عالية (Bloom)','High (Bloom)'],
  sFps:['عدّاد FPS','FPS counter'], sSnd:['الصوت','Sound'], sMus:['الموسيقى','Music'], sRad:['اللاسلكي','Radio'], sVib:['الاهتزاز','Vibration'],
  sTilt:['التحكم بالميلان (تجريبي)','Tilt control (experimental)'], sTiltInv:['عكس الميلان','Invert tilt'], sAssist:['مساعد تفادي الأرض','Terrain-avoid assist'],
  sSens:['الحساسية','Sensitivity'], sLang:['اللغة','Language'], on:['تشغيل','On'], off:['إيقاف','Off'],
  
  
  
  
  
  outMap:['⚠ ارجع لساحة المعركة','⚠ RETURN TO THE BATTLEFIELD'], pullUp:['⬆ ارفع الطائرة','⬆ PULL UP'], missile:['🚨 صاروخ قادم — FLR!','🚨 MISSILE — FLARES!'],
  lock:['🔒 LOCK','🔒 LOCK'], loading:['جارِ تحميل العالم…','Loading world…'], paused:['متوقف مؤقتاً','PAUSED'], resume:['متابعة','Resume'], quit:['إنهاء المهمة','End mission'],
  autoLow:['⚡ خفّضنا الجودة تلقائياً لسلاسة أعلى','⚡ Quality lowered automatically for smoother play'], combo:['كومبو','COMBO'],
  nLobby:['الرئيسية','Lobby'], nPlanes:['الطائرات','Aircraft'], nWeapons:['الأسلحة','Weapons'], nSettings:['الإعدادات','Settings'], 
  
  soon:['🔜 قريباً','🔜 Coming soon'], close:['إغلاق','Close'],
  
  hangarT:['الهنجر','Hangar'], weaponsT:['الأسلحة والترقيات','Weapons & upgrades'],
  xp:['XP','XP'],
  profileT:['الملف الشخصي','Profile'], pName:['اسم الطيار','Pilot name'], pCoins:['العملات','Coins'], pPlanes:['الطائرات المملوكة','Aircraft owned'], pSaved:['✅ تم حفظ الاسم','✅ Name saved'],
  ab_mig29:['محرك قوي: سرعة Boost أعلى وشحنه يرجع أسرع','Overboost: higher boost speed and faster recharge'],
  ab_su57:['توجيه الدفع: دوران أحدّ أثناء الـ Boost واستهلاك أقل','Thrust vectoring: sharper turns while boosting, lower drain'],
  skinsT:['الألوان','Skins'], skOn:['✅ مستخدم','✅ Equipped'], skBought:['🎨 تم شراء اللون','🎨 Skin unlocked'],
  sk_gray:['رمادي (أصلي)','Stock grey'], sk_desert:['صحراوي','Desert'], sk_forest:['غابات','Forest'], sk_arctic:['قطبي','Arctic'], sk_night:['ليلي','Night'], sk_crimson:['قرمزي','Crimson'], sk_gold:['ذهبي','Gold'],
  loginT:['🎁 مكافأة الدخول اليومي','🎁 Daily login reward'], loginS:['اليوم {d} من 7 · +{c}🪙{g}','Day {d} of 7 · +{c}🪙{g}'],
  claimedL:['+{r}🪙 مكافأة الدخول اليومي','+{r}🪙 daily login reward'],
  
  locking:['… جارٍ القفل','… LOCKING'], sInvY:['عكس محور الطيران (Y)','Invert pitch (Y)'], sTut:['إعادة التعليمات بالمهمة القادمة','Replay tutorial next mission'],
  tut1:['حرّك الجويستيك لتوجيه الطائرة (PC: الأسهم/WASD)','Move the joystick to steer (PC: arrows/WASD)'],
  tut2:['اضغط مطوّلاً على FIRE لإطلاق الرشاش (PC: Space)','Hold FIRE to shoot the cannon (PC: Space)'],
  tut3:['وجّه الأنف نحو عدو حتى يكتمل القفل 🔒 ثم اضغط MSL (PC: M)','Point at an enemy until it locks 🔒 then press MSL (PC: M)'],
  tut4:['اضغط BOOST مطوّلاً للسرعة، يستهلك الشحن ويرجع تلقائياً (PC: Shift)','Hold BOOST for speed: it drains, then recharges (PC: Shift)'],
  tut5:['صاروخ قادم؟ اضغط FLR لقنابل الإنذار وتشتيته (PC: F)','Incoming missile? Press FLR to drop decoy flares (PC: F)'],
  tutDone:['جاهز يا بطل! دمّر الأعداء 🎯','Ready, pilot! Destroy the enemies 🎯'], tutSkip:['تخطي','Skip'],
  /* ---- v16: كاميرا + زعماء بمراحل + حملة + مكافآت المستويات ---- */
  sCam:['زاوية الكاميرا','Camera view'], sFm:['نمط الطيران','Flight model'], fm0:['كلاسيك','Classic'], fm1:['احترافي','Pro'], cam0:['قريبة','Close'], cam1:['متوسطة','Mid'], cam2:['بعيدة','Far'],
  
  
  
  
  
  
  
  
  
  
  
  lvUp:['ارتقيت للمستوى {l}!','Level up! Lv {l}'], lvRwT:['مكافآت المستويات القادمة','Upcoming level rewards'],
  pAvg:['متوسط العملات / مهمة','Avg coins / run'], pRuns:['عدد المهام','Missions played'], qLite:['خفيفة جداً','Ultra-low'],
};
import {MISSION_TEXT} from './mission/mission_text.js';
import {UI_TEXT} from './mission/ui_text.js';
Object.assign(D,MISSION_TEXT,UI_TEXT);                         // نصوص المهمات والجهات (ملف مستقل: قاعدة R4)
export const t = (k,o) => { const e = D[k]; let s = e ? e[LANG === 'en' ? 1 : 0] : k; if(o) for(const x in o) s = s.replace('{'+x+'}',o[x]); return s; };
