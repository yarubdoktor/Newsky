/* سير اللعبة: بدء/نهاية المهمة، الإيقاف المؤقت، حلقة التحديث، الإقلاع. هذا الملف هو "المايسترو" وما فيه منطق قتال أو ذكاء. */
import {$} from './util.js';
import {S,save} from './save.js';
import {PLANES,stats,mslMax,mulMax,bombMax,bvrMax,agmMax,armMax,level,planeFlares,trackRun,SKINS,skinOf,claimLevelRewards} from './data.js';
import {MISSIONS} from './mission/mission_defs.js';
import {beginMission,missionUpdate} from './mission/mission_bridge.js';
import {showComm,showBrief} from './mission/comms_ui.js';
import {evaluate,rewardFor} from './mission/scoring.js';
import {record,chain,isUnlocked,nextIndex} from './mission/progress.js';
import {makeReport} from './mission/debrief.js';
import {Q} from './quality.js';
import {loadGreenland} from './greenland.js';
import {loadMap7} from './map7.js';
import {MAP_IDS} from './maps.js';
import {loadModels,mkJet} from './jets.js';
import {initAudio,setEngine,setEngineKind,setMute,setMusic,setRadio,startMusic,stopMusic,setIntensity,suspendAudio,setAmbience,sfx} from './audio.js';
import {setLang,t} from './i18n.js';
import {createMenu} from './menu.js';
import {renderer,scene,cam,world,fx,applyQuality,setAutoQuality,renderFrame} from './core.js';
import {W,P,shadow} from './state.js';
import {el,banner} from './ui.js';
import {bindPause,pollKeys,resetTilt,resetInput} from './input.js';
import './platform.js';
import {playerUpdate,cameraUpdate,cp,camCfg} from './player.js';
import {kill,hurt,die,clearEntities,projectilesUpdate,flaresUpdate} from './combat.js';
import {enemiesUpdate} from './ai.js';
import {addAir,addGround} from './spawn.js';
import {mkAirJet} from './enemy_jets.js';
import {hudUpdate} from './hud.js';
import {tutBegin,tutEnd,tutUpdate} from './tutorial.js';
import {makePreviews,mapList,mapsPending,genMapPreviews,isGenBusy} from './previews.js';

setLang(S.lang); setMute(!S.snd); setMusic(!!S.mus); setRadio(!!(S.rad??1));

const BTNS = ['#joy','#bf','#bm','#bb','#bw','#bo','#bl'];
let gid = 0;
let MISSION = null, MIDX = -1;                          // المهمة المختارة للبدء + رقمها

/* ================= Game flow ================= */
function startMission(i){                                       // يبدأ مهمة من المهمات (تُفتح بالترتيب)
  const m = MISSIONS[i]; if(!m || W.starting || W.run || !isUnlocked(S.ms,MISSIONS,i)) return;
  MISSION = m; MIDX = i; S.map = MAP_IDS.includes(m.map) ? m.map : 'island'; startGame();
}
async function startGame(){
  if(W.starting || W.run) return; W.starting = true;
  const MS = MISSION, mi = MIDX; MISSION = null;
  while(isGenBusy()) await new Promise(r => setTimeout(r,50));   // انتظر انتهاء توليد معاينات الخرائط
  initAudio();
  $('#lt').textContent = t('loading'); $('#load').classList.add('on'); await new Promise(r => setTimeout(r,40));
  try{
    if(world.id !== S.map) world.setMap(S.map);
    const id = S.sel, st = stats(id);
    scene.remove(P.g); P.g = mkJet(PLANES[id].kind,PLANES[id].col,true,SKINS[skinOf(id)].c); P.g.rotation.order = 'YXZ'; scene.add(P.g); setEngineKind(PLANES[id].kind);
    const sp = world.cfg.spawn || {x:0,z:0};
    let gy = 0; for(let d=0;d<=1400;d+=200) gy = Math.max(gy,world.ground(sp.x,sp.z-d)); const y0 = sp.alt ? world.ground(sp.x,sp.z)+sp.alt : Math.min(gy+170,500);
    Object.assign(P,{yaw:sp.yaw||0,pitch:sp.pitch||0,roll:0,wr:0,wp:0,gl:1,speed:st.speed,hp:st.hp,maxhp:st.hp,turn:st.turn,gcd:0,msl:mslMax(),bvr:(S.bvr?bvrMax():0),mul:mulMax(),bmb:bombMax(),agm:(S.agm?agmMax():0),arm:(S.arm?armMax():0),flr:planeFlares(),bm:PLANES[id].ab.bm,dr:PLANES[id].ab.dr,rc:PLANES[id].ab.rc,tv:PLANES[id].ab.tv,ms:PLANES[id].ab.ms,sx:0,sy:0,en:1,cur:st.speed,bk:0});
    P.g.position.set(sp.x,y0,sp.z); P.g.visible = true; const [cd0,ch0] = camCfg(); cp.set(sp.x+Math.sin(sp.yaw||0)*cd0,y0+ch0,sp.z+Math.cos(sp.yaw||0)*cd0); cam.position.copy(cp); W.shake = 0; resetTilt(); resetInput();
    clearEntities(); fx.clear();
    const G = W.G = {id:++gid,mi,diff:1,score:0,coins:0,xp:0,t:0,kj:0,kg:0,hit:false,combo:0,ct:0,mult:1,hudT:0,dead:false,deadT:0,wait:0,win:false};
    world.stream(P.g.position,true);
    W.run = true; W.paused = false; $('#menu').style.display = 'none'; $('#hud').classList.add('on'); $('#pz').style.display = 'block';
    for(const s of BTNS) $(s).style.display = s === '#joy' ? 'block' : 'flex';
    $('#bw').style.display = S.multi > 0 ? 'flex' : 'none'; $('#bo').style.display = S.bomb > 0 ? 'flex' : 'none';
    el.fps.style.display = S.fps ? 'block' : 'none';
    beginMission(MS); fx.bgEnable(true); setAmbience(true); startMusic(); setIntensity(.15); tutBegin();
  } catch(err){ MISSION = null; throw err;
  } finally { $('#load').classList.remove('on'); W.starting = false; }
}
function finish(win, quit){
  const G = W.G;
  if(!W.run) return; W.run = false; W.paused = false; resetInput(); tutEnd(); $('#pause').classList.remove('on'); suspendAudio(false); setEngine(0); stopMusic();
  $('#hud').classList.remove('on'); for(const s of BTNS) $(s).style.display = 'none'; $('#pz').style.display = 'none'; el.lkb.style.display = 'none';
  clearEntities(); fx.clear(); setAmbience(false); P.g.visible = false; shadow.visible = false;
  const lv0 = level(), def = G.ms.def, idx = G.mi, run = runOf(G, win, quit);
  const res = evaluate(def, run), rew = rewardFor(def, S.ms[def.id], res);
  record(S.ms, def.id, res); S.cp = chain(S.ms, MISSIONS); trackRun(G);
  S.coins += G.coins+rew.c; S.xp += G.xp+rew.xp; S.gems = (S.gems || 0)+rew.g;
  const lr = claimLevelRewards(lv0);                              // مكافآت المستويات الجديدة
  const lvUp = lr ? t('lvUp',{l:lr.to})+' +'+lr.c+'🪙'+(lr.g ? ' +'+lr.g+'💎' : '')
    +(lr.sk.length ? ' 🎨 '+lr.sk.map(k => t('sk_'+k)).join('، ') : '') : '';
  const next = res.win && idx+1 < MISSIONS.length && isUnlocked(S.ms,MISSIONS,idx+1) ? idx+1 : -1;
  const loot = G.coins+'🪙 · '+G.xp+' XP';
  save();
  menu.setDebrief(makeReport(def, G.ms, res, rew, {kj:G.kj, kg:G.kg, allyLost:G.al, hpFrac:run.hpFrac, lvUp, loot, next}, idx));
  menu.show('debrief');
}
/* لقطة نهاية الجولة لدالة التقييم (evaluate) */
function runOf(G, win, quit){
  return {win:!!win, quit:!!quit, t:G.t, hpFrac:Math.max(0,P.hp)/P.maxhp, allyLost:G.al | 0, ff:G.ff | 0, score:G.score,
    kj:G.kj, kg:G.kg, objectives:G.ms.objectives.map(o => ({id:o.id, status:o.status, optional:!!o.optional}))};
}
function setPause(p){
  if(!W.run || W.starting) return; W.paused = p; $('#pause').classList.toggle('on',p); suspendAudio(p); if(p) resetInput();
  if(p){ $('#pt').textContent = t('paused'); $('#prs').textContent = t('resume'); $('#pq').textContent = t('quit'); setEngine(0); }
}
bindPause(() => setPause(!W.paused));
$('#pz').addEventListener('click',() => setPause(true));
$('#pause').addEventListener('click',e => { const b = e.target.closest('button'); if(!b) return;
  if(b.dataset.a === 'resume') setPause(false); if(b.dataset.a === 'quit'){ setPause(false); finish(false,true); } });
document.addEventListener('visibilitychange',() => { if(document.hidden && W.run && !W.paused) setPause(true); });

/* ================= Update ================= */
function update(dt){
  const G = W.G;
  G.t += dt; G.ct -= dt; if(G.ct <= 0 && G.combo){ G.combo = 0; G.mult = 1; }
  if(G.dead){ G.deadT -= dt; if(G.deadT <= 0){ finish(!!G.win); return; } } else { playerUpdate(dt); if(W.tut) tutUpdate(dt); }
  if(G.wait > 0){ G.wait -= dt; if(G.wait <= 0){ finish(!!G.win); return; } }
  enemiesUpdate(dt); projectilesUpdate(dt); flaresUpdate(dt); missionUpdate(dt);
  // M9+M10: اشتباكات خلفية بعيدة + صوت
  if(fx._bgOn && fx._bgT <= 0){
    const p = P.g.position;
    fx.bgPulse(p.x, p.z, world.ground(p.x, p.z));
    sfx('bgboom', 0.35 + Math.random()*0.4, false, (Math.random()*2-1)*0.7);
    fx._bgT = 1.6 + Math.random()*1.8;
  }
  cameraUpdate(dt); hudUpdate(dt);
}

/* ================= Boot / frame loop ================= */
let PREV = {}, menu = null;
export async function boot(){
  $('#lt').textContent = t('loading'); $('#load').classList.add('on');
  if(!await loadGreenland()){ const i = MAP_IDS.indexOf('greenland'); if(i >= 0) MAP_IDS.splice(i,1); if(S.map === 'greenland') S.map = 'island'; }
  if(!await loadMap7()){ const i = MAP_IDS.indexOf('map7'); if(i >= 0) MAP_IDS.splice(i,1); if(S.map === 'map7') S.map = 'island'; }
  if(!MAP_IDS.includes(S.map)) S.map = 'island';   // خريطة محفوظة قديمة (مثل archipelago بـ v23) أو ما تحمّلت
  applyQuality(); world.setMap(S.map);
  await loadModels();                       // نماذج الطائرات (MiG-29/Su-57 للاعب، F-35 للعدو). إذا فشل نموذج يستعمل المجسم البرمجي تلقائياً
  PREV = makePreviews();
  menu = createMenu({startMission,applyQuality,previews:() => PREV,maps:mapList,mapsPending,genMapPreviews,rePrev:() => { PREV = makePreviews(); }});
  menu.show('lobby'); $('#load').classList.remove('on');
  renderer.setAnimationLoop(frame);
}

let last = performance.now(), pf = 0, pt = 0, lowN = 0;
function onFps(fps){
  if(S.fps) el.fps.textContent = Math.round(fps)+' FPS · '+Q.name;
  if(S.q !== 'auto' || !W.run || W.paused || W.G.dead) return;
  if(fps < 40) lowN++; else lowN = Math.max(0,lowN-1);
  if(lowN >= 4 && Q.name !== 'lite'){ lowN = -4; setAutoQuality(Q.name === 'high' ? 'med' : Q.name === 'med' ? 'low' : 'lite'); applyQuality(); world.stream(P.g.position,true); banner(t('autoLow')); }
}
function frame(now){
  const dt = Math.min(.05,(now-last)/1000); last = now;
  pf++; pt += dt; if(pt >= 1){ onFps(pf/pt); pf = 0; pt = 0; }
  if(W.run && !W.paused){ pollKeys(); update(dt); }
  else if(!W.run) return;   // اللوبي معتم تماماً: لا حاجة لرسم العالم خلفه (يوفّر بطارية الجوال)
  const sdt = W.paused ? 0 : dt; fx.update(sdt); world.follow(cam.position,sdt);
  renderFrame();
}

// خطّاف اختبار (يعمل فقط إذا عرّفت globalThis.__SS_DEBUG قبل التحميل) — لا يؤثر على اللعبة العادية
if(globalThis.__SS_DEBUG) globalThis.__ss = {get menu(){ return menu; },get G(){ return W.G; },get enemies(){ return W.units; },get units(){ return W.units; },get projs(){ return W.projs; },get flares(){ return W.flares; },P,W,S,renderer,MISSIONS,startGame,startMission,kill,hurt,die,finish,setPause,addAir,addGround,banner,showComm,showBrief,cam,scene,mkAirJet};
