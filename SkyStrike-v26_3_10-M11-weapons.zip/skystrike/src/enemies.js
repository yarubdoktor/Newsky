/* ---------- تعريفات الأعداء (v26.3.4: الزعماء الخياليون حُذفوا مع الموجات) ----------
   عدّل أرقام التوازن هنا بدل ما تفتح main.js. الأنواع: jet · ace (نخبة) · bomber · heli · drone · flak · turret · sam ·
   depot + المركبات (VEH). الصعوبة تأتي من difficulty بتعريف المهمة (w أدناه). */

/* ---------- أرقام كل الأعداء (v17: كل أرقام التوازن هنا، ما في أرقام داخل ai.js/spawn.js) ----------
   الصحة الفعلية = hp*(1+صعوبة*HP_SCALE) للطائرات ، و hp+صعوبة*hpw للأرضيات (الصعوبة = difficulty المهمة).
   gun/msl: range = المدى ، cd = زمن إعادة الرمي ، dmg+صعوبة*dmgw = الضرر ، speed = سرعة القذيفة */
export const HP_SCALE = .12;

/* ---------- سلوك اشتباك المقاتلات (v26.2.5، بند #9) — يقرأه ai_jet.js ----------
   آلة حالات: atk (هجوم بزاوية متقدمة) → ext (تمدد وانفصال) → clm (صعود والتفاف) أو rei (عودة بزاوية) ،  evd (مراوغة) ،  flk (التفاف جانبي ينتظر دوره).
   react = زمن رد فعل (ثانية) من ag=1 إلى ag=0 · err = خطأ تقدير موقع اللاعب (م) · break = مسافة الانفصال بعد المرور
   tail* = كشف اللصق على ذيل اللاعب (مسافة/جيب الزاوية/أقصى ثانية قبل إجباره على الانفصال) · cap* = سقف سرعة العدو نسبة لسرعة اللاعب عند القرب */
export const JET_AI = {react:[.22,.6], farReact:1.6, sense:2200, err:16, breakDist:150, breakR:50,
  atkT:[6,10], extT:[2.6,4.4], extDist:700, climbP:.45, climbT:1.5, climbDist:750, offAngle:.4, offT:2.2, enT:2.5,
  tailDist:350, tailCos:-.5, tailMax:2.6, capRatio:.93, capAce:1.0, capMin:75, capDist:520,
  flankDist:650, flankAlt:40, maxAtk:[1,3,3]};          // maxAtk: [أقل، كل كم درجة صعوبة تزيد، أقصى]: المهاجمون المتزامنون = clamp(1+⌊w/3⌋,1,3)
export const AGGR = {base:.3, w:.08};                       // e.ag = min(1, base + صعوبة*w) : يتحكم بالمراوغة وسرعة الرمي
export const MCD0 = [5,10];                                 // أول تأخير لإطلاق الصاروخ

export const JET = {hp:30, r:9, pts:100, sp:105, spw:5, spMax:185, tn:.65, tnw:.035, tnMax:1.5, fl:2, scale:1, mcd0:MCD0,
  gun:{range:550, aim:.15, cd:.45, cdAg:.15, cdMul:1, speed:520, dmg:5, dmgw:.5},
  msl:{from:2, min:450, max:1500, aim:.3, cd:[9,14], n:1, dmg:22, dmgw:1.5, speed:330, turn:1.5, life:9},
  dodge:{range:900, aim:.96, rate:2.5, dur:.8, durR:.6, cd:4, turn:1.4, close:170, closeT:1.6}};
export const ACE = {hp:110, r:10, pts:350, sp:130, spw:5, spMax:205, tn:.9, tnw:.035, tnMax:1.75, fl:4, scale:1.15, mcd0:[3,6],
  gun:{...JET.gun, cdMul:.7},
  msl:{...JET.msl, from:0, cd:[5,8], n:2},          // from:0 = النخبة تطلق صواريخ من أول موجة
  dodge:JET.dodge};
export const BOMBER = {hp:110, r:18, pts:300, sp:72, tn:.35,
  gun:{range:650, cd:.5, speed:480, dmg:5, dmgw:.4}};
export const HELI = {hp:55, r:9, pts:180, sp:60, tn:.9,
  gun:{range:750, aim:.25, cd:1.8, speed:480, dmg:6, dmgw:.5, spread:.05}, near:260, far:420};
export const DRONE = {hp:14, sp:190, spw:3, tn:2.2, r:6, pts:60, ram:12,   // ram = ضرر الاصطدام (+الصعوبة)
  ramDist:38, gun:{range:420, aim:.2, cd:1.2, speed:520, dmg:3, dmgw:.3}};
export const FLAK  = {hp:70, hpw:10, r:10, pts:260,
  gun:{range:950, cd:2.4, burst:5, spread:35, speed:520, dmg:4, dmgw:.4}};
export const TURRET = {hp:40, hpw:8, r:9, pts:150,
  gun:{range:800, cd:1.7, speed:420, dmg:7, dmgw:1}};
export const SAM = {hp:50, hpw:8, r:9, pts:220,
  msl:{min:180, max:1300, cd:[5,6.5], minAlt:25, speed:360, dmg:24, dmgw:1.5, turn:1.4, life:9}};
/* ذكاء الأرضيات (v26.2.6، بند #9). المنطق بـ ai_ground.js. sense = مدى الالتقاط × مدى السلاح · acq = زمن الالتقاط الأول (ث)
   slew = سرعة دوران البرج (راد/ث) · tol = تفاوت التصويب قبل بدء التحذير (راد) · warn = زمن التحذير قبل الرشقة (ث)
   commit = آخر ثوانٍ يُثبَّت فيها الهدف (مراوغة ممكنة) · err = خطأ تقدير الهدف (م) × (1.4 − عدوانية)
   patterns: w وزن الاختيار · n طلقات (رقم أو [أقل،أكثر]) · gap فاصل بينها · cd تبريد · minW أول درجة صعوبة ·
   warnMul/errMul/spreadMul/lead تعديلات النمط (lead = تقدّم إضافي أمام اللاعب لقطع مساره)
   crew: الوحدات المطلِقة معاً = clamp(1+⌊صعوبة/crewEvery⌋,1,crewMax) · stagger = أقل فاصل (ث) بين بدايات رشقات الوحدات */
export const GROUND_AI = {sense:1.25, acq:[.8,1.6], commit:.22, crewEvery:2, crewMax:4, stagger:.5,
  slew:{turret:1.9, flak:1.2, sam:1.4}, tol:{turret:.07, flak:.16, sam:.5},
  warn:{turret:.5, flak:.75, sam:.9}, err:{turret:16, flak:10, sam:0},
  patterns:{
    turret:[{id:'burst', w:5, n:[2,3], gap:.13, cd:2.2},
            {id:'snipe', w:2, n:1, gap:0, cd:2.4, warnMul:1.8, errMul:.3},
            {id:'suppress', w:3, n:[3,5], gap:.2, cd:2.3, errMul:2.2, lead:.5}],
    flak:[{id:'barrage', w:5, n:1, gap:0, cd:2.4},
          {id:'double', w:3, n:2, gap:.55, cd:3.2},
          {id:'wall', w:2, n:3, gap:.4, cd:3.6, spreadMul:1.5}],
    sam:[{id:'single', w:5, n:1, gap:0, cd:[5,6.5]},
         {id:'pair', w:3, n:2, gap:1.1, cd:[6,8], minW:4}]}};
export const DEPOT = {hp:220, hpw:60, r:18, pts:600};


/* ---------- المركبات الأرضية المتحركة (v26.3.3، M2): دبابة · ناقلة جند · شاحنة — يقرؤها vehicles.js / vehicle_ai.js ----------
   size = أكبر بُعد بالنموذج (م) · scale = مضاعف التكبير (كالأرضيات) · r = size×scale×0.42 (نصف قطر التصادم)
   sp = السرعة م/ث · turn = راد/ث · muz = ارتفاع الفوهة · barrel = بعد الفوهة عن مركز المركبة
   sense = مدى إحساسها بالأعداء (0 = لا تشتبك) · gun.air = أقصى مدى ضد الطائرات · gun.turn = سرعة دوران البرج */
export const VEH = {
  tank: {hp:260, size:8.7, scale:2.2, sp:14, turn:1.0, muz:6, barrel:9, pts:150, sense:1300, engage:.4,
    gun:{range:950, air:600, cd:2.4, dmg:16, dmgw:.5, speed:430, spread:.012, turn:1.3}},
  apc:  {hp:170, size:7.8, scale:2.2, sp:18, turn:1.3, muz:5, barrel:6, pts:100, sense:1000, engage:.5,
    gun:{range:700, air:450, cd:.55, dmg:3, dmgw:.15, speed:520, spread:.03, turn:1.8}},
  truck:{hp:90, size:8.4, scale:2.2, sp:16, turn:1.2, muz:0, barrel:0, pts:60, sense:0, engage:1, gun:null}
};
export const ACTIVE_CAP = 24;      // أقصى وحدات بكامل الذكاء؛ الأبعد تُبسَّط (حركة فقط) — لأداء الجوال
