import {S,save} from './save.js';
export const PLANES = {
  // up = معامل تكلفة الترقية ، fl = عدد قنابل الإنذار (Flares)
// ab = ميزة الطائرة: bm سرعة الـBoost (×) ، dr استهلاك الشحن ، rc سرعة الشحن ،
//      tv مضاعف الدوران أثناء الـBoost (توجيه الدفع) ، ms مضاعف تتبع صواريخ العدو (التخفّي، أقل = أصعب عليهم)
  mig29:{n:'MiG-29 Fulcrum',       speed:170, turn:1.3,  hp:75,  price:0,    col:0x6f8f6a, kind:1, up:.8, fl:3,  ab:{bm:1.6, dr:.42, rc:.2,  tv:1,   ms:1}},
  su57: {n:'Su-57 Felon (Sukhoi)', speed:175, turn:1.55, hp:115, price:4500, col:0x4b5563, kind:2, up:1.5,fl:5,  ab:{bm:1.45,dr:.3,  rc:.12, tv:1.3, ms:.85}}
};
export const level = () => Math.floor(Math.sqrt(S.xp/60)) + 1;
export const RANKS = [[35,'r5'],[20,'r4'],[10,'r3'],[5,'r2'],[0,'r1']];
export const rankKey = l => RANKS.find(r => l >= r[0])[1];
export const stats = id => { const l = S.pl[id], P = PLANES[id];
  return {speed:P.speed*(1+(l-1)*.06), turn:P.turn*(1+(l-1)*.05), hp:P.hp*(1+(l-1)*.12)}; };
/* M11: أسلحة موسّعة + سعة أعلى
   gun  رشاش · msl R-73 جو-جو قصير · bvr R-77 متوسط · multi دفعة متعددة
   bomb قنابل حرة · agm Kh-29 جو-أرض · arm Kh-31 مضاد رادار */
export const gunDmg = () => 7 + 3*S.gun;
export const mslDmg = () => 55 + 28*S.msl;
export const mslMax = () => 5 + S.msl * 2;          // كان 3+lvl → سعة أعلى
export const bvrDmg = () => 75 + 32*(S.bvr||0);
export const bvrMax = () => 2 + (S.bvr||0);          // صواريخ BVR أقل عدداً وأقوى
export const mulDmg = () => 35 + 16*S.multi;
export const mulMax = () => 2 + S.multi;             // دفعات أكثر
export const bombDmg = () => 100 + 45*S.bomb;
export const bombMax = () => 5 + 2*S.bomb;           // كان 3+2lvl
export const agmDmg = () => 120 + 50*(S.agm||0);
export const agmMax = () => 3 + (S.agm||0);
export const armDmg = () => 110 + 45*(S.arm||0);     // مضاد رادار/سام
export const armMax = () => 2 + (S.arm||0);
export const planeFlares = () => (PLANES[S.sel] || PLANES.mig29).fl + Math.min(2, S.gun|0); // ترقية خفيفة
export const MAXL = 10, upCost = (l,id) => Math.round(200*l*((PLANES[id]||{}).up||1)/10)*10, wCost = l => 150*l;
export const WPN = {
  gun:  {ic:'🔫', price:0,    role:'gun'},
  msl:  {ic:'🚀', price:0,    role:'aa'},    // R-73
  bvr:  {ic:'📡', price:1800, role:'aa'},    // R-77 BVR
  multi:{ic:'🎆', price:1200, role:'aa'},
  bomb: {ic:'💣', price:600,  role:'ag'},
  agm:  {ic:'🎯', price:2000, role:'ag'},    // Kh-29
  arm:  {ic:'📶', price:2200, role:'sead'}   // Kh-31
};
export const dayKey = () => new Date().toISOString().slice(0,10);
/* إحصاءات الطلعات (للملف الشخصي): عدد الطلعات ومجموع العملات. تُستدعى من game.js › finish */
export function trackRun(G){ S.st = S.st || {n:0,c:0}; S.st.n++; S.st.c += G.coins; }
export const avgCoins = () => (S.st && S.st.n) ? Math.round(S.st.c/S.st.n) : 0;

/* ---------- مكافأة الدخول اليومي (سلسلة 7 أيام، اليوم 7 فيه جواهر) ---------- */
const LOGIN = [100,150,200,250,300,400,500];
const ydayKey = () => new Date(Date.now()-864e5).toISOString().slice(0,10);
export function loginInfo(){
  const L = S.lg || {last:'',st:0}, today = dayKey();
  const day = L.last === today ? (L.st||1) : (L.last === ydayKey() ? (L.st%7)+1 : 1);
  return {can:L.last !== today, day, coins:LOGIN[day-1], gems:day === 7 ? 10 : 0};
}
export function claimLogin(){
  const r = loginInfo(); if(!r.can) return null;
  S.coins += r.coins; S.gems = (S.gems||0)+r.gems; S.lg = {last:dayKey(), st:r.day}; save(); return r;
}

/* ---------- ألوان الطائرات (Skins) تُشترى بالجواهر 💎 ---------- */
const sk = (c,g,sw) => ({c,g,sw:sw ?? c});
export const SKINS = {
  gray:sk(null,0,0x9099a5), desert:sk(0xc9b074,25), forest:sk(0x5f7d4e,25), arctic:sk(0xe2ebf4,40),
  night:sk(0x22252b,40), crimson:sk(0x9b2d2d,60), gold:sk(0xd4af37,120)
};
export const skinOf = id => { const k = S.sk && S.sk[id]; return SKINS[k] ? k : 'gray'; };
export const skinOwned = (id,k) => k === 'gray' || !!(S.sko && S.sko[id+':'+k]);
export function useSkin(id,k){ if(!SKINS[k] || !skinOwned(id,k)) return false; S.sk = S.sk || {}; S.sk[id] = k; save(); return true; }
export function buySkin(id,k){
  if(!SKINS[k] || skinOwned(id,k) || (S.gems||0) < SKINS[k].g) return false;
  S.gems -= SKINS[k].g; S.sko = S.sko || {}; S.sko[id+':'+k] = 1; S.sk = S.sk || {}; S.sk[id] = k; save(); return true;
}
/* ---------- مكافآت المستويات (v16) ----------
   كل مستوى: عملات. كل 5 مستويات: جواهر. مستويات معينة: لون (Skin) مجاني لكل الطائرات.
   تُمنح عند نهاية المهمة لكل مستوى جديد (S.lvr = آخر مستوى استلمت مكافأته). */
const SKIN_AT = {3:'desert',6:'forest',9:'arctic',12:'night',15:'crimson',20:'gold'};
export const lvReward = l => ({c:100+l*40, g:l%5===0 ? l : 0, sk:SKIN_AT[l]||null});
export function claimLevelRewards(lv0){
  const L = level(); if(S.lvr == null) S.lvr = lv0;       // الحسابات القديمة: ما نعطي بأثر رجعي
  const o = {to:L,c:0,g:0,sk:[]}; let any = false;
  for(let l=S.lvr+1;l<=L;l++){ const r = lvReward(l); any = true; S.coins += r.c; S.gems = (S.gems||0)+r.g; o.c += r.c; o.g += r.g;
    if(r.sk){ S.sko = S.sko || {}; for(const id in PLANES) S.sko[id+':'+r.sk] = 1; o.sk.push(r.sk); } }
  S.lvr = Math.max(S.lvr,L); return any ? o : null;
}
