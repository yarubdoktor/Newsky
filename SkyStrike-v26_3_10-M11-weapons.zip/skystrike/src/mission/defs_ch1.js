/* الفصل الأول «الجبهة الغربية» (m0–m4): خريطة front. الموقع المسمّى بمسرح src/theater/terrains.js */
import {at, near, aa, sam, dep, air, FAIL} from './defs_kit.js';

const BASE = at('alpha', 0);

export const CH1 = [
  { id:'m0', map:'front', title:'m0t', intro:'m0i', difficulty:1,
    reward:{c:300, g:0, xp:100}, par:240,
    entities:[
      dep('depot', at('e_pass_w', 40)),
      aa('aa1', 'depot', 110), aa('aa2', 'depot', 130, 'enemy', 1), sam('sam1', near('depot', 150))
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m0o1', targets:['depot']},
      {id:'o2', type:'rtb', text:'m0o2', pos:BASE, r:700, alt:300, after:['o1']}
    ],
    triggers:[{id:'t1', when:{zone:{pos:at('e_pass_w'), r:1800}}, do:[{comm:'c2'}]}],
    comms:[{id:'c1', from:'cmd', text:'m0c1', at:2}, {id:'c2', from:'gnd', text:'m0c2'}],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}] },

  { id:'m1', map:'front', title:'m1t', intro:'m1i', difficulty:2,
    reward:{c:700, g:5, xp:250}, par:600,
    entities:[
      {id:'cv', kind:'convoy', side:'ally', units:['tank', 'apc', 'truck', 'truck'], gap:34, speed:11,
       pos:at('f_stage', 60),
       route:[at('f_stage', 100, -450, -1500), at('t_ridge', 150, 120, 450), at('t_ridge', 150, -80, -250)]},
      {id:'et1', kind:'tank', side:'enemy', pos:at('t_ridge', 130, -80, -600)},
      {id:'et2', kind:'tank', side:'enemy', pos:near('et1', 130)},
      aa('aa1', 'et1', 220), aa('aa2', 'et2', 200, 'enemy', 1), sam('sam1', near('et2', 240))
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m1o1', targets:['et1', 'et2']},
      {id:'o2', type:'suppress', text:'m1o2', targets:['aa1', 'aa2', 'sam1'], need:2},
      {id:'o3', type:'escort', text:'m1o3', units:['cv1', 'cv2', 'cv3', 'cv4'], need:3},
      {id:'o4', type:'rtb', text:'m1o4', pos:BASE, r:700, alt:300, after:['o1', 'o2', 'o3']},
      {id:'o5', type:'destroy', text:'m1o5', targets:['rh1'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('t_ridge'), r:2200}}, do:[{comm:'c2'}]},
      {id:'t2', when:{dead:'et1'},
       do:[{spawn:[{id:'rh1', kind:'heli', side:'enemy', pos:at('e_pass_w', 200)}]}, {comm:'c3'}]},
      {id:'t3', when:{arrived:'cv1'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m1c1', at:2}, {id:'c2', from:'gnd', text:'m1c2'},
      {id:'c3', from:'cmd', text:'m1c3'}, {id:'c4', from:'ally', text:'m1c4'}
    ],
    fail:FAIL },

  { id:'m2', map:'front', title:'m2t', intro:'m2i', difficulty:2,
    reward:{c:900, g:8, xp:300}, par:330,
    entities:[
      dep('base', at('f_depot', 50), 0, 'ally', false),
      aa('g1', 'base', 90, 'ally'), aa('g2', 'base', 100, 'ally', 1), sam('s1', near('base', 110), 'ally')
    ],
    objectives:[
      {id:'o1', type:'defend', text:'m2o1', sites:['base'], t:150},
      {id:'o2', type:'intercept', text:'m2o2', targets:['b1', 'b2'], limit:260},
      {id:'o3', type:'destroy', text:'m2o3', targets:['j1', 'j2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{t:20}, do:[{spawn:[
        air('b1', 'bomber', -900, -1700), air('b2', 'bomber', -300, -1900)]}, {comm:'c2'}]},
      {id:'t2', when:{t:80}, do:[{spawn:[
        air('j1', 'jet', -1500, -2000), air('j2', 'jet', -100, -2200)]}, {comm:'c3'}]},
      {id:'t3', when:{done:'o2'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m2c1', at:2}, {id:'c2', from:'gnd', text:'m2c2'},
      {id:'c3', from:'gnd', text:'m2c3'}, {id:'c4', from:'cmd', text:'m2c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}] },

  { id:'m3', map:'front', title:'m3t', intro:'m3i', difficulty:2,
    reward:{c:1000, g:8, xp:350}, par:420,
    entities:[
      dep('rad', at('e_radar', 40), 1),
      aa('aa1', 'rad', 90), aa('aa2', 'rad', 100, 'enemy', 1),
      sam('sam1', near('rad', 130)), sam('sam2', near('rad', 150)),
      {id:'fl1', kind:'flak', side:'enemy', pos:near('rad', 110)}
    ],
    objectives:[
      {id:'o1', type:'destroy', text:'m3o1', targets:['rad']},
      {id:'o2', type:'suppress', text:'m3o2', targets:['sam1', 'sam2'], need:1, optional:true},
      {id:'o3', type:'destroy', text:'m3o3', targets:['rh1', 'rh2'], optional:true},
      {id:'o4', type:'rtb', text:'m0o2', pos:BASE, r:700, alt:300, after:['o1']}
    ],
    triggers:[
      {id:'t1', when:{zone:{pos:at('e_radar'), r:2600}}, do:[{comm:'c2'}]},
      {id:'t2', when:{zone:{pos:at('e_radar'), r:1400}}, do:[{spawn:[
        {id:'rh1', kind:'heli', side:'enemy', pos:at('e_pass_e', 150)},
        {id:'rh2', kind:'heli', side:'enemy', pos:at('s5', 150)}]}, {comm:'c3'}]},
      {id:'t3', when:{dead:'rad'}, do:[{comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m3c1', at:2}, {id:'c2', from:'gnd', text:'m3c2'},
      {id:'c3', from:'gnd', text:'m3c3'}, {id:'c4', from:'cmd', text:'m3c4'}
    ],
    fail:FAIL },

  { id:'m4', map:'front', title:'m4t', intro:'m4i', difficulty:2,
    reward:{c:1100, g:10, xp:400}, par:360,
    entities:[
      dep('post', at('t_mid', 50, 40, -90), 3, 'ally', false),
      aa('g1', 'post', 90, 'ally'), aa('g2', 'post', 110, 'ally', 1), sam('s1', near('post', 120), 'ally')
    ],
    objectives:[
      {id:'o1', type:'defend', text:'m4o1', sites:['post'], t:170},
      {id:'o2', type:'intercept', text:'m4o2', targets:['d1', 'd2', 'd3', 'd4', 'd5', 'd6'], need:5,
       limit:230},
      {id:'o3', type:'destroy', text:'m4o3', targets:['j1', 'j2'], optional:true}
    ],
    triggers:[
      {id:'t1', when:{t:12}, do:[{spawn:[
        air('d1', 'drone', -600, -1600), air('d2', 'drone', -300, -1700), air('d3', 'drone', 0, -1800)]}, {comm:'c2'}]},
      {id:'t2', when:{t:60}, do:[{spawn:[
        air('d4', 'drone', 1200, -1400), air('d5', 'drone', 1500, -1500),
        air('d6', 'drone', 1800, -1500)]}, {comm:'c3'}]},
      {id:'t3', when:{t:110}, do:[{spawn:[air('j1', 'jet', -400, -2300), air('j2', 'jet', 600, -2400)]}, {comm:'c4'}]}
    ],
    comms:[
      {id:'c1', from:'cmd', text:'m4c1', at:2}, {id:'c2', from:'gnd', text:'m4c2'},
      {id:'c3', from:'gnd', text:'m4c3'}, {id:'c4', from:'cmd', text:'m4c4'}
    ],
    fail:[{type:'playerDead'}, {type:'timeout', t:900}] }
];
