/* نصوص المهمات والجهات (عربي، إنجليزي). تُدمج بـ i18n.js. أسماء الجهات هنا فقط (f_*) ليسهل تعديلها. */
import {TEXT_CH1} from './text_ch1.js';
import {TEXT_CH2} from './text_ch2.js';
import {TEXT_CH3} from './text_ch3.js';
export const MISSION_TEXT = {
  ...TEXT_CH1, ...TEXT_CH2, ...TEXT_CH3,
  f_player:['الطيار','Pilot'], f_ally:['الجيش السوري','Syrian Army'], f_enemy:['الجيش الإسرائيلي','Israeli Army'],
  ffWarn:['⚠ نيران صديقة','⚠ Friendly fire'], ffKill:['أسقطت وحدة صديقة (−نقاط)','Friendly unit lost (−score)'],
  c_cmd:['القيادة','HQ'], c_gnd:['المراقب الأرضي','Ground observer'], c_ally:['قائد الرتل','Convoy lead'], c_mod:['وزارة الدفاع','Ministry of Defense'],
  cm_radio:['لاسلكي','RADIO'], cm_brief:['إحاطة المهمة','BRIEFING'], cm_nav:['الهدف','Objective'],
  cm_n:['شمال','North'], cm_ne:['شمال شرق','North-east'], cm_e:['شرق','East'], cm_se:['جنوب شرق','South-east'],
  cm_s:['جنوب','South'], cm_sw:['جنوب غرب','South-west'], cm_w:['غرب','West'], cm_nw:['شمال غرب','North-west'],
  cm_ahead:['أمامك','Ahead'], cm_left:['يسارك','On your left'], cm_right:['يمينك','On your right'], cm_back:['خلفك','Behind you'],
  m1t:['عملية الرتل','Operation Convoy'],
  m1i:['أمر من وزارة الدفاع: رتل مدرع صديق يتقدم نحو الجبهة. أزل كمين القوة المعادية على الطريق ثم أمّن عودتك.',
       'MoD order: a friendly armored convoy is advancing to the front. Clear the hostile ambush on its route, then return.'],
  m1d:['رتل مدرع صديق (دبابة + ناقلة + شاحنتان) يمر بكمين: دبابتان معاديتان ومدفعان وبطارية SAM. افتح الطريق وأوصل الرتل.',
       'A friendly armored convoy (tank, APC, two trucks) runs into an ambush: two hostile tanks, two guns and a SAM. Open the road.'],
  m1o1:['دمّر دبابتي الكمين','Destroy the two ambush tanks'],
  m1o2:['اقمع الدفاعات الجوية للكمين (2 من 3)','Suppress the ambush air defenses (2 of 3)'],
  m1o3:['أوصل الرتل (3 من 4 على الأقل)','Get the convoy through (at least 3 of 4)'],
  m1o4:['عُد إلى القاعدة','Return to base'],
  m1o5:['أسقط المروحية المعادية (ثانوي)','Shoot down the hostile helicopter'],
  m1c1:['الرتل يتحرك الآن نحو الجبهة. افتح له الطريق قبل أن يبلغ الكمين.','The convoy is moving out. Clear its way before it reaches the ambush.'],
  m1c2:['دبابتان معاديتان ومدفعان وبطارية دفاع جوي أمام الرتل. انتبه للصواريخ.','Two hostile tanks, two guns and a SAM ahead of the convoy. Watch for missiles.'],
  m1c3:['مروحية معادية تقترب من موقعك لدعم الكمين.','A hostile helicopter is closing in to support the ambush.'],
  m1c4:['وصلنا نقطة التجمع. شكراً للإسناد، عُد إلى القاعدة.','We reached the rally point. Thanks for the cover, return to base.'],
  m2t:['عملية الدرع','Operation Shield'],
  m2i:['أمر من وزارة الدفاع: مستودع إمداد الجبهة هدف لقاذفات معادية. اعترضها واحمِ الموقع حتى وصول الدعم.',
       'MoD order: the front supply depot is a target for hostile bombers. Intercept them and hold the site until relief arrives.'],
  m2d:['موقع إمداد صديق بمدفعين وبطارية SAM تهاجمه قاذفتان ثم مقاتلتان معاديتان. اعترض واحمِ الموقع.',
       'A friendly supply site with two guns and a SAM is attacked by two bombers, then two fighters. Intercept and defend it.'],
  m2o1:['احمِ مستودع الإمداد حتى وصول الدعم','Defend the supply depot until relief arrives'],
  m2o2:['اعترض القاذفتين المعاديتين','Intercept the two hostile bombers'],
  m2o3:['أسقط المقاتلتين المرافقتين (ثانوي)','Shoot down the two escort fighters'],
  m2c1:['المستودع تحت حمايتك. توقّع هجوماً جوياً قريباً.','The depot is under your cover. Expect an air attack soon.'],
  m2c2:['قاذفتان معاديتان تقتربان من الموقع. اعترضهما قبل أن تقصفا المستودع.','Two hostile bombers approach the site. Intercept them before they hit the depot.'],
  m2c3:['موجة ثانية: مقاتلتان معاديتان تتجهان نحوكم.','Second wave: two hostile fighters are heading your way.'],
  m2c4:['سقطت القاذفتان. حافظ على الموقع حتى وصول الدعم.','Both bombers are down. Hold the site until relief arrives.'],
  m0b:['من: وزارة الدفاع السورية — إلى: الطيار.\nالموضوع: عملية أول ضوء.\nمستودع ذخيرة معادٍ خلف خط التماس يغذّي ' +
       'القوات الأمامية. دمّره بضربة واحدة. تتوقع دفاعات أرضية خفيفة وبطارية دفاع جوي واحدة.',
       'From: Syrian Ministry of Defense — To: Pilot.\nSubject: Operation First Light.\nA hostile ammunition depot behind ' +
       'the line supplies the front. Destroy it in one strike. Expect light ground defenses and one SAM battery.'],
  m1b:['من: وزارة الدفاع السورية — إلى: الطيار.\nالموضوع: عملية الرتل.\nرتل مدرع صديق يتقدم نحو الجبهة وأمامه كمين معادٍ. ' +
       'أزل الكمين وأخضع دفاعه الجوي، أمّن وصول الرتل، ثم عُد إلى القاعدة. قد تدعم مروحية معادية الكمين.',
       'From: Syrian Ministry of Defense — To: Pilot.\nSubject: Operation Convoy.\nA friendly armored convoy advances to the ' +
       'front with a hostile ambush ahead. Clear the ambush, suppress its air defenses, see the convoy through, then return.'],
  m2b:['من: وزارة الدفاع السورية — إلى: الطيار.\nالموضوع: عملية الدرع.\nموقع إمداد الجبهة هدف لقاذفات معادية تتبعها ' +
       'مقاتلات. اعترض القاذفات واحمِ الموقع حتى وصول الدعم. الموقع محمي بمدفعين وبطارية دفاع جوي.',
       'From: Syrian Ministry of Defense — To: Pilot.\nSubject: Operation Shield.\nThe front supply site is a target for hostile ' +
       'bombers followed by fighters. Intercept the bombers and hold the site until relief arrives.'],
  ms_opt:['ثانوي','optional'], ms_lost:['خسرنا','lost'], ms_title:['المهمات','Missions'], ms_play:['انطلق','Launch'],
  ms_win:['✅ نجحت المهمة','✅ Mission accomplished'], ms_fail:['❌ فشلت المهمة','❌ Mission failed'],
  m0t:['عملية أول ضوء','Operation First Light'],
  m0d:['أمر من وزارة الدفاع: دمّر مستودع الذخيرة المعادي خلف خط التماس. دفاعات أرضية خفيفة وبطارية SAM.',
       'MoD order: destroy the hostile ammunition depot behind the line. Light ground defenses and one SAM battery.'],
  m0i:['وزارة الدفاع ← الطيار: دمّر مستودع الذخيرة','MoD to Pilot: destroy the ammunition depot'],
  m0o1:['دمّر مستودع الذخيرة','Destroy the ammunition depot']
};
