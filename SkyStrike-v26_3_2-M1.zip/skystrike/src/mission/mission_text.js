/* نصوص المهمات والجهات (عربي، إنجليزي). تُدمج بـ i18n.js. أسماء الجهات هنا فقط (f_*) ليسهل تعديلها. */
export const MISSION_TEXT = {
  f_player:['الطيار','Pilot'], f_ally:['الجيش السوري','Syrian Army'], f_enemy:['الجيش الإسرائيلي','Israeli Army'],
  ffWarn:['⚠ نيران صديقة','⚠ Friendly fire'], ffKill:['أسقطت وحدة صديقة (−نقاط)','Friendly unit lost (−score)'],
  ms_opt:['ثانوي','optional'], ms_title:['المهمات','Missions'], ms_play:['انطلق','Launch'],
  ms_win:['✅ نجحت المهمة','✅ Mission accomplished'], ms_fail:['❌ فشلت المهمة','❌ Mission failed'],
  m0t:['عملية أول ضوء','Operation First Light'],
  m0d:['أمر من وزارة الدفاع: دمّر مستودع الذخيرة المعادي خلف خط التماس. دفاعات أرضية خفيفة وبطارية SAM.',
       'MoD order: destroy the hostile ammunition depot behind the line. Light ground defenses and one SAM battery.'],
  m0i:['وزارة الدفاع ← الطيار: دمّر مستودع الذخيرة','MoD to Pilot: destroy the ammunition depot'],
  m0o1:['دمّر مستودع الذخيرة','Destroy the ammunition depot']
};
