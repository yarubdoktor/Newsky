/* اختيار الهدف لأي وحدة (دالة صرفة، بلا three/DOM): أقرب معادٍ ضمن مدى الإحساس، لاعباً كان أو وحدة.
   كل كيان (وحدة أو اللاعب P) له g.position و side. الاستعمال: me.tgt = pickTarget(me, units, P, {range, playerDead}).
   قواعد: (1) العدائية من جدول factions.js (2) تحيّز بسيط للاعب (PLAYER_BIAS) حتى لا تُهمَله الأعداء تماماً
   (3) ثبات: لا نبدّل الهدف الحالي إلا لو ظهر هدف أقرب بوضوح (STICK) كي لا يتذبذب الذكاء (4) null = لا هدف ضمن المدى. */
import {isHostile, sideOf} from './factions.js';

export const TARGET = {
  playerBias:.85,             // مسافة اللاعب تُضرب بهذا الرقم عند المقارنة (< 1 = أفضلية للاعب)
  stick:.7,                   // هدف جديد يُقبل فقط إذا كانت مسافته < stick × مسافة الحالي
  keep:1.15,                  // الهدف الحالي يبقى صالحاً حتى range × keep
  recheck:[.35, .7],          // فاصل إعادة الاختيار (ثانية): عشوائي بين الرقمين لتوزيع الحمل على الفريمات
  air:2600, ground:1900       // مدى الإحساس الافتراضي للطائرات / الأرضيات (م)
};
export const senseRange = u => (u.air ? TARGET.air : TARGET.ground);

const d2 = (a, b) => (a.x-b.x)**2+(a.y-b.y)**2+(a.z-b.z)**2;
export const isLive = (c, units, player, dead) => (c === player ? !dead : c.hp > 0 && units.indexOf(c) >= 0);

export function pickTarget(me, units, player, opts = {}){
  const mp = me.g.position, ms = sideOf(me), range = opts.range ?? senseRange(me), dead = !!opts.playerDead;
  let best = null, bs = Infinity;                              // bs = مسافة² مرجّحة بالتحيّز
  const consider = (c, k) => {
    if(c === me || !isHostile(ms, sideOf(c))) return;
    const d = d2(mp, c.g.position); if(d > range*range) return;
    const s = d*k*k; if(s < bs){ bs = s; best = c; }
  };
  for(const u of units) consider(u, 1);
  if(!dead) consider(player, TARGET.playerBias);
  const cur = me.tgt;
  if(cur && isLive(cur, units, player, dead) && isHostile(ms, sideOf(cur))){
    const cd = d2(mp, cur.g.position), keep = range*TARGET.keep;
    if(cd <= keep*keep){
      const ck = cur === player ? TARGET.playerBias : 1, cs = cd*ck*ck;
      return best && best !== cur && bs < cs*TARGET.stick*TARGET.stick ? best : cur;
    }
  }
  return best;
}
/* لو لا هدف ضمن المدى: اللاعب إن كان معادياً وحياً (سلوك الموجات القديم: الكل يطارد اللاعب) وإلا null */
export const fallbackTarget = (me, player, playerDead) =>
  (!playerDead && isHostile(sideOf(me), 'player') ? player : null);
