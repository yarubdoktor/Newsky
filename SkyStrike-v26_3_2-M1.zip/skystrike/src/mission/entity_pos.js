/* حساب مواضع الكيانات الموضوعة مسبقاً (دالة صرفة، بلا three). يحوّل وصف الموضع بالمهمة إلى مركز بحث {x,z,rad}.
   أنواع الموضع:
     {d, a}        مسافة d (م) من نقطة بداية اللاعب، وزاوية a (راد) عن اتجاه اللاعب عند البداية (+ = يسار)
     {near, r}     قرب كيان آخر موضوع مسبقاً (id) بنصف قطر بحث r
     {x, z, r}     إحداثيات مطلقة
   rad = نصف قطر البحث عن أرض صالحة حول المركز (يتوسّع تلقائياً إن لم توجد). */
export const DEF_RAD = 260;
export const GROUND_KINDS = ['depot', 'turret', 'sam', 'flak'];
export const AIR_KINDS = ['jet', 'ace', 'heli', 'drone', 'bomber'];
export const KINDS = [...GROUND_KINDS, ...AIR_KINDS];

// اتجاه الأمام لزاوية yaw (نفس معادلة ai.js)
export function headingDir(yaw){ return {x:-Math.sin(yaw), z:-Math.cos(yaw)}; }

export function anchorOf(pos, spawn, placed){
  const rad = pos.r ?? DEF_RAD;
  if(pos.near !== undefined){
    const p = placed && placed[pos.near];
    if(!p) throw new Error('entity_pos: near target not placed yet: '+pos.near);
    return {x:p.x, z:p.z, rad};
  }
  if(pos.d !== undefined){
    const h = headingDir((spawn.yaw || 0) + (pos.a || 0));
    return {x:spawn.x+h.x*pos.d, z:spawn.z+h.z*pos.d, rad};
  }
  if(pos.x !== undefined && pos.z !== undefined) return {x:pos.x, z:pos.z, rad};
  throw new Error('entity_pos: bad position');
}
