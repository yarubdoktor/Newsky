/* تعريفات المهمات كبيانات. الحقول:
   id · map · title/intro (مفاتيح i18n بـ mission_text.js) · difficulty (يحل مكان رقم الموجة: يضبط صحة/عدوانية الأعداء)
   entities[]: {id, kind:'depot'|'turret'|'sam'|'flak'|'jet'|'ace'|'heli'|'drone'|'bomber', side, pos, obj?, tt?, alt?}
   objectives[]: {id, type, text, targets[], optional?} · fail[] · triggers[] (M3) · comms[] (M3)
   لإضافة مهمة: أضف كائناً هنا + نصوصها بـ mission_text.js. */
export const MISSIONS = [
  { id:'m0', map:'desert', title:'m0t', intro:'m0i', difficulty:2,
    entities:[
      {id:'depot', kind:'depot', side:'enemy', pos:{d:1700, a:0, r:420}, obj:true},
      {id:'aa1', kind:'turret', tt:0, side:'enemy', pos:{near:'depot', r:150}},
      {id:'aa2', kind:'turret', tt:1, side:'enemy', pos:{near:'depot', r:170}},
      {id:'sam1', kind:'sam', side:'enemy', pos:{near:'depot', r:200}}
    ],
    objectives:[{id:'o1', type:'destroy', text:'m0o1', targets:['depot']}],
    fail:[{type:'playerDead'}], triggers:[], comms:[] }
];

export const missionById = id => MISSIONS.find(m => m.id === id) || null;

/* فحص سلامة تعريف المهمة (يستعمله الاختبار): يرجع قائمة أخطاء (فارغة = سليم) */
export function validateMission(m, kinds, objTypes){
  const err = [], ids = new Set();
  for(const e of m.entities){
    if(ids.has(e.id)) err.push('duplicate entity '+e.id); ids.add(e.id);
    if(!kinds.includes(e.kind)) err.push('bad kind '+e.kind);
    if(!e.pos) err.push('no pos '+e.id);
    else if(e.pos.near !== undefined && !m.entities.slice(0, m.entities.indexOf(e)).some(p => p.id === e.pos.near))
      err.push('near must reference an earlier entity: '+e.id);
  }
  if(!m.objectives.length) err.push('no objectives');
  for(const o of m.objectives){
    if(!objTypes.includes(o.type)) err.push('bad objective type '+o.type);
    for(const id of o.targets || []) if(!ids.has(id)) err.push('objective target missing: '+id);
  }
  return err;
}
