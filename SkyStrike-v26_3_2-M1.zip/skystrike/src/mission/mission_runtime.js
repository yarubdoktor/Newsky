/* آلة حالات المهمة (دالة صرفة، بلا DOM/three/state): تستقبل أحداثاً وتنتج حالة الأهداف ونهاية المهمة.
   الاستعمال:  rt = createRuntime(def) ؛ pushEvent(rt,{type:'entityDead',id}) ؛ out = stepRuntime(rt,dt).
   الأحداث: entityDead{id} · playerDead. شروط الفشل بـ def.fail: {type:'playerDead'} | {type:'timeout',t}.
   المخرجات (out): [{type:'objective',id,status}] و{type:'end',result:'won'|'lost',reason}. تحل مكان waves.js. */
import {makeObjective, feed} from './objectives.js';

export function createRuntime(def){
  return {def, id:def.id, t:0, status:'running', reason:null, q:[], objectives:def.objectives.map(makeObjective)};
}
export const pushEvent = (rt, ev) => { if(rt.status === 'running') rt.q.push(ev); };

function failRule(rt, evs){
  for(const f of rt.def.fail || []){
    if(f.type === 'playerDead' && evs.some(e => e.type === 'playerDead')) return 'playerDead';
    if(f.type === 'timeout' && rt.t >= f.t) return 'timeout';
  }
  return null;
}
export function stepRuntime(rt, dt){
  const out = []; if(rt.status !== 'running') return out;
  rt.t += dt; const evs = rt.q.splice(0, rt.q.length);
  for(const ev of evs) for(const o of rt.objectives){
    const r = feed(o, ev); if(r) out.push({type:'objective', id:o.id, status:r});
  }
  const objFailed = rt.objectives.some(o => !o.optional && o.status === 'failed');
  const reason = failRule(rt, evs) || (objFailed ? 'objective' : null);
  if(reason){ rt.status = 'lost'; rt.reason = reason; out.push({type:'end', result:'lost', reason}); return out; }
  const req = rt.objectives.filter(o => !o.optional);
  if(req.length && req.every(o => o.status === 'done')){
    rt.status = 'won'; out.push({type:'end', result:'won', reason:'objectives'});
  }
  return out;
}
