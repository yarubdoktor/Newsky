# Third-party 3D assets — IRON-FRONT 0.13

## 3DAssets.dev — Tanks, Military Vehicles and Field Camp
- Pack: https://3dassets.dev/packs/armoured-column-and-field-camp
- Licence: CC0 1.0 Universal; commercial use, modification and redistribution permitted without attribution.
- Shared metre scale and muted olive/sand/steel/canvas palette. These selected models are static geometry.

## 3DAssets.dev — Forest Trees and Woodland Plants
- Pack: https://3dassets.dev/packs/temperate-forest-ecology
- Licence: CC0 1.0 Universal; commercial use permitted without attribution.
- Three selected low-poly species are instanced in forest and snow biomes.

| Role | Asset | ID |
|---|---|---:|
| Main battle tank | Light Tank | 23673 |
| Haul truck | Fuel Tanker | 23675 |
| HQ | Command Tent | 23689 |
| Barracks | Squad Tent | 23687 |
| Power | Generator Trailer | 23688 |
| Refinery | Fuel Dump Berm | 23701 |
| Factory | Camouflage Net Frame | 23698 |
| Research | Radar Trailer | 23685 |
| Watchtower / perimeter towers | Guard Tower | 23692 |
| Hospital | Field Hospital Tent | 23690 |
| Ammunition depot | Storage Container | 23702 |
| Vehicle works | Field Office | 23703 |
| Airfield | Helipad Marker | 23699 |
| Missile defence | Mobile Rocket Launcher | 23671 |
| Walls | Sandbag Wall Straight | 23694 |
| Command relay | Command Vehicle | 23681 |
| Base dressing | Gate, supply point, flag, searchlight, ambulance and tanker | 23695, 23705, 23700, 23684, 23676, 23675 |
| Woodland | Mature Oak / Sycamore / Norway Spruce | 3776 / 3775 / 3801 |

The imported models are static; the existing game simulation still controls movement, selection, building health, construction progress and combat. The asset publisher does not provide collision or navigation data.
