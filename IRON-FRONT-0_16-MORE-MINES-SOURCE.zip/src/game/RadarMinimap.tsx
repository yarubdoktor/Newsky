import { useRef } from 'react';
import type { GameState } from './types';
import { visibleTo } from './visibility';
import { mountains, bridges, lakes, RIVER_X } from './navigation';

type ViewRect={x:number;z:number;w:number;h:number};
type Props={state:GameState;viewRect?:ViewRect;onJump:(x:number,z:number)=>void;inline?:boolean};
/** Radar minimap: the whole field at a glance. Tapping or dragging it pans the 3D camera. */
export function RadarMinimap({state,viewRect,onJump,inline}:Props) {
  const miniRef=useRef<SVGSVGElement|null>(null);
  const miniToWorld=(clientX:number,clientY:number):{x:number;y:number}=>{
    const mini=miniRef.current;if(!mini)return{x:0,y:0};
    const p=mini.createSVGPoint();p.x=clientX;p.y=clientY;
    const matrix=mini.getScreenCTM();if(!matrix)return{x:0,y:0};
    const q=p.matrixTransform(matrix.inverse());
    return{x:q.x,y:q.y};
  };
  const handlers={
    onPointerDown:(e:React.PointerEvent)=>{const p=miniToWorld(e.clientX,e.clientY);onJump(p.x,p.y);},
    onPointerMove:(e:React.PointerEvent)=>{if(e.buttons){const p=miniToWorld(e.clientX,e.clientY);onJump(p.x,p.y);}},
  };
  const body=<>
    <rect x="-34" y="-40" width="154" height="80" fill="#0c1618"/>
    <path d={`M${RIVER_X} -40V40`} stroke="#3d6b7a" strokeWidth="2.4"/>
    {lakes.map((l,i)=><circle key={'lake'+i} cx={l.x} cy={l.z} r={l.r} fill="#2f5663"/>)}
    {bridges.map(b=><rect key={b.z} x={RIVER_X-1} y={b.z-1.6} width="2" height="3.2" fill="#8a6f4d"/>)}
    {mountains.map((m,i)=><polygon key={i} points={`${m.x-m.r},${m.z+m.r*.8} ${m.x},${m.z-m.r*.9} ${m.x+m.r},${m.z+m.r*.8}`} fill="#5c6670"/>)}
    {state.zones.map(z=><circle key={z.id} cx={z.x} cy={z.z} r="1.6" fill="none" stroke={z.owner==='player'?'#a8dfb6':z.owner==='enemy'?'#ef9b85':'#dcc78e'} strokeWidth=".5"/>)}
    {state.mines.map((m,i)=><circle key={i} cx={m.x} cy={m.z} r="1.2" fill="#e8cb7f"/>)}
    {state.buildings.map(b=><rect key={b.id} x={b.x-1} y={b.z-.8} width="2" height="1.6" fill="#7dd8a2"/>)}
    {state.opponent.buildings.map(b=><rect key={b.id} x={b.x-1} y={b.z-.8} width="2" height="1.6"
      fill={visibleTo(state,'player',b)?'#ed8e7b':'#ed8e7b44'}/>)}
    {state.units.map(u=><circle key={u.id} cx={u.x} cy={u.z} r="1"
      fill={u.faction==='player'?'#7dd8a2':visibleTo(state,'player',u)?'#ff6b57':'#ff6b5722'}/>)}
    {viewRect&&<rect x={viewRect.x} y={viewRect.z} width={Math.max(4,viewRect.w)} height={Math.max(3,viewRect.h)}
      fill="rgba(232,203,127,.08)" stroke="#e8cb7f" strokeWidth=".7"/>}
  </>;
  if(inline)return <svg ref={miniRef} viewBox="-34 -40 154 80" preserveAspectRatio="none"
    style={{width:'100%',height:'100%',display:'block',touchAction:'none',cursor:'pointer'}}
    aria-label="Radar minimap" role="application" {...handlers}>{body}</svg>;
  return <div className="minimap-wrap">
    <svg ref={miniRef} className="minimap" viewBox="-34 -40 154 80" preserveAspectRatio="none"
      aria-label="Radar minimap" role="application" {...handlers}>{body}</svg>
  </div>;
}
