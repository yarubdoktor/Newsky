import type { GameState, Unit, UnitFaction, UnitOrder } from './types';
import { ENEMY_HQ, PLAYER_HQ } from './combatSystem';

/** A full mixed bundle hauled from the mine to the headquarters per trip. */
const bundle=(kind:Unit['kind'])=>kind==='hauler'
  ?{steel:300,fuel:150,power:100,ammo:100}
  :{steel:50,fuel:25,power:20,ammo:20};
const hqOf=(faction:UnitFaction)=>faction==='player'?PLAYER_HQ:ENEMY_HQ;
const minePool=(mine:GameState['mines'][number])=>mine.steel+mine.fuel+mine.power+mine.ammo;

/**
 * Generals-style economy: laborers and haul trucks shuttle between each faction's
 * rich mine and its HQ along a dedicated route, converting the finite mine pool
 * into real resources. Runs for both factions every tick.
 */
export function advanceHarvest(state:GameState,dt:number):GameState {
  if(state.phase!=='playing')return state;
  const mines=state.mines.map(m=>({...m}));
  const resources={...state.resources},enemyResources={...state.opponent.resources};
  let dirty=false;
  const units=state.units.map(unit=>{
    if(unit.hp<=0||(unit.kind!=='worker'&&unit.kind!=='hauler'))return unit;
    const owned=mines.filter(m=>m.faction===unit.faction);
    if(!owned.length)return unit;
    const hq=hqOf(unit.faction);
    const job=unit.harvest??{phase:'toMine' as const,timer:0};
    const live=owned.filter(m=>minePool(m)>0);
    const nearest=(list:typeof owned)=>list.reduce((a,b)=>
      Math.hypot(unit.x-b.x,unit.z-b.z)<Math.hypot(unit.x-a.x,unit.z-a.z)?b:a);
    /** Several mines per side: keep the current one, otherwise pick the closest and least crowded. */
    const choose=():typeof owned[number]=>{
      if(!live.length)return nearest(owned);
      const going=unit.order==='move'?live.find(m=>Math.hypot(unit.targetX-m.x,unit.targetZ-m.z)<2.6):undefined;
      if(going)return going;
      const here=live.find(m=>Math.hypot(unit.x-m.x,unit.z-m.z)<2.6);
      if(here)return here;
      const crowd=(m:typeof owned[number])=>state.units.filter(v=>v.id!==unit.id&&v.hp>0&&v.faction===unit.faction&&v.harvest&&
        Math.hypot((v.harvest.phase==='toMine'?v.targetX:v.x)-m.x,(v.harvest.phase==='toMine'?v.targetZ:v.z)-m.z)<3).length;
      return live.reduce((a,b)=>Math.hypot(unit.x-b.x,unit.z-b.z)+5*crowd(b)<Math.hypot(unit.x-a.x,unit.z-a.z)+5*crowd(a)?b:a);
    };
    // While digging the unit works the mine it is standing at; otherwise it picks a destination.
    const mine=job.phase==='mining'?nearest(owned):choose();
    if(job.phase==='toMine'){
      if(minePool(mine)<=0)return unit.harvest?{...unit,harvest:undefined}:unit;
      if(Math.hypot(unit.x-mine.x,unit.z-mine.z)<2.6){
        dirty=true;
        return {...unit,harvest:{phase:'mining' as const,timer:unit.kind==='hauler'?2.5:3.5},
          order:'idle' as UnitOrder,targetX:unit.x,targetZ:unit.z,path:[]};
      }
      if(unit.order!=='move'||Math.hypot(unit.targetX-mine.x,unit.targetZ-mine.z)>2.6){
        dirty=true;
        return {...unit,harvest:job,order:'move' as UnitOrder,targetX:mine.x,targetZ:mine.z,targetId:null,path:[]};
      }
      return unit.harvest?unit:{...unit,harvest:job};
    }
    if(job.phase==='mining'){
      const timer=job.timer-dt;
      if(timer>1e-7){dirty=true;return {...unit,harvest:{...job,timer}};}
      if(minePool(mine)<=0)
        return {...unit,harvest:{phase:'toBase' as const,timer:0},order:'move' as UnitOrder,
          targetX:hq.x,targetZ:hq.z,targetId:null,path:[]};
      // Load a bundle from the mine's finite mixed pool.
      const load=bundle(unit.kind);
      const take={steel:Math.min(load.steel,mine.steel),fuel:Math.min(load.fuel,mine.fuel),
        power:Math.min(load.power,mine.power),ammo:Math.min(load.ammo,mine.ammo)};
      mine.steel-=take.steel;mine.fuel-=take.fuel;mine.power-=take.power;mine.ammo-=take.ammo;
      dirty=true;
      return {...unit,harvest:{phase:'toBase' as const,timer:0,load:take},
        order:'move' as UnitOrder,targetX:hq.x,targetZ:hq.z,targetId:null,path:[]};
    }
    // phase === 'toBase': deposit at the HQ, then head back for another load.
    if(Math.hypot(unit.x-hq.x,unit.z-hq.z)<4){
      const carried=job.load??{steel:0,fuel:0,power:0,ammo:0};
      if(unit.faction==='player'){
        resources.steel=Math.min(99999,resources.steel+carried.steel);
        resources.fuel=Math.min(99999,resources.fuel+carried.fuel);
        resources.power=Math.min(99999,resources.power+carried.power);
        resources.ammo=Math.min(99999,resources.ammo+carried.ammo);
      }else{
        enemyResources.steel=Math.min(99999,enemyResources.steel+carried.steel);
        enemyResources.fuel=Math.min(99999,enemyResources.fuel+carried.fuel);
        enemyResources.power=Math.min(99999,enemyResources.power+carried.power);
        enemyResources.ammo=Math.min(99999,enemyResources.ammo+carried.ammo);
      }
      dirty=true;
      return {...unit,harvest:{phase:'toMine' as const,timer:0},
        order:'move' as UnitOrder,targetX:mine.x,targetZ:mine.z,targetId:null,path:[]};
    }
    if(unit.order!=='move'){
      dirty=true;
      return {...unit,harvest:job,order:'move' as UnitOrder,targetX:hq.x,targetZ:hq.z,targetId:null,path:[]};
    }
    return unit;
  });
  if(!dirty)return state;
  return {...state,units,mines,resources,
    opponent:{...state.opponent,resources:enemyResources}};
}
