import type { GameState } from './types';
import { advanceCombat } from './combatSystem';
import { advanceProduction } from './productionSystem';
import { advanceAI } from './aiSystem';
import { advanceLogistics } from './logistics';
import { advanceHarvest } from './harvestSystem';
export { recruit,upgrade,repairBase,UNIT_SPECS } from './productionSystem';
export { makeUnit } from './unitSystem';

export function stepGame(state:GameState,dt=.1):GameState {
  if(state.phase!=='playing')return state;
  let next=advanceProduction(state,dt);
  next=advanceAI(next,dt);
  next=advanceCombat(next,dt);
  next=advanceLogistics(next,dt);
  next=advanceHarvest(next,dt);
  next={...next,tick:Math.round((state.tick+dt)*1e6)/1e6};
  // Engineers provide real nearby recovery; capturing needs uninterrupted numerical superiority.
  const units=next.units.map(u=>{
    const ally=next.units.find(e=>e.faction===u.faction&&e.kind==='engineer'&&e.id!==u.id&&
      Math.hypot(e.x-u.x,e.z-u.z)<4);
    return ally&&u.cooldown===0?{...u,hp:Math.min(u.maxHp,u.hp+1.5*dt)}:u;
  });
  const resources={...next.resources},opponent={...next.opponent,resources:{...next.opponent.resources}};
  const zones=next.zones.map(zone=>{
    const friends=units.filter(u=>u.faction==='player'&&Math.hypot(u.x-zone.x,u.z-zone.z)<3).length;
    const enemies=units.filter(u=>u.faction==='enemy'&&Math.hypot(u.x-zone.x,u.z-zone.z)<3).length;
    let progress=zone.progress;
    if(friends>enemies)progress=Math.min(10,progress+dt);
    if(enemies>friends)progress=Math.max(-10,progress-dt);
    const owner=progress>=10?'player' as const:progress<=-10?'enemy' as const:Math.abs(progress)<.1?'neutral' as const:zone.owner;
    let reserve=zone.reserve;
    if(owner!=='neutral'&&reserve>0&&Math.floor(next.tick)>Math.floor(state.tick)){
      const gain=Math.min(6,reserve);reserve-=gain;
      const target=owner==='player'?resources:opponent.resources;target.steel=Math.min(99999,target.steel+gain);
    }
    return {...zone,progress,owner,reserve};
  });
  next={...next,units,zones,resources,opponent};
  if(next.baseHp<=0||next.enemyHp<=0)next={...next,phase:next.baseHp<=0?'defeat':'victory',
    message:next.baseHp<=0?'FORTRESS LOST / سقطت القاعدة':'OPERATION COMPLETE / تمت المهمة'};
  if(next.message!==state.message)next={...next,events:[...state.events,{time:next.tick,text:next.message}].slice(-30)};
  return next;
}
export function advanceSeconds(state:GameState,seconds:number):GameState {
  let next=state;
  for(let elapsed=0;elapsed<seconds-1e-8;elapsed+=.1)next=stepGame(next,Math.min(.1,seconds-elapsed));
  return next;
}
