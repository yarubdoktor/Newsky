import type { GameState } from './types';
/**
 * Forward logistics: a paid supply truck carries ammunition and fuel from the rear.
 * Standing near friendly frontline units (or the HQ) transfers its cargo into the
 * faction pools until the truck is empty. This is the Phase-1 supply line: simple,
 * deterministic and testable, not a full cargo/passenger simulation.
 */
const HQ = { player:{x:-12,z:4}, enemy:{x:20,z:-4} };
export function advanceLogistics(state:GameState,dt:number):GameState {
  if(state.phase!=='playing')return state;
  let resources={...state.resources},opponentResources={...state.opponent.resources};
  let changed=false;
  const units=state.units.map(u=>{
    if(u.kind!=='supply'||!u.cargo||u.hp<=0||u.cargo.ammo<=0&&u.cargo.fuel<=0)return u;
    const nearFront=state.units.some(v=>v.faction===u.faction&&v.hp>0&&v.kind!=='supply'&&
      Math.hypot(v.x-u.x,v.z-u.z)<6);
    const nearHQ=Math.hypot(HQ[u.faction].x-u.x,HQ[u.faction].z-u.z)<8;
    if(!nearFront&&!nearHQ)return u;
    const ammo=Math.min(2*dt,u.cargo.ammo),fuel=Math.min(1.5*dt,u.cargo.fuel);
    changed=true;
    if(u.faction==='player'){
      resources={...resources,ammo:Math.min(99999,resources.ammo+ammo),fuel:Math.min(99999,resources.fuel+fuel)};
    }else{
      opponentResources={...opponentResources,ammo:Math.min(99999,opponentResources.ammo+ammo),
        fuel:Math.min(99999,opponentResources.fuel+fuel)};
    }
    return {...u,cargo:{ammo:u.cargo.ammo-ammo,fuel:u.cargo.fuel-fuel}};
  });
  return changed?{...state,units,resources,
    opponent:{...state.opponent,resources:opponentResources}}:state;
}
