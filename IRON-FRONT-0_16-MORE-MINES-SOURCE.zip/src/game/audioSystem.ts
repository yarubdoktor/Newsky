class BattleAudio {
  private context:AudioContext|null=null;
  enabled=false;
  async toggle(){
    this.enabled=!this.enabled;
    if(this.enabled){
      this.context??=new AudioContext();
      await this.context.resume();
      this.play('ready');
    }
    return this.enabled;
  }
  play(kind:'shot'|'explosion'|'ready'){
    const c=this.context;if(!this.enabled||!c||c.state!=='running')return;
    const oscillator=c.createOscillator(),gain=c.createGain(),now=c.currentTime;
    oscillator.type=kind==='ready'?'sine':'triangle';
    oscillator.frequency.setValueAtTime(kind==='shot'?150:kind==='explosion'?65:480,now);
    oscillator.frequency.exponentialRampToValueAtTime(kind==='ready'?720:25,now+.16);
    gain.gain.setValueAtTime(kind==='explosion'?.09:.035,now);
    gain.gain.exponentialRampToValueAtTime(.0001,now+.22);
    oscillator.connect(gain);gain.connect(c.destination);oscillator.start(now);oscillator.stop(now+.25);
    oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
  }
}
export const battleAudio=new BattleAudio();
