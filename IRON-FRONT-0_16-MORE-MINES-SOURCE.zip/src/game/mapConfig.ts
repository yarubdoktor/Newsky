/**
 * Single source of truth for the battlefield size (v0.15 "wide map").
 * The enemy half is the player half shifted east by GAP and mirrored around MIRROR_X.
 */
/** Maximum player units (workers and trucks included). */
export const ARMY_LIMIT = 40;
export const GAP = 40;
export const MIRROR_X = 46 + GAP;            // enemy base = MIRROR_X - player base x
export const MAP_BOUNDS = { minX: -34, maxX: 120, minZ: -40, maxZ: 40 };
export const CENTER_X = 23 + GAP / 2;        // middle of the no-man's-land
export const RIVER_X = 32 + GAP / 2;
export const MAP_W = MAP_BOUNDS.maxX - MAP_BOUNDS.minX;
export const MAP_H = MAP_BOUNDS.maxZ - MAP_BOUNDS.minZ;
export const MAP_CX = (MAP_BOUNDS.maxX + MAP_BOUNDS.minX) / 2;
