import type { GameState } from './types';
export function visibleTo(state:GameState,faction:'player'|'enemy',point:{x:number;z:number}):boolean {
  const technologies=faction==='player'?state.technologies:state.opponent.technologies;
  if(state.units.some(u=>u.faction===faction&&u.hp>0&&
    Math.hypot(u.x-point.x,u.z-point.z)<=u.vision*(1+technologies.recon*.35)))return true;
  const buildings=faction==='player'?state.buildings:state.opponent.buildings;
  return buildings.some(b=>b.status==='active'&&Math.hypot(b.x-point.x,b.z-point.z)<(b.kind==='command'?21:9));
}
