import type { Building, BuildingKind, GameState } from './types';
import { BUILDINGS } from './catalog';
import { canAfford, payCost, produceResources } from './economy';

const SLOTS = [
  {x:-18,z:0},{x:-14,z:0},{x:-10,z:0},{x:-6,z:0},
  {x:-18,z:5},{x:-18,z:8.5},{x:-14,z:8.5},{x:-10,z:8.5},{x:-6,z:8.5},
  {x:-6,z:4.5},{x:-21,z:0},{x:-21,z:4},{x:-21,z:8},{x:-2,z:0},{x:-2,z:8},
];
/** Individual destructible barrier segments ring the fortress perimeter; the old static fence is gone. */
const WALL_SLOTS = [
  ...[-22,-19,-16,-13,-10,-7,-4].map(x=>({x,z:-3.4})),
  ...[-22,-19,-16,-13,-10,-7,-4].map(x=>({x,z:11.6})),
  ...[-1,2.5,5,7.5,10].map(z=>({x:-24,z})),
  {x:-1,z:-1},{x:-1,z:10},
];

export function queueBuilding(state: GameState, kind: BuildingKind): GameState {
  if(state.phase!=='playing') return state;
  const spec = BUILDINGS.find(item=>item.kind===kind);
  if (!spec) return {...state,message:'UNKNOWN BUILDING BLUEPRINT'};
  if (!canAfford(state.resources,spec.cost)) return {...state,message:'INSUFFICIENT RESOURCES FOR CONSTRUCTION'};
  if (state.buildings.filter(b=>b.kind===kind).length >= (kind==='wall'?10:kind==='watchtower'?4:1)) return {...state,message:'BUILD LIMIT REACHED FOR THIS STRUCTURE'};
  const occupied = new Set(state.buildings.map(b=>b.x+':'+b.z));
  const pool = kind==='wall'?WALL_SLOTS:SLOTS;
  const slot = pool.find(point=>!occupied.has(point.x+':'+point.z));
  if (!slot) return {...state,message:kind==='wall'?'PERIMETER SEGMENT LIMIT REACHED':'NO AVAILABLE CONSTRUCTION PLOT INSIDE THE FORTRESS'};
  const building: Building = {
    id:'BLD-'+String(state.nextBuildingId).padStart(3,'0'),kind,level:1,hp:kind==='wall'?220:100,maxHp:kind==='wall'?220:100,
    ...slot,status:'constructing',remaining:spec.seconds,buildSeconds:spec.seconds,
  };
  return {...state,resources:payCost(state.resources,spec.cost),buildings:[...state.buildings,building],
    nextBuildingId:state.nextBuildingId+1,message:spec.name+' CONSTRUCTION STARTED'};
}

export function upgradeBuilding(state:GameState,id:string):GameState {
  if(state.phase!=='playing')return state;
  const building=state.buildings.find(b=>b.id===id&&b.status==='active');
  if(!building||building.level>=3)return {...state,message:'UPGRADE UNAVAILABLE / التطوير غير متاح'};
  const base=BUILDINGS.find(b=>b.kind===building.kind)?.cost??{steel:220,fuel:40,power:30};
  const cost={steel:Math.ceil(base.steel*.65*building.level),fuel:Math.ceil(base.fuel*.65*building.level),power:Math.ceil(base.power*.65*building.level)};
  if(!canAfford(state.resources,cost))return {...state,message:'INSUFFICIENT RESOURCES / الموارد غير كافية'};
  return {...state,resources:payCost(state.resources,cost),buildings:state.buildings.map(b=>b.id===id
    ? {...b,level:b.level+1,maxHp:b.kind==='hq'?100:b.maxHp+40,hp:b.kind==='hq'?b.hp:Math.min(b.hp+40,b.maxHp+40),status:'constructing',remaining:10,buildSeconds:10}:b),
    message:'UPGRADE STARTED / بدأ تطوير المنشأة'};
}

export function advanceConstruction(state: GameState, dt=1): GameState {
  const buildings = state.buildings.map(b=>{
    if(b.status!=='constructing') return b;
    const remaining=b.remaining-dt<1e-7?0:Math.max(0,b.remaining-dt);
    return {...b,remaining,status:remaining===0?'active' as const:'constructing' as const};
  });
  const completed=state.buildings.find((b,i)=>b.status==='constructing'&&buildings[i].status==='active');
  const progressed={...state,buildings};
  let withIncome=progressed;
  if(Math.floor(state.tick+dt+1e-7)>Math.floor(state.tick+1e-7)&&state.reserve>0){
    const produced=produceResources(progressed);
    const multiplier=1+state.technologies.industry*.25;
    let budget=state.reserve;
    const resources={...state.resources};
    for(const key of ['steel','fuel','power','ammo'] as const){
      const gain=Math.min(budget,Math.floor((produced[key]-resources[key])*multiplier));
      resources[key]+=gain;budget-=gain;
    }
    withIncome={...progressed,resources,reserve:budget};
  }
  return completed ? {...withIncome,message:BUILDINGS.find(s=>s.kind===completed.kind)?.name+' CONSTRUCTION COMPLETE'} : withIncome;
}
