import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Line, OrbitControls, useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import type { Building, BuildingKind, GameState, Unit, UnitKind } from './types';
import { visibleTo } from './visibility';
import { UNIT_SPECS } from './unitSystem';
import { rocks, mountains, bridges, lakes, RIVER_X, RIVER_HALF } from './navigation';
import { MAP_BOUNDS, MAP_W, MAP_H, MAP_CX, MIRROR_X } from './mapConfig';
import { UnitVisual } from './UnitModels';


function Box({position=[0,0,0],size=[1,1,1],color='#758880'}:{
  position?:[number,number,number];size?:[number,number,number];color?:string}) {
  return <mesh position={position} castShadow receiveShadow><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.72} metalness={.28}/></mesh>;
}
function PerformanceMeter({onDegraded}:{onDegraded?:()=>void}){
  const renderer=useThree(s=>s.gl),counter=useRef({frames:0,time:performance.now(),slow:0});
  useFrame(()=>{
    counter.current.frames++;const now=performance.now();
    if(now-counter.current.time>1000){
      const fps=Math.round(counter.current.frames*1000/(now-counter.current.time));
      if(fps<25&&renderer.shadowMap.enabled){renderer.shadowMap.enabled=false;renderer.shadowMap.needsUpdate=true;}
      const slow=fps<20?counter.current.slow+1:0;
      if(slow>=4)onDegraded?.();
      const element=document.getElementById('performance');
      if(element)element.textContent=`${fps} FPS / ${renderer.info.render.calls} DRAW`;
      counter.current={frames:0,time:now,slow};
    }
  });
  return null;
}
type TreePlacement={x:number;z:number;s:number;r:number};
function InstancedNature({url,placements}:{url:string;placements:TreePlacement[]}){
  const {scene}=useGLTF(url);
  const object=useMemo(()=>{
    const root=new THREE.Group();scene.updateMatrixWorld(true);
    scene.traverse(child=>{
      const source=child as THREE.Mesh;
      if(!source.isMesh)return;
      const instanced=new THREE.InstancedMesh(source.geometry,source.material,placements.length);
      instanced.frustumCulled=false;instanced.castShadow=true;instanced.receiveShadow=true;
      placements.forEach((p,i)=>{
        const position=new THREE.Vector3(p.x,0,p.z);
        const rotation=new THREE.Quaternion().setFromEuler(new THREE.Euler(0,p.r,0));
        const scale=new THREE.Vector3(p.s,p.s,p.s);
        const matrix=new THREE.Matrix4().compose(position,rotation,scale).multiply(source.matrixWorld);
        instanced.setMatrixAt(i,matrix);
      });
      instanced.instanceMatrix.needsUpdate=true;root.add(instanced);
    });
    return root;
  },[scene,placements]);
  return <primitive object={object}/>;
}
const STRUCTURE_MODELS:Record<BuildingKind,string>={
  hq:'/assets/3d/base/command-tent.glb',barracks:'/assets/3d/base/squad-tent.glb',
  power:'/assets/3d/base/generator-trailer.glb',refinery:'/assets/3d/base/fuel-dump-berm.glb',
  factory:'/assets/3d/base/camo-net-frame.glb',research:'/assets/3d/base/radar-trailer.glb',
  watchtower:'/assets/3d/base/guard-tower.glb',hospital:'/assets/3d/base/field-hospital-tent.glb',
  ammo:'/assets/3d/base/storage-container.glb',vehicleFactory:'/assets/3d/base/field-office.glb',
  airfield:'/assets/3d/base/helipad-marker.glb',missile:'/assets/3d/base/mobile-rocket-launcher.glb',
  wall:'/assets/3d/base/sandbag-wall-straight.glb',command:'/assets/3d/base/command-vehicle.glb'
};
const STRUCTURE_FIT:Record<BuildingKind,[number,number,number]>={
  hq:[4.8,3.1,4.2],barracks:[3.7,2.2,3.2],power:[2.8,2,2.5],refinery:[4.2,2.4,3.8],
  factory:[4,2.7,4],research:[3.6,2.7,3.2],watchtower:[2,4.2,2],hospital:[4,2.5,3.8],
  ammo:[3.3,2.5,2.8],vehicleFactory:[3.6,2.6,3.2],airfield:[4.5,.45,4.5],
  missile:[3.9,2.2,3],wall:[3,1.35,.9],command:[3.8,2.8,3.2]
};
function FittedGLB({url,maxSize,enemy=false}:{url:string;maxSize:[number,number,number];enemy?:boolean}){
  const {scene}=useGLTF(url);
  const model=useMemo(()=>{
    const clone=scene.clone(true);
    clone.updateMatrixWorld(true);
    const bounds=new THREE.Box3().setFromObject(clone),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());
    const fit=Math.min(maxSize[0]/Math.max(size.x,.001),maxSize[1]/Math.max(size.y,.001),maxSize[2]/Math.max(size.z,.001));
    clone.scale.setScalar(fit);clone.position.set(-center.x*fit,-bounds.min.y*fit,-center.z*fit);
    clone.traverse(object=>{
      const mesh=object as THREE.Mesh;if(!mesh.isMesh)return;
      mesh.castShadow=true;mesh.receiveShadow=true;
      const tint=new THREE.Color(enemy?'#c68c82':'#b7c2a8');
      const tintMaterial=(material:THREE.Material)=>{
        const copy=material.clone();const standard=copy as THREE.MeshStandardMaterial;
        if(standard.color)standard.color.multiply(tint);
        return copy;
      };
      mesh.material=Array.isArray(mesh.material)?mesh.material.map(tintMaterial):tintMaterial(mesh.material);
    });
    return clone;
  },[scene,maxSize[0],maxSize[1],maxSize[2],enemy]);
  return <primitive object={model}/>;
}
function SafeFittedGLB({url,maxSize,enemy=false,fallbackSize=[2.4,1.2,2.2]}:{url:string;maxSize:[number,number,number];enemy?:boolean;fallbackSize?:[number,number,number]}){
  return <Suspense fallback={<Box position={[0,maxSize[1]/2,0]} size={fallbackSize} color={enemy?'#956659':'#657767'}/> }><FittedGLB url={url} maxSize={maxSize} enemy={enemy}/></Suspense>;
}

const rnd=(n:number)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
const ZONE_SPOTS=[{x:43,z:-28},{x:43,z:-11},{x:43,z:0},{x:43,z:10},{x:43,z:28},{x:6,z:-11},{x:8,z:20},{x:-10,z:-18},{x:26,z:-12},{x:80,z:11},{x:78,z:-20},{x:96,z:18},{x:60,z:12}];
/** True when a decoration (tree, tuft) may stand here: clear of bases, river, roads, lakes, rocks and capture points. */
function freeGround(x:number,z:number,margin:number):boolean {
  if(x>-28&&x<4&&z>-8&&z<16)return false;                       // player base
  if(x>MIRROR_X-4&&x<MIRROR_X+28&&z>-16&&z<8)return false;     // enemy base
  if(Math.abs(x-RIVER_X)<RIVER_HALF+margin+1)return false;
  if(x>-4&&x<90&&Math.abs(z-1.5)<2.5+margin*.4)return false;   // main road
  if(x>12&&x<84&&bridges.some(b=>Math.abs(z-b.z)<2+margin*.4))return false;
  if(lakes.some(l=>Math.hypot(x-l.x,z-l.z)<l.r+margin+1))return false;
  if(rocks.some(r=>Math.hypot(x-r.x,z-r.z)<r.r+margin))return false;
  if(mountains.some(m=>Math.hypot(x-m.x,z-m.z)<m.r+margin))return false;
  return !ZONE_SPOTS.some(q=>Math.hypot(x-q.x,z-q.z)<margin+2.5);
}
/** Soft grass/rock tufts scattered over free ground: one instanced draw call each. */
function Tufts({color,count,seed,size=1}:{color:string;count:number;seed:number;size?:number}){
  const ref=useRef<THREE.InstancedMesh>(null);
  useEffect(()=>{
    const mesh=ref.current;if(!mesh)return;
    const d=new THREE.Object3D();let n=0;
    for(let i=0;i<count*3&&n<count;i++){
      const x=MAP_BOUNDS.minX+rnd(i+seed)*MAP_W,z=MAP_BOUNDS.minZ+2+rnd(i+seed+7000)*(MAP_H-4);
      if(!freeGround(x,z,.8))continue;
      d.position.set(x,.1*size,z);d.rotation.set(0,rnd(i+seed+3000)*6.28,0);d.scale.setScalar((.6+rnd(i+seed+5000)*.9)*size);
      d.updateMatrix();mesh.setMatrixAt(n++,d.matrix);
    }
    mesh.count=n;mesh.instanceMatrix.needsUpdate=true;
  },[count,seed,size]);
  return <instancedMesh ref={ref} args={[undefined,undefined,count]} frustumCulled={false}>
    <coneGeometry args={[.13,.36,4]}/><meshStandardMaterial color={color} roughness={1}/></instancedMesh>;
}
function Terrain({state,rallyMode,onMoveOrder,onSetRally}:{state:GameState;rallyMode:boolean;
  onMoveOrder:(x:number,z:number)=>void;onSetRally:(x:number,z:number)=>void}) {
  const snow=state.biome==='snow',desert=state.biome==='desert';
  const trees=useMemo(()=>{
    const out:{x:number;z:number;s:number}[]=[];
    // Groves give the wide field forests and clearings instead of an even sprinkle of trees.
    for(let g=0;g<26;g++){
      const cx=MAP_BOUNDS.minX+6+rnd(g+1)*(MAP_W-12),cz=-35+rnd(g+40)*70,n=10+Math.floor(rnd(g+80)*14),spread=4.5+rnd(g+120)*5;
      for(let k=0;k<n;k++){const a=rnd(g*100+k)*Math.PI*2,d=Math.sqrt(rnd(g*100+k+50))*spread;
        out.push({x:cx+Math.cos(a)*d,z:cz+Math.sin(a)*d,s:.7+(k%4)*.18});}
    }
    for(let i=0;i<110;i++)out.push({x:MAP_BOUNDS.minX+4+rnd(i+500)*(MAP_W-8),z:-37+rnd(i+700)*74,s:.7+(i%4)*.18});
    return out.filter(p=>freeGround(p.x,p.z,2.6));
  },[]);
  const forestTrees=useMemo(()=>trees.map((t,i)=>({x:t.x,z:t.z,s:.13*t.s,r:(i%7)*.73})),[trees]);
  const oakTrees=useMemo(()=>forestTrees.filter((_,i)=>i%3===0),[forestTrees]);
  const sycamoreTrees=useMemo(()=>forestTrees.filter((_,i)=>i%3===1),[forestTrees]);
  const spruceTrees=useMemo(()=>forestTrees.filter((_,i)=>i%3===2),[forestTrees]);
  const snowTrees=useMemo(()=>forestTrees.map(p=>({...p,s:p.s*1.05})),[forestTrees]);
  const color=snow?'#c0ccc8':desert?'#a18b65':'#4b6150';
  const light=snow?'#dbe6e3':desert?'#b9a074':'#5d7c59',dark=snow?'#a7b8b4':desert?'#8c7852':'#3b5140';
  const patches=useMemo(()=>Array.from({length:60},(_,i)=>({x:MAP_BOUNDS.minX+rnd(i+900)*MAP_W,z:-38+rnd(i+950)*76,
    r:5+rnd(i+990)*10,light:i%2===0})),[]);
  const gridGeo=useMemo(()=>{
    const pts:number[]=[];
    for(let x=MAP_BOUNDS.minX;x<=MAP_BOUNDS.maxX;x+=2)pts.push(x,0,MAP_BOUNDS.minZ,x,0,MAP_BOUNDS.maxZ);
    for(let z=MAP_BOUNDS.minZ;z<=MAP_BOUNDS.maxZ;z+=2)pts.push(MAP_BOUNDS.minX,0,z,MAP_BOUNDS.maxX,0,z);
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));return g;
  },[]);
  const water=snow?'#7fa8b5':'#3d6b7a',bank=snow?'#aebcb8':desert?'#b49d70':'#7d7556',roadColor=snow?'#9baaa6':'#897f69';
  /** Thin strip between two ground points: haul roads and the dirt roads that lead to every bridge. */
  const strip=(ax:number,az:number,bx:number,bz:number,w=.8,opacity=.3,c='#c9b97e')=>{
    const len=Math.hypot(bx-ax,bz-az),mx=(ax+bx)/2,mz=(az+bz)/2,angle=Math.atan2(bz-az,bx-ax);
    return <mesh position={[mx,.035,mz]} rotation={[-Math.PI/2,0,-angle]}><planeGeometry args={[len,w]}/><meshBasicMaterial color={c} transparent opacity={opacity}/></mesh>;
  };
  const road=(ax:number,az:number,bx:number,bz:number,w=2.2,opacity=.8)=>strip(ax,az,bx,bz,w,opacity,roadColor);
  const skyline=(i:number,x:number,z:number)=><mesh key={`${i}:${x}:${z}`} position={[x,2,z]} scale={[5+(i%3),4+(i%4),4]}>
    <coneGeometry args={[1,2,5]}/><meshStandardMaterial color={snow?'#a0b4b1':'#5b6b60'} roughness={1}/></mesh>;
  const edgeX=Math.ceil((MAP_W+12)/7)+1,edgeZ=Math.ceil(MAP_H/7)+1;
  return <group>
    {/* Dark skirt so the horizon never shows empty space beyond the playable field. */}
    <mesh rotation={[-Math.PI/2,0,0]} position={[MAP_CX,-.06,0]}><planeGeometry args={[700,500]}/>
      <meshStandardMaterial color={snow?'#8fa5a2':desert?'#7d6a4a':'#2c4036'} roughness={1}/></mesh>
    <mesh rotation={[-Math.PI/2,0,0]} position={[MAP_CX,0,0]} receiveShadow onClick={e=>{e.stopPropagation();
      if(e.delta>6)return; // a finger drag pans the camera, it is not a tap
      if(rallyMode)onSetRally(e.point.x,e.point.z);else onMoveOrder(e.point.x,e.point.z);}}>
      <planeGeometry args={[MAP_W+8,MAP_H+8]}/><meshStandardMaterial color={color} roughness={1}/></mesh>
    {/* Soft light and dark ground patches break up the flat colour. */}
    {patches.map((p,i)=><mesh key={i} position={[p.x,.012+i*.0003,p.z]} rotation={[-Math.PI/2,0,0]}>
      <circleGeometry args={[p.r,22]}/><meshBasicMaterial color={p.light?light:dark} transparent opacity={.3} depthWrite={false}/></mesh>)}
    {/* The river runs the full depth of the map; five bridges are the only crossings. */}
    <mesh position={[RIVER_X,.02,0]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[RIVER_HALF*2+3,MAP_H+4]}/><meshStandardMaterial color={bank} roughness={1}/></mesh>
    <mesh position={[RIVER_X,.028,0]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[RIVER_HALF*2,MAP_H+4]}/><meshStandardMaterial color={water} roughness={.25} metalness={.35}/></mesh>
    <mesh position={[RIVER_X,.031,0]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[RIVER_HALF*.8,MAP_H+4]}/><meshBasicMaterial color="#9fd0d8" transparent opacity={.22} depthWrite={false}/></mesh>
    {lakes.map((l,i)=><group key={i} position={[l.x,0,l.z]} rotation={[-Math.PI/2,0,0]}>
      <mesh position={[0,0,.02]}><circleGeometry args={[l.r+.9,32]}/><meshStandardMaterial color={bank} roughness={1}/></mesh>
      <mesh position={[0,0,.028]}><circleGeometry args={[l.r,32]}/><meshStandardMaterial color={water} roughness={.25} metalness={.35}/></mesh>
      <mesh position={[l.r*.18,l.r*.12,.031]}><circleGeometry args={[l.r*.55,24]}/><meshBasicMaterial color="#9fd0d8" transparent opacity={.2} depthWrite={false}/></mesh>
    </group>)}
    {bridges.map(b=><group key={b.z} position={[RIVER_X,0,b.z]}>
      <Box position={[0,.14,0]} size={[3.8,.26,5]} color="#8a6f4d"/>
      <Box position={[0,.32,2.4]} size={[3.8,.1,.14]} color="#5f4c33"/><Box position={[0,.32,-2.4]} size={[3.8,.1,.14]} color="#5f4c33"/>
      {[-1.2,-.4,.4,1.2].map(o=><Box key={o} position={[0,.27,o]} size={[3.8,.05,.1]} color="#6b5539"/>)}
    </group>)}
    {mountains.map((m,i)=><mesh key={i} position={[m.x,m.r*.85,m.z]} castShadow><coneGeometry args={[m.r,m.r*1.7,7]}/><meshStandardMaterial color="#5c6670" roughness={1}/></mesh>)}
    {mountains.map((m,i)=><mesh key={'cap'+i} position={[m.x,m.r*1.5,m.z]}><coneGeometry args={[m.r*.38,m.r*.55,7]}/><meshStandardMaterial color="#e6ecef" roughness={1}/></mesh>)}
    {/* Rich mines: gold-flecked rock on each faction's side, joined to its HQ by a haul road. */}
    {state.mines.map((m,mi)=><group key={mi}>
      {m.faction==='player'?strip(-1,4,m.x,m.z,.8,.3):strip(MIRROR_X,-4,m.x,m.z)}
      <group position={[m.x,0,m.z]}>
        <mesh position={[0,.75,0]} castShadow><dodecahedronGeometry args={[1.1,0]}/><meshStandardMaterial color="#4a4038" roughness={.9}/></mesh>
        <mesh position={[.5,1.5,.3]}><octahedronGeometry args={[.32]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
        <mesh position={[-.45,1.3,-.25]}><octahedronGeometry args={[.24]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
        <mesh position={[.1,1.7,-.4]}><octahedronGeometry args={[.2]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
      </group>
    </group>)}
    {/* Rally flag: fresh reinforcements march here. */}
    <group position={[state.rally?.x??-6,0,state.rally?.z??3]}>
      <mesh position={[0,1.1,0]}><cylinderGeometry args={[.05,.05,2.2,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>
      <mesh position={[.45,1.95,0]}><planeGeometry args={[.9,.5]}/><meshBasicMaterial color="#e8cb7f" side={THREE.DoubleSide}/></mesh>
      <mesh rotation={[-Math.PI/2,0,0]} position={[0,.04,0]}><ringGeometry args={[.85,.95,24]}/><meshBasicMaterial color="#e8cb7f" transparent opacity={.55}/></mesh>
    </group>
    {/* Dirt roads: the main road crosses the centre bridge, flank roads lead to the other four. */}
    {road(-2,3,RIVER_X-4,0,3.2,.85)}{road(RIVER_X-4,0,RIVER_X+4,0,3.2,.85)}{road(RIVER_X+4,0,MIRROR_X+1,-4,3.2,.85)}
    {bridges.filter(b=>b.z!==0).map(b=><group key={'road'+b.z}>
      {road(14,b.z,RIVER_X-3,b.z,2.2,.7)}{road(RIVER_X+3,b.z,80,b.z,2.2,.7)}</group>)}
    <lineSegments geometry={gridGeo} position={[0,.018,0]}><lineBasicMaterial color={snow?'#a0b3ad':'#7d8a6e'} transparent opacity={.16}/></lineSegments>
    {/* Rally flag: fresh reinforcements march here. */}
    <group position={[state.rally?.x??-6,0,state.rally?.z??3]}>
      <mesh position={[0,1.1,0]}><cylinderGeometry args={[.05,.05,2.2,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>
      <mesh position={[.45,1.95,0]}><planeGeometry args={[.9,.5]}/><meshBasicMaterial color="#e8cb7f" side={THREE.DoubleSide}/></mesh>
      <mesh rotation={[-Math.PI/2,0,0]} position={[0,.04,0]}><ringGeometry args={[.85,.95,24]}/><meshBasicMaterial color="#e8cb7f" transparent opacity={.55}/></mesh>
    </group>
    <Tufts color={snow?'#e4eeeb':desert?'#b89c62':'#5f8a56'} count={420} seed={2000}/>
    <Tufts color={snow?'#cfdcd8':desert?'#8e7a4e':'#7da05f'} count={300} seed={9000} size={.8}/>
    <Suspense fallback={null}>
      {state.biome==='forest'&&<>
        <InstancedNature url="/assets/3d/nature/mature-oak.glb" placements={oakTrees}/>
        <InstancedNature url="/assets/3d/nature/mature-sycamore.glb" placements={sycamoreTrees}/>
        <InstancedNature url="/assets/3d/nature/mature-spruce.glb" placements={spruceTrees}/>
      </>}
      {snow&&<InstancedNature url="/assets/3d/nature/mature-spruce.glb" placements={snowTrees}/>}
    </Suspense>
    {rocks.map((r,i)=><mesh key={i} position={[r.x,.65,r.z]} scale={[r.r,1.2,r.r]} castShadow><dodecahedronGeometry args={[1,0]}/><meshStandardMaterial color="#707a73" roughness={1}/></mesh>)}
    {/* Mountain skyline walls all the way round the enlarged field. */}
    {Array.from({length:edgeX},(_,i)=>skyline(i,MAP_BOUNDS.minX-6+i*7,MAP_BOUNDS.minZ-3-(i%2)*3))}
    {Array.from({length:edgeX},(_,i)=>skyline(i+100,MAP_BOUNDS.minX-6+i*7,MAP_BOUNDS.maxZ+3+(i%2)*3))}
    {Array.from({length:edgeZ},(_,i)=>skyline(i+200,MAP_BOUNDS.minX-5-(i%2)*3,MAP_BOUNDS.minZ+i*7))}
    {Array.from({length:edgeZ},(_,i)=>skyline(i+300,MAP_BOUNDS.maxX+5+(i%2)*3,MAP_BOUNDS.minZ+i*7))}
  </group>;
}
/** Corner towers remain as decoration; the fence itself is now built as destructible wall segments. */
function CornerTowers({enemy=false}:{enemy?:boolean}) {
  const transform=(x:number,z:number):[number,number,number]=>[enemy?MIRROR_X-x:x,0,enemy?-z:z];
  return <group>
    {[-24,-1].flatMap((x)=>[-3.4,11.6].map(z=><group key={`${x}:${z}`} position={transform(x,z)}>
      <SafeFittedGLB url="/assets/3d/base/guard-tower.glb" maxSize={[2.1,3.9,2.1]} enemy={enemy} fallbackSize={[1.4,2.5,1.4]}/>
    </group>))}
  </group>;
}
function BaseDressing({enemy=false}:{enemy?:boolean}){
  const place=(x:number,z:number):[number,number,number]=>[enemy?MIRROR_X-x:x,0,enemy?-z:z];
  return <group>
    <group position={place(-15,0)}><SafeFittedGLB url="/assets/3d/base/flag-pole.glb" maxSize={[.75,3.1,1.1]} enemy={enemy} fallbackSize={[.2,2.6,.2]}/></group>
    <group position={place(-7.2,9.2)}><SafeFittedGLB url="/assets/3d/base/supply-point.glb" maxSize={[2.3,2.2,2.3]} enemy={enemy}/></group>
    <group position={place(-16.2,8.5)}><SafeFittedGLB url="/assets/3d/base/searchlight.glb" maxSize={[1.2,1.6,1.2]} enemy={enemy}/></group>
    <group position={place(-7.4,-1.8)}><SafeFittedGLB url="/assets/3d/base/fuel-tanker.glb" maxSize={[2.8,1.8,2.2]} enemy={enemy}/></group>
    <group position={place(-16,10.5)}><SafeFittedGLB url="/assets/3d/base/field-ambulance.glb" maxSize={[2.5,1.9,2.3]} enemy={enemy}/></group>
    <group position={place(-18.2,4)}><SafeFittedGLB url="/assets/3d/base/camp-gate.glb" maxSize={[3.8,2.8,1.2]} enemy={enemy}/></group>
    <group position={place(-4.5,-5.5)}><SafeFittedGLB url="/assets/3d/base/recovery-vehicle.glb" maxSize={[2.8,1.8,2.5]} enemy={enemy}/></group>
    <group position={place(-20.5,10.5)}><SafeFittedGLB url="/assets/3d/base/basket-wall-straight.glb" maxSize={[3,1.4,1]} enemy={enemy}/></group>
    <group position={place(-20.5,-7.5)}><SafeFittedGLB url="/assets/3d/base/trench-straight.glb" maxSize={[3.8,1.7,3.2]} enemy={enemy}/></group>
    <group position={place(-16.5,-9.5)}><SafeFittedGLB url="/assets/3d/base/trench-corner.glb" maxSize={[3.6,1.7,3.6]} enemy={enemy}/></group>
  </group>;
}
function Structure({building,enemy=false,onAttackBuilding,onSelectBuilding,selected}:{building:Building;enemy?:boolean;
  onAttackBuilding:(id:string)=>void;onSelectBuilding:(id:string)=>void;selected?:boolean}) {
  const {kind,x,z,status,remaining,buildSeconds}=building;
  const progress=status==='active'?1:1-remaining/buildSeconds;
  return <group position={[x,0,z]} onClick={e=>{e.stopPropagation();if(e.delta>6)return;
      if(enemy)onAttackBuilding(building.id);else onSelectBuilding(building.id);}}>
    {selected&&!enemy&&<mesh rotation={[-Math.PI/2,0,0]} position={[0,.05,0]}><ringGeometry args={[3,3.2,40]}/><meshBasicMaterial color="#e8cb7f"/></mesh>}
    <Box position={[0,.08,0]} size={kind==='hq'?[4.8,.16,4.2]:[3.2,.16,2.8]} color="#34473f"/>
    <group scale={[1,Math.max(.08,progress),1]}>
      <SafeFittedGLB url={STRUCTURE_MODELS[kind]} maxSize={STRUCTURE_FIT[kind]} enemy={enemy}
        fallbackSize={kind==='wall'?[2.8,1.2,.7]:kind==='watchtower'?[1.3,2.8,1.3]:[2.6,1.4,2.2]}/>
    </group>
    <mesh position={[0,.19,1.6]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[2.5*building.hp/building.maxHp,.12]}/><meshBasicMaterial color={enemy?'#ee9683':'#a9d8ab'}/></mesh>
    {building.level>1&&<mesh position={[1.2,1.5,0]}><sphereGeometry args={[.14,6,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>}
  </group>;
}
function UnitMesh({unit,onSelect,onSelectKind}:{unit:Unit;onSelect:(id:number,enemy:boolean,multi:boolean)=>void;onSelectKind:(kind:UnitKind)=>void}) {
  const enemy=unit.faction==='enemy',spec=UNIT_SPECS[unit.kind],vehicle=spec.armor>=2,
    air=!!spec.air,rotation=Math.atan2(unit.targetX-unit.x,unit.targetZ-unit.z);
  return <group position={[unit.x,air?2.7:.1,unit.z]} onClick={e=>{e.stopPropagation();if(e.delta>6)return;onSelect(unit.id,enemy,!!(e.nativeEvent as PointerEvent).shiftKey);}}
    onDoubleClick={e=>{e.stopPropagation();if(!enemy)onSelectKind(unit.kind);}}>
    {/* Original touch target remains independent of the visual model. */}
    <mesh position={[0,.6,0]}><cylinderGeometry args={[vehicle?1.3:.9,vehicle?1.3:.9,1.4,10]}/><meshBasicMaterial transparent opacity={0} depthWrite={false}/></mesh>
    <group rotation={[0,rotation,0]}><UnitVisual kind={unit.kind} enemy={enemy}/></group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,.03,0]}><ringGeometry args={[vehicle?.9:.5,vehicle?1:.6,20]}/><meshBasicMaterial color={unit.selected?'#85e2d1':enemy?'#ef9b85':'#c4d6a8'} transparent opacity={unit.selected?1:.45}/></mesh>
    <group position={[0,1.85,0]}><mesh><planeGeometry args={[.95,.09]}/><meshBasicMaterial color="#152b22"/></mesh>
      <mesh position={[-.475*(1-unit.hp/unit.maxHp),0,.002]}><planeGeometry args={[.95*unit.hp/unit.maxHp,.065]}/><meshBasicMaterial color={enemy?'#ed9b8e':'#a3e1ac'}/></mesh></group>
  </group>;
}
/** Low-cost static shell scars and scattered debris add battlefield scale without changing navigation. */
function BattlefieldDetails(){
  const marks=useMemo(()=>Array.from({length:50},(_,i)=>({
    x:-24+((i*37)%140),z:-34+((i*23)%68),r:.55+(i%4)*.18,rot:(i*1.71)%Math.PI
  })),[]);
  return <group>
    {marks.map((m,i)=><group key={i} position={[m.x,.045,m.z]} rotation={[-Math.PI/2,0,m.rot]}>
      <mesh><circleGeometry args={[m.r,18]}/><meshBasicMaterial color="#202b28" transparent opacity={.25} depthWrite={false}/></mesh>
      <mesh><ringGeometry args={[m.r*.72,m.r,18]}/><meshBasicMaterial color="#657064" transparent opacity={.28} depthWrite={false}/></mesh>
    </group>)}
    {marks.filter((_,i)=>i%2===0).map((m,i)=><mesh key={`debris-${i}`} position={[m.x+.8,.13,m.z-.35]} rotation={[.2,i*.8,.15]}>
      <dodecahedronGeometry args={[.18+(i%3)*.05,0]}/><meshStandardMaterial color="#62645a" roughness={1}/>
    </mesh>)}
  </group>;
}
function Weather({state,paused}:{state:GameState;paused:boolean}){
  const points=useRef<THREE.Points>(null);
  const positions=useMemo(()=>{
    const array=new Float32Array(260*3);
    for(let i=0;i<260;i++){array[i*3]=Math.sin(i*13.7)*80+43;array[i*3+1]=(i%19)*.8;array[i*3+2]=Math.cos(i*9.3)*40;}
    return array;
  },[]);
  useFrame((_,dt)=>{
    if(!points.current||paused)return;
    const attr=points.current.geometry.attributes.position;
    for(let i=0;i<attr.count;i++){attr.setY(i,(attr.getY(i)-dt*(state.biome==='snow'?1.5:8)+16)%16);}
    attr.needsUpdate=true;
  });
  if(state.biome==='desert')return null;
  return <points ref={points}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry>
    <pointsMaterial color={state.biome==='snow'?'#edf5ed':'#b6d1c9'} size={state.biome==='snow'?.08:.045} transparent opacity={.5}/></points>;
}
function AutoCamera(){
  const {camera,size}=useThree();
  useMemo(()=>{
    const distance=Math.min(2,Math.max(1,1.4/(size.width/size.height)));
    camera.position.set(-8,30*distance,38*distance);camera.lookAt(-8,0,4);
  },[camera,size.width,size.height]);
  return null;
}
/** Expanding ring where a move order was just given: instant visual feedback for a tap. */
function OrderPing({ping}:{ping:{x:number;z:number;k:number}|null}){
  const ref=useRef<THREE.Mesh>(null);
  useFrame(()=>{
    if(!ref.current||!ping)return;
    const age=Math.min(1,(Date.now()-ping.k)/700);
    ref.current.scale.setScalar(.6+age*1.6);
    (ref.current.material as THREE.MeshBasicMaterial).opacity=1-age;
  });
  if(!ping)return null;
  return <mesh key={ping.k} ref={ref} position={[ping.x,.09,ping.z]} rotation={[-Math.PI/2,0,0]}>
    <ringGeometry args={[.8,1,28]}/><meshBasicMaterial color="#85e2d1" transparent opacity={1} depthWrite={false}/></mesh>;
}
/** Keeps the free camera over the battlefield so a drag can never lose the map. */
function CameraBounds(){
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  useFrame(()=>{
    if(!controls?.target)return;
    const t=controls.target,x=THREE.MathUtils.clamp(t.x,MAP_BOUNDS.minX,MAP_BOUNDS.maxX),z=THREE.MathUtils.clamp(t.z,MAP_BOUNDS.minZ,MAP_BOUNDS.maxZ);
    if(x!==t.x||z!==t.z){camera.position.x+=x-t.x;camera.position.z+=z-t.z;t.x=x;t.z=z;}
  });
  return null;
}
function CameraCapture({cameraRef}:{cameraRef:React.MutableRefObject<THREE.Camera|null>}){
  const camera=useThree(s=>s.camera);
  useEffect(()=>{cameraRef.current=camera;});
  return null;
}
/** Reports the orbit camera's target and distance to the parent so the radar minimap can frame it. */
function CameraLink({onCameraMove}:{onCameraMove:(x:number,z:number,dist:number)=>void}) {
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  const last=useRef(0);
  useFrame(()=>{
    const now=performance.now();if(now-last.current<250)return;last.current=now;
    if(controls?.target)onCameraMove(controls.target.x,controls.target.z,camera.position.distanceTo(controls.target));
  });
  return null;
}
/** Exposes a jump function so tapping the radar minimap pans the 3D camera to that point. */
function JumpBinder({jumpRef}:{jumpRef:React.MutableRefObject<((x:number,z:number)=>void)|null>}) {
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  useEffect(()=>{
    jumpRef.current=(x:number,z:number)=>{
      if(!controls?.target)return;
      if(!Number.isFinite(x)||!Number.isFinite(z))return;
      const dx=x-controls.target.x,dz=z-controls.target.z;
      controls.target.x+=dx;controls.target.z+=dz;camera.position.x+=dx;camera.position.z+=dz;
    };
    return ()=>{jumpRef.current=null;};
  },[camera,controls,jumpRef]);
  return null;
}
export function FortressScene({state,paused,onSelect,onSelectKind,onMoveOrder,onAttackBuilding,onRectSelect,rallyMode,onSetRally,onSelectBuilding,selectedBuildingId,onCameraMove,jumpRef}:{state:GameState;paused:boolean;
  onSelectKind:(kind:UnitKind)=>void;
  onSelect:(id:number,enemy:boolean,multi:boolean)=>void;onMoveOrder:(x:number,z:number)=>void;
  onAttackBuilding:(id:string)=>void;onRectSelect:(ids:number[],additive:boolean)=>void;
  moveMode?:boolean;rallyMode?:boolean;onSetRally:(x:number,z:number)=>void;
  onSelectBuilding:(id:string)=>void;selectedBuildingId?:string|null;
  onCameraMove?:(x:number,z:number,dist:number)=>void;jumpRef:React.MutableRefObject<((x:number,z:number)=>void)|null>}) {
  const daylight=.65+.35*Math.cos(state.tick/300*Math.PI*2);
  const wrap=useRef<HTMLDivElement|null>(null);
  const [ping,setPing]=useState<{x:number;z:number;k:number}|null>(null);
  const hasSelection=state.units.some(u=>u.faction==='player'&&u.selected);
  const orderMove=(x:number,z:number)=>{onMoveOrder(x,z);if(hasSelection)setPing({x,z,k:Date.now()});};
  const cameraRef=useRef<THREE.Camera|null>(null);
  const start=useRef<{x:number;y:number}|null>(null);
  const [marquee,setMarquee]=useState<{x1:number;y1:number;x2:number;y2:number}|null>(null);
  const toLocal=(e:React.PointerEvent)=>{const r=wrap.current!.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};};
  const onPointerDown=(e:React.PointerEvent)=>{
    if(e.button!==0||e.pointerType!=='mouse')return;
    start.current=toLocal(e);setMarquee(null);
  };
  const onPointerMove=(e:React.PointerEvent)=>{
    if(!start.current)return;
    const p=toLocal(e);
    setMarquee({x1:start.current.x,y1:start.current.y,x2:p.x,y2:p.y});
  };
  const onPointerUp=(e:React.PointerEvent)=>{
    const s=start.current;start.current=null;
    if(!s){setMarquee(null);return;}
    const end=toLocal(e);setMarquee(null);
    const w=Math.abs(end.x-s.x),h=Math.abs(end.y-s.y);
    const camera=cameraRef.current;
    if(!camera||w<6||h<6)return;
    const size=wrap.current!.getBoundingClientRect();
    const box={x1:Math.min(s.x,end.x),x2:Math.max(s.x,end.x),y1:Math.min(s.y,end.y),y2:Math.max(s.y,end.y)};
    const ids=state.units.filter(u=>u.faction==='player'&&u.hp>0).map(u=>{
      const v=new THREE.Vector3(u.x,.1,u.z).project(camera);
      return {id:u.id,x:(v.x+1)/2*size.width,y:(1-v.y)/2*size.height};
    }).filter(p=>p.x>=box.x1&&p.x<=box.x2&&p.y>=box.y1&&p.y<=box.y2).map(p=>p.id);
    if(ids.length)onRectSelect(ids,e.shiftKey);
  };
  return <div ref={wrap} style={{position:'relative',width:'100%',height:'100%'}}>
    <Canvas shadows camera={{position:[-8,30,38],fov:48,near:.1,far:560}} dpr={1}
      gl={{antialias:false,powerPreference:'high-performance'}}
      onCreated={({gl})=>{
        const context=gl.getContext(),info=context.getExtension('WEBGL_debug_renderer_info');
        const name=info?String(context.getParameter(info.UNMASKED_RENDERER_WEBGL)):'';
        if(/swiftshader|llvmpipe|software/i.test(name))gl.shadowMap.enabled=false;
      }}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
      fallback={<div>WebGL unavailable on this device.</div>}>
      <color attach="background" args={[state.biome==='snow'?'#738c90':'#263f3d']}/>
      <fog attach="fog" args={[state.biome==='snow'?'#a5bcb8':'#3c554a',130,420]}/>
      <ambientLight intensity={.9+daylight*.35}/><hemisphereLight args={['#cfdfdd','#50604b',1.4]}/>
      <directionalLight position={[-18,28,10]} intensity={daylight*2.2} castShadow shadow-mapSize={[1024,1024]}
        shadow-camera-left={-60} shadow-camera-right={60} shadow-camera-top={50} shadow-camera-bottom={-50} shadow-bias={-.001}/>
      <Terrain state={state} rallyMode={!!rallyMode} onMoveOrder={orderMove} onSetRally={onSetRally}/>
      <BattlefieldDetails/>
      <OrderPing ping={ping}/>
      <CornerTowers/><CornerTowers enemy/>
      <BaseDressing/><BaseDressing enemy/>
      {state.buildings.map(b=><Structure key={b.id} building={b} onAttackBuilding={onAttackBuilding}
        onSelectBuilding={onSelectBuilding} selected={selectedBuildingId===b.id}/>)}
      {state.opponent.buildings.filter(b=>b.kind==='hq'||visibleTo(state,'player',b)).map(b=>
        <Structure key={b.id} building={b} enemy onAttackBuilding={onAttackBuilding} onSelectBuilding={onSelectBuilding}/>)}
      {state.units.filter(u=>u.faction==='player'||visibleTo(state,'player',u)).map(u=><UnitMesh key={u.id} unit={u} onSelect={onSelect} onSelectKind={onSelectKind}/>)}
      {state.zones.map(z=><group key={z.id} position={[z.x,.07,z.z]}>
        <mesh rotation={[-Math.PI/2,0,0]}><ringGeometry args={[2.5,2.65,40]}/><meshBasicMaterial color={z.owner==='player'?'#a9d8ab':z.owner==='enemy'?'#ee9683':'#e4cd8f'}/></mesh>
        <Box position={[0,.25,0]} size={[1,.5,1]} color="#b9a875"/><Box position={[0,1.2,0]} size={[.06,2,.06]} color="#d5dcc4"/>
        <Box position={[.4,1.8,0]} size={[.8,.5,.03]} color={z.owner==='player'?'#80af8a':z.owner==='enemy'?'#c97662':'#c9b97e'}/>
      </group>)}
      {state.shots.map(shot=><group key={shot.id}>
        <Line points={[[shot.x,.85,shot.z],[shot.toX,.7,shot.toZ]]} color={shot.faction==='player'?'#ffe5a0':'#ffac80'} lineWidth={1.5}/>
        {/* Brief muzzle flash and expanding impact ring make each hit readable on mobile. */}
        <mesh position={[shot.x,.85,shot.z]}><sphereGeometry args={[.11,6,6]}/>
          <meshBasicMaterial color={shot.faction==='player'?'#fff0b5':'#ffc0a0'}/></mesh>
        <mesh position={[shot.toX,.72,shot.toZ]}><sphereGeometry args={[.2,8,6]}/>
          <meshBasicMaterial color="#ffd293"/></mesh>
        <mesh position={[shot.toX,.075,shot.toZ]} rotation={[-Math.PI/2,0,0]}
          scale={1+(Math.max(0,(shot.weapon==='artillery'?.48:shot.weapon==='heavy'||shot.weapon==='tank'?.34:.22)-shot.life))* (shot.weapon==='artillery'?8:5)}>
          <ringGeometry args={[shot.weapon==='artillery'?.28:.16,shot.weapon==='artillery'?.52:.28,20]}/>
          <meshBasicMaterial color={shot.faction==='player'?'#ffe5a0':'#ffac80'} transparent
            opacity={Math.max(0,shot.life/(shot.weapon==='artillery'?.48:shot.weapon==='heavy'||shot.weapon==='tank'?.34:.22))*.8} depthWrite={false}/>
        </mesh>
        {(shot.weapon==='artillery'||shot.weapon==='heavy'||shot.weapon==='tank')&&<group>
          <mesh position={[shot.toX,.38+(.48-shot.life)*1.5,shot.toZ]} scale={1+(.48-shot.life)*3}>
            <sphereGeometry args={[shot.weapon==='artillery'?.48:.28,8,6]}/>
            <meshBasicMaterial color="#d58b55" transparent opacity={Math.max(0,shot.life/.48)*.32} depthWrite={false}/>
          </mesh>
          {[0,1,2].map(i=><mesh key={i} position={[shot.toX+(i-1)*.22,.65+(.48-shot.life)*(1.2+i*.18),shot.toZ+(i%2?-.18:.18)]}
            scale={.65+(.48-shot.life)*1.8}>
            <sphereGeometry args={[.24,7,6]}/><meshBasicMaterial color="#5b625e" transparent
              opacity={Math.max(0,shot.life/.48)*.28} depthWrite={false}/>
          </mesh>)}
        </group>}
      </group>)}
      <Weather state={state} paused={paused}/><AutoCamera/><PerformanceMeter/><CameraCapture cameraRef={cameraRef}/>
      {onCameraMove&&<CameraLink onCameraMove={onCameraMove}/>}
      <JumpBinder jumpRef={jumpRef}/><CameraBounds/>
      <OrbitControls makeDefault target={[-8,0,4]} maxPolarAngle={Math.PI/2.15} minDistance={14} maxDistance={120}
        enableRotate={false} screenSpacePanning={false} panSpeed={1.1} enableDamping dampingFactor={.12}
        mouseButtons={{LEFT:undefined as unknown as THREE.MOUSE,MIDDLE:THREE.MOUSE.PAN,RIGHT:THREE.MOUSE.PAN}}
        touches={{ONE:THREE.TOUCH.PAN,TWO:THREE.TOUCH.DOLLY_PAN}}/>
    </Canvas>
    {marquee&&<div style={{position:'absolute',left:Math.min(marquee.x1,marquee.x2),top:Math.min(marquee.y1,marquee.y2),
      width:Math.abs(marquee.x2-marquee.x1),height:Math.abs(marquee.y2-marquee.y1),
      border:'1px solid #85e2d1',background:'rgba(133,226,209,.12)',pointerEvents:'none'}}/>}
  </div>;
}
