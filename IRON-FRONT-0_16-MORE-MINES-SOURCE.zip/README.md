# IRON FRONT: TOTAL DOMINATION

Version 0.4 is a playable single-player RTS skirmish, continuing the existing React/TypeScript project rather than replacing it with an unrelated game. It is an integrated first release, not a claim that the full AAA production brief is finished.

## Play the portable release

Extract the ZIP and open `PLAY-IRON-FRONT.html` in a current desktop browser. The HTML contains the runtime, procedural graphics, styles and fonts, so it can run offline without npm or a server.

The game is fully 2D since 0.5.2: a lightweight SVG tactical map that runs smoothly on weak devices without WebGL, with a collapsible command panel for a full-screen battle view. The package is a browser game plus editable source, not a native Windows executable or Android application.

## Develop

From the source directory, use Node.js 20.19+:

```sh
npm ci
npm test
npm run dev
npm run build
```

The build produces one portable `dist/index.html`. `npm ci` needs internet on first setup; the compiled game does not.

## Included gameplay

- Three terrain/climate variants of the tactical sector: forest, desert and snow.
- A large extended battlefield with the enemy base far away, three contested central steel depots, rocky mid-field cover and a rich finite mine per faction connected by a dedicated dashed haul road.
- A river splits the field with exactly three bridges; mountain walls guard the outer crossings. Every ground attack must funnel through these chokepoints, so you can fortify a bridge instead of the whole front.
- A free 3D camera: drag with two fingers to pan and pinch to zoom (desktop: middle-drag pans, right-drag rotates, wheel zooms), and a radar minimap in the corner — tap it to jump anywhere; hostile blips appear only while detected. One finger on the field drags a selection rectangle.
- Day/night lighting, precipitation, tracers and generated sound effects.
- Four resource currencies, finite industrial reserves, capturable steel depots and the mine economy: mine workers (small mixed bundles) and haul trucks (large bundles) shuttle between each faction's mine and HQ, depleting the finite deposit.
- Fourteen structure kinds including the HQ and destructible perimeter wall segments, with construction timers, health, destruction and paid upgrades.
- Fourteen unit kinds: infantry, sniper, engineer, anti-armor, scout, main battle tank, heavy tank, armored vehicle, artillery, attack helicopter, recon drone, supply truck, mine worker and haul truck.
- Paid, prerequisite-driven sequential recruitment, capped queues and army sizes.
- Group move with line/wedge/flank formations, drag-rectangle multi-select, targeted attacks against specific enemy structures, hold and retreat orders, A* navigation, vision limits, armor and deterministic range/cover modifiers.
- Ground vehicles burn fuel while moving and crawl at half speed when the faction fuel pool is dry; supply trucks transfer ammunition and fuel to nearby frontline units.
- A collapsible command HUD: fold the bottom panel away for a full-screen map and unfold it to command.
- An opponent with its own resources, buildings, training, research and decision-state machine, using the same economic code and costs as the player. The AI builds, expands and researches but never initiates hostilities before the first engagement between the two armies; full assault waves unlock only after first contact.
- Timed weapons, armor, mobility, industry and reconnaissance research.
- Victory/defeat, restart, pause, simulation speed and Arabic/English UI.
- Validated versioned JSON save export/import, including the opponent's full state.

## Controls

Select a friendly unit, drag a selection rectangle over the field, Shift-click to add units, or toggle members in the roster. Pick a formation (line, wedge or flank) and select Move then click the ground or minimap, click a visible hostile unit or structure to attack it specifically, or issue Attack HQ to advance through enemy defenses. Hold stops movement but retains local automatic defense.

`A` selects all, `M` toggles destination mode, `Space` pauses/resumes and `Esc` cancels destination mode. Tap a building on the map to open its contextual card (training and upgrades); tap the mine worker or haul truck buttons to grow your economy. The Commands button folds the bottom HUD away for a full-screen map. Sound starts only after clicking SFX, in the header or Support panel.

## Saves and privacy

Save exports a JSON file; loading restores it paused for review. There is no account, analytics, cloud save, automatic save, external AI service or required game-network connection.

Version 3 browser-storage saves from the original project are left untouched but are not imported by the new version 4 file format. Save before closing the page. The validator rejects oversized, corrupted, invalid-enum and inconsistent-ID saves.

## Engine layout

| File | Responsibility |
|---|---|
| `simulation.ts` | Fixed-step orchestration, capture zones, game-over and events |
| `aiSystem.ts` | Mirrored same-rules economic adapter and opponent state machine |
| `navigation.ts` | Bounded A* and ground/air movement |
| `visibility.ts` | Unit and structure sensor queries |
| `combatSystem.ts` | Orders, simultaneous damage, cooldowns, ammunition and defenses |
| `economy.ts` | Production, affordability and payment |
| `buildingSystem.ts` | Slots, limits, construction and upgrades |
| `productionSystem.ts` | Training, timed research, repair |
| `unitSystem.ts` | Unit definitions and instantiation |
| `saveSystem.ts` | Versioned export and schema-validated import |
| `audioSystem.ts` | User-initiated synthesized effects |
| `FortressScene.tsx` | Procedural Three.js presentation (3D-only battlefield) |
| `RadarMinimap.tsx` | Tactical radar minimap with tap-to-jump |
| `App.tsx`, `i18n.ts` | Entry integration, UI and localization |

No Godot archive in the parent repository is modified. Nothing is pushed to the remote repository by this delivery.

## Status and limitations

See `FEATURE-STATUS.md` for the exact scope against the requested roadmap, `TEST-REPORT.md` for verification and `README-AR.md` for the Arabic player guide. Third-party notices accompany the release; no new license is assigned to the owner's original project.
