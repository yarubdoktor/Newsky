# IRON-FRONT main flows and acceptance checks

Baseline inspected in Chromium before editing: 3D scene renders, Command / Construction / Garrison tabs work, pause works, seven construction cards appear. Original game has no recruit, HQ combat, victory or defeat loop.

## Preserved flows
- Open the game: fortress, friendly units, enemy base, health and resources render.
- Construction: buy an affordable building, resources decrease, progress completes and production starts.
- Select a friendly unit, issue Move, click the ground: the unit reaches its destination. Shift-click adds units.
- Select friendly units and click an enemy: units engage. Hold cancels movement.
- Pause and resume: simulation, income, construction and combat freeze and resume.
- Navigate all tabs and orbit/zoom the 3D scene.

## New acceptance checks
- Start briefing, Arabic/English language switch, instructions and new mission confirmation.
- Select-all and roster controls work on mobile and desktop.
- Recruit all eleven unit types, queue completion, production-building prerequisites, queue and army limits, resource rejection.
- Enemy advances; idle friendlies defend; simultaneous damage applies cooldown; dead units disappear.
- Attack HQ changes health. Win and loss stop time and provide restart.
- Hospital heals, tower defends, research improves damage, repairs cost resources.
- Paid AI production, assault countdown and actual funded assault groups; score/salvage update.
- AI builds, saves for infrastructure, defends detected threats and uses the same costs, finite reserves and ammunition rules.
- Five timed research technologies; paid building upgrades improve production/defense/durability.
- Strategic depots capture after sustained presence and generate finite steel income.
- Save downloads JSON; valid import restores; malformed/oversized/nonfinite/invalid-enum files are rejected without destroying the current mission.
- A visible fallback notice appears if WebGL is unavailable (the battlefield itself is 3D-only since 0.8).
- Desktop 1440x960, mobile 375x812 and short desktop layout: no horizontal clipping, controls accessible.
- Portable single HTML loads with network disabled over file://, no external assets required.
- Automated simulation tests cover economy, construction, training, combat, terminal states, AI fairness, capture, sensors, save validation and determinism.

## Off-happy-path checks
- No selection, out-of-bounds move, insufficient ammo, invalid save and restart cancellation.
- Paused export/import, repeated unit queues and all four watchtowers.
