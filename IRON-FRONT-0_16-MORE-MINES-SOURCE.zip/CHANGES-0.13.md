# IRON-FRONT 0.13 — World asset integration

- Replaced all 14 building silhouettes with purpose-matched CC0 GLB military base assets.
- Replaced the four decorative corner towers with real guard-tower models.
- Added a consistent field-camp dressing set: flag, gate, supply point, searchlight, fuel tanker, ambulance, recovery vehicle, basket wall and trench pieces.
- Replaced procedural forest trees with instanced GLB oak, sycamore and spruce species; snow biome uses spruce. Desert remains intentionally sparse.
- Added a distinct light tank and fuel tanker to the imported vehicle roster.
- Preserved the existing interaction hit areas, selection, health bars, construction progress, movement, camera, combat and pathfinding.
- All added assets are CC0 1.0. Imported models are static; gameplay remains controlled by the existing simulation.
