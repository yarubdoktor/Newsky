import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

export default defineConfig({
  plugins: [react(),viteSingleFile()],
  build:{assetsInlineLimit:10000000,target:'es2020'},
  base: './',
  server: { host: '0.0.0.0' },
});
