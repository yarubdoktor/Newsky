# IRON-FRONT 0.11 — Army visual pack (Phase 1)

- Replaced the single generic unit silhouette with 14 role-specific 3D mesh models: four combat infantry roles plus laborer, scout vehicle, main tank, heavy tank, APC, self-propelled artillery, attack helicopter, recon drone, supply truck and haul truck.
- Added faction-specific body palettes while keeping glass, metal, rubber, equipment and lights visually distinct.
- Added track/wheel assemblies, turrets and barrels, vehicle cabins/cargo, soldier equipment and weapons, helicopter rotor animation and drone rotor animation.
- Kept the original invisible touch hit areas, selection rings, health bars, unit IDs, unit kinds, coordinates, movement, selection, combat, navigation and camera controls unchanged.
- These are lightweight in-engine mesh models; they add no remote downloads or external runtime asset dependency.

## Verification status

- Source patch applies cleanly to the 0.10 source archive.
- TypeScript/JSX syntax transpilation passed for the modified scene and new model module.
- Full npm tests, production build, Android APK build and device FPS/playability verification are pending the GitHub Actions run and phone test.
