import { cpSync,existsSync,mkdirSync,readFileSync,readdirSync,statSync,writeFileSync } from 'node:fs';
import { dirname,join,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const project=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const destination=resolve(process.argv[2]??join(project,'output'));
const name='IRON-FRONT-0.8';
const root=join(destination,name),source=join(root,'SOURCE');
if(!existsSync(join(project,'dist/index.html')))throw new Error('Run npm run build first.');
mkdirSync(source,{recursive:true});
const files=['src','tests','tools','index.html','package.json','package-lock.json','tsconfig.json',
  'vite.config.ts','.gitignore','README.md','README-AR.md','FEATURE-STATUS.md','TEST-REPORT.md','FLOWS.md','progress.md'];
for(const file of files)cpSync(join(project,file),join(source,file),{recursive:true});
cpSync(join(project,'dist'),join(source,'dist'),{recursive:true});
cpSync(join(project,'dist/index.html'),join(root,'PLAY-IRON-FRONT.html'));
for(const file of ['README.md','README-AR.md','FEATURE-STATUS.md','TEST-REPORT.md'])
  cpSync(join(project,file),join(root,file));

// Mechanically collect package license text, including nested dependencies and bundled fonts.
const notices=['# Third-party notices','These notices cover installed dependency packages. Some development-only packages are not present in the playable bundle.',
  'No license is assigned here to the original game owner’s project.'];
function collect(nodeModules){
  if(!existsSync(nodeModules))return;
  for(const entry of readdirSync(nodeModules)){
    if(entry.startsWith('.'))continue;
    const path=join(nodeModules,entry);if(!statSync(path).isDirectory())continue;
    if(entry.startsWith('@')){for(const item of readdirSync(path))inspect(join(path,item));}
    else inspect(path);
  }
}
function inspect(path){
  const manifest=join(path,'package.json');if(!existsSync(manifest))return;
  const pkg=JSON.parse(readFileSync(manifest,'utf8'));
  const licenses=readdirSync(path).filter(file=>/^(license|licence|copying|ofl)([._-].*)?$/i.test(file)&&statSync(join(path,file)).isFile());
  notices.push(`\n## ${pkg.name} ${pkg.version}\nDeclared license: ${typeof pkg.license==='string'?pkg.license:JSON.stringify(pkg.license??'See package')}`);
  for(const file of licenses)notices.push(`\n### ${file}\n\n${readFileSync(join(path,file),'utf8')}`);
  collect(join(path,'node_modules'));
}
collect(join(project,'node_modules'));
writeFileSync(join(root,'THIRD-PARTY-NOTICES.md'),notices.join('\n\n'));
cpSync(join(root,'THIRD-PARTY-NOTICES.md'),join(source,'THIRD-PARTY-NOTICES.md'));
const archive=join(destination,`${name}-Ready.zip`);
execFileSync('python3',['-m','zipfile','-c',archive,name],{cwd:destination,stdio:'inherit'});
console.log(JSON.stringify({root,archive,bytes:statSync(archive).size},null,2));
