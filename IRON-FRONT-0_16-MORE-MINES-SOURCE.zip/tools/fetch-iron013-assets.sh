#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BASE="$ROOT/public/assets/3d/base"
NATURE="$ROOT/public/assets/3d/nature"
VEHICLES="$ROOT/public/assets/3d/vehicles"
mkdir -p "$BASE" "$NATURE" "$VEHICLES"
fetch(){
  local folder="$1"
  local name="$2"
  local id="$3"
  local max="$4"
  local target="$folder/$name"
  curl -fL --retry 3 --retry-delay 2 "https://cdn.3dassets.dev/assets/${id}/v1/model.glb" -o "$target"
  test -s "$target"
  test "$(head -c 4 "$target")" = "glTF"
  local bytes; bytes="$(wc -c < "$target")"
  test "$bytes" -gt 1024; test "$bytes" -lt "$max"
  echo "Verified $name (${bytes} bytes)"
}
# Field-camp and base structures, fortifications, logistics and support props (CC0).
fetch "$BASE" command-tent.glb 23689 300000
fetch "$BASE" squad-tent.glb 23687 300000
fetch "$BASE" generator-trailer.glb 23688 300000
fetch "$BASE" fuel-dump-berm.glb 23701 300000
fetch "$BASE" camo-net-frame.glb 23698 300000
fetch "$BASE" radar-trailer.glb 23685 300000
fetch "$BASE" guard-tower.glb 23692 300000
fetch "$BASE" field-hospital-tent.glb 23690 300000
fetch "$BASE" storage-container.glb 23702 300000
fetch "$BASE" field-office.glb 23703 300000
fetch "$BASE" helipad-marker.glb 23699 300000
fetch "$BASE" mobile-rocket-launcher.glb 23671 300000
fetch "$BASE" sandbag-wall-straight.glb 23694 300000
fetch "$BASE" camp-gate.glb 23695 300000
fetch "$BASE" basket-wall-straight.glb 23693 300000
fetch "$BASE" basket-wall-corner.glb 23696 300000
fetch "$BASE" trench-straight.glb 23704 300000
fetch "$BASE" trench-corner.glb 23706 300000
fetch "$BASE" supply-point.glb 23705 300000
fetch "$BASE" flag-pole.glb 23700 300000
fetch "$BASE" searchlight.glb 23684 300000
fetch "$BASE" field-ambulance.glb 23676 300000
fetch "$BASE" fuel-tanker.glb 23675 300000
fetch "$BASE" command-vehicle.glb 23681 300000
fetch "$BASE" recovery-vehicle.glb 23678 300000
# Add two role-specific vehicles to the existing 0.12 vehicle roster.
fetch "$VEHICLES" light-tank.glb 23673 300000
fetch "$VEHICLES" fuel-tanker.glb 23675 300000
# Mixed woodland species in a shared low-poly art direction (CC0).
fetch "$NATURE" mature-oak.glb 3776 300000
fetch "$NATURE" mature-sycamore.glb 3775 300000
fetch "$NATURE" mature-spruce.glb 3801 300000
