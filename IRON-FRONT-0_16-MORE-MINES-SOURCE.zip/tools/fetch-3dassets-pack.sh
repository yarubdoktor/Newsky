#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VEHICLES="$ROOT/public/assets/3d/vehicles"
mkdir -p "$VEHICLES"
fetch_model(){
  local name="$1"
  local id="$2"
  local target="$VEHICLES/$name"
  curl -fL --retry 3 --retry-delay 2 "https://cdn.3dassets.dev/assets/${id}/v1/model.glb" -o "$target"
  test -s "$target"
  local magic
  magic="$(head -c 4 "$target")"
  test "$magic" = "glTF"
  local bytes
  bytes="$(wc -c < "$target")"
  test "$bytes" -gt 1024
  test "$bytes" -lt 1000000
  echo "Verified $name (${bytes} bytes)"
}
fetch_model main-battle-tank.glb 23667
fetch_model tracked-apc.glb 23668
fetch_model self-propelled-gun.glb 23670
fetch_model armoured-car.glb 23669
fetch_model supply-truck.glb 23674
