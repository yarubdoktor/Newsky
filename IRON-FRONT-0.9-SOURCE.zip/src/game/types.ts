export type BuildingKind = 'hq' | 'barracks' | 'power' | 'refinery' | 'factory' | 'research' | 'watchtower' | 'hospital' | 'ammo' | 'vehicleFactory' | 'airfield' | 'missile' | 'wall' | 'command';
export type BuildingStatus = 'active' | 'constructing';
export type Cost = { steel: number; fuel: number; power: number };
export type Resources = { steel: number; fuel: number; power: number; ammo: number };
export type Building = { id:string; kind:BuildingKind; level:number; hp:number; maxHp:number; x:number; z:number; status:BuildingStatus; remaining:number; buildSeconds:number };
export type UnitKind = 'tank' | 'infantry' | 'sniper' | 'engineer' | 'antitank' | 'scout' | 'heavy' | 'apc' | 'artillery' | 'helicopter' | 'drone' | 'supply' | 'worker' | 'hauler';
export type UnitFaction = 'player' | 'enemy';
export type UnitOrder = 'idle' | 'move' | 'attack';
export type Unit = {
  id:number; faction:UnitFaction; x:number; z:number; hp:number; maxHp:number;
  kind:UnitKind; selected:boolean; order:UnitOrder; targetX:number; targetZ:number;
  targetId:number|null; targetBld?:string|null; cargo?:{ammo:number;fuel:number};
  harvest?:{phase:'toMine'|'mining'|'toBase';timer:number;load?:{steel:number;fuel:number;power:number;ammo:number}};
  range:number; damage:number; speed:number; cooldown:number;
  armor:number; vision:number; path:{x:number;z:number}[];
};
export type Training = { id:number; kind:UnitKind; remaining:number; total:number };
export type Shot = { id:number; x:number; z:number; toX:number; toZ:number; faction:UnitFaction; life:number };
export type ResearchKind='weapons'|'armor'|'mobility'|'industry'|'recon';
export type ResearchJob={kind:ResearchKind;remaining:number;total:number};
export type Technologies=Record<ResearchKind,number>;
export type Opponent={resources:Resources;buildings:Building[];training:Training[];technologies:Technologies;
  research:ResearchJob|null;reserve:number;lastDecision:number;stance:'expand'|'defend'|'attack'|'rebuild';};
export type GameState = {
  resources:Resources; buildings:Building[]; units:Unit[]; enemyHp:number; baseHp:number;
  tick:number; message:string; nextBuildingId:number; nextUnitId:number;
  phase:'playing'|'victory'|'defeat'; training:Training[]; wave:number; nextWave:number;
  kills:number; losses:number; tech:number; shots:Shot[]; seed:number;
  opponent:Opponent;research:ResearchJob|null;technologies:Technologies;
  contact:boolean;rally:{x:number;z:number};
  reserve:number; difficulty:'easy'|'normal'|'hard';biome:'forest'|'desert'|'snow';
  events:{time:number;text:string}[];
  zones:{id:number;x:number;z:number;owner:'player'|'enemy'|'neutral';progress:number;reserve:number}[];
  /** Rich mixed-resource mines: workers and haul trucks shuttle between them and the HQ. */
  mines:{x:number;z:number;faction:UnitFaction;steel:number;fuel:number;power:number;ammo:number}[];
};
