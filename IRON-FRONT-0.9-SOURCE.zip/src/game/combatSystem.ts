import type { GameState } from './types';
import { advanceMovement } from './navigation';
import { visibleTo } from './visibility';
import { UNIT_SPECS } from './unitSystem';

export const PLAYER_HQ = { x:-12, z:4 };
export const ENEMY_HQ = { x:58, z:-4 };
/** Usable battlefield bounds for player orders on the enlarged map. */
export const MAP_BOUNDS = { minX:-28, maxX:76, minZ:-24, maxZ:24 };
const distance=(a:{x:number;z:number},b:{x:number;z:number})=>Math.hypot(a.x-b.x,a.z-b.z);
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));

export type Formation='line'|'wedge'|'flank';
/** Group destination offsets per formation: firing line, V-lead wedge, wide enveloping columns. */
export function formationOffset(index:number,formation:Formation):{dx:number;dz:number} {
  if(formation==='wedge')return {dx:-(Math.floor(index/2))*1.2,dz:(index%2?1:-1)*Math.ceil((index+1)/2)*.85};
  if(formation==='flank')return {dx:(index%2?1:-1)*1.6,dz:Math.floor(index/2)*1.1};
  return {dx:(index%3-1)*1.1,dz:Math.floor(index/3)*1.1};
}
export function issueMove(state:GameState,x:number,z:number,formation:Formation='line'):GameState {
  if(state.phase!=='playing'||!Number.isFinite(x)||!Number.isFinite(z))return state;
  const selected=state.units.filter(u=>u.faction==='player'&&u.selected&&u.hp>0);
  const units=state.units.map(u=>{
    const index=selected.findIndex(s=>s.id===u.id);
    if(index<0)return u;
    const {dx,dz}=formationOffset(index,formation);
    return {...u,order:'move' as const,targetX:clamp(x+dx,MAP_BOUNDS.minX,MAP_BOUNDS.maxX),
      targetZ:clamp(z+dz,MAP_BOUNDS.minZ,MAP_BOUNDS.maxZ),targetId:null,targetBld:null,path:[]};
  });
  return {...state,units,message:selected.length?'MOVE ORDER / أمر تحرك':'SELECT UNITS FIRST / حدد وحدات أولاً'};
}

export function issueAttack(state:GameState,targetId:number):GameState {
  if(state.phase!=='playing')return state;
  const target=targetId===-1?ENEMY_HQ:state.units.find(u=>u.id===targetId&&u.faction==='enemy'&&u.hp>0);
  if(!target)return state;
  const count=state.units.filter(u=>u.faction==='player'&&u.selected&&u.hp>0).length;
  const units=state.units.map(u=>u.faction==='player'&&u.selected&&u.hp>0
    ? {...u,order:'attack' as const,targetId,targetBld:null,targetX:target.x,targetZ:target.z,path:[]}:u);
  return {...state,units,message:count?'ATTACK CONFIRMED / تأكيد الهجوم':'SELECT UNITS FIRST / حدد وحدات أولاً'};
}

/** Direct order against one specific hostile structure, including individual barrier segments. */
export function issueAttackBuilding(state:GameState,buildingId:string):GameState {
  if(state.phase!=='playing')return state;
  const target=state.opponent.buildings.find(b=>b.id===buildingId);
  if(!target)return state;
  if(target.kind==='hq')return issueAttack(state,-1);
  const count=state.units.filter(u=>u.faction==='player'&&u.selected&&u.hp>0).length;
  const units=state.units.map(u=>u.faction==='player'&&u.selected&&u.hp>0
    ? {...u,order:'attack' as const,targetId:null,targetBld:buildingId,targetX:target.x,targetZ:target.z,path:[]}:u);
  return {...state,units,message:count?'STRUCTURE TARGETED / استهداف منشأة':'SELECT UNITS FIRST / حدد وحدات أولاً'};
}

/** Drag-box selection over a world-space rectangle; only friendly units respond. */
export function selectInRect(state:GameState,rect:{x1:number;z1:number;x2:number;z2:number},additive:boolean):GameState {
  if(state.phase!=='playing')return state;
  const x1=Math.min(rect.x1,rect.x2),x2=Math.max(rect.x1,rect.x2);
  const z1=Math.min(rect.z1,rect.z2),z2=Math.max(rect.z1,rect.z2);
  const inside=(u:{x:number;z:number})=>u.x>=x1&&u.x<=x2&&u.z>=z1&&u.z<=z2;
  const units=state.units.map(u=>{
    if(u.faction!=='player'||u.hp<=0)return u;
    if(inside(u))return {...u,selected:additive?!u.selected:true};
    return additive?u:{...u,selected:false};
  });
  return {...state,units};
}

export function holdSelected(state:GameState):GameState {
  return {...state,units:state.units.map(u=>u.faction==='player'&&u.selected
    ? {...u,order:'idle' as const,targetId:null,targetBld:null,targetX:u.x,targetZ:u.z,path:[]}:u),
    message:'HOLD & DEFEND / ثبات ودفاع'};
}

/** Fixed-step, simultaneous combat. Damage and weapon cooldown are independent. */
export function advanceCombat(state:GameState,dt=1):GameState {
  if(state.phase!=='playing')return state;
  let units=state.units.filter(u=>u.hp>0).map(u=>({...u,cooldown:Math.max(0,u.cooldown-dt)}));
  const shots=state.shots.map(s=>({...s,life:s.life-dt})).filter(s=>s.life>0);
  let ammo=state.resources.ammo,fuel=state.resources.fuel,enemyHp=state.enemyHp,baseHp=state.baseHp;
  let engaged=false;
  let enemyResources={...state.opponent.resources};
  const damage=new Map<number,number>(),buildingDamage=new Map<string,number>();
  const buildingsOf=(faction:'player'|'enemy')=>faction==='player'?state.opponent.buildings:state.buildings;
  // Stale building targets are cleared the tick after that structure is destroyed.
  units=units.map(unit=>{
    if(unit.targetBld&&!buildingsOf(unit.faction).some(b=>b.id===unit.targetBld))
      return {...unit,order:'idle' as const,targetId:null,targetBld:null,targetX:unit.x,targetZ:unit.z,path:[]};
    const opponents=units.filter(v=>v.faction!==unit.faction&&visibleTo(state,unit.faction,v));
    const nearest=opponents.sort((a,b)=>distance(unit,a)-distance(unit,b))[0];
    if(unit.faction==='enemy'&&state.tick>=15&&nearest&&distance(unit,nearest)<unit.vision) {
      return {...unit,order:'attack' as const,targetId:nearest.id,targetBld:null};
    }
    if(unit.order==='attack'&&unit.targetId!==null&&unit.targetId>=0&&!opponents.some(v=>v.id===unit.targetId))
      return unit.faction==='enemy'?{...unit,targetId:-2,targetBld:null,path:[]}:{...unit,order:'idle' as const,targetId:null,targetBld:null,path:[]};
    return unit;
  });
  units=units.map(unit=>{
    const burnFuel=()=>{
      // Ground vehicles burn faction fuel while underway; a dry pool halves their speed.
      if(!UNIT_SPECS[unit.kind].air&&unit.armor>=2){
        const burn=unit.speed*dt*.05;
        if(unit.faction==='player')fuel=Math.max(0,fuel-burn);
        else enemyResources={...enemyResources,fuel:Math.max(0,enemyResources.fuel-burn)};
      }
    };
    if(unit.order==='move'){burnFuel();return advanceMovement(state,unit,{x:unit.targetX,z:unit.targetZ},dt);}
    if(unit.order!=='attack')return unit;
    if(unit.targetBld){
      const building=buildingsOf(unit.faction).find(b=>b.id===unit.targetBld);
      if(building&&distance(unit,building)>unit.range*.86){burnFuel();
        return advanceMovement(state,{...unit,targetX:building.x,targetZ:building.z},building,dt);}
      return unit;
    }
    const target=unit.targetId===-1?ENEMY_HQ:unit.targetId===-2?PLAYER_HQ:units.find(v=>v.id===unit.targetId);
    if(!target)return unit;
    if(distance(unit,target)>unit.range*.86){burnFuel();
      return advanceMovement(state,{...unit,targetX:target.x,targetZ:target.z},target,dt);}
    return unit;
  });
  for(const unit of units) {
    if(unit.cooldown>1e-7||unit.damage<=0)continue;
    const nearby=units.filter(v=>v.faction!==unit.faction&&distance(unit,v)<=unit.range&&visibleTo(state,unit.faction,v))
      .sort((a,b)=>distance(unit,a)-distance(unit,b))[0];
    const structures=buildingsOf(unit.faction)
      .filter(b=>b.kind!=='hq'&&distance(unit,b)<=unit.range);
    let preferred=structures[0]??null;
    if(unit.targetBld){
      const ordered=structures.find(b=>b.id===unit.targetBld);
      if(ordered)preferred=ordered;
    }
    const orderedUnit=unit.targetId===-1?ENEMY_HQ:unit.targetId===-2?PLAYER_HQ:units.find(v=>v.id===unit.targetId&&v.faction!==unit.faction);
    const target=nearby ?? (unit.order==='attack'?preferred??(orderedUnit&&distance(unit,orderedUnit)<=unit.range?orderedUnit:null):null);
    if(!target)continue;
    const ammoCost=unit.armor>=7||unit.kind==='artillery'?3:1;
    const resources=unit.faction==='player'?{ammo}:enemyResources;
    if(resources.ammo<ammoCost)continue;
    if(unit.faction==='player')ammo-=ammoCost;
    else enemyResources={...enemyResources,ammo:resources.ammo-ammoCost};
    const technologies=unit.faction==='player'?state.technologies:state.opponent.technologies;
    const opponentTech=unit.faction==='player'?state.opponent.technologies:state.technologies;
    const armor='armor' in target?target.armor+opponentTech.armor*5:0;
    const penetration=unit.kind==='antitank'?armor*.8:0;
    const cover=state.biome==='forest'&&'kind' in target&&['infantry','sniper','engineer','antitank'].includes(target.kind)?.85:1;
    const accuracy=1-.18*Math.min(1,distance(unit,target)/unit.range);
    const hit=Math.max(2,unit.damage*(1+technologies.weapons*.3)-armor+penetration)*cover*accuracy;
    if('id' in target&&typeof target.id==='number')damage.set(target.id,(damage.get(target.id)??0)+hit);
    else if('id' in target&&typeof target.id==='string')buildingDamage.set(target.id,(buildingDamage.get(target.id)??0)+hit*.3);
    else if(unit.faction==='player')enemyHp=Math.max(0,enemyHp-hit*.12);
    else baseHp=Math.max(0,baseHp-hit*.12);
    unit.cooldown=unit.kind==='artillery'?3:unit.armor>=7?2.2:1.2;
    engaged=true;
    shots.push({id:state.tick*1000+unit.id,x:unit.x,z:unit.z,toX:target.x,toZ:target.z,faction:unit.faction,life:.22});
  }
  // Towers and the command HQ provide functional, bounded point defense.
  if(Math.floor(state.tick+dt+1e-7)>Math.floor(state.tick+1e-7)){
    for(const [faction,buildings] of [['player',state.buildings],['enemy',state.opponent.buildings]] as const){
      for(const b of buildings.filter(b=>b.status==='active'&&['watchtower','hq','missile'].includes(b.kind))){
        const target=units.find(u=>u.faction!==faction&&distance(u,b)<(b.kind==='hq'?8:b.kind==='missile'?12:9));
        if(target){damage.set(target.id,(damage.get(target.id)??0)+(b.kind==='hq'?8:b.kind==='missile'?24:15)*b.level);engaged=true;}
      }
    }
  }
  // Same-faction units gently push apart so armies never stack into a single point.
  for(let i=0;i<units.length;i++)for(let j=i+1;j<units.length;j++){
    const a=units[i],b=units[j];
    if(a.faction!==b.faction)continue;
    const dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz);
    if(d>=.95||d<1e-6)continue;
    const push=(1-d)*Math.min(.5,dt*1.5)/2,nx=dx/d,nz=dz/d;
    units[i]={...a,x:a.x-nx*push,z:a.z-nz*push};
    units[j]={...b,x:b.x+nx*push,z:b.z+nz*push};
  }
  units=units.map(u=>{
    const hospital=(u.faction==='player'?state.buildings:state.opponent.buildings)
      .some(b=>b.kind==='hospital'&&b.status==='active'&&distance(b,u)<13);
    return {...u,hp:Math.max(0,Math.min(u.maxHp,u.hp-(damage.get(u.id)??0)+(hospital&&!damage.has(u.id)?3*dt:0)))};
  });
  const kills=units.filter(u=>u.hp<=0&&u.faction==='enemy').length;
  const losses=units.filter(u=>u.hp<=0&&u.faction==='player').length;
  const updateBuildings=(buildings:GameState['buildings'],hq:number)=>buildings.map(b=>({...b,
    hp:b.kind==='hq'?hq:Math.max(0,b.hp-(buildingDamage.get(b.id)??0))})).filter(b=>b.hp>0||b.kind==='hq');
  return {...state,units:units.filter(u=>u.hp>0),shots,enemyHp,baseHp,kills:state.kills+kills,losses:state.losses+losses,
    contact:state.contact||engaged,
    buildings:updateBuildings(state.buildings,baseHp),
    opponent:{...state.opponent,buildings:updateBuildings(state.opponent.buildings,enemyHp),
      resources:{...enemyResources,steel:Math.min(99999,enemyResources.steel+losses*30)}},
    resources:{...state.resources,ammo,fuel,steel:Math.min(99999,state.resources.steel+kills*30)},
    message:kills?'HOSTILE DESTROYED +30 STEEL / تدمير عدو':losses?'FRIENDLY UNIT LOST / خسارة وحدة':state.message};
}
