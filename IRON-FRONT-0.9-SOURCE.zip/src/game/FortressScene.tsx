import { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Instance, Instances, Line, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import type { Building, BuildingKind, GameState, Unit, UnitKind } from './types';
import { visibleTo } from './visibility';
import { UNIT_SPECS } from './unitSystem';
import { rocks, mountains, bridges, RIVER_X } from './navigation';

function Box({position=[0,0,0],size=[1,1,1],color='#758880'}:{
  position?:[number,number,number];size?:[number,number,number];color?:string}) {
  return <mesh position={position} castShadow receiveShadow><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.72} metalness={.28}/></mesh>;
}
function PerformanceMeter({onDegraded}:{onDegraded?:()=>void}){
  const renderer=useThree(s=>s.gl),counter=useRef({frames:0,time:performance.now(),slow:0});
  useFrame(()=>{
    counter.current.frames++;const now=performance.now();
    if(now-counter.current.time>1000){
      const fps=Math.round(counter.current.frames*1000/(now-counter.current.time));
      if(fps<25&&renderer.shadowMap.enabled){renderer.shadowMap.enabled=false;renderer.shadowMap.needsUpdate=true;}
      const slow=fps<20?counter.current.slow+1:0;
      if(slow>=4)onDegraded?.();
      const element=document.getElementById('performance');
      if(element)element.textContent=`${fps} FPS / ${renderer.info.render.calls} DRAW`;
      counter.current={frames:0,time:now,slow};
    }
  });
  return null;
}
function Terrain({state,rallyMode,onMoveOrder,onSetRally}:{state:GameState;rallyMode:boolean;
  onMoveOrder:(x:number,z:number)=>void;onSetRally:(x:number,z:number)=>void}) {
  const trees=useMemo(()=>Array.from({length:110},(_,i)=>({x:Math.sin(i*17.31)*52+23,z:Math.cos(i*9.17)*24,
    s:.7+(i%4)*.18})).filter(p=>!(p.x<1&&p.x>-25&&p.z>-4&&p.z<13)&&
      !(p.x>45&&p.x<71&&p.z<5&&p.z>-13)&&Math.abs(p.x-RIVER_X)>3.6),[]);
  const color=state.biome==='snow'?'#c0ccc8':state.biome==='desert'?'#a18b65':'#4b6150';
  /** Thin translucent strip between two ground points: the dedicated haul roads. */
  const strip=(ax:number,az:number,bx:number,bz:number,w=.8,opacity=.3)=>{
    const len=Math.hypot(bx-ax,bz-az),mx=(ax+bx)/2,mz=(az+bz)/2,angle=Math.atan2(bz-az,bx-ax);
    return <mesh position={[mx,.035,mz]} rotation={[-Math.PI/2,0,-angle]}><planeGeometry args={[len,w]}/><meshBasicMaterial color="#c9b97e" transparent opacity={opacity}/></mesh>;
  };
  return <group>
    <mesh rotation={[-Math.PI/2,0,0]} receiveShadow onClick={e=>{e.stopPropagation();
      if(e.delta>6)return; // a finger drag pans the camera, it is not a tap
      if(rallyMode)onSetRally(e.point.x,e.point.z);else onMoveOrder(e.point.x,e.point.z);}}>
      <planeGeometry args={[112,56]}/><meshStandardMaterial color={color} roughness={1}/></mesh>
    {/* The river splits the field; three bridges are the only crossings, guarded by mountain walls. */}
    <mesh position={[RIVER_X,.028,0]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[2.4,54]}/><meshStandardMaterial color={state.biome==='snow'?'#7fa8b5':'#3d6b7a'} roughness={.25} metalness={.35}/></mesh>
    {bridges.map(b=><group key={b.z} position={[RIVER_X,0,b.z]}>
      <Box position={[0,.14,0]} size={[3.8,.26,5]} color="#8a6f4d"/>
      <Box position={[0,.32,2.4]} size={[3.8,.1,.14]} color="#5f4c33"/><Box position={[0,.32,-2.4]} size={[3.8,.1,.14]} color="#5f4c33"/>
      {[-1.2,-.4,.4,1.2].map(o=><Box key={o} position={[0,.27,o]} size={[3.8,.05,.1]} color="#6b5539"/>)}
    </group>)}
    {mountains.map((m,i)=><mesh key={i} position={[m.x,m.r*.85,m.z]} castShadow><coneGeometry args={[m.r,m.r*1.7,7]}/><meshStandardMaterial color="#5c6670" roughness={1}/></mesh>)}
    {/* Rich mines: gold-flecked rock on each faction's side, joined to its HQ by a haul road. */}
    {state.mines.map(m=><group key={m.faction}>
      {m.faction==='player'?strip(-1,4,m.x,m.z):strip(46,-4,m.x,m.z)}
      <group position={[m.x,0,m.z]}>
        <mesh position={[0,.75,0]} castShadow><dodecahedronGeometry args={[1.1,0]}/><meshStandardMaterial color="#4a4038" roughness={.9}/></mesh>
        <mesh position={[.5,1.5,.3]}><octahedronGeometry args={[.32]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
        <mesh position={[-.45,1.3,-.25]}><octahedronGeometry args={[.24]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
        <mesh position={[.1,1.7,-.4]}><octahedronGeometry args={[.2]}/><meshStandardMaterial color="#e8cb7f" metalness={.6} roughness={.3}/></mesh>
      </group>
    </group>)}
    {/* Rally flag: fresh reinforcements march here. */}
    <group position={[state.rally?.x??-6,0,state.rally?.z??3]}>
      <mesh position={[0,1.1,0]}><cylinderGeometry args={[.05,.05,2.2,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>
      <mesh position={[.45,1.95,0]}><planeGeometry args={[.9,.5]}/><meshBasicMaterial color="#e8cb7f" side={THREE.DoubleSide}/></mesh>
      <mesh rotation={[-Math.PI/2,0,0]} position={[0,.04,0]}><ringGeometry args={[.85,.95,24]}/><meshBasicMaterial color="#e8cb7f" transparent opacity={.55}/></mesh>
    </group>
    <gridHelper args={[104,52,state.biome==='snow'?'#a0b3ad':'#7d8a6e','#63775f']} position={[23,.018,0]} material-transparent material-opacity={.22}/>
    <mesh position={[23,.025,3]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[88,3.2]}/><meshStandardMaterial color={state.biome==='snow'?'#9baaa6':'#897f69'} roughness={1}/></mesh>
    {state.biome!=='desert'&&<><Instances limit={140} castShadow><cylinderGeometry args={[.13,.2,1.6,5]}/><meshStandardMaterial color="#4b4c3c"/>
      {trees.map((t,i)=><Instance key={i} position={[t.x,.8*t.s,t.z]} scale={t.s}/>)}</Instances>
      <Instances limit={140} castShadow><coneGeometry args={[1,2.8,6]}/><meshStandardMaterial color={state.biome==='snow'?'#819b90':'#294b3c'}/>
        {trees.map((t,i)=><Instance key={i} position={[t.x,2.4*t.s,t.z]} scale={t.s}/>)}</Instances></>}
    {rocks.map((r,i)=><mesh key={i} position={[r.x,.65,r.z]} scale={[r.r,1.2,r.r]} castShadow><dodecahedronGeometry args={[1,0]}/><meshStandardMaterial color="#707a73" roughness={1}/></mesh>)}
    {Array.from({length:17},(_,i)=><mesh key={i} position={[-34+i*7,2,-27-(i%2)*3]} scale={[5+(i%3),4+(i%4),4]}><coneGeometry args={[1,2,5]}/><meshStandardMaterial color={state.biome==='snow'?'#a0b4b1':'#5b6b60'} roughness={1}/></mesh>)}
    {Array.from({length:17},(_,i)=><mesh key={'s'+i} position={[-34+i*7,2,27+(i%2)*3]} scale={[5+(i%3),4+(i%4),4]}><coneGeometry args={[1,2,5]}/><meshStandardMaterial color={state.biome==='snow'?'#a0b4b1':'#5b6b60'} roughness={1}/></mesh>)}
  </group>;
}
/** Corner towers remain as decoration; the fence itself is now built as destructible wall segments. */
function CornerTowers({enemy=false}:{enemy?:boolean}) {
  const transform=(x:number,z:number):[number,number,number]=>[enemy?46-x:x,0,enemy?-z:z];
  return <group>
    {[-24,-1].flatMap((x)=>[-3.4,11.6].map(z=><group key={`${x}:${z}`} position={transform(x,z)}>
      <Box position={[0,.85,0]} size={[1.3,1.7,1.3]} color="#718179"/><Box position={[0,1.9,0]} size={[1.6,.4,1.6]} color={enemy?'#956659':'#b5a273'}/>
    </group>))}
  </group>;
}
function Structure({building,enemy=false,onAttackBuilding,onSelectBuilding,selected}:{building:Building;enemy?:boolean;
  onAttackBuilding:(id:string)=>void;onSelectBuilding:(id:string)=>void;selected?:boolean}) {
  const {kind,x,z,status,remaining,buildSeconds}=building;
  const colors:Record<BuildingKind,string>={hq:'#a9b8b5',barracks:'#819878',power:'#b4a76d',refinery:'#9ba49c',
    factory:'#869a9d',research:'#819fa6',watchtower:'#9eac9e',hospital:'#c2cbc0',ammo:'#a99a72',
    vehicleFactory:'#819490',airfield:'#7b918d',missile:'#9d9e89',wall:'#87968b',command:'#9caca8'};
  const c=enemy?'#a76b5d':colors[kind],progress=status==='active'?1:1-remaining/buildSeconds;
  const tower=kind==='watchtower'||kind==='missile',height=tower?2.7:kind==='hq'?1.6:1;
  return <group position={[x,0,z]} onClick={e=>{e.stopPropagation();if(e.delta>6)return;
      if(enemy)onAttackBuilding(building.id);else onSelectBuilding(building.id);}}>
    {selected&&!enemy&&<mesh rotation={[-Math.PI/2,0,0]} position={[0,.05,0]}><ringGeometry args={[3,3.2,40]}/><meshBasicMaterial color="#e8cb7f"/></mesh>}
    <Box position={[0,.08,0]} size={kind==='hq'?[4.8,.16,4.2]:[3.2,.16,2.8]} color="#34473f"/>
    <group scale={[1,Math.max(.08,progress),1]}>
      <Box position={[0,height/2,0]} size={tower?[.8,height,.8]:kind==='wall'?[2.8,1.3,.65]:kind==='hq'?[3.8,height,3.2]:[2.7,height,2.3]} color={c}/>
      {!['wall','refinery','airfield'].includes(kind)&&<Box position={[0,height+.18,0]} size={tower?[1.5,.35,1.5]:[2,.35,1.6]} color={enemy?'#66493f':'#41564f'}/>}
      {(kind==='hq'||kind==='command'||kind==='research')&&<group position={[.55,height+.3,0]}>
        <Box position={[0,.65,0]} size={[.08,1.3,.08]} color="#263b35"/>
        <mesh position={[0,1.25,0]} rotation={[.3,0,.5]}><sphereGeometry args={[.5,12,6,0,Math.PI]}/><meshStandardMaterial color="#c6d0bc" side={THREE.DoubleSide}/></mesh>
      </group>}
      {kind==='power'&&<><Box position={[-.6,1.7,0]} size={[.45,1.4,.45]} color="#d4c398"/><Box position={[.6,1.5,0]} size={[.45,1,.45]} color="#d4c398"/></>}
      {kind==='refinery'&&[-.8,0,.8].map(offset=><mesh key={offset} position={[offset,1.2,0]} castShadow><cylinderGeometry args={[.4,.4,2,12]}/><meshStandardMaterial color="#c1c3a8" roughness={.45} metalness={.5}/></mesh>)}
      {(kind==='factory'||kind==='vehicleFactory')&&<Box position={[0,.5,1.18]} size={[1.8,.8,.08]} color="#172b25"/>}
      {kind==='barracks'&&[-.8,0,.8].map(offset=><Box key={offset} position={[offset,.6,1.17]} size={[.3,.35,.04]} color="#d3d0a6"/>)}
      {kind==='hospital'&&<><Box position={[0,1.4,0]} size={[.4,.08,1.3]} color="#d64f40"/><Box position={[0,1.4,0]} size={[1.3,.08,.4]} color="#d64f40"/></>}
      {kind==='airfield'&&<><Box position={[0,1.03,0]} size={[2.8,.04,2.5]} color="#4b5a54"/><Box position={[0,1.08,0]} size={[1.6,.03,.15]} color="#dad9b5"/><Box position={[-.8,1.08,0]} size={[.15,.03,1.4]} color="#dad9b5"/><Box position={[.8,1.08,0]} size={[.15,.03,1.4]} color="#dad9b5"/></>}
      {kind==='missile'&&<group position={[0,3.1,0]} rotation={[0,0,-.5]}><Box size={[1.3,.45,.8]} color="#d4ca98"/><Box position={[-.5,.3,0]} size={[.12,.4,.9]} color="#364c40"/></group>}
      {kind==='ammo'&&[-.7,.1,.8].map(offset=><Box key={offset} position={[offset,1.35,0]} size={[.5,.5,.7]} color="#d0b979"/>)}
    </group>
    <mesh position={[0,.19,1.6]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[2.5*building.hp/building.maxHp,.12]}/><meshBasicMaterial color={enemy?'#ee9683':'#a9d8ab'}/></mesh>
    {building.level>1&&<mesh position={[1.2,1.5,0]}><sphereGeometry args={[.14,6,6]}/><meshBasicMaterial color="#e8cb7f"/></mesh>}
  </group>;
}
function UnitMesh({unit,onSelect,onSelectKind}:{unit:Unit;onSelect:(id:number,enemy:boolean,multi:boolean)=>void;onSelectKind:(kind:UnitKind)=>void}) {
  const enemy=unit.faction==='enemy',spec=UNIT_SPECS[unit.kind],vehicle=spec.armor>=2,
    air=!!spec.air,color=enemy?'#b86f5d':'#a4b58c',rotation=Math.atan2(unit.targetX-unit.x,unit.targetZ-unit.z);
  return <group position={[unit.x,air?2.7:.1,unit.z]} onClick={e=>{e.stopPropagation();if(e.delta>6)return;onSelect(unit.id,enemy,!!(e.nativeEvent as PointerEvent).shiftKey);}}
    onDoubleClick={e=>{e.stopPropagation();if(!enemy)onSelectKind(unit.kind);}}>
    {/* Invisible, finger-sized hit area: small soldiers are easy to tap. */}
    <mesh position={[0,.6,0]}><cylinderGeometry args={[vehicle?1.3:.9,vehicle?1.3:.9,1.4,10]}/><meshBasicMaterial transparent opacity={0} depthWrite={false}/></mesh>
    <group rotation={[0,rotation,0]}>
      <Box position={[0,.35,0]} size={air?[.6,.4,1.7]:vehicle?[1.2,.5,1.8]:[.35,.65,.3]} color={color}/>
      {vehicle&&!air&&<><Box position={[-.64,.18,0]} size={[.25,.3,1.9]} color="#293c33"/><Box position={[.64,.18,0]} size={[.25,.3,1.9]} color="#293c33"/>
        <Box position={[0,.72,-.1]} size={unit.kind==='artillery'?[.6,.5,1.2]:[.65,.35,.7]} color={enemy?'#865144':'#6c845f'}/>
        <Box position={[0,.77,.8]} size={[.12,.12,unit.kind==='artillery'?2.3:1.5]} color="#304139"/></>}
      {!vehicle&&!air&&<><mesh position={[0,.89,0]}><sphereGeometry args={[.2,8,6]}/><meshStandardMaterial color={enemy?'#b7a089':'#d1c49e'}/></mesh>
        <Box position={[.22,.5,.2]} size={[.1,.1,unit.kind==='sniper'?.9:.5]} color="#26372d"/>
        {unit.kind==='antitank'&&<Box position={[.22,.73,0]} size={[.18,.18,.9]} color="#495a37"/>}</>}
      {air&&<><Box position={[0,.7,0]} size={unit.kind==='helicopter'?[3.5,.06,.18]:[2.4,.08,.2]} color="#c3ccb2"/><Box position={[0,.4,-1.1]} size={[1,.12,.25]} color="#a4b58c"/></>}
    </group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,.03,0]}><ringGeometry args={[vehicle?.9:.5,vehicle?1:.6,20]}/><meshBasicMaterial color={unit.selected?'#85e2d1':enemy?'#ef9b85':'#c4d6a8'} transparent opacity={unit.selected?1:.45}/></mesh>
    <group position={[0,1.5,0]}><mesh><planeGeometry args={[.95,.09]}/><meshBasicMaterial color="#152b22"/></mesh>
      <mesh position={[-.475*(1-unit.hp/unit.maxHp),0,.002]}><planeGeometry args={[.95*unit.hp/unit.maxHp,.065]}/><meshBasicMaterial color={enemy?'#ed9b8e':'#a3e1ac'}/></mesh></group>
  </group>;
}
function Weather({state,paused}:{state:GameState;paused:boolean}){
  const points=useRef<THREE.Points>(null);
  const positions=useMemo(()=>{
    const array=new Float32Array(140*3);
    for(let i=0;i<140;i++){array[i*3]=Math.sin(i*13.7)*54+23;array[i*3+1]=(i%19)*.8;array[i*3+2]=Math.cos(i*9.3)*25;}
    return array;
  },[]);
  useFrame((_,dt)=>{
    if(!points.current||paused)return;
    const attr=points.current.geometry.attributes.position;
    for(let i=0;i<attr.count;i++){attr.setY(i,(attr.getY(i)-dt*(state.biome==='snow'?1.5:8)+16)%16);}
    attr.needsUpdate=true;
  });
  if(state.biome==='desert')return null;
  return <points ref={points}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry>
    <pointsMaterial color={state.biome==='snow'?'#edf5ed':'#b6d1c9'} size={state.biome==='snow'?.08:.045} transparent opacity={.5}/></points>;
}
function AutoCamera(){
  const {camera,size}=useThree();
  useMemo(()=>{
    const distance=Math.min(2,Math.max(1,1.4/(size.width/size.height)));
    camera.position.set(-8,30*distance,38*distance);camera.lookAt(-8,0,4);
  },[camera,size.width,size.height]);
  return null;
}
/** Expanding ring where a move order was just given: instant visual feedback for a tap. */
function OrderPing({ping}:{ping:{x:number;z:number;k:number}|null}){
  const ref=useRef<THREE.Mesh>(null);
  useFrame(()=>{
    if(!ref.current||!ping)return;
    const age=Math.min(1,(Date.now()-ping.k)/700);
    ref.current.scale.setScalar(.6+age*1.6);
    (ref.current.material as THREE.MeshBasicMaterial).opacity=1-age;
  });
  if(!ping)return null;
  return <mesh key={ping.k} ref={ref} position={[ping.x,.09,ping.z]} rotation={[-Math.PI/2,0,0]}>
    <ringGeometry args={[.8,1,28]}/><meshBasicMaterial color="#85e2d1" transparent opacity={1} depthWrite={false}/></mesh>;
}
/** Keeps the free camera over the battlefield so a drag can never lose the map. */
function CameraBounds(){
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  useFrame(()=>{
    if(!controls?.target)return;
    const t=controls.target,x=THREE.MathUtils.clamp(t.x,-34,70),z=THREE.MathUtils.clamp(t.z,-26,26);
    if(x!==t.x||z!==t.z){camera.position.x+=x-t.x;camera.position.z+=z-t.z;t.x=x;t.z=z;}
  });
  return null;
}
function CameraCapture({cameraRef}:{cameraRef:React.MutableRefObject<THREE.Camera|null>}){
  const camera=useThree(s=>s.camera);
  useEffect(()=>{cameraRef.current=camera;});
  return null;
}
/** Reports the orbit camera's target and distance to the parent so the radar minimap can frame it. */
function CameraLink({onCameraMove}:{onCameraMove:(x:number,z:number,dist:number)=>void}) {
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  const last=useRef(0);
  useFrame(()=>{
    const now=performance.now();if(now-last.current<250)return;last.current=now;
    if(controls?.target)onCameraMove(controls.target.x,controls.target.z,camera.position.distanceTo(controls.target));
  });
  return null;
}
/** Exposes a jump function so tapping the radar minimap pans the 3D camera to that point. */
function JumpBinder({jumpRef}:{jumpRef:React.MutableRefObject<((x:number,z:number)=>void)|null>}) {
  const camera=useThree(s=>s.camera),controls=useThree(s=>s.controls) as {target:THREE.Vector3}|null;
  useEffect(()=>{
    jumpRef.current=(x:number,z:number)=>{
      if(!controls?.target)return;
      if(!Number.isFinite(x)||!Number.isFinite(z))return;
      const dx=x-controls.target.x,dz=z-controls.target.z;
      controls.target.x+=dx;controls.target.z+=dz;camera.position.x+=dx;camera.position.z+=dz;
    };
    return ()=>{jumpRef.current=null;};
  },[camera,controls,jumpRef]);
  return null;
}
export function FortressScene({state,paused,onSelect,onSelectKind,onMoveOrder,onAttackBuilding,onRectSelect,rallyMode,onSetRally,onSelectBuilding,selectedBuildingId,onCameraMove,jumpRef}:{state:GameState;paused:boolean;
  onSelectKind:(kind:UnitKind)=>void;
  onSelect:(id:number,enemy:boolean,multi:boolean)=>void;onMoveOrder:(x:number,z:number)=>void;
  onAttackBuilding:(id:string)=>void;onRectSelect:(ids:number[],additive:boolean)=>void;
  moveMode?:boolean;rallyMode?:boolean;onSetRally:(x:number,z:number)=>void;
  onSelectBuilding:(id:string)=>void;selectedBuildingId?:string|null;
  onCameraMove?:(x:number,z:number,dist:number)=>void;jumpRef:React.MutableRefObject<((x:number,z:number)=>void)|null>}) {
  const daylight=.65+.35*Math.cos(state.tick/300*Math.PI*2);
  const wrap=useRef<HTMLDivElement|null>(null);
  const [ping,setPing]=useState<{x:number;z:number;k:number}|null>(null);
  const hasSelection=state.units.some(u=>u.faction==='player'&&u.selected);
  const orderMove=(x:number,z:number)=>{onMoveOrder(x,z);if(hasSelection)setPing({x,z,k:Date.now()});};
  const cameraRef=useRef<THREE.Camera|null>(null);
  const start=useRef<{x:number;y:number}|null>(null);
  const [marquee,setMarquee]=useState<{x1:number;y1:number;x2:number;y2:number}|null>(null);
  const toLocal=(e:React.PointerEvent)=>{const r=wrap.current!.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};};
  const onPointerDown=(e:React.PointerEvent)=>{
    if(e.button!==0||e.pointerType!=='mouse')return;
    start.current=toLocal(e);setMarquee(null);
  };
  const onPointerMove=(e:React.PointerEvent)=>{
    if(!start.current)return;
    const p=toLocal(e);
    setMarquee({x1:start.current.x,y1:start.current.y,x2:p.x,y2:p.y});
  };
  const onPointerUp=(e:React.PointerEvent)=>{
    const s=start.current;start.current=null;
    if(!s){setMarquee(null);return;}
    const end=toLocal(e);setMarquee(null);
    const w=Math.abs(end.x-s.x),h=Math.abs(end.y-s.y);
    const camera=cameraRef.current;
    if(!camera||w<6||h<6)return;
    const size=wrap.current!.getBoundingClientRect();
    const box={x1:Math.min(s.x,end.x),x2:Math.max(s.x,end.x),y1:Math.min(s.y,end.y),y2:Math.max(s.y,end.y)};
    const ids=state.units.filter(u=>u.faction==='player'&&u.hp>0).map(u=>{
      const v=new THREE.Vector3(u.x,.1,u.z).project(camera);
      return {id:u.id,x:(v.x+1)/2*size.width,y:(1-v.y)/2*size.height};
    }).filter(p=>p.x>=box.x1&&p.x<=box.x2&&p.y>=box.y1&&p.y<=box.y2).map(p=>p.id);
    if(ids.length)onRectSelect(ids,e.shiftKey);
  };
  return <div ref={wrap} style={{position:'relative',width:'100%',height:'100%'}}>
    <Canvas shadows camera={{position:[-8,30,38],fov:48,near:.1,far:420}} dpr={1}
      gl={{antialias:false,powerPreference:'high-performance'}}
      onCreated={({gl})=>{
        const context=gl.getContext(),info=context.getExtension('WEBGL_debug_renderer_info');
        const name=info?String(context.getParameter(info.UNMASKED_RENDERER_WEBGL)):'';
        if(/swiftshader|llvmpipe|software/i.test(name))gl.shadowMap.enabled=false;
      }}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
      fallback={<div>WebGL unavailable on this device.</div>}>
      <color attach="background" args={[state.biome==='snow'?'#738c90':'#263f3d']}/>
      <fog attach="fog" args={[state.biome==='snow'?'#a5bcb8':'#3c554a',95,300]}/>
      <ambientLight intensity={.9+daylight*.35}/><hemisphereLight args={['#cfdfdd','#50604b',1.4]}/>
      <directionalLight position={[-18,28,10]} intensity={daylight*2.2} castShadow shadow-mapSize={[1024,1024]}
        shadow-camera-left={-60} shadow-camera-right={60} shadow-camera-top={50} shadow-camera-bottom={-50} shadow-bias={-.001}/>
      <Terrain state={state} rallyMode={!!rallyMode} onMoveOrder={orderMove} onSetRally={onSetRally}/>
      <OrderPing ping={ping}/>
      <CornerTowers/><CornerTowers enemy/>
      {state.buildings.map(b=><Structure key={b.id} building={b} onAttackBuilding={onAttackBuilding}
        onSelectBuilding={onSelectBuilding} selected={selectedBuildingId===b.id}/>)}
      {state.opponent.buildings.filter(b=>b.kind==='hq'||visibleTo(state,'player',b)).map(b=>
        <Structure key={b.id} building={b} enemy onAttackBuilding={onAttackBuilding} onSelectBuilding={onSelectBuilding}/>)}
      {state.units.filter(u=>u.faction==='player'||visibleTo(state,'player',u)).map(u=><UnitMesh key={u.id} unit={u} onSelect={onSelect} onSelectKind={onSelectKind}/>)}
      {state.zones.map(z=><group key={z.id} position={[z.x,.07,z.z]}>
        <mesh rotation={[-Math.PI/2,0,0]}><ringGeometry args={[2.5,2.65,40]}/><meshBasicMaterial color={z.owner==='player'?'#a9d8ab':z.owner==='enemy'?'#ee9683':'#e4cd8f'}/></mesh>
        <Box position={[0,.25,0]} size={[1,.5,1]} color="#b9a875"/><Box position={[0,1.2,0]} size={[.06,2,.06]} color="#d5dcc4"/>
        <Box position={[.4,1.8,0]} size={[.8,.5,.03]} color={z.owner==='player'?'#80af8a':z.owner==='enemy'?'#c97662':'#c9b97e'}/>
      </group>)}
      {state.shots.map(shot=><group key={shot.id}>
        <Line points={[[shot.x,.85,shot.z],[shot.toX,.7,shot.toZ]]} color={shot.faction==='player'?'#ffe5a0':'#ffac80'} lineWidth={1.5}/>
        <mesh position={[shot.toX,.7,shot.toZ]}><sphereGeometry args={[.25,6,6]}/><meshBasicMaterial color="#ffd293"/></mesh>
      </group>)}
      <Weather state={state} paused={paused}/><AutoCamera/><PerformanceMeter/><CameraCapture cameraRef={cameraRef}/>
      {onCameraMove&&<CameraLink onCameraMove={onCameraMove}/>}
      <JumpBinder jumpRef={jumpRef}/><CameraBounds/>
      <OrbitControls makeDefault target={[-8,0,4]} maxPolarAngle={Math.PI/2.15} minDistance={14} maxDistance={120}
        enableRotate={false} screenSpacePanning={false} panSpeed={1.1} enableDamping dampingFactor={.12}
        mouseButtons={{LEFT:undefined as unknown as THREE.MOUSE,MIDDLE:THREE.MOUSE.PAN,RIGHT:THREE.MOUSE.PAN}}
        touches={{ONE:THREE.TOUCH.PAN,TWO:THREE.TOUCH.DOLLY_PAN}}/>
    </Canvas>
    {marquee&&<div style={{position:'absolute',left:Math.min(marquee.x1,marquee.x2),top:Math.min(marquee.y1,marquee.y2),
      width:Math.abs(marquee.x2-marquee.x1),height:Math.abs(marquee.y2-marquee.y1),
      border:'1px solid #85e2d1',background:'rgba(133,226,209,.12)',pointerEvents:'none'}}/>}
  </div>;
}
