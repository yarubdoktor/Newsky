# IRON-FRONT 0.10 — Combat response update

- Player units now automatically retaliate against the exact hostile unit that damages them.
- Retaliation is unit-to-unit only; it never creates an HQ or building attack order.
- Retaliating units close distance to their attacker using the existing navigation system.
- Nearest visible hostile selection within weapon range is covered by a regression test.
- Existing HP, damage, cooldown, ammunition, death/removal, kill credit and health bars are retained and tested.
- Shot feedback now includes a brief muzzle flash and expanding impact ring in addition to the existing tracer.
- Existing movement, selection, camera, touch gestures, and manual HQ/building attack controls are unchanged.

## Verification

- TypeScript no-emit check passed for combat and navigation modules.
- Syntax transpilation passed for the scene and simulation tests.
- Focused runtime tests passed for attacker-specific retaliation, movement toward the attacker, nearest-target selection, lethal damage, kill credit, and no automatic HQ attack.
- Full npm test/build and Android APK build still require the GitHub Actions run; local dependency installation timed out in this environment.
