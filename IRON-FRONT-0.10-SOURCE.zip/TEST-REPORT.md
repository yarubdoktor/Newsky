# IRON FRONT 0.8: verification report

This release continues the original repository's `IRON-FRONT` React application. Tests verify an integrated single-sector skirmish release, not completion of every feature in the AAA brief.

## Automated checks

- `npm test`: 43 tests passed, zero failures.
- `npm run build`: TypeScript project check and Vite production build passed.
- `npm install --package-lock-only`: lockfile synchronized with version 0.4.0; audit reported zero known vulnerabilities at the time of this run.
- Production output: one self-contained `dist/index.html`, approximately 1.95 MB before ZIP compression (the Three.js 3D renderer is restored as the only battlefield view). Fonts and application assets are embedded.
- A cloud browser with a phone-sized viewport (390 x 844) ran the production HTML: Arabic briefing, the folded command HUD, the 3D battlefield at 60 FPS with terrain, trees, the river, three bridges, mountain walls, mines with haul roads and the rally flag. Tapping the radar minimap pans the 3D camera (verified jumping to the enemy base and back), a gold selection ring and the contextual card open when the HQ is tapped (training a mine worker from the card spawns it after the 5-second training strip countdown), trusted touch gestures work (one-finger drag draws the selection rectangle without rotating the camera, two-finger pinch zooms, two-finger drag pans, right-drag rotates on desktop) and move orders send selected units across the field. No layout overflow, clipped text or mixed-direction (bidi) label defects remained after the direction fixes.
- Two nonfatal Rollup warnings concern dependency comment annotations in Zod. They do not indicate TypeScript errors or a failed build.

## Simulation coverage

- Fresh independent missions and equal initial resources/unit statistics for both factions.
- Immediate construction payment, construction timing, real income and structure limits.
- Production prerequisites, all fourteen unit types including the supply truck, mine worker and haul truck, sequential queues, queue/army limits and destroyed-production interruption.
- Bounded group movement, coordinate conventions, A* obstacle avoidance, direct aerial routes and hold orders.
- Simultaneous damage plus cooldown, symmetric ammunition consumption, empty-ammo behavior and automatic defense.
- HQ attack, victory/defeat and terminal-state freeze; destruction/removal of ordinary buildings; direct structure-target orders that clear when the target falls.
- Perimeter wall-segment ring placement and the ten-segment cap.
- Drag-rectangle selection toggling only friendly units, line/wedge/flank formation destination distribution and enlarged-map movement bounds.
- Vehicle fuel burn, half-speed dry-pool crawling and supply-truck ammunition/fuel transfer near friendly units only.
- Mine economy: workers and haul trucks shuttle along each faction's dedicated haul road, mine the finite mixed deposit (2.5 s hauler / 3.5 s worker), carry a bundle home and deposit it into the faction pool; the mine pool depletes and the percentage label tracks it.
- Chokepoints: the river is impassable except at its three bridges, mountain walls block the outer fords, and every A* path crossing the field passes through a bridge band (asserted for four approach lanes).
- The first cross-faction engagement flips the contact flag; the AI builds infrastructure and an army but issues no attack orders before first contact; with contact set and a ready army it launches assaults.
- Hospital and engineer healing, timed paid research, finite industrial stock, paid repair and building upgrades.
- Paid AI training/building, autonomous construction and tactical-state changes without free reinforcement spawns.
- Sensor coverage and reconnaissance upgrades; finite-resource strategic capture.
- Full save round-trip, malformed/oversized/nonfinite/invalid-enum/duplicate-ID rejection.
- Deterministic, nonmutating simulation updates.

## Browser checks

Chromium was driven against the development app and the production HTML. Desktop and narrow-screen screenshots were visually inspected; no game JavaScript exceptions were observed during the final checks.

- Arabic briefing, English switch, mission start and actual connected game entry.
- Command/build/army/support panels, paid power/factory construction and infantry training.
- Multi-unit selection, ground movement, hold, enemy-HQ attack, pause/resume and simulation speeds.
- Research-center construction and completed paid weapons research through the actual UI.
- Actual save-file download, valid reimport, invalid-file rejection and unchanged game after rejection.
- Help, restart confirmation/cancellation and restart after a result.
- Victory and defeat dialogs tested with controlled valid save fixtures followed by real combat. This is not a claim of manually completing a natural campaign.
- Sound toggle state checked and synthesized sound code exercised. Physical speaker quality was not audited.
- Layout inspected at 1440 × 960 and 375 × 812; the narrow layout had no horizontal document overflow.
- The supplied game Playwright client completed two screenshot/state iterations without an errors output file after fixing the favicon request.
- A fresh browser context with networking disabled opened the production HTML through `file://`, started the Arabic mission and returned live game state. It made no HTTP/HTTPS requests and produced no JavaScript exceptions.

## Opponent smoke simulations

Since 0.5 the opponent never initiates hostilities, so a fully idle player no longer auto-loses: the AI expands, constructs and trains with paid systems but issues no assault until the first engagement between the two armies. Smoke simulations over 60 simulated seconds confirm base growth beyond the initial two structures with zero attack orders before contact, and assault waves after contact once the army is ready. These are smoke checks of behavior, not evidence of broad balance testing.

## Performance and limitations

Since 0.8 the game is 3D-only (WebGL): the restored Three.js scene renders the battlefield at 60 FPS, with a fallback notice if WebGL is unavailable. No claim is made of physical-phone compatibility or AAA visual quality.

Unit separation is implemented (0.5.2); full ballistic line-of-sight and a dynamic navigation mesh are not. Maps share one layout, and campaign/multiplayer are not implemented. See `FEATURE-STATUS.md` for all scope boundaries.

## Release packaging

The release script collects the portable HTML, source and built distribution, lockfile, tests, guides and dependency notices without `node_modules` or repository history.

- Python ZIP integrity validation passed.
- The archive was extracted into a separate verification directory.
- Its extracted `PLAY-IRON-FRONT.html` opened offline through `file://`, accepted select-all, advanced its simulation and built paid enemy infrastructure without JavaScript exceptions.
- `npm ci`, all 43 tests, TypeScript and the production build also passed inside the extracted `SOURCE` directory.
- Dependency license notices include the embedded Barlow Condensed and Noto Sans Arabic font licenses. The `three` dependency tree was removed with the 3D renderer in 0.5.2, so its warnings no longer appear.

## IRON-FRONT 0.10 combat response update

- Added attacker-specific automatic retaliation for player units: a unit that takes damage from a hostile unit locks onto that attacker and advances to engage it.
- Retaliation is strictly unit-to-unit and does not create HQ or building attack orders.
- Added regression coverage for retaliation target identity, movement toward the attacker, no automatic HQ assault, nearest visible hostile selection, lethal damage, unit removal, kill credit and shot feedback.
- Added a brief muzzle flash and expanding impact ring to the existing projectile tracer effect.
- Existing HP/damage/death, weapon cooldown, ammunition, nearest-in-range fire selection and health bars were already present in 0.9 and are retained.
- Existing player movement, selection, camera/touch controls and manual HQ/building attack orders are unchanged.
- Focused runtime checks and TypeScript checks for the combat/navigation modules passed locally. Full `npm test`, production build and APK build are being verified by the separate `iron-front-combat-1.0` GitHub Actions branch; they are not claimed complete until that run succeeds.
