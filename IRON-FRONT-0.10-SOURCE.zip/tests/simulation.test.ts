import test from 'node:test';
import assert from 'node:assert/strict';
import { newGame } from '../src/game/initialState';
import { advanceSeconds,stepGame } from '../src/game/simulation';
import { advanceProduction,recruit,repairBase,upgrade } from '../src/game/productionSystem';
import { advanceCombat,holdSelected,issueAttack,issueAttackBuilding,issueMove,selectInRect } from '../src/game/combatSystem';
import { advanceLogistics } from '../src/game/logistics';
import { queueBuilding,upgradeBuilding } from '../src/game/buildingSystem';
import { decodeSave,encodeSave } from '../src/game/saveSystem';
import { makeUnit,UNIT_SPECS } from '../src/game/unitSystem';
import { advanceAI } from '../src/game/aiSystem';
import { blocked,findPath,bridges } from '../src/game/navigation';
import { visibleTo } from '../src/game/visibility';
import type { BuildingKind,GameState } from '../src/game/types';

function withBuilding(state:GameState,kind:BuildingKind):GameState {
  const next=queueBuilding(state,kind);
  return {...next,buildings:next.buildings.map(b=>({...b,status:'active',remaining:0}))};
}
function isolated():GameState {
  const state=newGame();
  return {...state,units:state.units.filter(u=>u.faction==='player'),nextWave:9999,
    opponent:{...state.opponent,lastDecision:9999}};
}
test('fresh missions are independent and initial sides have identical resources and unit stats',()=>{
  const a=newGame(),b=newGame();a.resources.steel=0;assert.equal(b.resources.steel,1100);
  assert.deepEqual(b.resources,b.opponent.resources);
  assert.deepEqual(b.units.slice(0,3).map(u=>[u.kind,u.hp,u.damage]),b.units.slice(3).map(u=>[u.kind,u.hp,u.damage]));
});
test('construction deducts costs immediately, completes on time and produces real income',()=>{
  let state=queueBuilding(newGame(),'power');assert.equal(state.resources.steel,920);
  assert.equal(state.buildings.at(-1)?.status,'constructing');
  for(let i=0;i<120;i++){state=advanceProduction(state,.1);state={...state,tick:Math.round((state.tick+.1)*10)/10};}
  assert.equal(state.buildings.at(-1)?.status,'active');
  assert(state.resources.power>260);
});
test('unaffordable construction and structure limits cannot overspend',()=>{
  const state=newGame();state.resources.steel=0;
  const next=queueBuilding(state,'factory');assert.equal(next.buildings.length,2);assert.equal(next.resources.steel,0);
  let towers=newGame();towers.resources.steel=9999;
  for(let i=0;i<5;i++)towers=queueBuilding(towers,'watchtower');
  assert.equal(towers.buildings.filter(b=>b.kind==='watchtower').length,4);
});
test('recruitment has production prerequisites, exact payment and sequential training',()=>{
  let state=isolated();assert.equal(recruit(state,'tank').training.length,0);
  state=recruit(recruit(state,'infantry'),'infantry');
  assert.equal(state.training.length,2);assert.equal(state.resources.steel,920);
  state=advanceSeconds(state,6.1);assert.equal(state.units.length,4);assert.equal(state.training.length,1);
  assert(state.training[0].remaining>5.8);
});
test('training and research stop when their building is destroyed',()=>{
  let state=recruit(isolated(),'infantry');
  state={...state,buildings:state.buildings.filter(b=>b.kind!=='barracks')};
  const next=advanceSeconds(state,10);assert.equal(next.training[0].remaining,6);
});
test('recruitment caps queues and armies',()=>{
  let state=isolated();state.resources={steel:9999,fuel:9999,power:9999,ammo:9999};
  for(let i=0;i<9;i++)state=recruit(state,'infantry');assert.equal(state.training.length,5);
});
test('all fourteen unit types are connected to real production prerequisites',()=>{
  let state=isolated();state.resources={steel:99999,fuel:99999,power:99999,ammo:99999};
  for(const kind of ['factory','vehicleFactory','airfield'] as const)state=withBuilding(state,kind);
  for(const kind of Object.keys(UNIT_SPECS) as (keyof typeof UNIT_SPECS)[]){
    const next=recruit({...state,training:[]},kind);assert.equal(next.training[0].kind,kind);
  }
  const truck=makeUnit(50,'supply','player',0,0);
  assert.deepEqual(truck.cargo,{ammo:150,fuel:100});
});
test('movement is bounded, uses distinct formation destinations and correct x/z axes',()=>{
  let state=isolated();state.units=state.units.map(u=>({...u,selected:true}));
  state=issueMove(state,999,-999);
  assert(state.units.every(u=>u.targetX<=76&&u.targetZ>=-24));
  const before=state.units[0];state=advanceCombat(state,.1);
  assert.notEqual(state.units[0].x,before.x);
  assert.equal(issueMove(state,NaN,0),state);
});
test('A* avoids blocked structure/rock cells and aerial units take direct routes',()=>{
  const state=newGame();const unit=makeUnit(500,'infantry','player',1,-2);
  const path=findPath(state,unit,{x:10,z:-2});assert(path.length>2);
  assert(path.every(p=>!blocked(state,p)));
  assert.deepEqual(findPath(state,makeUnit(501,'drone','player',1,-2),{x:10,z:-2}),[{x:10,z:-2}]);
});
test('hold cancels movement and retains selection',()=>{
  let state=isolated();state.units[0].selected=true;state=holdSelected(issueMove(state,3,4));
  assert.equal(state.units[0].order,'idle');assert.equal(state.units[0].selected,true);
});
test('simultaneous fire applies both damage AND cooldown; ammunition is consumed symmetrically',()=>{
  let state=newGame();state.units=[makeUnit(1,'tank','player',0,0),makeUnit(101,'tank','enemy',2,0)];
  state=advanceCombat(state,.1);
  assert(state.units.every(u=>u.hp<u.maxHp&&u.cooldown>0));
  assert.equal(state.resources.ammo,357);assert.equal(state.opponent.resources.ammo,357);
  const health=state.units.map(u=>u.hp);state=advanceCombat(state,.1);
  assert.deepEqual(state.units.map(u=>u.hp),health);
});
test('weapons cannot fire without ammunition',()=>{
  let state=newGame();state.units=[makeUnit(1,'tank','player',0,0),makeUnit(101,'tank','enemy',2,0)];
  state.resources.ammo=0;state.opponent.resources.ammo=0;
  state=advanceCombat(state,.1);assert(state.units.every(u=>u.hp===u.maxHp));
});
test('idle units automatically defend against nearby visible enemies',()=>{
  let state=newGame();state.units=[makeUnit(1,'infantry','player',0,0),makeUnit(101,'infantry','enemy',2,0)];
  state=advanceCombat(state,.1);assert(state.units[1].hp<80);
});
test('attack HQ damages the base, victory freezes the entire simulation',()=>{
  let state=isolated();state.units=[{...makeUnit(1,'heavy','player',58,-3),selected:true}];
  state.opponent.buildings=state.opponent.buildings.filter(b=>b.kind==='hq');state.enemyHp=.1;
  state=stepGame(issueAttack(state,-1));assert.equal(state.phase,'victory');assert.equal(state.enemyHp,0);
  assert.equal(stepGame(state),state);
});
test('defeat occurs when enemy units destroy the friendly HQ',()=>{
  let state=isolated();state.units=[{...makeUnit(101,'heavy','enemy',-10,4),order:'attack',targetId:-2}];
  state.buildings=state.buildings.filter(b=>b.kind==='hq');state.baseHp=.1;
  state=stepGame(state);assert.equal(state.phase,'defeat');
});
test('ordinary enemy buildings can be destroyed and removed',()=>{
  let state=isolated();const target=state.opponent.buildings.find(b=>b.kind==='barracks')!;
  target.hp=.1;state.units=[{...makeUnit(1,'heavy','player',target.x-2,target.z),selected:true}];
  state=advanceCombat(issueAttack(state,-1),.1);
  assert(!state.opponent.buildings.some(b=>b.kind==='barracks'));
});
test('hospital restores nearby damaged units; engineer restores teammates',()=>{
  let state=withBuilding(isolated(),'hospital');state.units[0]={...state.units[0],x:-9,z:4,hp:30};
  const healed=advanceCombat(state,1);assert(healed.units[0].hp>30);
  state=isolated();state.units=[makeUnit(1,'engineer','player',0,0),{...makeUnit(2,'tank','player',1,0),hp:30}];
  assert(stepGame(state).units[1].hp>30);
});
test('research costs resources, takes time and applies a persistent technology',()=>{
  let state=withBuilding(isolated(),'research');state.resources={steel:9999,fuel:9999,power:9999,ammo:9999};
  state=upgrade(state,'weapons');assert.equal(state.technologies.weapons,0);assert.equal(state.resources.steel,9749);
  state=advanceSeconds(state,25.1);assert.equal(state.technologies.weapons,1);assert.equal(state.research,null);
});
test('industrial reserves are finite and cannot become negative',()=>{
  let state=isolated();state.reserve=3;
  state=advanceSeconds(state,5);assert.equal(state.reserve,0);assert.equal(state.resources.steel,1103);
});
test('enemy shares paid construction and training; there are no free reinforcement spawns',()=>{
  let state=newGame();state.tick=4;
  const before=state.opponent.resources.steel;state=advanceAI(state,.1);
  assert(state.opponent.resources.steel<before);
  assert(state.opponent.buildings.some(b=>b.status==='constructing'));
  state=newGame();state.tick=100;state.opponent.resources={steel:0,fuel:0,power:0,ammo:0};state.opponent.reserve=0;
  const count=state.units.length;state=advanceAI(state,.1);assert.equal(state.units.length,count);
  assert.equal(state.opponent.training.length,0);
});
test('AI builds, produces and changes strategy during an autonomous simulation',()=>{
  const state=advanceSeconds(newGame(),65);
  assert(state.opponent.buildings.length>2);
  assert(state.nextUnitId>104);
  assert(state.opponent.resources.steel<2000);
});
test('fog-of-war visibility is expanded by reconnaissance research',()=>{
  const state=isolated();state.units=[makeUnit(1,'infantry','player',0,0)];
  assert.equal(visibleTo(state,'player',{x:11,z:0}),false);
  state.technologies.recon=1;assert.equal(visibleTo(state,'player',{x:11,z:0}),true);
});
test('strategic depots capture after sustained presence and pay finite steel income',()=>{
  let state=isolated();state.units=[makeUnit(1,'infantry','player',23,-11)];
  state=advanceSeconds(state,12);assert.equal(state.zones[0].owner,'player');
  assert(state.zones[0].reserve<1500);
});
test('repair and building upgrades are paid and have tangible effects',()=>{
  let state=isolated();state.baseHp=50;
  state=repairBase(state);assert.equal(state.baseHp,80);assert.equal(state.resources.steel,980);
  state=upgradeBuilding(state,'BLD-000');assert.equal(state.buildings[1].level,2);
  assert.equal(state.buildings[1].status,'constructing');
});
test('save round trip includes opponent, orders, research and map settings',()=>{
  const state=advanceSeconds(newGame('snow','hard'),20);
  const loaded=decodeSave(encodeSave(state));
  assert.deepEqual(loaded,{...state,shots:[]});
});
test('save rejects corrupted, oversized, invalid enum, duplicate IDs and nonfinite input',()=>{
  const state=newGame(),data=JSON.parse(encodeSave(state));
  for(const text of ['not json','x'.repeat(500001),JSON.stringify({...data,version:9})])assert.throws(()=>decodeSave(text));
  data.state.units[0].kind='spaceship';assert.throws(()=>decodeSave(JSON.stringify(data)));
  data.state.units[0].kind='tank';data.state.units[1].id=1;assert.throws(()=>decodeSave(JSON.stringify(data)));
  data.state.units[1].id=2;data.state.resources.steel=null;assert.throws(()=>decodeSave(JSON.stringify(data)));
});
test('simulation is deterministic and does not mutate the input state',()=>{
  const first=newGame(),baseline=JSON.stringify(first),a=advanceSeconds(first,10),b=advanceSeconds(newGame(),10);
  assert.deepEqual(a,b);assert.equal(JSON.stringify(first),baseline);
});
test('barrier sections fill the perimeter ring and are capped at ten',()=>{
  let state=newGame();state.resources={steel:9999,fuel:9999,power:9999,ammo:9999};
  for(let i=0;i<12;i++)state=queueBuilding(state,'wall');
  const walls=state.buildings.filter(b=>b.kind==='wall');
  assert.equal(walls.length,10);
  // Segments sit on the fortress perimeter ring, not inside the building plots.
  assert(walls.every(w=>w.z<-2||w.z>10||Math.abs(w.x+24)<.1||Math.abs(w.x+1)<.1));
});
test('units directly target one enemy structure and clear the order when it falls',()=>{
  let state=isolated();
  state.opponent.buildings=[...state.opponent.buildings,
    {id:'EN-W1',kind:'wall',level:1,hp:220,maxHp:220,x:12,z:0,status:'active',remaining:0,buildSeconds:7}];
  state.units=[{...makeUnit(1,'heavy','player',8,0),selected:true}];
  state=issueAttackBuilding(state,'EN-W1');
  assert.equal(state.units[0].targetBld,'EN-W1');
  state=advanceCombat(state,.1);
  assert(state.opponent.buildings.find(b=>b.id==='EN-W1')!.hp<220);
  state={...state,opponent:{...state.opponent,buildings:state.opponent.buildings.map(b=>
    b.id==='EN-W1'?{...b,hp:.01}:b)}};
  // Wait out the weapon cooldown so the finishing shot is actually fired.
  state=advanceCombat(state,3);
  assert(!state.opponent.buildings.some(b=>b.id==='EN-W1'));
  state=advanceCombat(state,.1);
  assert.equal(state.units[0].order,'idle');
  assert.equal(state.units[0].targetBld??null,null);
});
test('attacking the enemy HQ by its building id routes to the HQ order',()=>{
  let state=isolated();state.units=[{...makeUnit(1,'tank','player',0,0),selected:true}];
  state=issueAttackBuilding(state,'EN-HQ');
  assert.equal(state.units[0].targetId,-1);
  assert.equal(state.units[0].targetBld??null,null);
});
test('drag-rectangle selection toggles only friendly units inside the box',()=>{
  const state=isolated();
  const next=selectInRect(state,{x1:-4,z1:2,x2:-2,z2:5},false);
  assert.equal(next.units.filter(u=>u.faction==='player'&&u.selected).length,2);
  assert(next.units.every(u=>u.faction==='enemy'?!u.selected:true));
  const shifted=selectInRect(state,{x1:-4,z1:2,x2:-2,z2:5},true);
  assert.equal(shifted.units.filter(u=>u.faction==='player'&&u.selected).length,2);
});
test('group movement distributes destinations per selected formation',()=>{
  let state=isolated();state.units=state.units.map(u=>({...u,selected:true}));
  const line=issueMove(state,5,5,'line'),wedge=issueMove(state,5,5,'wedge'),flank=issueMove(state,5,5,'flank');
  const key=(s:typeof line)=>JSON.stringify(s.units.map(u=>[u.targetX,u.targetZ]));
  assert.notEqual(key(line),key(wedge));assert.notEqual(key(line),key(flank));
  assert(line.units.every(u=>u.targetX<=76&&u.targetZ>=-24));
});
test('supply trucks transfer carried ammunition and fuel near friendly units only',()=>{
  let state=isolated();
  state.units=[makeUnit(1,'supply','player',0,0),makeUnit(2,'infantry','player',1,0)];
  const delivered=advanceLogistics(state,5);
  assert(delivered.resources.ammo>360);assert(delivered.resources.fuel>650);
  const truck=delivered.units.find(u=>u.id===1)!;
  assert(truck.cargo!.ammo<150);
  state=isolated();
  state.units=[makeUnit(1,'supply','player',0,0)];
  const parked=advanceLogistics(state,5);
  assert.equal(parked.resources.ammo,360);
});
test('moving vehicles burn fuel and crawl at half speed when the pool is dry',()=>{
  let state=isolated();
  state.units=[{...makeUnit(1,'tank','player',0,0),order:'move',targetX:10,targetZ:0,path:[]}];
  const before=state.resources.fuel;
  state=advanceCombat(state,1);
  assert(state.resources.fuel<before);
  const dry=isolated();
  dry.resources={...dry.resources,fuel:0};
  dry.units=[{...makeUnit(1,'tank','player',0,0),order:'move',targetX:10,targetZ:0,path:[]}];
  const crawled=advanceCombat(dry,1);
  assert(crawled.units[0].x>0&&crawled.units[0].x<1.4);
});
test('saves round-trip the new building-target and cargo fields',()=>{
  let state=isolated();
  state.opponent.buildings=[...state.opponent.buildings,
    {id:'EN-W2',kind:'wall',level:1,hp:220,maxHp:220,x:12,z:0,status:'active',remaining:0,buildSeconds:7}];
  state.units=[{...makeUnit(1,'supply','player',0,0),selected:true}];
  state=issueAttackBuilding(state,'EN-W2');
  const loaded=decodeSave(encodeSave(state));
  assert.equal(loaded.units[0].targetBld,'EN-W2');
  assert.deepEqual(loaded.units[0].cargo,{ammo:150,fuel:100});
});
test('the first cross-faction engagement flips the contact flag',()=>{
  let state=isolated();
  state.units=[makeUnit(1,'tank','player',0,0),makeUnit(101,'tank','enemy',2,0)];
  assert.equal(state.contact,false);
  state=advanceCombat(state,.1);
  assert.equal(state.contact,true);
});
test('the AI builds up its base and army but holds fire before the first engagement',()=>{
  let state=newGame();
  state=advanceSeconds(state,60);
  assert.equal(state.contact,false);
  assert(state.units.filter(u=>u.faction==='enemy').every(u=>u.order!=='attack'));
  assert(state.opponent.buildings.length>2);
});
test('after first contact the AI launches assaults once its army is ready',()=>{
  let state=isolated();
  state={...state,contact:true,tick:80,nextWave:70};
  state.units=[...state.units,
    {...makeUnit(201,'infantry','enemy',58,-2),order:'idle'},
    {...makeUnit(202,'infantry','enemy',57,-3),order:'idle'},
    {...makeUnit(203,'infantry','enemy',59,-5),order:'idle'},
    {...makeUnit(204,'infantry','enemy',56,-6),order:'idle'}];
  state=advanceAI({...state,opponent:{...state.opponent,lastDecision:0}},.1);
  assert(state.units.some(u=>u.faction==='enemy'&&u.order==='attack'));
});
test('trained reinforcements march to the rally flag instead of stacking',()=>{
  let state=isolated();
  const before=state.units.length;
  state=recruit(state,'infantry');
  state=advanceSeconds(state,7);
  assert.equal(state.units.length,before+1);
  const newest=state.units[state.units.length-1];
  assert.equal(newest.order,'move');
  assert(Math.hypot(newest.targetX-state.rally.x,newest.targetZ-state.rally.z)<2.5);
  state={...state,rally:{x:20,z:0}};
  state=recruit(state,'infantry');
  state=advanceSeconds(state,7);
  const second=state.units[state.units.length-1];
  assert(Math.hypot(second.targetX-20,second.targetZ)<2.5);
});
test('same-faction units standing on the same spot push apart',()=>{
  let state=isolated();
  state.units=[makeUnit(1,'infantry','player',0,0),makeUnit(2,'infantry','player',.2,0)];
  state=advanceCombat(state,1);
  const [a,b]=state.units;
  assert(Math.hypot(b.x-a.x,b.z-a.z)>.5);
});
test('the river is only crossable at its three bridges',()=>{
  const state=isolated();
  assert.equal(blocked(state,{x:32,z:-6}),true);
  assert.equal(blocked(state,{x:32,z:6}),true);
  assert.equal(blocked(state,{x:32,z:20}),true);
  for(const bz of [-12,0,12]){
    assert.equal(blocked(state,{x:32,z:bz}),false);
    assert.equal(blocked(state,{x:32,z:bz+2}),false);
  }
  // Mountain walls guard the outer fords so armies cannot slip around the bridges.
  assert.equal(blocked(state,{x:31,z:-19}),true);
  assert.equal(blocked(state,{x:31,z:19}),true);
});
test('armies crossing the field must funnel through a bridge',()=>{
  const state=isolated();
  for(const z of [-18,-6,6,18]){
    const unit=makeUnit(900,'tank','player',-4,z);
    const path=findPath(state,unit,{x:50,z});
    assert(path.length>0,'no path at z='+z);
    for(const p of path)if(Math.abs(p.x-32)<1.2)
      assert(bridges.some(b=>Math.abs(p.z-b.z)<2.2),'crossed the river off a bridge at z='+p.z);
  }
});
test('workers mine the rich deposit and haul the wealth home to the HQ',()=>{
  let state=isolated();
  const steelBefore=state.resources.steel;
  state.units=[...state.units.filter(u=>u.faction==='player'),makeUnit(50,'worker','player',6,-11)];
  state=advanceSeconds(state,3);
  assert.equal(state.units.find(u=>u.id===50)!.harvest?.phase,'mining');
  state=advanceSeconds(state,4);
  const loaded=state.units.find(u=>u.id===50)!;
  assert.equal(loaded.harvest?.phase,'toBase');
  assert.equal(state.mines[0].steel,7950);
  // The walk home follows the haul road; the bundle lands in the player's pool.
  state=advanceSeconds(state,22);
  assert(state.resources.steel>steelBefore);
  const pool=state.mines[0].steel+state.mines[0].fuel+state.mines[0].power+state.mines[0].ammo;
  assert(pool<17500);
});

test('player units automatically retaliate against the specific enemy unit that hits them',()=>{
  let state=isolated();
  const defender=makeUnit(1,'infantry','player',0,0);
  const attacker=makeUnit(101,'tank','enemy',4.5,0);
  state.units=[defender,attacker];
  const friendlyBase=state.baseHp,hostileBase=state.enemyHp;
  state=advanceCombat(state,.1);
  const returned=state.units.find(u=>u.id===1)!;
  assert.equal(returned.order,'attack');
  assert.equal(returned.targetId,101);
  assert.equal(returned.targetBld??null,null);
  assert.equal(state.baseHp,friendlyBase);
  assert.equal(state.enemyHp,hostileBase);
  const before=returned.x;
  state=advanceCombat(state,.1);
  assert(state.units.find(u=>u.id===1)!.x>before,'defender should close distance to the attacker');
});

test('being attacked does not make idle units march toward the enemy HQ',()=>{
  let state=isolated();
  state.units=[makeUnit(1,'infantry','player',0,0),makeUnit(101,'tank','enemy',4.5,0)];
  state=advanceCombat(state,.1);
  const defender=state.units.find(u=>u.id===1)!;
  assert.equal(defender.targetId,101);
  assert.notEqual(defender.targetId,-1);
  assert.equal(defender.targetBld??null,null);
});

test('automatic fire chooses the nearest visible hostile unit inside weapon range',()=>{
  let state=isolated();
  const shooter=makeUnit(1,'infantry','player',0,0);
  const nearest={...makeUnit(101,'infantry','enemy',2.5,0),cooldown:1};
  const farther={...makeUnit(102,'infantry','enemy',3.4,0),cooldown:1};
  state.units=[shooter,farther,nearest];
  state=advanceCombat(state,.1);
  assert(state.units.find(u=>u.id===101)!.hp<nearest.hp);
  assert.equal(state.units.find(u=>u.id===102)!.hp,farther.hp);
  assert(state.shots.some(s=>s.faction==='player'&&s.toX===nearest.x));
});

test('unit damage resolves into removal and kill credit with a visible shot effect',()=>{
  let state=isolated();
  state.units=[makeUnit(1,'heavy','player',0,0),{...makeUnit(101,'infantry','enemy',2,0),hp:1}];
  state=advanceCombat(state,.1);
  assert(!state.units.some(u=>u.id===101));
  assert.equal(state.kills,1);
  assert(state.shots.some(s=>s.faction==='player'&&s.toX===2));
});
